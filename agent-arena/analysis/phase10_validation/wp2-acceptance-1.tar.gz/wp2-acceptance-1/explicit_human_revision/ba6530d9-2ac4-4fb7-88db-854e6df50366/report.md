# Canonical local audit

## Execution and release

READY&#95;FOR&#95;RELEASE — local artifact status

RECORDED OFFLINE / SYNTHETIC. Local artifact decision only; no live model execution, scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | completed |
| local release | READY&#95;FOR&#95;RELEASE |
| mandatory review | false |
| review execution | not&#95;executed |
| review route | AUTO&#95;RESOLVABLE |
| scientific judgment | supported |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T17&#58;59&#58;18.347567+00&#58;00 |
| parent / manifest fingerprint | b495b4fd4fc04f14eea73d72b5809112b8a10f04a30c0c52e2e96b17397f7e37 |
| parent / revision id | 9e63dd84-7f9d-40d4-83e5-4c5b9099f3ac |
| record fingerprint | 56769738b0ab1e07ef899f2f91300f6b2683eef76ab60cfd908605a4cdef3876 |
| revision | ba6530d9-2ac4-4fb7-88db-854e6df50366 |
| selected position id | p9position&#58;9475726f54c2d3f598eaaea0 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
intervention X reduces event Q in adults.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | supported |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | supported |
| contract version | AA-P8/1.0 |
| derived label | solid |
| input sha256 | d405ae6768246618b95a4d04eedcd9b6222fd78b607a902ace3a2e9ef0bebc71 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0 |
| record fingerprint | 3e4b5fd9192394ce9a4fb8753007c9167f65dd211a06bd3390e080a8a3982d99 |
| technical status | completed |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | single&#95;source |
|  / 1 / derived state | supported |
|  / 1 / evidence ids | e1 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
|  / 1 / reported verdict | supported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | solid |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | Generic represented core-error analysis |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks. |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | solid |
| taxonomy check / reasons | Honest reporting with supported represented propositions |
| taxonomy check / technical status | completed |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | offline extraction from supplied prompt and context |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | origin |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | single&#95;source |
| derived judgment / derived state | supported |
| derived judgment / evidence ids | e1 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | species<br>population<br>intervention<br>comparator<br>endpoint<br>endpoint&#95;type<br>relation<br>follow&#95;up<br>certainty<br>comparison |
| materiality | required |
| parent claim id | claim |
| proposition id | claim&#58;p1 |
| provenance id | origin |
| reason | Source reports the stated comparison |
| reported verdict | supported |
| search question | What evidence supports&#58; intervention X reduces event Q in adults. |
| search scope ids | review |

Quoted proposition; this is represented input, not a release assertion.

```
intervention X reduces event Q in adults.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 41 |
| start | 0 |
| text | intervention X reduces event Q in adults. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | placebo |
| comparison | between |
| endpoint | event Q |
| endpoint type | clinical&#95;event |
| follow up | 12 weeks |
| intervention | intervention X |
| population | adults |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Matching trial |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation extraction

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | extraction |

### Transformation search&#95;question

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | intervention X reduces event Q in adults. |
| reason | Meaning retained |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | What evidence supports&#58; intervention X reduces event Q in adults. |
| transformation id | search&#95;question |

### Transformation internal

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | internal |

### Transformation summary

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | summary |
| target id | client1 |
| transformation id | summary |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | event Q |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | asserted |
| attributes / comparator | placebo |
| attributes / comparison | between |
| attributes / endpoint | event Q |
| attributes / endpoint type | clinical&#95;event |
| attributes / follow up | 12 weeks |
| attributes / intervention | intervention X |
| attributes / population | adults |
| attributes / relation | causal |
| attributes / species | human |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| randomized | true |
| source role | primary&#95;study |
| study id | synthetic-study-1 |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | review |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | intervention X reduces event Q in adults. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | origin |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | intervention X reduces event Q in adults. |
|  / 1 / provenance id | origin |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | client1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | intervention X reduces event Q in adults. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | origin |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| final position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| mandatory | false |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | adjudicated |
| route | AUTO&#95;RESOLVABLE |
| technical status | completed |
| uncertainty | p9position&#58;ce90a3ec23ee364d485a3239/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| fingerprint | 9b905c5c27de5fcbb7eb2e7fefbd3f511e3a7173cd5f859095796784da5328ff |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| reference | record.json&#35;/run&#95;record |
| route | AUTO&#95;RESOLVABLE |
| technical status | completed |

### Position p9position&#58;ce90a3ec23ee364d485a3239

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | offline-recording-no-live-model |
| origin | original |
| original model label | solid |
| position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| provider | offline-recording-no-live-model |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 13c0f2cf642485c81585fd8b089f36713c16094ee668e6bbdd563105bf975a76 |
| run id | 3d66f54b-0caf-4b32-9492-3a463eec6792 |
| scientific state | unknown |
| selected | false |
| taxonomy status | completed |
| technical status | completed |

### Position judgments and uncertainty

| Field | Recorded value |
| --- | --- |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| propositions / 1 / dependency status | single&#95;source |
| propositions / 1 / derived state | unknown |
| propositions / 1 / evidence ids | e1 |
| propositions / 1 / proposition id | claim&#58;p1 |
| propositions / 1 / reasons | Source reports the stated comparison<br>Recorded fixture&#58; study design is unresolved.<br>b1&#58; Matching trial<br>unresolved relation or evidence capability<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred<br>reported scientific UNKNOWN retained; guards cannot resolve it |
| propositions / 1 / reported verdict | unknown |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0 |
| transformation findings | No entries recorded |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

### Position p9position&#58;9475726f54c2d3f598eaaea0

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/1 |
| derived taxonomy | solid |
| model |  |
| origin | human&#95;correction |
| original model label | solid |
| position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| provider | host&#95;human&#95;submission |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/1/agent&#95;result/raw&#95;output |
| raw sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| run id | 3d66f54b-0caf-4b32-9492-3a463eec6792&#58;correction&#58;1 |
| scientific state | supported |
| selected | true |
| taxonomy status | completed |
| technical status | completed |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;490cad954a31d46a88fb6d51 |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| positions / 1 / value / 1 / attributes / certainty | asserted |
| positions / 1 / value / 1 / attributes / comparator | placebo |
| positions / 1 / value / 1 / attributes / comparison | between |
| positions / 1 / value / 1 / attributes / dose | Not supplied |
| positions / 1 / value / 1 / attributes / effect basis | Not supplied |
| positions / 1 / value / 1 / attributes / effect direction | Not supplied |
| positions / 1 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 1 / attributes / endpoint | event Q |
| positions / 1 / value / 1 / attributes / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / attributes / follow up | 12 weeks |
| positions / 1 / value / 1 / attributes / formulation | Not supplied |
| positions / 1 / value / 1 / attributes / intervention | intervention X |
| positions / 1 / value / 1 / attributes / population | adults |
| positions / 1 / value / 1 / attributes / relation | causal |
| positions / 1 / value / 1 / attributes / route | Not supplied |
| positions / 1 / value / 1 / attributes / species | human |
| positions / 1 / value / 1 / cohort id | Not supplied |
| positions / 1 / value / 1 / dataset id | Not supplied |
| positions / 1 / value / 1 / design limitations | No entries recorded |
| positions / 1 / value / 1 / evidence id | e1 |
| positions / 1 / value / 1 / evidence type | controlled&#95;intervention |
| positions / 1 / value / 1 / identification argument | Not supplied |
| positions / 1 / value / 1 / identification evidence ids | No entries recorded |
| positions / 1 / value / 1 / randomized | true |
| positions / 1 / value / 1 / source role | primary&#95;study |
| positions / 1 / value / 1 / study id | synthetic-study-1 |
| positions / 1 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| positions / 2 / value / 1 / attributes / certainty | asserted |
| positions / 2 / value / 1 / attributes / comparator | placebo |
| positions / 2 / value / 1 / attributes / comparison | between |
| positions / 2 / value / 1 / attributes / dose | Not supplied |
| positions / 2 / value / 1 / attributes / effect basis | Not supplied |
| positions / 2 / value / 1 / attributes / effect direction | Not supplied |
| positions / 2 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 1 / attributes / endpoint | event Q |
| positions / 2 / value / 1 / attributes / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / attributes / follow up | 12 weeks |
| positions / 2 / value / 1 / attributes / formulation | Not supplied |
| positions / 2 / value / 1 / attributes / intervention | intervention X |
| positions / 2 / value / 1 / attributes / population | adults |
| positions / 2 / value / 1 / attributes / relation | causal |
| positions / 2 / value / 1 / attributes / route | Not supplied |
| positions / 2 / value / 1 / attributes / species | human |
| positions / 2 / value / 1 / cohort id | Not supplied |
| positions / 2 / value / 1 / dataset id | Not supplied |
| positions / 2 / value / 1 / design limitations | No entries recorded |
| positions / 2 / value / 1 / evidence id | e1 |
| positions / 2 / value / 1 / evidence type | unknown |
| positions / 2 / value / 1 / identification argument | Not supplied |
| positions / 2 / value / 1 / identification evidence ids | No entries recorded |
| positions / 2 / value / 1 / randomized | Not supplied |
| positions / 2 / value / 1 / source role | primary&#95;study |
| positions / 2 / value / 1 / study id | synthetic-study-1 |
| positions / 2 / value / 1 / underlying evidence ids | No entries recorded |
| projected object fingerprint | d09d87bcb2d4923102d19454da335171e349748976882903821c7976d13c7515 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;52616ef0335cc18014b1422e |
| field | propositions.claim&#58;p1.output&#95;transformations |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| positions / 1 / value / 1 / 1 | extraction |
| positions / 1 / value / 1 / 2 / certainty | asserted |
| positions / 1 / value / 1 / 2 / comparator | placebo |
| positions / 1 / value / 1 / 2 / comparison | between |
| positions / 1 / value / 1 / 2 / dose | Not supplied |
| positions / 1 / value / 1 / 2 / effect basis | Not supplied |
| positions / 1 / value / 1 / 2 / effect direction | Not supplied |
| positions / 1 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 2 / endpoint | event Q |
| positions / 1 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 2 / follow up | 12 weeks |
| positions / 1 / value / 1 / 2 / formulation | Not supplied |
| positions / 1 / value / 1 / 2 / intervention | intervention X |
| positions / 1 / value / 1 / 2 / population | adults |
| positions / 1 / value / 1 / 2 / relation | causal |
| positions / 1 / value / 1 / 2 / route | Not supplied |
| positions / 1 / value / 1 / 2 / species | human |
| positions / 1 / value / 1 / 3 / certainty | asserted |
| positions / 1 / value / 1 / 3 / comparator | placebo |
| positions / 1 / value / 1 / 3 / comparison | between |
| positions / 1 / value / 1 / 3 / dose | Not supplied |
| positions / 1 / value / 1 / 3 / effect basis | Not supplied |
| positions / 1 / value / 1 / 3 / effect direction | Not supplied |
| positions / 1 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 3 / endpoint | event Q |
| positions / 1 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 3 / follow up | 12 weeks |
| positions / 1 / value / 1 / 3 / formulation | Not supplied |
| positions / 1 / value / 1 / 3 / intervention | intervention X |
| positions / 1 / value / 1 / 3 / population | adults |
| positions / 1 / value / 1 / 3 / relation | causal |
| positions / 1 / value / 1 / 3 / route | Not supplied |
| positions / 1 / value / 1 / 3 / species | human |
| positions / 1 / value / 1 / 4 | Not supplied |
| positions / 1 / value / 1 / 5 | false |
| positions / 1 / value / 2 / 1 | internal |
| positions / 1 / value / 2 / 2 / certainty | asserted |
| positions / 1 / value / 2 / 2 / comparator | placebo |
| positions / 1 / value / 2 / 2 / comparison | between |
| positions / 1 / value / 2 / 2 / dose | Not supplied |
| positions / 1 / value / 2 / 2 / effect basis | Not supplied |
| positions / 1 / value / 2 / 2 / effect direction | Not supplied |
| positions / 1 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 2 / endpoint | event Q |
| positions / 1 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 2 / follow up | 12 weeks |
| positions / 1 / value / 2 / 2 / formulation | Not supplied |
| positions / 1 / value / 2 / 2 / intervention | intervention X |
| positions / 1 / value / 2 / 2 / population | adults |
| positions / 1 / value / 2 / 2 / relation | causal |
| positions / 1 / value / 2 / 2 / route | Not supplied |
| positions / 1 / value / 2 / 2 / species | human |
| positions / 1 / value / 2 / 3 / certainty | asserted |
| positions / 1 / value / 2 / 3 / comparator | placebo |
| positions / 1 / value / 2 / 3 / comparison | between |
| positions / 1 / value / 2 / 3 / dose | Not supplied |
| positions / 1 / value / 2 / 3 / effect basis | Not supplied |
| positions / 1 / value / 2 / 3 / effect direction | Not supplied |
| positions / 1 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 3 / endpoint | event Q |
| positions / 1 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 3 / follow up | 12 weeks |
| positions / 1 / value / 2 / 3 / formulation | Not supplied |
| positions / 1 / value / 2 / 3 / intervention | intervention X |
| positions / 1 / value / 2 / 3 / population | adults |
| positions / 1 / value / 2 / 3 / relation | causal |
| positions / 1 / value / 2 / 3 / route | Not supplied |
| positions / 1 / value / 2 / 3 / species | human |
| positions / 1 / value / 2 / 4 | Not supplied |
| positions / 1 / value / 2 / 5 | false |
| positions / 1 / value / 3 / 1 | search&#95;question |
| positions / 1 / value / 3 / 2 / certainty | asserted |
| positions / 1 / value / 3 / 2 / comparator | placebo |
| positions / 1 / value / 3 / 2 / comparison | between |
| positions / 1 / value / 3 / 2 / dose | Not supplied |
| positions / 1 / value / 3 / 2 / effect basis | Not supplied |
| positions / 1 / value / 3 / 2 / effect direction | Not supplied |
| positions / 1 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 2 / endpoint | event Q |
| positions / 1 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 2 / follow up | 12 weeks |
| positions / 1 / value / 3 / 2 / formulation | Not supplied |
| positions / 1 / value / 3 / 2 / intervention | intervention X |
| positions / 1 / value / 3 / 2 / population | adults |
| positions / 1 / value / 3 / 2 / relation | causal |
| positions / 1 / value / 3 / 2 / route | Not supplied |
| positions / 1 / value / 3 / 2 / species | human |
| positions / 1 / value / 3 / 3 / certainty | asserted |
| positions / 1 / value / 3 / 3 / comparator | placebo |
| positions / 1 / value / 3 / 3 / comparison | between |
| positions / 1 / value / 3 / 3 / dose | Not supplied |
| positions / 1 / value / 3 / 3 / effect basis | Not supplied |
| positions / 1 / value / 3 / 3 / effect direction | Not supplied |
| positions / 1 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 3 / endpoint | event Q |
| positions / 1 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 3 / follow up | 12 weeks |
| positions / 1 / value / 3 / 3 / formulation | Not supplied |
| positions / 1 / value / 3 / 3 / intervention | intervention X |
| positions / 1 / value / 3 / 3 / population | adults |
| positions / 1 / value / 3 / 3 / relation | causal |
| positions / 1 / value / 3 / 3 / route | Not supplied |
| positions / 1 / value / 3 / 3 / species | human |
| positions / 1 / value / 3 / 4 | Not supplied |
| positions / 1 / value / 3 / 5 | false |
| positions / 1 / value / 4 / 1 | summary |
| positions / 1 / value / 4 / 2 / certainty | asserted |
| positions / 1 / value / 4 / 2 / comparator | placebo |
| positions / 1 / value / 4 / 2 / comparison | between |
| positions / 1 / value / 4 / 2 / dose | Not supplied |
| positions / 1 / value / 4 / 2 / effect basis | Not supplied |
| positions / 1 / value / 4 / 2 / effect direction | Not supplied |
| positions / 1 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 2 / endpoint | event Q |
| positions / 1 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 2 / follow up | 12 weeks |
| positions / 1 / value / 4 / 2 / formulation | Not supplied |
| positions / 1 / value / 4 / 2 / intervention | intervention X |
| positions / 1 / value / 4 / 2 / population | adults |
| positions / 1 / value / 4 / 2 / relation | causal |
| positions / 1 / value / 4 / 2 / route | Not supplied |
| positions / 1 / value / 4 / 2 / species | human |
| positions / 1 / value / 4 / 3 / certainty | asserted |
| positions / 1 / value / 4 / 3 / comparator | placebo |
| positions / 1 / value / 4 / 3 / comparison | between |
| positions / 1 / value / 4 / 3 / dose | Not supplied |
| positions / 1 / value / 4 / 3 / effect basis | Not supplied |
| positions / 1 / value / 4 / 3 / effect direction | Not supplied |
| positions / 1 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 3 / endpoint | event Q |
| positions / 1 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 3 / follow up | 12 weeks |
| positions / 1 / value / 4 / 3 / formulation | Not supplied |
| positions / 1 / value / 4 / 3 / intervention | intervention X |
| positions / 1 / value / 4 / 3 / population | adults |
| positions / 1 / value / 4 / 3 / relation | causal |
| positions / 1 / value / 4 / 3 / route | Not supplied |
| positions / 1 / value / 4 / 3 / species | human |
| positions / 1 / value / 4 / 4 | supported |
| positions / 1 / value / 4 / 5 | true |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| positions / 2 / value / 1 / 1 | extraction |
| positions / 2 / value / 1 / 2 / certainty | asserted |
| positions / 2 / value / 1 / 2 / comparator | placebo |
| positions / 2 / value / 1 / 2 / comparison | between |
| positions / 2 / value / 1 / 2 / dose | Not supplied |
| positions / 2 / value / 1 / 2 / effect basis | Not supplied |
| positions / 2 / value / 1 / 2 / effect direction | Not supplied |
| positions / 2 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 2 / endpoint | event Q |
| positions / 2 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 2 / follow up | 12 weeks |
| positions / 2 / value / 1 / 2 / formulation | Not supplied |
| positions / 2 / value / 1 / 2 / intervention | intervention X |
| positions / 2 / value / 1 / 2 / population | adults |
| positions / 2 / value / 1 / 2 / relation | causal |
| positions / 2 / value / 1 / 2 / route | Not supplied |
| positions / 2 / value / 1 / 2 / species | human |
| positions / 2 / value / 1 / 3 / certainty | asserted |
| positions / 2 / value / 1 / 3 / comparator | placebo |
| positions / 2 / value / 1 / 3 / comparison | between |
| positions / 2 / value / 1 / 3 / dose | Not supplied |
| positions / 2 / value / 1 / 3 / effect basis | Not supplied |
| positions / 2 / value / 1 / 3 / effect direction | Not supplied |
| positions / 2 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 3 / endpoint | event Q |
| positions / 2 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 3 / follow up | 12 weeks |
| positions / 2 / value / 1 / 3 / formulation | Not supplied |
| positions / 2 / value / 1 / 3 / intervention | intervention X |
| positions / 2 / value / 1 / 3 / population | adults |
| positions / 2 / value / 1 / 3 / relation | causal |
| positions / 2 / value / 1 / 3 / route | Not supplied |
| positions / 2 / value / 1 / 3 / species | human |
| positions / 2 / value / 1 / 4 | Not supplied |
| positions / 2 / value / 1 / 5 | false |
| positions / 2 / value / 2 / 1 | internal |
| positions / 2 / value / 2 / 2 / certainty | asserted |
| positions / 2 / value / 2 / 2 / comparator | placebo |
| positions / 2 / value / 2 / 2 / comparison | between |
| positions / 2 / value / 2 / 2 / dose | Not supplied |
| positions / 2 / value / 2 / 2 / effect basis | Not supplied |
| positions / 2 / value / 2 / 2 / effect direction | Not supplied |
| positions / 2 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 2 / endpoint | event Q |
| positions / 2 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 2 / follow up | 12 weeks |
| positions / 2 / value / 2 / 2 / formulation | Not supplied |
| positions / 2 / value / 2 / 2 / intervention | intervention X |
| positions / 2 / value / 2 / 2 / population | adults |
| positions / 2 / value / 2 / 2 / relation | causal |
| positions / 2 / value / 2 / 2 / route | Not supplied |
| positions / 2 / value / 2 / 2 / species | human |
| positions / 2 / value / 2 / 3 / certainty | asserted |
| positions / 2 / value / 2 / 3 / comparator | placebo |
| positions / 2 / value / 2 / 3 / comparison | between |
| positions / 2 / value / 2 / 3 / dose | Not supplied |
| positions / 2 / value / 2 / 3 / effect basis | Not supplied |
| positions / 2 / value / 2 / 3 / effect direction | Not supplied |
| positions / 2 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 3 / endpoint | event Q |
| positions / 2 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 3 / follow up | 12 weeks |
| positions / 2 / value / 2 / 3 / formulation | Not supplied |
| positions / 2 / value / 2 / 3 / intervention | intervention X |
| positions / 2 / value / 2 / 3 / population | adults |
| positions / 2 / value / 2 / 3 / relation | causal |
| positions / 2 / value / 2 / 3 / route | Not supplied |
| positions / 2 / value / 2 / 3 / species | human |
| positions / 2 / value / 2 / 4 | Not supplied |
| positions / 2 / value / 2 / 5 | false |
| positions / 2 / value / 3 / 1 | search&#95;question |
| positions / 2 / value / 3 / 2 / certainty | asserted |
| positions / 2 / value / 3 / 2 / comparator | placebo |
| positions / 2 / value / 3 / 2 / comparison | between |
| positions / 2 / value / 3 / 2 / dose | Not supplied |
| positions / 2 / value / 3 / 2 / effect basis | Not supplied |
| positions / 2 / value / 3 / 2 / effect direction | Not supplied |
| positions / 2 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 2 / endpoint | event Q |
| positions / 2 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 2 / follow up | 12 weeks |
| positions / 2 / value / 3 / 2 / formulation | Not supplied |
| positions / 2 / value / 3 / 2 / intervention | intervention X |
| positions / 2 / value / 3 / 2 / population | adults |
| positions / 2 / value / 3 / 2 / relation | causal |
| positions / 2 / value / 3 / 2 / route | Not supplied |
| positions / 2 / value / 3 / 2 / species | human |
| positions / 2 / value / 3 / 3 / certainty | asserted |
| positions / 2 / value / 3 / 3 / comparator | placebo |
| positions / 2 / value / 3 / 3 / comparison | between |
| positions / 2 / value / 3 / 3 / dose | Not supplied |
| positions / 2 / value / 3 / 3 / effect basis | Not supplied |
| positions / 2 / value / 3 / 3 / effect direction | Not supplied |
| positions / 2 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 3 / endpoint | event Q |
| positions / 2 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 3 / follow up | 12 weeks |
| positions / 2 / value / 3 / 3 / formulation | Not supplied |
| positions / 2 / value / 3 / 3 / intervention | intervention X |
| positions / 2 / value / 3 / 3 / population | adults |
| positions / 2 / value / 3 / 3 / relation | causal |
| positions / 2 / value / 3 / 3 / route | Not supplied |
| positions / 2 / value / 3 / 3 / species | human |
| positions / 2 / value / 3 / 4 | Not supplied |
| positions / 2 / value / 3 / 5 | false |
| positions / 2 / value / 4 / 1 | summary |
| positions / 2 / value / 4 / 2 / certainty | asserted |
| positions / 2 / value / 4 / 2 / comparator | placebo |
| positions / 2 / value / 4 / 2 / comparison | between |
| positions / 2 / value / 4 / 2 / dose | Not supplied |
| positions / 2 / value / 4 / 2 / effect basis | Not supplied |
| positions / 2 / value / 4 / 2 / effect direction | Not supplied |
| positions / 2 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 2 / endpoint | event Q |
| positions / 2 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 2 / follow up | 12 weeks |
| positions / 2 / value / 4 / 2 / formulation | Not supplied |
| positions / 2 / value / 4 / 2 / intervention | intervention X |
| positions / 2 / value / 4 / 2 / population | adults |
| positions / 2 / value / 4 / 2 / relation | causal |
| positions / 2 / value / 4 / 2 / route | Not supplied |
| positions / 2 / value / 4 / 2 / species | human |
| positions / 2 / value / 4 / 3 / certainty | asserted |
| positions / 2 / value / 4 / 3 / comparator | placebo |
| positions / 2 / value / 4 / 3 / comparison | between |
| positions / 2 / value / 4 / 3 / dose | Not supplied |
| positions / 2 / value / 4 / 3 / effect basis | Not supplied |
| positions / 2 / value / 4 / 3 / effect direction | Not supplied |
| positions / 2 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 3 / endpoint | event Q |
| positions / 2 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 3 / follow up | 12 weeks |
| positions / 2 / value / 4 / 3 / formulation | Not supplied |
| positions / 2 / value / 4 / 3 / intervention | intervention X |
| positions / 2 / value / 4 / 3 / population | adults |
| positions / 2 / value / 4 / 3 / relation | causal |
| positions / 2 / value / 4 / 3 / route | Not supplied |
| positions / 2 / value / 4 / 3 / species | human |
| positions / 2 / value / 4 / 4 | unknown |
| positions / 2 / value / 4 / 5 | true |
| projected object fingerprint | a4daddf3d50133c79459d673c16a79226de93fdf0adbd512bda89dbdc19536a8 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| dimension | unknown |
| disagreement id | p9conflict&#58;8d674b2ef62cae7382fc9d90 |
| field | propositions.claim&#58;p1.derived&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| positions / 1 / value | supported |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| positions / 2 / value | unknown |
| projected object fingerprint | 795b1f291446af3f548cb1c2381d308b3ff7c1f97705615d953f37746ae326e2 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;a90a0e8e421bc2d006d4c1ee |
| field | phase8.derived&#95;label |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| positions / 1 / value | solid |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| positions / 2 / value | Not supplied |
| projected object fingerprint | a3b382725cb859b7bc2d460ba1f1b133fbbd085d7d9572ab03a71ca91626d4dc |
| proposition ids | No entries recorded |
| provenance | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| dimension | composite |
| disagreement id | p9conflict&#58;cffd1c8cfaa7eada1243b38a |
| field | phase8.composite&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| positions / 1 / value | supported |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| positions / 2 / value | unknown |
| projected object fingerprint | 34b45bd4491501857f3ca0a61ec6f09394f988f1dd30d2a0fda77f03161f7145 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| code | composite&#95;conflict |
| evidence ids | e1 |
| field | phase8.composite&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| projected object fingerprint | c77ce8216f0425210d270d739b4be3f64799d96b7be92360d2bf173d7fe6b074 |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |
| trigger id | p9trigger&#58;3730f35a82f6181031fba43b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| code | label&#95;conflict |
| evidence ids | e1 |
| field | phase8.derived&#95;label |
| mandatory | true |
| material | true |
| position ids | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| projected object fingerprint | 6f8b8bc05b2d1348967e26bbd3335377281e15bf30cf2b7459d30c2cd1e5633b |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |
| trigger id | p9trigger&#58;813ba9caf9d038f162936391 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| code | unknown&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| projected object fingerprint | 562fc091b94612107ba4a0f11d3770524caeab1f97210b955ca5cf1274ed867d |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |
| trigger id | p9trigger&#58;98b7b171ada99f430e2762e0 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ce90a3ec23ee364d485a3239 |
| projected object fingerprint | dae4a675d7b887d5ea86fd330977cc1840666d93707e1bda23f70f91a34365ca |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |
| trigger id | p9trigger&#58;9b6d8bbe955a9cd34355b7d6 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.output&#95;transformations |
| mandatory | true |
| material | true |
| position ids | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| projected object fingerprint | 22aca17fabd8338c11feeb6ea188565815f53aa6ce94941aa3e34f8a5eacfe5b |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |
| trigger id | p9trigger&#58;e56176b954421a3c8e1bcdcb |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| mandatory | true |
| material | true |
| position ids | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| projected object fingerprint | 8a46b7a4c111447f54630b28cf68ed8fbfca2cf99c9e7e3160e134f2f701dba5 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |
| trigger id | p9trigger&#58;fe60a39e7172716a22d66bbd |

### Adjudication

| Field | Recorded value |
| --- | --- |
| adjudication id | p9decision&#58;91b30f66ff31ba3b5cb00b5a |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| claim id | claim |
| code version | f5203a273d198f966303f68c6e39b48a17697fa4230181079a71e1c61ec08004 |
| conflict ids | p9conflict&#58;490cad954a31d46a88fb6d51<br>p9conflict&#58;52616ef0335cc18014b1422e<br>p9conflict&#58;8d674b2ef62cae7382fc9d90<br>p9conflict&#58;a90a0e8e421bc2d006d4c1ee<br>p9conflict&#58;cffd1c8cfaa7eada1243b38a |
| conflict types | composite<br>evidence<br>label<br>proposition<br>unknown |
| contract version | AA-P9/1.0 |
| corrected parent position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| evidence ids | e1 |
| independence | Explicit host-submitted human adjudication; provenance is not identity authentication. |
| origin | host&#95;human&#95;submission |
| original decisions / 1 / derived label | Not supplied |
| original decisions / 1 / original model label | solid |
| original decisions / 1 / position id | p9position&#58;ce90a3ec23ee364d485a3239 |
| original decisions / 1 / raw sha256 | 13c0f2cf642485c81585fd8b089f36713c16094ee668e6bbdd563105bf975a76 |
| original decisions / 1 / scientific state | unknown |
| original decisions / 1 / technical status | completed |
| original position ids | p9position&#58;ce90a3ec23ee364d485a3239 |
| outcome | resolved |
| position binding reference | record.json&#35;/run&#95;record/adjudications/0/position&#95;fingerprints |
| position ids | p9position&#58;9475726f54c2d3f598eaaea0<br>p9position&#58;ce90a3ec23ee364d485a3239 |
| projected object fingerprint | c53f6809844e01d1d6bc76634e4f6759c29892a5fc84e6b96305722cbe004fbb |
| proposition ids | claim&#58;p1 |
| reason | Bound correction resolves study design from supplied source |
| review decision / derived label | solid |
| review decision / original model label | solid |
| review decision / position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| review decision / raw sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| review decision / scientific state | supported |
| review decision / technical status | completed |
| reviewer provenance | Explicit offline acceptance adjudicator |
| reviewer type | human |
| run id | 3d66f54b-0caf-4b32-9492-3a463eec6792&#58;correction&#58;1 |
| selected position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| source reference | record.json&#35;/run&#95;record (recomputed current assessment) |
| timestamp | 2026-10-10T17&#58;59&#58;18.175262+00&#58;00 |

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and offline configuration bound |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 1f14fa67603d82b8ae0005af927a57b487cf8335f8c1ef295e0eb79e0d1dc641 |
| case id | p9case&#58;7ccab726b74fce3f789c0fff |
| code / code fingerprint | 245990c4139ad2be4bdf16c07004e9ad672456a1b796d500abdd6a0ac6045f17 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 72 |
| code / source binding | installed bytes only; no verified tracked-source claim |
| code / verified source commit | Not supplied |
| config | offline-recording-v1 |
| contract | AA-P10/1.0 |
| evidence fingerprint | cea4af84c8fff4b5d9a8b2b09054e1cfe5ed96a978fae1752f5027d2f1dfea08 |
| input fingerprint | 0cadda17a4feb445ef9f8ce4cb05391f5eab8239b9cd6460b5ec2245cfc2f5f2 |
| ledger fingerprint | b82403260c8afdbc7d321ff53a22693ef1741414b800847a3cc61936a1b22e56 |
| package version | 0.1.0 |
| phase8 summary / composite state | supported |
| phase8 summary / derived label | solid |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | completed |
| phase8 summary / technical status | completed |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | p9position&#58;9475726f54c2d3f598eaaea0 |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | false |
| phase9 summary / review state | adjudicated |
| phase9 summary / route | AUTO&#95;RESOLVABLE |
| phase9 summary / technical status | completed |
| providers / 1 / model | offline-recording-no-live-model |
| providers / 1 / provider | offline-recording-no-live-model |
| providers / 1 / usage | Not supplied |
| recording notice | RECORDED OFFLINE / SYNTHETIC; no live model execution |
| review counts / adjudications | 1 |
| review counts / attempts | 0 |
| review counts / conflicts | 5 |
| review counts / positions | 2 |
| review fingerprint | 9b905c5c27de5fcbb7eb2e7fefbd3f511e3a7173cd5f859095796784da5328ff |
| run id | 3d66f54b-0caf-4b32-9492-3a463eec6792 |
| selected position id | p9position&#58;9475726f54c2d3f598eaaea0 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

