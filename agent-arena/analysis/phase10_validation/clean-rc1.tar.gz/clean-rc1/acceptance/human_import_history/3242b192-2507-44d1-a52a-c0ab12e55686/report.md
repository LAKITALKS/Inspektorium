# Canonical local audit

## Execution and release

READY&#95;FOR&#95;RELEASE — local artifact status

RECORDED OFFLINE / SYNTHETIC. Local artifact decision only; no live model execution, scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | completed |
| local release | READY&#95;FOR&#95;RELEASE |
| mandatory review | false |
| review execution | completed |
| review route | AUTO&#95;RESOLVABLE |
| scientific judgment | supported |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T18&#58;14&#58;54.960411+00&#58;00 |
| parent | Not supplied |
| record fingerprint | c6146ce040f17dd35a0e7ad05c3addefc5d1b573bcafa72395e2293434382023 |
| revision | 3242b192-2507-44d1-a52a-c0ab12e55686 |
| selected position id | p9position&#58;34ec1bd1dedf82c107b6f771 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
intervention X reduces event Q in adults.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | supported |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | supported |
| contract version | AA-P8/1.0 |
| derived label | solid |
| input sha256 | d405ae6768246618b95a4d04eedcd9b6222fd78b607a902ace3a2e9ef0bebc71 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0 |
| record fingerprint | 3e4b5fd9192394ce9a4fb8753007c9167f65dd211a06bd3390e080a8a3982d99 |
| technical status | completed |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | single&#95;source |
|  / 1 / derived state | supported |
|  / 1 / evidence ids | e1 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
|  / 1 / reported verdict | supported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | solid |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | Generic represented core-error analysis |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks. |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | solid |
| taxonomy check / reasons | Honest reporting with supported represented propositions |
| taxonomy check / technical status | completed |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | offline extraction from supplied prompt and context |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | origin |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | single&#95;source |
| derived judgment / derived state | supported |
| derived judgment / evidence ids | e1 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | species<br>population<br>intervention<br>comparator<br>endpoint<br>endpoint&#95;type<br>relation<br>follow&#95;up<br>certainty<br>comparison |
| materiality | required |
| parent claim id | claim |
| proposition id | claim&#58;p1 |
| provenance id | origin |
| reason | Source reports the stated comparison |
| reported verdict | supported |
| search question | What evidence supports&#58; intervention X reduces event Q in adults. |
| search scope ids | review |

Quoted proposition; this is represented input, not a release assertion.

```
intervention X reduces event Q in adults.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 41 |
| start | 0 |
| text | intervention X reduces event Q in adults. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | placebo |
| comparison | between |
| endpoint | event Q |
| endpoint type | clinical&#95;event |
| follow up | 12 weeks |
| intervention | intervention X |
| population | adults |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Matching trial |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation extraction

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | extraction |

### Transformation search&#95;question

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | intervention X reduces event Q in adults. |
| reason | Meaning retained |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | What evidence supports&#58; intervention X reduces event Q in adults. |
| transformation id | search&#95;question |

### Transformation internal

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | internal |

### Transformation summary

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | summary |
| target id | client1 |
| transformation id | summary |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | event Q |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | asserted |
| attributes / comparator | placebo |
| attributes / comparison | between |
| attributes / endpoint | event Q |
| attributes / endpoint type | clinical&#95;event |
| attributes / follow up | 12 weeks |
| attributes / intervention | intervention X |
| attributes / population | adults |
| attributes / relation | causal |
| attributes / species | human |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| randomized | true |
| source role | primary&#95;study |
| study id | synthetic-study-1 |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | review |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | intervention X reduces event Q in adults. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | origin |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | intervention X reduces event Q in adults. |
|  / 1 / provenance id | origin |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | client1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | intervention X reduces event Q in adults. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | origin |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| contract version | AA-P9/1.0 |
| execution status | completed |
| final position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| mandatory | false |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | adjudicated |
| route | AUTO&#95;RESOLVABLE |
| technical status | completed |
| uncertainty | p9position&#58;26a9a744a0b0e32c48368e76/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | b5a8e0a8d7f8c654601cc0d4f4ec159f40c560d6a70271097483ee669c6db8eb |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | AUTO&#95;RESOLVABLE |
| source reference | record.json&#35;/run&#95;record |
| technical status | completed |

### Position p9position&#58;34ec1bd1dedf82c107b6f771

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | solid |
| model | offline-recording-no-live-model |
| origin | original |
| original model label | solid |
| position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| provider | offline-recording-no-live-model |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| run id | acceptance-conflict |
| scientific state | supported |
| selected | true |
| taxonomy status | completed |
| technical status | completed |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

### Position p9position&#58;d856c532e1d999df7f6458a7

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/1 |
| derived taxonomy | overclaim |
| model | offline-recording-no-live-model |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;d856c532e1d999df7f6458a7 |
| provider | offline-recording-no-live-model |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/1/agent&#95;result/raw&#95;output |
| raw sha256 | 60b459914871cc5da49895b02eddc0c1d577b3a6fdd72ef0e9f4c21bbc33e371 |
| run id | acceptance-conflict |
| scientific state | contradicted |
| selected | false |
| taxonomy status | completed |
| technical status | completed |

### Position judgments and uncertainty

| Field | Recorded value |
| --- | --- |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| propositions / 1 / dependency status | single&#95;source |
| propositions / 1 / derived state | contradicted |
| propositions / 1 / evidence ids | e1 |
| propositions / 1 / proposition id | claim&#58;p1 |
| propositions / 1 / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>relevant capable contradictory evidence<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| propositions / 1 / reported verdict | contradicted |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0 |
| transformation findings | No entries recorded |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

### Position p9position&#58;26a9a744a0b0e32c48368e76

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/2 |
| derived taxonomy | Not supplied |
| model | offline-recording-no-live-model |
| origin | model&#95;review |
| original model label | solid |
| position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| provider | offline-recording-no-live-model |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/2/agent&#95;result/raw&#95;output |
| raw sha256 | 13c0f2cf642485c81585fd8b089f36713c16094ee668e6bbdd563105bf975a76 |
| run id | acceptance-conflict&#58;counterreview |
| scientific state | unknown |
| selected | false |
| taxonomy status | completed |
| technical status | completed |

### Position judgments and uncertainty

| Field | Recorded value |
| --- | --- |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| propositions / 1 / dependency status | single&#95;source |
| propositions / 1 / derived state | unknown |
| propositions / 1 / evidence ids | e1 |
| propositions / 1 / proposition id | claim&#58;p1 |
| propositions / 1 / reasons | Source reports the stated comparison<br>Recorded fixture&#58; study design is unresolved.<br>b1&#58; Matching trial<br>unresolved relation or evidence capability<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred<br>reported scientific UNKNOWN retained; guards cannot resolve it |
| propositions / 1 / reported verdict | unknown |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0 |
| transformation findings | No entries recorded |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;0e342dc2de027b778c463210 |
| field | phase8.derived&#95;label |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value | Not supplied |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | overclaim |
| projected object fingerprint | 970a3e427f53c42f3deb35cca26e1d441df5eaae0b3e5d61282e009cf37db120 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/0 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;1d219692b09ae7b73ab66818 |
| field | phase8.original&#95;model&#95;label |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value | solid |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | overclaim |
| projected object fingerprint | 3a6d340d329a0b0f585fc195e2a84bdf10277054ac1dddf5bcdc0c01544f309a |
| proposition ids | No entries recorded |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/1 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;1f38e70ec8d311ea6b5f86fb |
| field | propositions.claim&#58;p1.selected&#95;source&#95;objects |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 1 / value / 1 | e1<br>context<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>supporting |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value / 1 | e1<br>context<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>contradictory |
| projected object fingerprint | ceb7c1f62d579fb3413eb23291acc85b1a553b7d941e91f08d81c0602b6e3285 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/2 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;2dfb98b423a46e354d8a6591 |
| field | propositions.claim&#58;p1.selected&#95;source&#95;objects |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value / 1 | e1<br>context<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>supporting |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value / 1 | e1<br>context<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.<br>contradictory |
| projected object fingerprint | 8099e86743739710e4758cdd0b51ad7dc2eec1a37017b09f0fc1e0b8a8d8c093 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/3 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;437a5e84c002d90038affa7a |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value / 1 / attributes / certainty | asserted |
| positions / 1 / value / 1 / attributes / comparator | placebo |
| positions / 1 / value / 1 / attributes / comparison | between |
| positions / 1 / value / 1 / attributes / dose | Not supplied |
| positions / 1 / value / 1 / attributes / effect basis | Not supplied |
| positions / 1 / value / 1 / attributes / effect direction | Not supplied |
| positions / 1 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 1 / attributes / endpoint | event Q |
| positions / 1 / value / 1 / attributes / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / attributes / follow up | 12 weeks |
| positions / 1 / value / 1 / attributes / formulation | Not supplied |
| positions / 1 / value / 1 / attributes / intervention | intervention X |
| positions / 1 / value / 1 / attributes / population | adults |
| positions / 1 / value / 1 / attributes / relation | causal |
| positions / 1 / value / 1 / attributes / route | Not supplied |
| positions / 1 / value / 1 / attributes / species | human |
| positions / 1 / value / 1 / cohort id | Not supplied |
| positions / 1 / value / 1 / dataset id | Not supplied |
| positions / 1 / value / 1 / design limitations | No entries recorded |
| positions / 1 / value / 1 / evidence id | e1 |
| positions / 1 / value / 1 / evidence type | unknown |
| positions / 1 / value / 1 / identification argument | Not supplied |
| positions / 1 / value / 1 / identification evidence ids | No entries recorded |
| positions / 1 / value / 1 / randomized | Not supplied |
| positions / 1 / value / 1 / source role | primary&#95;study |
| positions / 1 / value / 1 / study id | synthetic-study-1 |
| positions / 1 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 2 / value / 1 / attributes / certainty | asserted |
| positions / 2 / value / 1 / attributes / comparator | placebo |
| positions / 2 / value / 1 / attributes / comparison | between |
| positions / 2 / value / 1 / attributes / dose | Not supplied |
| positions / 2 / value / 1 / attributes / effect basis | Not supplied |
| positions / 2 / value / 1 / attributes / effect direction | Not supplied |
| positions / 2 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 1 / attributes / endpoint | event Q |
| positions / 2 / value / 1 / attributes / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / attributes / follow up | 12 weeks |
| positions / 2 / value / 1 / attributes / formulation | Not supplied |
| positions / 2 / value / 1 / attributes / intervention | intervention X |
| positions / 2 / value / 1 / attributes / population | adults |
| positions / 2 / value / 1 / attributes / relation | causal |
| positions / 2 / value / 1 / attributes / route | Not supplied |
| positions / 2 / value / 1 / attributes / species | human |
| positions / 2 / value / 1 / cohort id | Not supplied |
| positions / 2 / value / 1 / dataset id | Not supplied |
| positions / 2 / value / 1 / design limitations | No entries recorded |
| positions / 2 / value / 1 / evidence id | e1 |
| positions / 2 / value / 1 / evidence type | controlled&#95;intervention |
| positions / 2 / value / 1 / identification argument | Not supplied |
| positions / 2 / value / 1 / identification evidence ids | No entries recorded |
| positions / 2 / value / 1 / randomized | true |
| positions / 2 / value / 1 / source role | primary&#95;study |
| positions / 2 / value / 1 / study id | synthetic-study-1 |
| positions / 2 / value / 1 / underlying evidence ids | No entries recorded |
| projected object fingerprint | 42643be0239c2777423571cd703a1fcc8d69ce53f5ff1f508ad361a4ed273096 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/4 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | composite |
| disagreement id | p9conflict&#58;4ec77e9889693870d71fae46 |
| field | phase8.composite&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 1 / value | supported |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | contradicted |
| projected object fingerprint | 0ab0e206ecb2fd0cb4303d424b73f9d171e1173f3e4210b0b10b0bbbe2e2df04 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/5 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;613eab30e8107a8b31dac2bf |
| field | propositions.claim&#58;p1.output&#95;transformations |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value / 1 / 1 | extraction |
| positions / 1 / value / 1 / 2 / certainty | asserted |
| positions / 1 / value / 1 / 2 / comparator | placebo |
| positions / 1 / value / 1 / 2 / comparison | between |
| positions / 1 / value / 1 / 2 / dose | Not supplied |
| positions / 1 / value / 1 / 2 / effect basis | Not supplied |
| positions / 1 / value / 1 / 2 / effect direction | Not supplied |
| positions / 1 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 2 / endpoint | event Q |
| positions / 1 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 2 / follow up | 12 weeks |
| positions / 1 / value / 1 / 2 / formulation | Not supplied |
| positions / 1 / value / 1 / 2 / intervention | intervention X |
| positions / 1 / value / 1 / 2 / population | adults |
| positions / 1 / value / 1 / 2 / relation | causal |
| positions / 1 / value / 1 / 2 / route | Not supplied |
| positions / 1 / value / 1 / 2 / species | human |
| positions / 1 / value / 1 / 3 / certainty | asserted |
| positions / 1 / value / 1 / 3 / comparator | placebo |
| positions / 1 / value / 1 / 3 / comparison | between |
| positions / 1 / value / 1 / 3 / dose | Not supplied |
| positions / 1 / value / 1 / 3 / effect basis | Not supplied |
| positions / 1 / value / 1 / 3 / effect direction | Not supplied |
| positions / 1 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 3 / endpoint | event Q |
| positions / 1 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 3 / follow up | 12 weeks |
| positions / 1 / value / 1 / 3 / formulation | Not supplied |
| positions / 1 / value / 1 / 3 / intervention | intervention X |
| positions / 1 / value / 1 / 3 / population | adults |
| positions / 1 / value / 1 / 3 / relation | causal |
| positions / 1 / value / 1 / 3 / route | Not supplied |
| positions / 1 / value / 1 / 3 / species | human |
| positions / 1 / value / 1 / 4 | Not supplied |
| positions / 1 / value / 1 / 5 | false |
| positions / 1 / value / 2 / 1 | internal |
| positions / 1 / value / 2 / 2 / certainty | asserted |
| positions / 1 / value / 2 / 2 / comparator | placebo |
| positions / 1 / value / 2 / 2 / comparison | between |
| positions / 1 / value / 2 / 2 / dose | Not supplied |
| positions / 1 / value / 2 / 2 / effect basis | Not supplied |
| positions / 1 / value / 2 / 2 / effect direction | Not supplied |
| positions / 1 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 2 / endpoint | event Q |
| positions / 1 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 2 / follow up | 12 weeks |
| positions / 1 / value / 2 / 2 / formulation | Not supplied |
| positions / 1 / value / 2 / 2 / intervention | intervention X |
| positions / 1 / value / 2 / 2 / population | adults |
| positions / 1 / value / 2 / 2 / relation | causal |
| positions / 1 / value / 2 / 2 / route | Not supplied |
| positions / 1 / value / 2 / 2 / species | human |
| positions / 1 / value / 2 / 3 / certainty | asserted |
| positions / 1 / value / 2 / 3 / comparator | placebo |
| positions / 1 / value / 2 / 3 / comparison | between |
| positions / 1 / value / 2 / 3 / dose | Not supplied |
| positions / 1 / value / 2 / 3 / effect basis | Not supplied |
| positions / 1 / value / 2 / 3 / effect direction | Not supplied |
| positions / 1 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 3 / endpoint | event Q |
| positions / 1 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 3 / follow up | 12 weeks |
| positions / 1 / value / 2 / 3 / formulation | Not supplied |
| positions / 1 / value / 2 / 3 / intervention | intervention X |
| positions / 1 / value / 2 / 3 / population | adults |
| positions / 1 / value / 2 / 3 / relation | causal |
| positions / 1 / value / 2 / 3 / route | Not supplied |
| positions / 1 / value / 2 / 3 / species | human |
| positions / 1 / value / 2 / 4 | Not supplied |
| positions / 1 / value / 2 / 5 | false |
| positions / 1 / value / 3 / 1 | search&#95;question |
| positions / 1 / value / 3 / 2 / certainty | asserted |
| positions / 1 / value / 3 / 2 / comparator | placebo |
| positions / 1 / value / 3 / 2 / comparison | between |
| positions / 1 / value / 3 / 2 / dose | Not supplied |
| positions / 1 / value / 3 / 2 / effect basis | Not supplied |
| positions / 1 / value / 3 / 2 / effect direction | Not supplied |
| positions / 1 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 2 / endpoint | event Q |
| positions / 1 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 2 / follow up | 12 weeks |
| positions / 1 / value / 3 / 2 / formulation | Not supplied |
| positions / 1 / value / 3 / 2 / intervention | intervention X |
| positions / 1 / value / 3 / 2 / population | adults |
| positions / 1 / value / 3 / 2 / relation | causal |
| positions / 1 / value / 3 / 2 / route | Not supplied |
| positions / 1 / value / 3 / 2 / species | human |
| positions / 1 / value / 3 / 3 / certainty | asserted |
| positions / 1 / value / 3 / 3 / comparator | placebo |
| positions / 1 / value / 3 / 3 / comparison | between |
| positions / 1 / value / 3 / 3 / dose | Not supplied |
| positions / 1 / value / 3 / 3 / effect basis | Not supplied |
| positions / 1 / value / 3 / 3 / effect direction | Not supplied |
| positions / 1 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 3 / endpoint | event Q |
| positions / 1 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 3 / follow up | 12 weeks |
| positions / 1 / value / 3 / 3 / formulation | Not supplied |
| positions / 1 / value / 3 / 3 / intervention | intervention X |
| positions / 1 / value / 3 / 3 / population | adults |
| positions / 1 / value / 3 / 3 / relation | causal |
| positions / 1 / value / 3 / 3 / route | Not supplied |
| positions / 1 / value / 3 / 3 / species | human |
| positions / 1 / value / 3 / 4 | Not supplied |
| positions / 1 / value / 3 / 5 | false |
| positions / 1 / value / 4 / 1 | summary |
| positions / 1 / value / 4 / 2 / certainty | asserted |
| positions / 1 / value / 4 / 2 / comparator | placebo |
| positions / 1 / value / 4 / 2 / comparison | between |
| positions / 1 / value / 4 / 2 / dose | Not supplied |
| positions / 1 / value / 4 / 2 / effect basis | Not supplied |
| positions / 1 / value / 4 / 2 / effect direction | Not supplied |
| positions / 1 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 2 / endpoint | event Q |
| positions / 1 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 2 / follow up | 12 weeks |
| positions / 1 / value / 4 / 2 / formulation | Not supplied |
| positions / 1 / value / 4 / 2 / intervention | intervention X |
| positions / 1 / value / 4 / 2 / population | adults |
| positions / 1 / value / 4 / 2 / relation | causal |
| positions / 1 / value / 4 / 2 / route | Not supplied |
| positions / 1 / value / 4 / 2 / species | human |
| positions / 1 / value / 4 / 3 / certainty | asserted |
| positions / 1 / value / 4 / 3 / comparator | placebo |
| positions / 1 / value / 4 / 3 / comparison | between |
| positions / 1 / value / 4 / 3 / dose | Not supplied |
| positions / 1 / value / 4 / 3 / effect basis | Not supplied |
| positions / 1 / value / 4 / 3 / effect direction | Not supplied |
| positions / 1 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 3 / endpoint | event Q |
| positions / 1 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 3 / follow up | 12 weeks |
| positions / 1 / value / 4 / 3 / formulation | Not supplied |
| positions / 1 / value / 4 / 3 / intervention | intervention X |
| positions / 1 / value / 4 / 3 / population | adults |
| positions / 1 / value / 4 / 3 / relation | causal |
| positions / 1 / value / 4 / 3 / route | Not supplied |
| positions / 1 / value / 4 / 3 / species | human |
| positions / 1 / value / 4 / 4 | unknown |
| positions / 1 / value / 4 / 5 | true |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value / 1 / 1 | extraction |
| positions / 2 / value / 1 / 2 / certainty | asserted |
| positions / 2 / value / 1 / 2 / comparator | placebo |
| positions / 2 / value / 1 / 2 / comparison | between |
| positions / 2 / value / 1 / 2 / dose | Not supplied |
| positions / 2 / value / 1 / 2 / effect basis | Not supplied |
| positions / 2 / value / 1 / 2 / effect direction | Not supplied |
| positions / 2 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 2 / endpoint | event Q |
| positions / 2 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 2 / follow up | 12 weeks |
| positions / 2 / value / 1 / 2 / formulation | Not supplied |
| positions / 2 / value / 1 / 2 / intervention | intervention X |
| positions / 2 / value / 1 / 2 / population | adults |
| positions / 2 / value / 1 / 2 / relation | causal |
| positions / 2 / value / 1 / 2 / route | Not supplied |
| positions / 2 / value / 1 / 2 / species | human |
| positions / 2 / value / 1 / 3 / certainty | asserted |
| positions / 2 / value / 1 / 3 / comparator | placebo |
| positions / 2 / value / 1 / 3 / comparison | between |
| positions / 2 / value / 1 / 3 / dose | Not supplied |
| positions / 2 / value / 1 / 3 / effect basis | Not supplied |
| positions / 2 / value / 1 / 3 / effect direction | Not supplied |
| positions / 2 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 3 / endpoint | event Q |
| positions / 2 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 3 / follow up | 12 weeks |
| positions / 2 / value / 1 / 3 / formulation | Not supplied |
| positions / 2 / value / 1 / 3 / intervention | intervention X |
| positions / 2 / value / 1 / 3 / population | adults |
| positions / 2 / value / 1 / 3 / relation | causal |
| positions / 2 / value / 1 / 3 / route | Not supplied |
| positions / 2 / value / 1 / 3 / species | human |
| positions / 2 / value / 1 / 4 | Not supplied |
| positions / 2 / value / 1 / 5 | false |
| positions / 2 / value / 2 / 1 | internal |
| positions / 2 / value / 2 / 2 / certainty | asserted |
| positions / 2 / value / 2 / 2 / comparator | placebo |
| positions / 2 / value / 2 / 2 / comparison | between |
| positions / 2 / value / 2 / 2 / dose | Not supplied |
| positions / 2 / value / 2 / 2 / effect basis | Not supplied |
| positions / 2 / value / 2 / 2 / effect direction | Not supplied |
| positions / 2 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 2 / endpoint | event Q |
| positions / 2 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 2 / follow up | 12 weeks |
| positions / 2 / value / 2 / 2 / formulation | Not supplied |
| positions / 2 / value / 2 / 2 / intervention | intervention X |
| positions / 2 / value / 2 / 2 / population | adults |
| positions / 2 / value / 2 / 2 / relation | causal |
| positions / 2 / value / 2 / 2 / route | Not supplied |
| positions / 2 / value / 2 / 2 / species | human |
| positions / 2 / value / 2 / 3 / certainty | asserted |
| positions / 2 / value / 2 / 3 / comparator | placebo |
| positions / 2 / value / 2 / 3 / comparison | between |
| positions / 2 / value / 2 / 3 / dose | Not supplied |
| positions / 2 / value / 2 / 3 / effect basis | Not supplied |
| positions / 2 / value / 2 / 3 / effect direction | Not supplied |
| positions / 2 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 3 / endpoint | event Q |
| positions / 2 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 3 / follow up | 12 weeks |
| positions / 2 / value / 2 / 3 / formulation | Not supplied |
| positions / 2 / value / 2 / 3 / intervention | intervention X |
| positions / 2 / value / 2 / 3 / population | adults |
| positions / 2 / value / 2 / 3 / relation | causal |
| positions / 2 / value / 2 / 3 / route | Not supplied |
| positions / 2 / value / 2 / 3 / species | human |
| positions / 2 / value / 2 / 4 | Not supplied |
| positions / 2 / value / 2 / 5 | false |
| positions / 2 / value / 3 / 1 | search&#95;question |
| positions / 2 / value / 3 / 2 / certainty | asserted |
| positions / 2 / value / 3 / 2 / comparator | placebo |
| positions / 2 / value / 3 / 2 / comparison | between |
| positions / 2 / value / 3 / 2 / dose | Not supplied |
| positions / 2 / value / 3 / 2 / effect basis | Not supplied |
| positions / 2 / value / 3 / 2 / effect direction | Not supplied |
| positions / 2 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 2 / endpoint | event Q |
| positions / 2 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 2 / follow up | 12 weeks |
| positions / 2 / value / 3 / 2 / formulation | Not supplied |
| positions / 2 / value / 3 / 2 / intervention | intervention X |
| positions / 2 / value / 3 / 2 / population | adults |
| positions / 2 / value / 3 / 2 / relation | causal |
| positions / 2 / value / 3 / 2 / route | Not supplied |
| positions / 2 / value / 3 / 2 / species | human |
| positions / 2 / value / 3 / 3 / certainty | asserted |
| positions / 2 / value / 3 / 3 / comparator | placebo |
| positions / 2 / value / 3 / 3 / comparison | between |
| positions / 2 / value / 3 / 3 / dose | Not supplied |
| positions / 2 / value / 3 / 3 / effect basis | Not supplied |
| positions / 2 / value / 3 / 3 / effect direction | Not supplied |
| positions / 2 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 3 / endpoint | event Q |
| positions / 2 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 3 / follow up | 12 weeks |
| positions / 2 / value / 3 / 3 / formulation | Not supplied |
| positions / 2 / value / 3 / 3 / intervention | intervention X |
| positions / 2 / value / 3 / 3 / population | adults |
| positions / 2 / value / 3 / 3 / relation | causal |
| positions / 2 / value / 3 / 3 / route | Not supplied |
| positions / 2 / value / 3 / 3 / species | human |
| positions / 2 / value / 3 / 4 | Not supplied |
| positions / 2 / value / 3 / 5 | false |
| positions / 2 / value / 4 / 1 | summary |
| positions / 2 / value / 4 / 2 / certainty | asserted |
| positions / 2 / value / 4 / 2 / comparator | placebo |
| positions / 2 / value / 4 / 2 / comparison | between |
| positions / 2 / value / 4 / 2 / dose | Not supplied |
| positions / 2 / value / 4 / 2 / effect basis | Not supplied |
| positions / 2 / value / 4 / 2 / effect direction | Not supplied |
| positions / 2 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 2 / endpoint | event Q |
| positions / 2 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 2 / follow up | 12 weeks |
| positions / 2 / value / 4 / 2 / formulation | Not supplied |
| positions / 2 / value / 4 / 2 / intervention | intervention X |
| positions / 2 / value / 4 / 2 / population | adults |
| positions / 2 / value / 4 / 2 / relation | causal |
| positions / 2 / value / 4 / 2 / route | Not supplied |
| positions / 2 / value / 4 / 2 / species | human |
| positions / 2 / value / 4 / 3 / certainty | asserted |
| positions / 2 / value / 4 / 3 / comparator | placebo |
| positions / 2 / value / 4 / 3 / comparison | between |
| positions / 2 / value / 4 / 3 / dose | Not supplied |
| positions / 2 / value / 4 / 3 / effect basis | Not supplied |
| positions / 2 / value / 4 / 3 / effect direction | Not supplied |
| positions / 2 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 3 / endpoint | event Q |
| positions / 2 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 3 / follow up | 12 weeks |
| positions / 2 / value / 4 / 3 / formulation | Not supplied |
| positions / 2 / value / 4 / 3 / intervention | intervention X |
| positions / 2 / value / 4 / 3 / population | adults |
| positions / 2 / value / 4 / 3 / relation | causal |
| positions / 2 / value / 4 / 3 / route | Not supplied |
| positions / 2 / value / 4 / 3 / species | human |
| positions / 2 / value / 4 / 4 | contradicted |
| positions / 2 / value / 4 / 5 | true |
| projected object fingerprint | 7546d508c44d263d8cb6765da672b178b45a2a4ef826f9fc74dd7d9c6854a79d |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/6 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;6a425db104fb02cd551b6d9b |
| field | phase8.original&#95;model&#95;label |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 1 / value | solid |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | overclaim |
| projected object fingerprint | b72223e706c399c30c0bc63f3bc6ecbf144bac12256ab7bc1ebc135933cb84b0 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/7 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;70bbfd60913badb70121317a |
| field | propositions.claim&#58;p1.derived&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 1 / value | supported |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | contradicted |
| projected object fingerprint | 830c568f8260f665e3863b920df4a19d4951d443065f6c7a9d4c04421d893fe9 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/8 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;8fcb754a57f3f1ce74efc84c |
| field | propositions.claim&#58;p1.output&#95;transformations |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value / 1 / 1 | extraction |
| positions / 1 / value / 1 / 2 / certainty | asserted |
| positions / 1 / value / 1 / 2 / comparator | placebo |
| positions / 1 / value / 1 / 2 / comparison | between |
| positions / 1 / value / 1 / 2 / dose | Not supplied |
| positions / 1 / value / 1 / 2 / effect basis | Not supplied |
| positions / 1 / value / 1 / 2 / effect direction | Not supplied |
| positions / 1 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 2 / endpoint | event Q |
| positions / 1 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 2 / follow up | 12 weeks |
| positions / 1 / value / 1 / 2 / formulation | Not supplied |
| positions / 1 / value / 1 / 2 / intervention | intervention X |
| positions / 1 / value / 1 / 2 / population | adults |
| positions / 1 / value / 1 / 2 / relation | causal |
| positions / 1 / value / 1 / 2 / route | Not supplied |
| positions / 1 / value / 1 / 2 / species | human |
| positions / 1 / value / 1 / 3 / certainty | asserted |
| positions / 1 / value / 1 / 3 / comparator | placebo |
| positions / 1 / value / 1 / 3 / comparison | between |
| positions / 1 / value / 1 / 3 / dose | Not supplied |
| positions / 1 / value / 1 / 3 / effect basis | Not supplied |
| positions / 1 / value / 1 / 3 / effect direction | Not supplied |
| positions / 1 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 3 / endpoint | event Q |
| positions / 1 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 3 / follow up | 12 weeks |
| positions / 1 / value / 1 / 3 / formulation | Not supplied |
| positions / 1 / value / 1 / 3 / intervention | intervention X |
| positions / 1 / value / 1 / 3 / population | adults |
| positions / 1 / value / 1 / 3 / relation | causal |
| positions / 1 / value / 1 / 3 / route | Not supplied |
| positions / 1 / value / 1 / 3 / species | human |
| positions / 1 / value / 1 / 4 | Not supplied |
| positions / 1 / value / 1 / 5 | false |
| positions / 1 / value / 2 / 1 | internal |
| positions / 1 / value / 2 / 2 / certainty | asserted |
| positions / 1 / value / 2 / 2 / comparator | placebo |
| positions / 1 / value / 2 / 2 / comparison | between |
| positions / 1 / value / 2 / 2 / dose | Not supplied |
| positions / 1 / value / 2 / 2 / effect basis | Not supplied |
| positions / 1 / value / 2 / 2 / effect direction | Not supplied |
| positions / 1 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 2 / endpoint | event Q |
| positions / 1 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 2 / follow up | 12 weeks |
| positions / 1 / value / 2 / 2 / formulation | Not supplied |
| positions / 1 / value / 2 / 2 / intervention | intervention X |
| positions / 1 / value / 2 / 2 / population | adults |
| positions / 1 / value / 2 / 2 / relation | causal |
| positions / 1 / value / 2 / 2 / route | Not supplied |
| positions / 1 / value / 2 / 2 / species | human |
| positions / 1 / value / 2 / 3 / certainty | asserted |
| positions / 1 / value / 2 / 3 / comparator | placebo |
| positions / 1 / value / 2 / 3 / comparison | between |
| positions / 1 / value / 2 / 3 / dose | Not supplied |
| positions / 1 / value / 2 / 3 / effect basis | Not supplied |
| positions / 1 / value / 2 / 3 / effect direction | Not supplied |
| positions / 1 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 3 / endpoint | event Q |
| positions / 1 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 3 / follow up | 12 weeks |
| positions / 1 / value / 2 / 3 / formulation | Not supplied |
| positions / 1 / value / 2 / 3 / intervention | intervention X |
| positions / 1 / value / 2 / 3 / population | adults |
| positions / 1 / value / 2 / 3 / relation | causal |
| positions / 1 / value / 2 / 3 / route | Not supplied |
| positions / 1 / value / 2 / 3 / species | human |
| positions / 1 / value / 2 / 4 | Not supplied |
| positions / 1 / value / 2 / 5 | false |
| positions / 1 / value / 3 / 1 | search&#95;question |
| positions / 1 / value / 3 / 2 / certainty | asserted |
| positions / 1 / value / 3 / 2 / comparator | placebo |
| positions / 1 / value / 3 / 2 / comparison | between |
| positions / 1 / value / 3 / 2 / dose | Not supplied |
| positions / 1 / value / 3 / 2 / effect basis | Not supplied |
| positions / 1 / value / 3 / 2 / effect direction | Not supplied |
| positions / 1 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 2 / endpoint | event Q |
| positions / 1 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 2 / follow up | 12 weeks |
| positions / 1 / value / 3 / 2 / formulation | Not supplied |
| positions / 1 / value / 3 / 2 / intervention | intervention X |
| positions / 1 / value / 3 / 2 / population | adults |
| positions / 1 / value / 3 / 2 / relation | causal |
| positions / 1 / value / 3 / 2 / route | Not supplied |
| positions / 1 / value / 3 / 2 / species | human |
| positions / 1 / value / 3 / 3 / certainty | asserted |
| positions / 1 / value / 3 / 3 / comparator | placebo |
| positions / 1 / value / 3 / 3 / comparison | between |
| positions / 1 / value / 3 / 3 / dose | Not supplied |
| positions / 1 / value / 3 / 3 / effect basis | Not supplied |
| positions / 1 / value / 3 / 3 / effect direction | Not supplied |
| positions / 1 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 3 / endpoint | event Q |
| positions / 1 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 3 / follow up | 12 weeks |
| positions / 1 / value / 3 / 3 / formulation | Not supplied |
| positions / 1 / value / 3 / 3 / intervention | intervention X |
| positions / 1 / value / 3 / 3 / population | adults |
| positions / 1 / value / 3 / 3 / relation | causal |
| positions / 1 / value / 3 / 3 / route | Not supplied |
| positions / 1 / value / 3 / 3 / species | human |
| positions / 1 / value / 3 / 4 | Not supplied |
| positions / 1 / value / 3 / 5 | false |
| positions / 1 / value / 4 / 1 | summary |
| positions / 1 / value / 4 / 2 / certainty | asserted |
| positions / 1 / value / 4 / 2 / comparator | placebo |
| positions / 1 / value / 4 / 2 / comparison | between |
| positions / 1 / value / 4 / 2 / dose | Not supplied |
| positions / 1 / value / 4 / 2 / effect basis | Not supplied |
| positions / 1 / value / 4 / 2 / effect direction | Not supplied |
| positions / 1 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 2 / endpoint | event Q |
| positions / 1 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 2 / follow up | 12 weeks |
| positions / 1 / value / 4 / 2 / formulation | Not supplied |
| positions / 1 / value / 4 / 2 / intervention | intervention X |
| positions / 1 / value / 4 / 2 / population | adults |
| positions / 1 / value / 4 / 2 / relation | causal |
| positions / 1 / value / 4 / 2 / route | Not supplied |
| positions / 1 / value / 4 / 2 / species | human |
| positions / 1 / value / 4 / 3 / certainty | asserted |
| positions / 1 / value / 4 / 3 / comparator | placebo |
| positions / 1 / value / 4 / 3 / comparison | between |
| positions / 1 / value / 4 / 3 / dose | Not supplied |
| positions / 1 / value / 4 / 3 / effect basis | Not supplied |
| positions / 1 / value / 4 / 3 / effect direction | Not supplied |
| positions / 1 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 3 / endpoint | event Q |
| positions / 1 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 3 / follow up | 12 weeks |
| positions / 1 / value / 4 / 3 / formulation | Not supplied |
| positions / 1 / value / 4 / 3 / intervention | intervention X |
| positions / 1 / value / 4 / 3 / population | adults |
| positions / 1 / value / 4 / 3 / relation | causal |
| positions / 1 / value / 4 / 3 / route | Not supplied |
| positions / 1 / value / 4 / 3 / species | human |
| positions / 1 / value / 4 / 4 | unknown |
| positions / 1 / value / 4 / 5 | true |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 2 / value / 1 / 1 | extraction |
| positions / 2 / value / 1 / 2 / certainty | asserted |
| positions / 2 / value / 1 / 2 / comparator | placebo |
| positions / 2 / value / 1 / 2 / comparison | between |
| positions / 2 / value / 1 / 2 / dose | Not supplied |
| positions / 2 / value / 1 / 2 / effect basis | Not supplied |
| positions / 2 / value / 1 / 2 / effect direction | Not supplied |
| positions / 2 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 2 / endpoint | event Q |
| positions / 2 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 2 / follow up | 12 weeks |
| positions / 2 / value / 1 / 2 / formulation | Not supplied |
| positions / 2 / value / 1 / 2 / intervention | intervention X |
| positions / 2 / value / 1 / 2 / population | adults |
| positions / 2 / value / 1 / 2 / relation | causal |
| positions / 2 / value / 1 / 2 / route | Not supplied |
| positions / 2 / value / 1 / 2 / species | human |
| positions / 2 / value / 1 / 3 / certainty | asserted |
| positions / 2 / value / 1 / 3 / comparator | placebo |
| positions / 2 / value / 1 / 3 / comparison | between |
| positions / 2 / value / 1 / 3 / dose | Not supplied |
| positions / 2 / value / 1 / 3 / effect basis | Not supplied |
| positions / 2 / value / 1 / 3 / effect direction | Not supplied |
| positions / 2 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 3 / endpoint | event Q |
| positions / 2 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 3 / follow up | 12 weeks |
| positions / 2 / value / 1 / 3 / formulation | Not supplied |
| positions / 2 / value / 1 / 3 / intervention | intervention X |
| positions / 2 / value / 1 / 3 / population | adults |
| positions / 2 / value / 1 / 3 / relation | causal |
| positions / 2 / value / 1 / 3 / route | Not supplied |
| positions / 2 / value / 1 / 3 / species | human |
| positions / 2 / value / 1 / 4 | Not supplied |
| positions / 2 / value / 1 / 5 | false |
| positions / 2 / value / 2 / 1 | internal |
| positions / 2 / value / 2 / 2 / certainty | asserted |
| positions / 2 / value / 2 / 2 / comparator | placebo |
| positions / 2 / value / 2 / 2 / comparison | between |
| positions / 2 / value / 2 / 2 / dose | Not supplied |
| positions / 2 / value / 2 / 2 / effect basis | Not supplied |
| positions / 2 / value / 2 / 2 / effect direction | Not supplied |
| positions / 2 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 2 / endpoint | event Q |
| positions / 2 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 2 / follow up | 12 weeks |
| positions / 2 / value / 2 / 2 / formulation | Not supplied |
| positions / 2 / value / 2 / 2 / intervention | intervention X |
| positions / 2 / value / 2 / 2 / population | adults |
| positions / 2 / value / 2 / 2 / relation | causal |
| positions / 2 / value / 2 / 2 / route | Not supplied |
| positions / 2 / value / 2 / 2 / species | human |
| positions / 2 / value / 2 / 3 / certainty | asserted |
| positions / 2 / value / 2 / 3 / comparator | placebo |
| positions / 2 / value / 2 / 3 / comparison | between |
| positions / 2 / value / 2 / 3 / dose | Not supplied |
| positions / 2 / value / 2 / 3 / effect basis | Not supplied |
| positions / 2 / value / 2 / 3 / effect direction | Not supplied |
| positions / 2 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 3 / endpoint | event Q |
| positions / 2 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 3 / follow up | 12 weeks |
| positions / 2 / value / 2 / 3 / formulation | Not supplied |
| positions / 2 / value / 2 / 3 / intervention | intervention X |
| positions / 2 / value / 2 / 3 / population | adults |
| positions / 2 / value / 2 / 3 / relation | causal |
| positions / 2 / value / 2 / 3 / route | Not supplied |
| positions / 2 / value / 2 / 3 / species | human |
| positions / 2 / value / 2 / 4 | Not supplied |
| positions / 2 / value / 2 / 5 | false |
| positions / 2 / value / 3 / 1 | search&#95;question |
| positions / 2 / value / 3 / 2 / certainty | asserted |
| positions / 2 / value / 3 / 2 / comparator | placebo |
| positions / 2 / value / 3 / 2 / comparison | between |
| positions / 2 / value / 3 / 2 / dose | Not supplied |
| positions / 2 / value / 3 / 2 / effect basis | Not supplied |
| positions / 2 / value / 3 / 2 / effect direction | Not supplied |
| positions / 2 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 2 / endpoint | event Q |
| positions / 2 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 2 / follow up | 12 weeks |
| positions / 2 / value / 3 / 2 / formulation | Not supplied |
| positions / 2 / value / 3 / 2 / intervention | intervention X |
| positions / 2 / value / 3 / 2 / population | adults |
| positions / 2 / value / 3 / 2 / relation | causal |
| positions / 2 / value / 3 / 2 / route | Not supplied |
| positions / 2 / value / 3 / 2 / species | human |
| positions / 2 / value / 3 / 3 / certainty | asserted |
| positions / 2 / value / 3 / 3 / comparator | placebo |
| positions / 2 / value / 3 / 3 / comparison | between |
| positions / 2 / value / 3 / 3 / dose | Not supplied |
| positions / 2 / value / 3 / 3 / effect basis | Not supplied |
| positions / 2 / value / 3 / 3 / effect direction | Not supplied |
| positions / 2 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 3 / endpoint | event Q |
| positions / 2 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 3 / follow up | 12 weeks |
| positions / 2 / value / 3 / 3 / formulation | Not supplied |
| positions / 2 / value / 3 / 3 / intervention | intervention X |
| positions / 2 / value / 3 / 3 / population | adults |
| positions / 2 / value / 3 / 3 / relation | causal |
| positions / 2 / value / 3 / 3 / route | Not supplied |
| positions / 2 / value / 3 / 3 / species | human |
| positions / 2 / value / 3 / 4 | Not supplied |
| positions / 2 / value / 3 / 5 | false |
| positions / 2 / value / 4 / 1 | summary |
| positions / 2 / value / 4 / 2 / certainty | asserted |
| positions / 2 / value / 4 / 2 / comparator | placebo |
| positions / 2 / value / 4 / 2 / comparison | between |
| positions / 2 / value / 4 / 2 / dose | Not supplied |
| positions / 2 / value / 4 / 2 / effect basis | Not supplied |
| positions / 2 / value / 4 / 2 / effect direction | Not supplied |
| positions / 2 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 2 / endpoint | event Q |
| positions / 2 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 2 / follow up | 12 weeks |
| positions / 2 / value / 4 / 2 / formulation | Not supplied |
| positions / 2 / value / 4 / 2 / intervention | intervention X |
| positions / 2 / value / 4 / 2 / population | adults |
| positions / 2 / value / 4 / 2 / relation | causal |
| positions / 2 / value / 4 / 2 / route | Not supplied |
| positions / 2 / value / 4 / 2 / species | human |
| positions / 2 / value / 4 / 3 / certainty | asserted |
| positions / 2 / value / 4 / 3 / comparator | placebo |
| positions / 2 / value / 4 / 3 / comparison | between |
| positions / 2 / value / 4 / 3 / dose | Not supplied |
| positions / 2 / value / 4 / 3 / effect basis | Not supplied |
| positions / 2 / value / 4 / 3 / effect direction | Not supplied |
| positions / 2 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 3 / endpoint | event Q |
| positions / 2 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 3 / follow up | 12 weeks |
| positions / 2 / value / 4 / 3 / formulation | Not supplied |
| positions / 2 / value / 4 / 3 / intervention | intervention X |
| positions / 2 / value / 4 / 3 / population | adults |
| positions / 2 / value / 4 / 3 / relation | causal |
| positions / 2 / value / 4 / 3 / route | Not supplied |
| positions / 2 / value / 4 / 3 / species | human |
| positions / 2 / value / 4 / 4 | supported |
| positions / 2 / value / 4 / 5 | true |
| projected object fingerprint | 08458bfa6d17aff70663a3292c468b0c9d70de888bc7cb559fb8baeb6fca8129 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/9 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | unknown |
| disagreement id | p9conflict&#58;a383981a51587e3d22153ecf |
| field | propositions.claim&#58;p1.derived&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value | unknown |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 2 / value | supported |
| projected object fingerprint | 1043e51f4e6fb9921f120827892eeba7cc9bbece4121c873394325911015204e |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/10 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;b1dfc3bdcb146cdce9746104 |
| field | phase8.derived&#95;label |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 1 / value | solid |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | overclaim |
| projected object fingerprint | 7d6532351218c776385cec41ba6f95c4daf4b6d1a139392de8a48a58339fab74 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/11 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;b61379dcc19775c4e4fb6fb3 |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value / 1 | e1<br>support<br>direct |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value / 1 | e1<br>contradiction<br>direct |
| projected object fingerprint | 3ecd30abdb12dcbbe4c583837f2d81cfe6bf3cef008b5ca6d0ba65fa0f89b17b |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/12 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | composite |
| disagreement id | p9conflict&#58;b765a4fe6ede27cd58364209 |
| field | phase8.composite&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value | unknown |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | contradicted |
| projected object fingerprint | c97c2894bd12abaaeed123fba3bf1964e1e4183762aa0e3efc70d9b021ac78f7 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/13 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;c16a13b1194a453f5413cd85 |
| field | phase8.derived&#95;label |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value | Not supplied |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 2 / value | solid |
| projected object fingerprint | f1f7ca279e5ef26ede9c71bc35db58f7053c407f0deaf41f9014e06987742abd |
| proposition ids | No entries recorded |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/14 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;cf4ed5e7ccf5cc86b20c3cff |
| field | propositions.claim&#58;p1.output&#95;transformations |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 1 / value / 1 / 1 | extraction |
| positions / 1 / value / 1 / 2 / certainty | asserted |
| positions / 1 / value / 1 / 2 / comparator | placebo |
| positions / 1 / value / 1 / 2 / comparison | between |
| positions / 1 / value / 1 / 2 / dose | Not supplied |
| positions / 1 / value / 1 / 2 / effect basis | Not supplied |
| positions / 1 / value / 1 / 2 / effect direction | Not supplied |
| positions / 1 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 2 / endpoint | event Q |
| positions / 1 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 2 / follow up | 12 weeks |
| positions / 1 / value / 1 / 2 / formulation | Not supplied |
| positions / 1 / value / 1 / 2 / intervention | intervention X |
| positions / 1 / value / 1 / 2 / population | adults |
| positions / 1 / value / 1 / 2 / relation | causal |
| positions / 1 / value / 1 / 2 / route | Not supplied |
| positions / 1 / value / 1 / 2 / species | human |
| positions / 1 / value / 1 / 3 / certainty | asserted |
| positions / 1 / value / 1 / 3 / comparator | placebo |
| positions / 1 / value / 1 / 3 / comparison | between |
| positions / 1 / value / 1 / 3 / dose | Not supplied |
| positions / 1 / value / 1 / 3 / effect basis | Not supplied |
| positions / 1 / value / 1 / 3 / effect direction | Not supplied |
| positions / 1 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 3 / endpoint | event Q |
| positions / 1 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / 3 / follow up | 12 weeks |
| positions / 1 / value / 1 / 3 / formulation | Not supplied |
| positions / 1 / value / 1 / 3 / intervention | intervention X |
| positions / 1 / value / 1 / 3 / population | adults |
| positions / 1 / value / 1 / 3 / relation | causal |
| positions / 1 / value / 1 / 3 / route | Not supplied |
| positions / 1 / value / 1 / 3 / species | human |
| positions / 1 / value / 1 / 4 | Not supplied |
| positions / 1 / value / 1 / 5 | false |
| positions / 1 / value / 2 / 1 | internal |
| positions / 1 / value / 2 / 2 / certainty | asserted |
| positions / 1 / value / 2 / 2 / comparator | placebo |
| positions / 1 / value / 2 / 2 / comparison | between |
| positions / 1 / value / 2 / 2 / dose | Not supplied |
| positions / 1 / value / 2 / 2 / effect basis | Not supplied |
| positions / 1 / value / 2 / 2 / effect direction | Not supplied |
| positions / 1 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 2 / endpoint | event Q |
| positions / 1 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 2 / follow up | 12 weeks |
| positions / 1 / value / 2 / 2 / formulation | Not supplied |
| positions / 1 / value / 2 / 2 / intervention | intervention X |
| positions / 1 / value / 2 / 2 / population | adults |
| positions / 1 / value / 2 / 2 / relation | causal |
| positions / 1 / value / 2 / 2 / route | Not supplied |
| positions / 1 / value / 2 / 2 / species | human |
| positions / 1 / value / 2 / 3 / certainty | asserted |
| positions / 1 / value / 2 / 3 / comparator | placebo |
| positions / 1 / value / 2 / 3 / comparison | between |
| positions / 1 / value / 2 / 3 / dose | Not supplied |
| positions / 1 / value / 2 / 3 / effect basis | Not supplied |
| positions / 1 / value / 2 / 3 / effect direction | Not supplied |
| positions / 1 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 3 / endpoint | event Q |
| positions / 1 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 2 / 3 / follow up | 12 weeks |
| positions / 1 / value / 2 / 3 / formulation | Not supplied |
| positions / 1 / value / 2 / 3 / intervention | intervention X |
| positions / 1 / value / 2 / 3 / population | adults |
| positions / 1 / value / 2 / 3 / relation | causal |
| positions / 1 / value / 2 / 3 / route | Not supplied |
| positions / 1 / value / 2 / 3 / species | human |
| positions / 1 / value / 2 / 4 | Not supplied |
| positions / 1 / value / 2 / 5 | false |
| positions / 1 / value / 3 / 1 | search&#95;question |
| positions / 1 / value / 3 / 2 / certainty | asserted |
| positions / 1 / value / 3 / 2 / comparator | placebo |
| positions / 1 / value / 3 / 2 / comparison | between |
| positions / 1 / value / 3 / 2 / dose | Not supplied |
| positions / 1 / value / 3 / 2 / effect basis | Not supplied |
| positions / 1 / value / 3 / 2 / effect direction | Not supplied |
| positions / 1 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 2 / endpoint | event Q |
| positions / 1 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 2 / follow up | 12 weeks |
| positions / 1 / value / 3 / 2 / formulation | Not supplied |
| positions / 1 / value / 3 / 2 / intervention | intervention X |
| positions / 1 / value / 3 / 2 / population | adults |
| positions / 1 / value / 3 / 2 / relation | causal |
| positions / 1 / value / 3 / 2 / route | Not supplied |
| positions / 1 / value / 3 / 2 / species | human |
| positions / 1 / value / 3 / 3 / certainty | asserted |
| positions / 1 / value / 3 / 3 / comparator | placebo |
| positions / 1 / value / 3 / 3 / comparison | between |
| positions / 1 / value / 3 / 3 / dose | Not supplied |
| positions / 1 / value / 3 / 3 / effect basis | Not supplied |
| positions / 1 / value / 3 / 3 / effect direction | Not supplied |
| positions / 1 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 3 / endpoint | event Q |
| positions / 1 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 3 / 3 / follow up | 12 weeks |
| positions / 1 / value / 3 / 3 / formulation | Not supplied |
| positions / 1 / value / 3 / 3 / intervention | intervention X |
| positions / 1 / value / 3 / 3 / population | adults |
| positions / 1 / value / 3 / 3 / relation | causal |
| positions / 1 / value / 3 / 3 / route | Not supplied |
| positions / 1 / value / 3 / 3 / species | human |
| positions / 1 / value / 3 / 4 | Not supplied |
| positions / 1 / value / 3 / 5 | false |
| positions / 1 / value / 4 / 1 | summary |
| positions / 1 / value / 4 / 2 / certainty | asserted |
| positions / 1 / value / 4 / 2 / comparator | placebo |
| positions / 1 / value / 4 / 2 / comparison | between |
| positions / 1 / value / 4 / 2 / dose | Not supplied |
| positions / 1 / value / 4 / 2 / effect basis | Not supplied |
| positions / 1 / value / 4 / 2 / effect direction | Not supplied |
| positions / 1 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 2 / endpoint | event Q |
| positions / 1 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 2 / follow up | 12 weeks |
| positions / 1 / value / 4 / 2 / formulation | Not supplied |
| positions / 1 / value / 4 / 2 / intervention | intervention X |
| positions / 1 / value / 4 / 2 / population | adults |
| positions / 1 / value / 4 / 2 / relation | causal |
| positions / 1 / value / 4 / 2 / route | Not supplied |
| positions / 1 / value / 4 / 2 / species | human |
| positions / 1 / value / 4 / 3 / certainty | asserted |
| positions / 1 / value / 4 / 3 / comparator | placebo |
| positions / 1 / value / 4 / 3 / comparison | between |
| positions / 1 / value / 4 / 3 / dose | Not supplied |
| positions / 1 / value / 4 / 3 / effect basis | Not supplied |
| positions / 1 / value / 4 / 3 / effect direction | Not supplied |
| positions / 1 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 3 / endpoint | event Q |
| positions / 1 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 1 / value / 4 / 3 / follow up | 12 weeks |
| positions / 1 / value / 4 / 3 / formulation | Not supplied |
| positions / 1 / value / 4 / 3 / intervention | intervention X |
| positions / 1 / value / 4 / 3 / population | adults |
| positions / 1 / value / 4 / 3 / relation | causal |
| positions / 1 / value / 4 / 3 / route | Not supplied |
| positions / 1 / value / 4 / 3 / species | human |
| positions / 1 / value / 4 / 4 | supported |
| positions / 1 / value / 4 / 5 | true |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value / 1 / 1 | extraction |
| positions / 2 / value / 1 / 2 / certainty | asserted |
| positions / 2 / value / 1 / 2 / comparator | placebo |
| positions / 2 / value / 1 / 2 / comparison | between |
| positions / 2 / value / 1 / 2 / dose | Not supplied |
| positions / 2 / value / 1 / 2 / effect basis | Not supplied |
| positions / 2 / value / 1 / 2 / effect direction | Not supplied |
| positions / 2 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 2 / endpoint | event Q |
| positions / 2 / value / 1 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 2 / follow up | 12 weeks |
| positions / 2 / value / 1 / 2 / formulation | Not supplied |
| positions / 2 / value / 1 / 2 / intervention | intervention X |
| positions / 2 / value / 1 / 2 / population | adults |
| positions / 2 / value / 1 / 2 / relation | causal |
| positions / 2 / value / 1 / 2 / route | Not supplied |
| positions / 2 / value / 1 / 2 / species | human |
| positions / 2 / value / 1 / 3 / certainty | asserted |
| positions / 2 / value / 1 / 3 / comparator | placebo |
| positions / 2 / value / 1 / 3 / comparison | between |
| positions / 2 / value / 1 / 3 / dose | Not supplied |
| positions / 2 / value / 1 / 3 / effect basis | Not supplied |
| positions / 2 / value / 1 / 3 / effect direction | Not supplied |
| positions / 2 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 3 / endpoint | event Q |
| positions / 2 / value / 1 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / 3 / follow up | 12 weeks |
| positions / 2 / value / 1 / 3 / formulation | Not supplied |
| positions / 2 / value / 1 / 3 / intervention | intervention X |
| positions / 2 / value / 1 / 3 / population | adults |
| positions / 2 / value / 1 / 3 / relation | causal |
| positions / 2 / value / 1 / 3 / route | Not supplied |
| positions / 2 / value / 1 / 3 / species | human |
| positions / 2 / value / 1 / 4 | Not supplied |
| positions / 2 / value / 1 / 5 | false |
| positions / 2 / value / 2 / 1 | internal |
| positions / 2 / value / 2 / 2 / certainty | asserted |
| positions / 2 / value / 2 / 2 / comparator | placebo |
| positions / 2 / value / 2 / 2 / comparison | between |
| positions / 2 / value / 2 / 2 / dose | Not supplied |
| positions / 2 / value / 2 / 2 / effect basis | Not supplied |
| positions / 2 / value / 2 / 2 / effect direction | Not supplied |
| positions / 2 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 2 / endpoint | event Q |
| positions / 2 / value / 2 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 2 / follow up | 12 weeks |
| positions / 2 / value / 2 / 2 / formulation | Not supplied |
| positions / 2 / value / 2 / 2 / intervention | intervention X |
| positions / 2 / value / 2 / 2 / population | adults |
| positions / 2 / value / 2 / 2 / relation | causal |
| positions / 2 / value / 2 / 2 / route | Not supplied |
| positions / 2 / value / 2 / 2 / species | human |
| positions / 2 / value / 2 / 3 / certainty | asserted |
| positions / 2 / value / 2 / 3 / comparator | placebo |
| positions / 2 / value / 2 / 3 / comparison | between |
| positions / 2 / value / 2 / 3 / dose | Not supplied |
| positions / 2 / value / 2 / 3 / effect basis | Not supplied |
| positions / 2 / value / 2 / 3 / effect direction | Not supplied |
| positions / 2 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 3 / endpoint | event Q |
| positions / 2 / value / 2 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 2 / 3 / follow up | 12 weeks |
| positions / 2 / value / 2 / 3 / formulation | Not supplied |
| positions / 2 / value / 2 / 3 / intervention | intervention X |
| positions / 2 / value / 2 / 3 / population | adults |
| positions / 2 / value / 2 / 3 / relation | causal |
| positions / 2 / value / 2 / 3 / route | Not supplied |
| positions / 2 / value / 2 / 3 / species | human |
| positions / 2 / value / 2 / 4 | Not supplied |
| positions / 2 / value / 2 / 5 | false |
| positions / 2 / value / 3 / 1 | search&#95;question |
| positions / 2 / value / 3 / 2 / certainty | asserted |
| positions / 2 / value / 3 / 2 / comparator | placebo |
| positions / 2 / value / 3 / 2 / comparison | between |
| positions / 2 / value / 3 / 2 / dose | Not supplied |
| positions / 2 / value / 3 / 2 / effect basis | Not supplied |
| positions / 2 / value / 3 / 2 / effect direction | Not supplied |
| positions / 2 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 2 / endpoint | event Q |
| positions / 2 / value / 3 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 2 / follow up | 12 weeks |
| positions / 2 / value / 3 / 2 / formulation | Not supplied |
| positions / 2 / value / 3 / 2 / intervention | intervention X |
| positions / 2 / value / 3 / 2 / population | adults |
| positions / 2 / value / 3 / 2 / relation | causal |
| positions / 2 / value / 3 / 2 / route | Not supplied |
| positions / 2 / value / 3 / 2 / species | human |
| positions / 2 / value / 3 / 3 / certainty | asserted |
| positions / 2 / value / 3 / 3 / comparator | placebo |
| positions / 2 / value / 3 / 3 / comparison | between |
| positions / 2 / value / 3 / 3 / dose | Not supplied |
| positions / 2 / value / 3 / 3 / effect basis | Not supplied |
| positions / 2 / value / 3 / 3 / effect direction | Not supplied |
| positions / 2 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 3 / endpoint | event Q |
| positions / 2 / value / 3 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 3 / 3 / follow up | 12 weeks |
| positions / 2 / value / 3 / 3 / formulation | Not supplied |
| positions / 2 / value / 3 / 3 / intervention | intervention X |
| positions / 2 / value / 3 / 3 / population | adults |
| positions / 2 / value / 3 / 3 / relation | causal |
| positions / 2 / value / 3 / 3 / route | Not supplied |
| positions / 2 / value / 3 / 3 / species | human |
| positions / 2 / value / 3 / 4 | Not supplied |
| positions / 2 / value / 3 / 5 | false |
| positions / 2 / value / 4 / 1 | summary |
| positions / 2 / value / 4 / 2 / certainty | asserted |
| positions / 2 / value / 4 / 2 / comparator | placebo |
| positions / 2 / value / 4 / 2 / comparison | between |
| positions / 2 / value / 4 / 2 / dose | Not supplied |
| positions / 2 / value / 4 / 2 / effect basis | Not supplied |
| positions / 2 / value / 4 / 2 / effect direction | Not supplied |
| positions / 2 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 2 / endpoint | event Q |
| positions / 2 / value / 4 / 2 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 2 / follow up | 12 weeks |
| positions / 2 / value / 4 / 2 / formulation | Not supplied |
| positions / 2 / value / 4 / 2 / intervention | intervention X |
| positions / 2 / value / 4 / 2 / population | adults |
| positions / 2 / value / 4 / 2 / relation | causal |
| positions / 2 / value / 4 / 2 / route | Not supplied |
| positions / 2 / value / 4 / 2 / species | human |
| positions / 2 / value / 4 / 3 / certainty | asserted |
| positions / 2 / value / 4 / 3 / comparator | placebo |
| positions / 2 / value / 4 / 3 / comparison | between |
| positions / 2 / value / 4 / 3 / dose | Not supplied |
| positions / 2 / value / 4 / 3 / effect basis | Not supplied |
| positions / 2 / value / 4 / 3 / effect direction | Not supplied |
| positions / 2 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 3 / endpoint | event Q |
| positions / 2 / value / 4 / 3 / endpoint type | clinical&#95;event |
| positions / 2 / value / 4 / 3 / follow up | 12 weeks |
| positions / 2 / value / 4 / 3 / formulation | Not supplied |
| positions / 2 / value / 4 / 3 / intervention | intervention X |
| positions / 2 / value / 4 / 3 / population | adults |
| positions / 2 / value / 4 / 3 / relation | causal |
| positions / 2 / value / 4 / 3 / route | Not supplied |
| positions / 2 / value / 4 / 3 / species | human |
| positions / 2 / value / 4 / 4 | contradicted |
| positions / 2 / value / 4 / 5 | true |
| projected object fingerprint | 5642f40f0a0ac3fa11ae78a8ae5d7766f1280963d951a1eaec8156ddfafef3a5 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/15 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;dd0a5b11eee3367c90a94146 |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 1 / value / 1 | e1<br>support<br>direct |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value / 1 | e1<br>contradiction<br>direct |
| projected object fingerprint | 64399c5d6af2c2896cfac2b33c0c14d4950f596b1611cf8a28a61a87e1a87cd1 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/16 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | unknown |
| disagreement id | p9conflict&#58;e88a7ca49cb8ef010729ff38 |
| field | propositions.claim&#58;p1.derived&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value | unknown |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value | contradicted |
| projected object fingerprint | c995b91a4e4898e9181467d3ac5be352e2d31cadf84fd9db25a06ef1bc35e6f2 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/17 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | composite |
| disagreement id | p9conflict&#58;ed153c1e15e11d2358c7c36d |
| field | phase8.composite&#95;state |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value | unknown |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| positions / 2 / value | supported |
| projected object fingerprint | 8f89dacb9729e482182e3e578a75af0c6bf510b91c117a9eb93c9b8bed50c1e1 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/18 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;edf2be2be4ef491024648d6a |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| material | true |
| positions / 1 / evidence ids | e1 |
| positions / 1 / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| positions / 1 / value / 1 / attributes / certainty | asserted |
| positions / 1 / value / 1 / attributes / comparator | placebo |
| positions / 1 / value / 1 / attributes / comparison | between |
| positions / 1 / value / 1 / attributes / dose | Not supplied |
| positions / 1 / value / 1 / attributes / effect basis | Not supplied |
| positions / 1 / value / 1 / attributes / effect direction | Not supplied |
| positions / 1 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 1 / attributes / endpoint | event Q |
| positions / 1 / value / 1 / attributes / endpoint type | clinical&#95;event |
| positions / 1 / value / 1 / attributes / follow up | 12 weeks |
| positions / 1 / value / 1 / attributes / formulation | Not supplied |
| positions / 1 / value / 1 / attributes / intervention | intervention X |
| positions / 1 / value / 1 / attributes / population | adults |
| positions / 1 / value / 1 / attributes / relation | causal |
| positions / 1 / value / 1 / attributes / route | Not supplied |
| positions / 1 / value / 1 / attributes / species | human |
| positions / 1 / value / 1 / cohort id | Not supplied |
| positions / 1 / value / 1 / dataset id | Not supplied |
| positions / 1 / value / 1 / design limitations | No entries recorded |
| positions / 1 / value / 1 / evidence id | e1 |
| positions / 1 / value / 1 / evidence type | unknown |
| positions / 1 / value / 1 / identification argument | Not supplied |
| positions / 1 / value / 1 / identification evidence ids | No entries recorded |
| positions / 1 / value / 1 / randomized | Not supplied |
| positions / 1 / value / 1 / source role | primary&#95;study |
| positions / 1 / value / 1 / study id | synthetic-study-1 |
| positions / 1 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 2 / evidence ids | e1 |
| positions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| positions / 2 / value / 1 / attributes / certainty | asserted |
| positions / 2 / value / 1 / attributes / comparator | placebo |
| positions / 2 / value / 1 / attributes / comparison | between |
| positions / 2 / value / 1 / attributes / dose | Not supplied |
| positions / 2 / value / 1 / attributes / effect basis | Not supplied |
| positions / 2 / value / 1 / attributes / effect direction | Not supplied |
| positions / 2 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 1 / attributes / endpoint | event Q |
| positions / 2 / value / 1 / attributes / endpoint type | clinical&#95;event |
| positions / 2 / value / 1 / attributes / follow up | 12 weeks |
| positions / 2 / value / 1 / attributes / formulation | Not supplied |
| positions / 2 / value / 1 / attributes / intervention | intervention X |
| positions / 2 / value / 1 / attributes / population | adults |
| positions / 2 / value / 1 / attributes / relation | causal |
| positions / 2 / value / 1 / attributes / route | Not supplied |
| positions / 2 / value / 1 / attributes / species | human |
| positions / 2 / value / 1 / cohort id | Not supplied |
| positions / 2 / value / 1 / dataset id | Not supplied |
| positions / 2 / value / 1 / design limitations | No entries recorded |
| positions / 2 / value / 1 / evidence id | e1 |
| positions / 2 / value / 1 / evidence type | controlled&#95;intervention |
| positions / 2 / value / 1 / identification argument | Not supplied |
| positions / 2 / value / 1 / identification evidence ids | No entries recorded |
| positions / 2 / value / 1 / randomized | true |
| positions / 2 / value / 1 / source role | primary&#95;study |
| positions / 2 / value / 1 / study id | synthetic-study-1 |
| positions / 2 / value / 1 / underlying evidence ids | No entries recorded |
| projected object fingerprint | 5ad355c432c780f210edc7aed79a96549e714dbbbd1c6cfb8740438b4aedca60 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| reason | Same-dimension positions change admissible output |
| resolution | adjudicated |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/19 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | label&#95;conflict |
| evidence ids | e1 |
| field | phase8.derived&#95;label |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 1d8b6a34caf76930d5f1191398fb4496606816991ec8ef37637930e4b27c4107 |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;032edce440a715026170dc3e |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.selected&#95;source&#95;objects |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 22726134d786de048cb6f62f25bd38afbe4970b742c02e210d7e5dd819f0005c |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;17b024be8d3af69da3ddcaa6 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| mandatory | true |
| material | true |
| position ids | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 26a6f6ac134cdfb91e406ad0bb4cde6d88dbd711d9089c733370e92f72350c29 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;50fb514878cb0c4da878ffcf |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| projected object fingerprint | 84e25aef10c7c1ed3a084623a28514f301d2f5b4c6c639e726978386c562692b |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;6403bde535bc2b83ef1f65a1 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 4aadc816f7a975e7dc0dc40a999e54245563609b23fe6be0be132bdafd6b253d |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;6992e0b62cf00fd3a41d5005 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | composite&#95;conflict |
| evidence ids | e1 |
| field | phase8.composite&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| projected object fingerprint | 0230d8268352748f34e4aa017fb8445076eadfd2f96b60a7c005cf285f2bba71 |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;8eeb895e2a96a25616df207b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.output&#95;transformations |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 456cde9901409d1d9a263584f9e0dd64c0c61c236d8601f8389d7372138953e4 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/6 |
| trigger id | p9trigger&#58;9447844e046b0aed24724dd0 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | unknown&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | de592e64f5c0fe65cf49cb1264014776b3e1aa8a7fdc837869ed34ec6e929b99 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/7 |
| trigger id | p9trigger&#58;9e2beb2d0eb36782d2f3669a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | label&#95;conflict |
| evidence ids | e1 |
| field | phase8.derived&#95;label |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| projected object fingerprint | 30c60c562e35240f714e0b88cb619f8d8d6b57dc50af58dd31acf25e0620175d |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/8 |
| trigger id | p9trigger&#58;a5218c5ac482d40d4521dcf8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | label&#95;conflict |
| evidence ids | e1 |
| field | phase8.original&#95;model&#95;label |
| mandatory | true |
| material | true |
| position ids | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 5f3ce6cebe95b423f3d6f9900307f387d522c248dd99dcefab402f058f7cb522 |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/9 |
| trigger id | p9trigger&#58;abf82ed5a208d0775f08a8a6 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | label&#95;conflict |
| evidence ids | e1 |
| field | phase8.original&#95;model&#95;label |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 80d09d20dcc133c44f7c470e75c98cf30c93bfd32841692937a923aaa14ac6e1 |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/10 |
| trigger id | p9trigger&#58;be591e34fb16b78d2057fc6d |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | composite&#95;conflict |
| evidence ids | e1 |
| field | phase8.composite&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 30329da941ab22969d9b0855ef31a9b384d9848ce04b31b46395256a7b9b34fb |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/11 |
| trigger id | p9trigger&#58;cb13c2f3f64b447f11128fe6 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.output&#95;transformations |
| mandatory | true |
| material | true |
| position ids | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | d969e73ba8cc44f6117a578b66df33139f352acd4675801843d0d9c38dcc3f66 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/12 |
| trigger id | p9trigger&#58;cee384718c44c4a7f7d649de |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | fc314018421fe9c77753deffb9ae45c4fb9288d7f23a6bd290b1805a25f159b3 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/13 |
| trigger id | p9trigger&#58;d37d1459cdd231906852fb2b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | unknown&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771 |
| projected object fingerprint | 182d9ddcde53ef6e38e98ce6e85339a8eb300a776966694bbe17d04bdcf33553 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/14 |
| trigger id | p9trigger&#58;d6737d5ea1605bc9affad26a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | a94f31c9c1f051141652643f8b38225c446312cb163fcc3c68a4adb0f9e6e123 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/15 |
| trigger id | p9trigger&#58;e0ac9734c17d11de034b2e53 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76 |
| projected object fingerprint | bcedd0343852708769461967419c0ba96cd9b2e2e6c5de323250ce5553402688 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/16 |
| trigger id | p9trigger&#58;e157033d5a1a80f4a0b2ce40 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.selected&#95;source&#95;objects |
| mandatory | true |
| material | true |
| position ids | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | aa8af85d2048851e84a4376c03cebbefc99af7280fbd151d850475c65ac3da68 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/17 |
| trigger id | p9trigger&#58;e3c832f324212a2a3a7596ab |

### Adjudication

| Field | Recorded value |
| --- | --- |
| adjudication id | p9decision&#58;c605989c9bfca29105df802e |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code version | f5203a273d198f966303f68c6e39b48a17697fa4230181079a71e1c61ec08004 |
| conflict ids | p9conflict&#58;0e342dc2de027b778c463210<br>p9conflict&#58;1d219692b09ae7b73ab66818<br>p9conflict&#58;1f38e70ec8d311ea6b5f86fb<br>p9conflict&#58;2dfb98b423a46e354d8a6591<br>p9conflict&#58;437a5e84c002d90038affa7a<br>p9conflict&#58;4ec77e9889693870d71fae46<br>p9conflict&#58;613eab30e8107a8b31dac2bf<br>p9conflict&#58;6a425db104fb02cd551b6d9b<br>p9conflict&#58;70bbfd60913badb70121317a<br>p9conflict&#58;8fcb754a57f3f1ce74efc84c<br>p9conflict&#58;a383981a51587e3d22153ecf<br>p9conflict&#58;b1dfc3bdcb146cdce9746104<br>p9conflict&#58;b61379dcc19775c4e4fb6fb3<br>p9conflict&#58;b765a4fe6ede27cd58364209<br>p9conflict&#58;c16a13b1194a453f5413cd85<br>p9conflict&#58;cf4ed5e7ccf5cc86b20c3cff<br>p9conflict&#58;dd0a5b11eee3367c90a94146<br>p9conflict&#58;e88a7ca49cb8ef010729ff38<br>p9conflict&#58;ed153c1e15e11d2358c7c36d<br>p9conflict&#58;edf2be2be4ef491024648d6a |
| conflict types | composite<br>evidence<br>label<br>proposition<br>unknown |
| contract version | AA-P9/1.0 |
| corrected parent position id | Not supplied |
| evidence ids | e1 |
| independence | Recorded offline comparison&#58; first verdict withheld, shared source/extraction basis; no empirical model independence or human approval. |
| origin | offline&#95;comparison |
| original decisions / 1 / derived label | solid |
| original decisions / 1 / original model label | solid |
| original decisions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| original decisions / 1 / raw sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| original decisions / 1 / scientific state | supported |
| original decisions / 1 / technical status | completed |
| original decisions / 2 / derived label | overclaim |
| original decisions / 2 / original model label | overclaim |
| original decisions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| original decisions / 2 / raw sha256 | 60b459914871cc5da49895b02eddc0c1d577b3a6fdd72ef0e9f4c21bbc33e371 |
| original decisions / 2 / scientific state | contradicted |
| original decisions / 2 / technical status | completed |
| original position ids | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| outcome | considered |
| position binding reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/0/position&#95;fingerprints |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | 02cd5ba9586bfb2ca4155e3e0afc8c2e51f34bd11841dbe42d69c18f247f4d28 |
| proposition ids | claim&#58;p1 |
| reason | Targeted comparison&#58; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Scientific UNKNOWN affects admissible output; Same-dimension positions change admissible output |
| review decision / derived label | Not supplied |
| review decision / original model label | solid |
| review decision / position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| review decision / raw sha256 | 13c0f2cf642485c81585fd8b089f36713c16094ee668e6bbdd563105bf975a76 |
| review decision / scientific state | unknown |
| review decision / technical status | completed |
| reviewer provenance | Built-in offline recording via existing runner/parser |
| reviewer type | model |
| run id | acceptance-conflict&#58;counterreview |
| selected position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/0 |
| timestamp | 2026-10-10T18&#58;14&#58;54.289774+00&#58;00 |

### Adjudication

| Field | Recorded value |
| --- | --- |
| adjudication id | p9decision&#58;be62afc458c8755f7bedbeec |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code version | f5203a273d198f966303f68c6e39b48a17697fa4230181079a71e1c61ec08004 |
| conflict ids | p9conflict&#58;0e342dc2de027b778c463210<br>p9conflict&#58;1d219692b09ae7b73ab66818<br>p9conflict&#58;1f38e70ec8d311ea6b5f86fb<br>p9conflict&#58;2dfb98b423a46e354d8a6591<br>p9conflict&#58;437a5e84c002d90038affa7a<br>p9conflict&#58;4ec77e9889693870d71fae46<br>p9conflict&#58;613eab30e8107a8b31dac2bf<br>p9conflict&#58;6a425db104fb02cd551b6d9b<br>p9conflict&#58;70bbfd60913badb70121317a<br>p9conflict&#58;8fcb754a57f3f1ce74efc84c<br>p9conflict&#58;a383981a51587e3d22153ecf<br>p9conflict&#58;b1dfc3bdcb146cdce9746104<br>p9conflict&#58;b61379dcc19775c4e4fb6fb3<br>p9conflict&#58;b765a4fe6ede27cd58364209<br>p9conflict&#58;c16a13b1194a453f5413cd85<br>p9conflict&#58;cf4ed5e7ccf5cc86b20c3cff<br>p9conflict&#58;dd0a5b11eee3367c90a94146<br>p9conflict&#58;e88a7ca49cb8ef010729ff38<br>p9conflict&#58;ed153c1e15e11d2358c7c36d<br>p9conflict&#58;edf2be2be4ef491024648d6a |
| conflict types | composite<br>evidence<br>label<br>proposition<br>unknown |
| contract version | AA-P9/1.0 |
| corrected parent position id | Not supplied |
| evidence ids | e1 |
| independence | Explicit host-submitted human adjudication; provenance is not identity authentication. |
| origin | host&#95;human&#95;submission |
| original decisions / 1 / derived label | solid |
| original decisions / 1 / original model label | solid |
| original decisions / 1 / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| original decisions / 1 / raw sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| original decisions / 1 / scientific state | supported |
| original decisions / 1 / technical status | completed |
| original decisions / 2 / derived label | overclaim |
| original decisions / 2 / original model label | overclaim |
| original decisions / 2 / position id | p9position&#58;d856c532e1d999df7f6458a7 |
| original decisions / 2 / raw sha256 | 60b459914871cc5da49895b02eddc0c1d577b3a6fdd72ef0e9f4c21bbc33e371 |
| original decisions / 2 / scientific state | contradicted |
| original decisions / 2 / technical status | completed |
| original position ids | p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| outcome | resolved |
| position binding reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/1/position&#95;fingerprints |
| position ids | p9position&#58;26a9a744a0b0e32c48368e76<br>p9position&#58;34ec1bd1dedf82c107b6f771<br>p9position&#58;d856c532e1d999df7f6458a7 |
| projected object fingerprint | d04c3412b0fe7caaa1491dfa88c2e57cce85eafff1bbaaf0ba693183a784bebd |
| proposition ids | claim&#58;p1 |
| reason | Select a bound position retaining all history |
| review decision / derived label | solid |
| review decision / original model label | solid |
| review decision / position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| review decision / raw sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| review decision / scientific state | supported |
| review decision / technical status | completed |
| reviewer provenance | Offline human import control |
| reviewer type | human |
| run id | acceptance-conflict |
| selected position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/1 |
| timestamp | 2026-10-10T18&#58;14&#58;54.617102+00&#58;00 |

### Attempt

| Field | Recorded value |
| --- | --- |
| attempt id | attempt-001 |
| code version | f5203a273d198f966303f68c6e39b48a17697fa4230181079a71e1c61ec08004 |
| contract version | AA-P9/1.0 |
| independence | First verdict withheld; shared original sources and extraction IDs. Recorded offline output; no empirical model independence established. |
| kind | counterreview |
| packet sha256 | 611caa03f34ed71dc0f05d0d2c609894ee45d1d7ba5f746ab3fa67ad5104fe0d |
| position id | p9position&#58;26a9a744a0b0e32c48368e76 |
| projected object fingerprint | 20f99712c4db1be511d8a5a8662f7bf2d3d1c0266063c99b50ab6bb7a9d9c978 |
| reason |  |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/attempts/0 |
| status | completed |
| timestamp | 2026-10-10T18&#58;14&#58;54.261810+00&#58;00 |

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and offline configuration bound |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 1f4376dc4b6c123ce9f8bf366c1ab1cc573a2f45bf10358eaffd1a424a17b7fb |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| code / code fingerprint | e83954a5e67e0224b81d96a37540375317e88242448eec2da08679cfbf642783 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 72 |
| code / source binding | installed bytes only; no verified tracked-source claim |
| code / verified source commit | Not supplied |
| config | offline-recording-v1 |
| contract | AA-P10/1.0 |
| evidence fingerprint | cea4af84c8fff4b5d9a8b2b09054e1cfe5ed96a978fae1752f5027d2f1dfea08 |
| input fingerprint | 3ed6c37cef5b16e6a8cd1e2a61f4133a4bc14a2777c9492cd85cbfa124b206d8 |
| ledger fingerprint | b82403260c8afdbc7d321ff53a22693ef1741414b800847a3cc61936a1b22e56 |
| package version | 0.1.0 |
| phase8 summary / composite state | supported |
| phase8 summary / derived label | solid |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | completed |
| phase8 summary / technical status | completed |
| phase9 summary / execution status | completed |
| phase9 summary / final position id | p9position&#58;34ec1bd1dedf82c107b6f771 |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | false |
| phase9 summary / review state | adjudicated |
| phase9 summary / route | AUTO&#95;RESOLVABLE |
| phase9 summary / technical status | completed |
| providers / 1 / model | offline-recording-no-live-model |
| providers / 1 / provider | offline-recording-no-live-model |
| providers / 1 / usage | Not supplied |
| providers / 2 / model | offline-recording-no-live-model |
| providers / 2 / provider | offline-recording-no-live-model |
| providers / 2 / usage | Not supplied |
| recording notice | RECORDED OFFLINE / SYNTHETIC; no live model execution |
| review counts / adjudications | 2 |
| review counts / attempts | 1 |
| review counts / conflicts | 20 |
| review counts / positions | 3 |
| review fingerprint | b5a8e0a8d7f8c654601cc0d4f4ec159f40c560d6a70271097483ee669c6db8eb |
| run id | acceptance-conflict |
| selected position id | p9position&#58;34ec1bd1dedf82c107b6f771 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

