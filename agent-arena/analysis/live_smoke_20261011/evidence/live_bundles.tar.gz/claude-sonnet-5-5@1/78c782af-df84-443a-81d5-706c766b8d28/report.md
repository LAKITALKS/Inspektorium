# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;39&#58;33.577109+00&#58;00 |
| parent | Not supplied |
| record fingerprint | eb418b5216ecc03551a8bf777acb38d383e7acc4b438be7b134ee70ee0465279 |
| revision | 78c782af-df84-443a-81d5-706c766b8d28 |
| selected position id | p9position&#58;ec690c39f70cca921c9612a4 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-012 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | ae978e24152822ae6738117309f8d2dddf0c4fe256a1e75b5910770672b9c327 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 61944 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 21634 |
|  / 1 / message id | msg&#95;011CfuSPH3kVhi7zaGVSavGD |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;1 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011CfuSPGi9huKtkgGj1gpTZ |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 218318 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-sonnet-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11142 |
|  / 1 / usage / output tokens | 3966 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Eating a good breakfast every morning makes you lose weight.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 609ee28c8d2fb302457ee4550b78e951b6c05250ac44fdaf263f5cdc58dd02e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | correlation&#95;vs&#95;causation |
| raw response sha256 | 792c5d35c1b5f9fa2b1b15e767ae1f71f90c4f721c851a26b3a17186f35365ec |
| reasons | claim&#58;p1&#58; invalid material dimension<br>missing, duplicate or orphan mandatory transformation audit<br>t1&#58; transformed source mismatch<br>t2&#58; transformed source mismatch<br>t3&#58; transformed source mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch |
| record fingerprint | 127e5d49100f534c0485f864ecd9a3a1232cd71481259636c74d44310664d165 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | correlation&#95;vs&#95;causation |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | causal&#95;inference |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1<br>e2<br>e3 |
| represented trigger analysis / implies human benefit | Not supplied |
| represented trigger analysis / noncausal result used | true |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | A causal claim is drawn from observational, confounded association, and RCTs found no weight-loss effect from assigned breakfast. |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | The &quot;people who skip breakfast weigh more&quot; finding comes from cross-sectional and prospective OBSERVATIONAL studies |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Extracted by the model from the task prompt, with evidence from the supplied context only. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov-claim |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | causal relation<br>endpoint<br>comparator |
| materiality | required |
| not applicable | No entries recorded |
| observation target | contradiction |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov-claim |
| reason | The causal weight-loss claim is contradicted by RCT evidence and rests on confounded observational association. |
| reported verdict | contradicted |
| required bridge ids | br1 |
| search question | Does eating breakfast cause weight loss? |
| search scope ids | ss1 |
| uncertainty | Only the supplied context was reviewed. |

Quoted proposition; this is represented input, not a release assertion.

```
Eating a good breakfast every morning makes you lose weight.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 60 |
| start | 0 |
| text | Eating a good breakfast every morning makes you lose weight. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | unhedged |
| comparator | skipping breakfast |
| effect direction | decrease in weight |
| endpoint | weight loss |
| intervention | eating a good breakfast every morning |
| population | people generally |
| relation | causal |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | indirect |
|  / 1 / evidence id | e1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Observational association only; it cannot establish that breakfast causes weight loss. |
|  / 1 / search scope id | ss1 |
|  / 2 / binding id | b2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | e2 |
|  / 2 / observation | contradiction |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | RCT evidence on assigned breakfast found no weight loss. |
|  / 2 / search scope id | ss1 |
|  / 3 / binding id | b3 |
|  / 3 / directness | direct |
|  / 3 / evidence id | e3 |
|  / 3 / observation | inconclusive |
|  / 3 / proposition id | claim&#58;p1 |
|  / 3 / reason | Lifestyle differences between skippers and eaters mean the observational association is confounded. |
|  / 3 / search scope id | ss1 |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | br1 |
|  / 1 / conclusion proposition id | claim&#58;p1 |
|  / 1 / dimensions | confounding |
|  / 1 / evidence ids | e1<br>e3 |
|  / 1 / kind | causal&#95;identification |
|  / 1 / premise proposition ids | No entries recorded |
|  / 1 / reason | The observational association is confounded and the RCTs do not show weight loss. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / endpoint | weight loss |
| from and to attributes (identical) / relation | causal |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | The search question keeps the causal relation and endpoint; the unhedged certainty is not carried into the question. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does eating breakfast cause weight loss? |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| from and to attributes (identical) / relation | causal |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | The proposition text is unchanged; the verdict summary is added. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Eating a good breakfast every morning makes you lose weight.<br>Contradicted by RCT evidence in the supplied context; the supporting evidence is only observational and confounded. |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| asserts whole claim | true |
| from and to attributes (identical) / relation | causal |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | The display claim repeats the original text, and the explanation states the claim is not supported and why. |
| stage | summary |
| target id | cf1 |
| to text | Eating a good breakfast every morning makes you lose weight.<br>This is not supported&#58; the association comes from confounded observational studies, and RCTs show that assigning breakfast does not cause weight loss. |
| transformation id | t3 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | body weight, breakfast skippers vs eaters |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
The "people who skip breakfast weigh more" finding comes from cross-sectional and prospective OBSERVATIONAL studies
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | body weight |
| attributes / population | breakfast skippers vs eaters |
| attributes / relation | association |
| design limitations | confounding by lifestyle and health behaviours |
| evidence id | e1 |
| evidence type | observational |
| randomized | false |
| source role | context description of the observational studies |

### Evidence e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | weight change in RCTs of assigned breakfast |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | contradictory |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
assigning people to eat breakfast did not cause weight loss
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | assigned to skip breakfast |
| attributes / endpoint | weight change |
| attributes / intervention | assigned to eat breakfast |
| attributes / population | adults |
| evidence id | e2 |
| evidence type | controlled&#95;intervention |
| randomized | true |
| source role | context description of the RCT meta-analysis (Sievert et al., BMJ, 2019) |

### Evidence e3

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | confounding in observational studies |
| evidence id | e3 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
breakfast skippers differ from eaters in many health and lifestyle behaviours
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / relation | confounding |
| evidence id | e3 |
| evidence type | observational |
| randomized | false |
| source role | context statement about confounding |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied material only |
|  / 1 / search scope id | ss1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A nutrition feature advises: "Breakfast is the most important meal of the day. Studies show people who skip breakfast weigh more, so skipping breakfast makes you gain weight — eat a good breakfast every morning and you will lose weight."

The "people who skip breakfast weigh more" finding comes from cross-sectional and prospective OBSERVATIONAL studies (breakfast skippers differ from eaters in many health and lifestyle behaviours). Randomized controlled trials tell a different story: a systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) found that assigning people to eat breakfast did not cause weight loss — adults assigned to eat breakfast consumed more total daily calories and, if anything, weighed slightly more than those assigned to skip it — providing no support for eating breakfast as a weight-loss strategy.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov-claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | contradicted |
|  / 1 / confidence status | high |
|  / 1 / contrary evidence ids | e2<br>e3 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | correlation&#95;vs&#95;causation |
|  / 1 / proposition | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / provenance id | prov-claim |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary | Contradicted by RCT evidence in the supplied context; the supporting evidence is only observational and confounded. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | This is not supported&#58; the association comes from confounded observational studies, and RCTs show that assigning breakfast does not cause weight loss. |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | contradicted |
|  / 1 / display claim | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov-claim |
|  / 1 / referenced evidence ids | e1<br>e2<br>e3 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 88749997389e84aa7171e6ff49268004cafdbc99f6e72b7b14ad6b2b3dfae137 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;ec690c39f70cca921c9612a4

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | correlation&#95;vs&#95;causation |
| position id | p9position&#58;ec690c39f70cca921c9612a4 |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 792c5d35c1b5f9fa2b1b15e767ae1f71f90c4f721c851a26b3a17186f35365ec |
| run id | 6393e13f-3934-4463-93a2-5b9e7b7d8965 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11142 |
| usage / output tokens | 3966 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ec690c39f70cca921c9612a4 |
| projected object fingerprint | 65a5de05dbfa77ab67453238a038bf4cc3ddae1a6fdd62612a41331ca7393430 |
| proposition ids | No entries recorded |
| reason | claim&#58;p1&#58; invalid material dimension; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;00be4d4ade155e94ac85b440 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1<br>e2<br>e3 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ec690c39f70cca921c9612a4 |
| projected object fingerprint | eddadc7430b2bde5076126a12a45364e295098f4f744339a7cbc6b7531f671de |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;68cc3b897236cebab1801a0a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ec690c39f70cca921c9612a4 |
| projected object fingerprint | bf84cc4cdc01bc7f5c66ddb45c3f4a4e86c6514ee3e9a67353bf06084e72084c |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;d3802f5935e7c42db769fb83 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 3<br>Evaluated&#58; 3<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | a20774218204f9475b36a0ac03adb5fade9c1976c2159b1686b97c797a9f550a |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 88c6df80447e3e7f6e6550218f267c0cc383945ee3c297b13a33374e680e4384 |
| execution evidence / 1 / attempt ids | attempt-012 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | ae978e24152822ae6738117309f8d2dddf0c4fe256a1e75b5910770672b9c327 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 61944 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 21634 |
| execution evidence / 1 / message id | msg&#95;011CfuSPH3kVhi7zaGVSavGD |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011CfuSPGi9huKtkgGj1gpTZ |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 218318 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-sonnet-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11142 |
| execution evidence / 1 / usage / output tokens | 3966 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 708e656386b9545c47cc8b478bddb08eea8281957c4ca503a0f284ce53b10632 |
| ledger fingerprint | 7919ccb97136b90fe70f0f3cb24f1902daf30ef7995a9e0a88a4a2b7afae778f |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | correlation&#95;vs&#95;causation |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11142 |
| providers / 1 / usage / output tokens | 3966 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 88749997389e84aa7171e6ff49268004cafdbc99f6e72b7b14ad6b2b3dfae137 |
| run id | 6393e13f-3934-4463-93a2-5b9e7b7d8965 |
| selected position id | p9position&#58;ec690c39f70cca921c9612a4 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

