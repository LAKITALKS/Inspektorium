# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;38&#58;18.475262+00&#58;00 |
| parent | Not supplied |
| record fingerprint | edd35ede8f3b3b967d3005b156e7eab0b106a38ce62334e552b8c432a736404e |
| revision | 69c39c53-1628-47e2-8380-89f1ccf0a9de |
| selected position id | p9position&#58;923dd4844384f29e41b11e1e |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-009 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 9589c78395f6b187b91edb965cfcd996b47f712eeba902f413e13a97195f0502 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 103890 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 45436 |
|  / 1 / message id | msg&#95;011CfuSFzdKoqmpYukw9MpnV |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;1 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011CfuSFz9oTZQmSx8XbDFR6 |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 218176 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-sonnet-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11105 |
|  / 1 / usage / output tokens | 8168 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 487aab0a628c1f44c2b48d2030d8802e758ab89deb04eac557bd486c70c2186f |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | ebde5309f005d7e1ad7d364cba9f02208ed44ce028e54910ae533381a76475ab |
| reasons | t1&#58; invalid product dimensions<br>claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace<br>missing, duplicate or orphan mandatory transformation audit<br>tr1&#58; transformed source mismatch<br>tr2&#58; transformed source mismatch<br>tr3&#58; transformed source mismatch<br>tr4&#58; transformed source mismatch<br>tr5&#58; transformed source mismatch<br>tr6&#58; transformed source mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; t1&#58; invalid product dimensions; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; transformed source mismatch; tr6&#58; transformed source mismatch<br>Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;e1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed)<br>Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;e2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| record fingerprint | f62a16093e36798e2e3731d31c6315a8531d2768aee3029b9e283e5d7d98db4b |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | Not supplied |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1<br>e2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1<br>claim&#58;p2 |
| represented trigger analysis / reason | A biomarker (LDL) result is presented as a clinical outcome (reduced heart attacks), and no outcome data exist. This is biomarker-to-clinical inflation. No biological mechanism is described, and no causal inference from confounded or noncausal data is the core error, so the label is overstatement. |
| represented trigger analysis / trigger evidence id | e2 |
| represented trigger analysis / trigger proposition id | claim&#58;p2 |
| represented trigger analysis / trigger quote | no cardiovascular events were tracked |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Extracted from task.prompt (source&#95;id input); evidence quoted from task.context (source&#95;id context). |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | and |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | population<br>endpoint |
| materiality | required |
| not applicable | No entries recorded |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | The LDL endpoint was measured directly in the relevant population. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Did the new injectable drug lower LDL cholesterol in patients with familial hypercholesterolaemia? |
| search scope ids | scope1 |
| uncertainty | Design details such as randomization and comparator are not stated.<br>Follow-up was only twelve weeks. |

Quoted proposition; this is represented input, not a release assertion.

```
The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 47 |
| start | 0 |
| text | The new injectable drug lowered LDL cholesterol |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| effect direction | decrease |
| endpoint | LDL cholesterol |
| endpoint type | biomarker |
| intervention | new injectable cholesterol-lowering drug |
| population | patients with familial hypercholesterolaemia |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The Phase 2 result reports a 65 percent LDL reduction in the same population. |
|  / 1 / search scope id | scope1 |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | endpoint<br>endpoint&#95;type<br>population |
| materiality | required |
| not applicable | No entries recorded |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | claim&#58;p1 |
| proposition id | claim&#58;p2 |
| provenance id | prov1 |
| reason | Only LDL and liver safety were measured. The LDL-to-heart-attack inference is unverified here. |
| reported verdict | unsupported |
| required bridge ids | br1 |
| search question | Did the new injectable drug reduce heart attacks in patients with familial hypercholesterolaemia? |
| search scope ids | scope1 |
| uncertainty | No external search was run; an outcomes trial is not expected for at least four years. |

Quoted proposition; this is represented input, not a release assertion.

```
The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 73 |
| start | 52 |
| text | reduced heart attacks |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| effect direction | decrease |
| endpoint | heart attacks |
| endpoint type | clinical outcome |
| intervention | new injectable cholesterol-lowering drug |
| population | patients with familial hypercholesterolaemia |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b2 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e2 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The context states no cardiovascular events were tracked, so no heart attack data exist in the reviewed material. |
|  / 1 / search scope id | scope1 |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | br1 |
|  / 1 / conclusion proposition id | claim&#58;p2 |
|  / 1 / dimensions | endpoint<br>endpoint&#95;type |
|  / 1 / evidence ids | e1<br>e2 |
|  / 1 / kind | semantic&#95;transfer |
|  / 1 / premise proposition ids | claim&#58;p1 |
|  / 1 / reason | The LDL biomarker result is used for a heart attack outcome claim, but no cardiovascular events were tracked and no outcomes trial has reported. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / dimensions | product<br>population |
|  / 1 / evidence ids | e1 |
|  / 1 / reason | The evidence concerns the same injectable drug in familial hypercholesterolaemia patients. |
|  / 1 / state | direct&#95;match |
|  / 1 / transfer id | t1 |

### Transformation tr1

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from proposition ids | claim&#58;p1 |
| from text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| reason | Converted to a question; endpoint and population unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Did the new injectable drug lower LDL cholesterol in patients with familial hypercholesterolaemia? |
| transformation id | tr1 |

### Transformation tr2

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical outcome |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| reason | Converted to a question; the clinical endpoint is preserved and not replaced by LDL. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Did the new injectable drug reduce heart attacks in patients with familial hypercholesterolaemia? |
| transformation id | tr2 |

### Transformation tr3

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from proposition ids | claim&#58;p1 |
| from text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| reason | Unchanged proposition with a verdict summary added. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.<br>Supported by the reported Phase 2 LDL reduction. |
| transformation id | tr3 |

### Transformation tr4

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical outcome |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| reason | Unchanged proposition; the verdict states it is unsupported. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia.<br>Unsupported&#58; no cardiovascular events were tracked. |
| transformation id | tr4 |

### Transformation tr5

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from attributes / endpoint | LDL cholesterol |
| from attributes / endpoint type | biomarker |
| from proposition ids | claim&#58;p1 |
| from text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| reason | The summary adds trial context and the reported magnitude and asserts only the supported LDL part, not the whole claim. |
| stage | summary |
| target id | cf1 |
| to attributes / effect magnitude | 65 percent |
| to attributes / endpoint | LDL cholesterol |
| to attributes / endpoint type | biomarker |
| to attributes / follow up | twelve weeks |
| to text | The drug lowered LDL cholesterol in a Phase 2 trial in patients with familial hypercholesterolaemia.<br>The trial reported a 65 percent LDL reduction over twelve weeks. |
| transformation id | tr5 |

### Transformation tr6

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical outcome |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| reason | The summary reports the absence of outcome evidence within the reviewed set only. |
| stage | summary |
| target id | cf2 |
| to text | No evidence in the supplied material shows the drug reduced heart attacks.<br>The trial tracked only lipid levels and liver safety, and no cardiovascular events. |
| transformation id | tr6 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | LDL cholesterol |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | 65 percent LDL reduction |
| role | supporting |
| source id | context |
| value origin | reported |

Evidence text and exact source reference (identical)&#58;

```
The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / effect direction | decrease |
| attributes / effect magnitude | 65 percent |
| attributes / endpoint | LDL cholesterol |
| attributes / endpoint type | biomarker |
| attributes / follow up | twelve weeks |
| attributes / intervention | new injectable cholesterol-lowering agent |
| attributes / population | patients with familial hypercholesterolaemia on maximum statin therapy |
| attributes / species | human |
| design limitations | Randomization and comparator not stated<br>Biomarker endpoint only<br>Twelve-week follow-up<br>Company-announced result |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| quality | Not supplied |
| randomized | Not supplied |
| source role | company-announced Phase 2 trial result |

### Evidence e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | heart attacks / cardiovascular events |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | reported |

Evidence text and exact source reference (identical)&#58;

```
The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked and no outcomes trial is expected to report for at least four more years.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | lipid levels and liver safety only |
| attributes / follow up | twelve weeks |
| design limitations | States that no cardiovascular events were tracked |
| evidence id | e2 |
| evidence type | descriptive |
| quality | Not supplied |
| randomized | Not supplied |
| source role | description of trial scope and outcomes-trial timeline |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied&#95;material&#95;only |
|  / 1 / search scope id | scope1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg1 |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p2 |
|  / 1 / proposition | No heart attack outcome data were found in the supplied material. |
|  / 1 / search scope id | scope1 |
|  / 1 / source local evidence ids | e2 |

Captured context (source&#95;id&#58; context)&#58;

```
A pharmaceutical company announced results from its Phase 2 trial of a new injectable cholesterol-lowering agent. The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy. Company executives described the results as a major breakthrough in cardiovascular protection and said the drug would transform outcomes for patients at high risk of heart attack and stroke. They announced plans for an accelerated approval pathway based on the LDL reduction data. The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked and no outcomes trial is expected to report for at least four more years.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | solid |
|  / 1 / proposition | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary | Supported by the reported Phase 2 LDL reduction. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status |  |
|  / 2 / contrary evidence ids | e2 |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | overclaim |
|  / 2 / proposition | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 2 / provenance id | prov1 |
|  / 2 / supporting evidence ids | No entries recorded |
|  / 2 / verdict summary | Unsupported&#58; no cardiovascular events were tracked. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The trial reported a 65 percent LDL reduction over twelve weeks. |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The drug lowered LDL cholesterol in a Phase 2 trial in patients with familial hypercholesterolaemia. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims / 1 / claimed origin | reported |
|  / 1 / value claims / 1 / claimed source ids | context |
|  / 1 / value claims / 1 / evidence id | e1 |
|  / 2 / client explanation | The trial tracked only lipid levels and liver safety, and no cardiovascular events. |
|  / 2 / client finding id | cf2 |
|  / 2 / client negative assertions | No entries recorded |
|  / 2 / client strength | not&#95;assessed |
|  / 2 / display claim | No evidence in the supplied material shows the drug reduced heart attacks. |
|  / 2 / parent finding id | claim&#58;p2 |
|  / 2 / provenance id | prov1 |
|  / 2 / referenced evidence ids | e2 |
|  / 2 / value claims / 1 / claimed origin | reported |
|  / 2 / value claims / 1 / claimed source ids | context |
|  / 2 / value claims / 1 / evidence id | e2 |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 48cc01b5b0ff056ef11a9e3ffbed0ae101fdfba4d198d70e6adbb2afb166ec09 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;923dd4844384f29e41b11e1e

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;923dd4844384f29e41b11e1e |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | ebde5309f005d7e1ad7d364cba9f02208ed44ce028e54910ae533381a76475ab |
| run id | e047d4df-f1b6-4cc9-bdef-bd2d084f57f7 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11105 |
| usage / output tokens | 8168 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;923dd4844384f29e41b11e1e |
| projected object fingerprint | 8cf35d9b790bfb96a18444c2a53c39f32f5daf598c00f8d27fc678b9f1fcc79f |
| proposition ids | No entries recorded |
| reason | t1&#58; invalid product dimensions; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; transformed source mismatch; tr6&#58; transformed source mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; t1&#58; invalid product dimensions; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; transformed source mismatch; tr6&#58; transformed source mismatch; Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;e1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed); Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;e2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;18a9256692cffe03abdab6a5 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1<br>e2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;923dd4844384f29e41b11e1e |
| projected object fingerprint | 88e288ce6887c72e19957c4e311bedc8e2ac5588660a12630579e870c70d1b1a |
| proposition ids | claim&#58;p1<br>claim&#58;p2 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;44f89a41f11b2196a80e3f21 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e2 |
| field | phase8.phase7&#95;controls.value&#95;origin&#95;provenance |
| mandatory | true |
| material | true |
| position ids | p9position&#58;923dd4844384f29e41b11e1e |
| projected object fingerprint | 388d1dfc568839ced55d928d67778f940487c3e8b01c21b018fa7878a837d50f |
| proposition ids | No entries recorded |
| reason | client-visible value &#x27;e2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;66098b8f98123ae8a7cc9bbf |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;923dd4844384f29e41b11e1e |
| projected object fingerprint | 6bd5cdc15fd09c2af9d0a2c8257b08408f909b1a2e93088b737616d9a18b2a0c |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; t1&#58; invalid product dimensions; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; transformed source mismatch; tr6&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;fdc5080ce1170d419672d1fd |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; t1&#58; invalid product dimensions; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; transformed source mismatch; tr6&#58; transformed source mismatch |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

### Findings&#58; value&#95;origin&#95;provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / check | VF |
|  / 1 / client finding id | cf1 |
|  / 1 / code | unresolved&#95;value&#95;origin |
|  / 1 / detail | client-visible value &#x27;e1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
|  / 1 / refs | e1 |
|  / 1 / severity | critical |
|  / 2 / check | VF |
|  / 2 / client finding id | cf2 |
|  / 2 / code | unresolved&#95;value&#95;origin |
|  / 2 / detail | client-visible value &#x27;e2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
|  / 2 / refs | e2 |
|  / 2 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 74f8c0f4bedac504b42d35a80614149780570976ef96ee60d5c86cbf4959f580 |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 38603c64d7daf5e3fa35dab630fb3a9f7bb793250d0c1cfd2b2cb56ea76a1d79 |
| execution evidence / 1 / attempt ids | attempt-009 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 9589c78395f6b187b91edb965cfcd996b47f712eeba902f413e13a97195f0502 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 103890 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 45436 |
| execution evidence / 1 / message id | msg&#95;011CfuSFzdKoqmpYukw9MpnV |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011CfuSFz9oTZQmSx8XbDFR6 |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 218176 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-sonnet-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11105 |
| execution evidence / 1 / usage / output tokens | 8168 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 38d25af7fe1fef7b110fbcad00f93f2a4948109f0ef5268dbbe1d74155b6a166 |
| ledger fingerprint | a419207a7e0192598a072c2b695e33d7a1d0f3bd52be7c0559df875e34e8cf89 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11105 |
| providers / 1 / usage / output tokens | 8168 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 48cc01b5b0ff056ef11a9e3ffbed0ae101fdfba4d198d70e6adbb2afb166ec09 |
| run id | e047d4df-f1b6-4cc9-bdef-bd2d084f57f7 |
| selected position id | p9position&#58;923dd4844384f29e41b11e1e |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

