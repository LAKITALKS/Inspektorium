# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;34&#58;24.020041+00&#58;00 |
| parent | Not supplied |
| record fingerprint | b500e282e46fb6d04709fb6bbb789ccc8a2edbd7679729f39038a46f0081cb34 |
| revision | 3d93024c-d7ae-4a66-9162-ff6eca582338 |
| selected position id | p9position&#58;0bdfa0464f93b6e77bce307a |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-004 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 3a0259ff710386648302c669e97fbb0176d92d45b2026cd0c6ac16b10968cfc5 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 8856 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 57941 |
|  / 1 / message id | msg&#95;011CfuRwogFot61eYAgyKwiA |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;1 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011CfuRwnxr5Ha4V1dVUXdUW |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 10896 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-haiku-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11032 |
|  / 1 / usage / output tokens | 15505 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The virtual tutoring program improved struggling students' reading progress or reduced their school absenteeism.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 246cf9f13d09d7cdc83068f66b29e2050e3571e48998a839b807e29d8fba14ad |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | e805bebbdc3033d149dc3cf280eddb23b9c0ff8611642889ddc35b6cab72735c |
| reasons | empty or missing declared required proposition set<br>ev1&#58; identification argument is not source-bound<br>ev2&#58; identification argument is not source-bound<br>claim&#58;p2&#58; internal finding/evidence trace mismatch<br>claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace<br>tr&#58;extract&#58;p1&#58; unresolved transformation origin<br>tr&#58;extract&#58;p2&#58; unresolved transformation origin<br>tr&#58;internal&#58;p1&#58; transformed source mismatch<br>tr&#58;internal&#58;p2&#58; transformed source mismatch<br>tr&#58;internal&#58;p2&#58; internal target mismatch<br>tr&#58;summary&#58;cf1&#58; transformed source mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; empty or missing declared required proposition set; ev1&#58; identification argument is not source-bound; ev2&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; tr&#58;extract&#58;p1&#58; unresolved transformation origin; tr&#58;extract&#58;p2&#58; unresolved transformation origin; tr&#58;internal&#58;p1&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; internal target mismatch; tr&#58;summary&#58;cf1&#58; transformed source mismatch<br>Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| record fingerprint | 66fa9805b4f7371b45d64e87df917e6d424d7c66862b71dfe6b35b2a81ee3232 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev1<br>ev2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1<br>claim&#58;p2 |
| represented trigger analysis / reason | The causal wording (&#x27;improved&#x27;) rests on a randomized design, so no causal inference from noncausal evidence is triggered. No mechanism is described and no mechanism-to-outcome step is used. The completer-based result is a limitation for scope, not a taxonomy trigger, and the reading outcome is the human-relevant benefit that the supplied trial measures. |
| represented trigger analysis / trigger evidence id | ev1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | A randomized controlled trial tested a virtual reading tutoring program in a rural school district. |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Propositions extracted from the supplied task prompt by splitting the disjunction at &#x27;or&#x27;; no external source used. |
| logic / children / 1 / children | No entries recorded |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / children | No entries recorded |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | or |
| logic / proposition id | Not supplied |
| provenance id | prov&#58;claim |
| required proposition ids | No entries recorded |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | population<br>endpoint<br>comparison |
| materiality | required |
| not applicable | No entries recorded |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| reason | Randomized trial reports reading-progress gains against controls for students completing about forty sessions. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied context report improved reading progress among struggling students receiving the virtual tutoring program? |
| search scope ids | scope&#58;context |
| uncertainty | Completer-based result; no intention-to-treat figure in context.<br>Generalisation from completers to all struggling students not established. |

Quoted proposition; this is represented input, not a release assertion.

```
The virtual tutoring program improved struggling students' reading progress.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 75 |
| start | 29 |
| text | improved struggling students&#x27; reading progress |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | Not supplied |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | improvement |
| effect magnitude | Not supplied |
| endpoint | reading progress |
| endpoint type | Not supplied |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | virtual tutoring program |
| population | struggling students |
| relation | improved |
| route | Not supplied |
| species | Not supplied |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | RCT design tests the program against controls for reading progress; population is struggling elementary students in a rural district. |
|  / 1 / search scope id | Not supplied |
|  / 2 / binding id | b2 |
|  / 2 / directness | partial |
|  / 2 / evidence id | ev2 |
|  / 2 / observation | support |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | Reports reading gains for completers of about forty sessions, not for all struggling students enrolled; completer comparison is not an all-enrolled effect. |
|  / 2 / search scope id | Not supplied |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | endpoint |
| materiality | required |
| not applicable | No entries recorded |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p2 |
| provenance id | prov&#58;claim |
| reason | No absenteeism outcome appears in the supplied context, so the disjunct is unknown. |
| reported verdict | unknown |
| required bridge ids | No entries recorded |
| search question | Does the supplied context report reduced school absenteeism from the virtual tutoring program? |
| search scope ids | scope&#58;context |
| uncertainty | Absence of a supplied result is not evidence of no effect. |

Quoted proposition; this is represented input, not a release assertion.

```
The virtual tutoring program reduced their school absenteeism.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 111 |
| start | 79 |
| text | reduced their school absenteeism |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | Not supplied |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | reduction |
| effect magnitude | Not supplied |
| endpoint | school absenteeism |
| endpoint type | Not supplied |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | virtual tutoring program |
| population | struggling students |
| relation | reduced |
| route | Not supplied |
| species | Not supplied |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b3 |
|  / 1 / directness | unknown |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The supplied trial description does not mention absenteeism; no absenteeism result is found in the supplied context. |
|  / 1 / search scope id | scope&#58;context |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation tr&#58;extract&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes | No entries recorded |
| from proposition ids | No entries recorded |
| from text | improved struggling students&#x27; reading progress |
| reason | Extracts the reading-progress disjunct from the original span; intervention and population restated from the prompt. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / certainty | Not supplied |
| to attributes / comparator | Not supplied |
| to attributes / comparison | Not supplied |
| to attributes / dose | Not supplied |
| to attributes / effect basis | Not supplied |
| to attributes / effect direction | improvement |
| to attributes / effect magnitude | Not supplied |
| to attributes / endpoint | reading progress |
| to attributes / endpoint type | Not supplied |
| to attributes / follow up | Not supplied |
| to attributes / formulation | Not supplied |
| to attributes / intervention | virtual tutoring program |
| to attributes / population | struggling students |
| to attributes / relation | improved |
| to attributes / route | Not supplied |
| to attributes / species | Not supplied |
| to text | The virtual tutoring program improved struggling students&#x27; reading progress. |
| transformation id | tr&#58;extract&#58;p1 |

### Transformation tr&#58;extract&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes | No entries recorded |
| from proposition ids | No entries recorded |
| from text | reduced their school absenteeism |
| reason | Extracts the absenteeism disjunct from the original span; &#x27;their&#x27; is resolved to struggling students by the sentence. |
| stage | extraction |
| target id | claim&#58;p2 |
| to attributes / certainty | Not supplied |
| to attributes / comparator | Not supplied |
| to attributes / comparison | Not supplied |
| to attributes / dose | Not supplied |
| to attributes / effect basis | Not supplied |
| to attributes / effect direction | reduction |
| to attributes / effect magnitude | Not supplied |
| to attributes / endpoint | school absenteeism |
| to attributes / endpoint type | Not supplied |
| to attributes / follow up | Not supplied |
| to attributes / formulation | Not supplied |
| to attributes / intervention | virtual tutoring program |
| to attributes / population | struggling students |
| to attributes / relation | reduced |
| to attributes / route | Not supplied |
| to attributes / species | Not supplied |
| to text | The virtual tutoring program reduced their school absenteeism. |
| transformation id | tr&#58;extract&#58;p2 |

### Transformation tr&#58;search&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | improved |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress. |
| reason | Unchanged semantic content; converted to a question for inspection of the supplied scope. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the supplied context report improved reading progress among struggling students receiving the virtual tutoring program? |
| transformation id | tr&#58;search&#58;p1 |

### Transformation tr&#58;search&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | reduction |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | reduced |
| from proposition ids | claim&#58;p2 |
| from text | The virtual tutoring program reduced their school absenteeism. |
| reason | Unchanged semantic content; the question is inspected against the supplied context only. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Does the supplied context report reduced school absenteeism from the virtual tutoring program? |
| transformation id | tr&#58;search&#58;p2 |

### Transformation tr&#58;internal&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | improved |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress. |
| reason | Internal verdict for the reading disjunct; the verdict summary records the completer limitation. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The virtual tutoring program improved struggling students&#x27; reading progress.<br>Supported by the supplied RCT for students completing about forty sessions. The completer comparison does not by itself establish an effect for all enrolled students. |
| transformation id | tr&#58;internal&#58;p1 |

### Transformation tr&#58;internal&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | unknown |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | reduced |
| from proposition ids | claim&#58;p2 |
| from text | The virtual tutoring program reduced their school absenteeism. |
| reason | Absence of supplied evidence is recorded as unknown, not as a negative finding. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | The virtual tutoring program reduced their school absenteeism.<br>No absenteeism result appears in the supplied context. Unknown, not disproven. |
| transformation id | tr&#58;internal&#58;p2 |

### Transformation tr&#58;summary&#58;cf1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from attributes / comparison | Not supplied |
| from attributes / endpoint | reading progress |
| from attributes / intervention | virtual tutoring program |
| from attributes / population | struggling students |
| from attributes / relation | improved |
| from proposition ids | claim&#58;p1 |
| from text | improved struggling students&#x27; reading progress |
| reason | Narrows the population from struggling students to completers of about forty sessions, and records the absenteeism disjunct as not assessed rather than as supported. |
| stage | summary |
| target id | cf&#58;claim&#58;p1 |
| to attributes / comparison | completers versus control |
| to attributes / endpoint | reading progress |
| to attributes / intervention | virtual tutoring program |
| to attributes / population | students who completed around forty sessions |
| to attributes / relation | improved |
| to text | The virtual tutoring program improved reading progress for students who completed around forty sessions.<br>The supplied randomized trial reports about two additional months of reading progress for students who completed around forty sessions, compared with controls. The supplied material says nothing about school absenteeism, so that part of the original claim is not assessed here. |
| transformation id | tr&#58;summary&#58;cf1 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading progress |
| evidence id | ev1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized controlled trial tested a virtual reading tutoring program in a rural school district.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | control condition |
| attributes / comparison | randomized versus control |
| attributes / dose | around forty sessions for completers |
| attributes / effect basis | Not supplied |
| attributes / effect direction | Not supplied |
| attributes / effect magnitude | Not supplied |
| attributes / endpoint | reading progress |
| attributes / endpoint type | Not supplied |
| attributes / follow up | ten-week sessions |
| attributes / formulation | Not supplied |
| attributes / intervention | virtual reading tutoring program with live online tutors in small groups, ten-week sessions |
| attributes / population | struggling elementary students in a rural school district |
| attributes / relation | Not supplied |
| attributes / route | Not supplied |
| attributes / species | Not supplied |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Only the supplied description is available; sample size, attrition and intention-to-treat results are not reported. |
| evidence id | ev1 |
| evidence type | controlled&#95;intervention |
| identification argument | Randomisation to condition is stated in the supplied description. |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | randomized controlled trial report |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading progress |
| evidence id | ev2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | roughly two additional months of reading progress |
| role | supporting |
| source id | context |
| value origin | reported |

Evidence text and exact source reference (identical)&#58;

```
Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | peers in the control condition |
| attributes / comparison | completers versus control |
| attributes / dose | around forty sessions |
| attributes / effect basis | reported gain versus control peers |
| attributes / effect direction | improvement |
| attributes / effect magnitude | roughly two additional months |
| attributes / endpoint | reading progress |
| attributes / endpoint type | Not supplied |
| attributes / follow up | Not supplied |
| attributes / formulation | Not supplied |
| attributes / intervention | virtual reading tutoring program |
| attributes / population | students who completed around forty tutoring sessions |
| attributes / relation | gain versus control |
| attributes / route | Not supplied |
| attributes / species | Not supplied |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Completion is post-randomisation, so the completer comparison may be confounded by completion.<br>Relative gain reported without absolute baseline or variance. |
| evidence id | ev2 |
| evidence type | controlled&#95;intervention |
| identification argument | Completer comparison is post-randomisation selection; the randomised comparison is in ev1. |
| identification evidence ids | ev1 |
| quality | Not supplied |
| randomized | Not supplied |
| source role | trial outcome result |
| study id | Not supplied |
| underlying evidence ids | ev1 |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | absenteeism<br>school absenteeism<br>reading progress |
|  / 1 / resources | supplied task context |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied context only; no external search executed |
|  / 1 / search scope id | scope&#58;context |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg&#58;p2 |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p2 |
|  / 1 / proposition | No absenteeism result appears in the supplied context. |
|  / 1 / search scope id | scope&#58;context |
|  / 1 / source local evidence ids | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized controlled trial tested a virtual reading tutoring program in a rural school district. The program paired live online tutors with small groups of struggling elementary students for ten-week sessions. Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition. Even those attending fewer sessions showed modest gains. Researchers emphasised that consistent participation was critical and highlighted that the program delivered results at a lower cost than typical high-dose tutoring.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The virtual tutoring program improved struggling students&#x27; reading progress or reduced their school absenteeism. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | moderate; completer-based result, no intention-to-treat figure supplied |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | The virtual tutoring program improved struggling students&#x27; reading progress. |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / supporting evidence ids | ev1<br>ev2 |
|  / 1 / verdict summary | Supported by the supplied RCT for students completing about forty sessions. The completer comparison does not by itself establish an effect for all enrolled students. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status | unknown |
|  / 2 / contrary evidence ids | No entries recorded |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | Not supplied |
|  / 2 / proposition | The virtual tutoring program reduced school absenteeism. |
|  / 2 / provenance id | prov&#58;claim |
|  / 2 / supporting evidence ids | No entries recorded |
|  / 2 / verdict summary | No absenteeism result appears in the supplied context. Unknown, not disproven. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The supplied randomized trial reports about two additional months of reading progress for students who completed around forty sessions, compared with controls. The supplied material says nothing about school absenteeism, so that part of the original claim is not assessed here. |
|  / 1 / client finding id | cf&#58;claim&#58;p1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The virtual tutoring program improved reading progress for students who completed around forty sessions. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / referenced evidence ids | ev1<br>ev2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 1b9ea45528ea60738a96156decd1f10d05048f5a529c0f2cf621bb45fee64c76 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;0bdfa0464f93b6e77bce307a

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;0bdfa0464f93b6e77bce307a |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | e805bebbdc3033d149dc3cf280eddb23b9c0ff8611642889ddc35b6cab72735c |
| run id | c5d23b46-2bdd-4219-972c-11a793e12863 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11032 |
| usage / output tokens | 15505 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;0bdfa0464f93b6e77bce307a |
| projected object fingerprint | 89da758ef9b6d4c83bbc907f8c71504813c4688bca9a7c6b1525deaf9d08a7ab |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; empty or missing declared required proposition set; ev1&#58; identification argument is not source-bound; ev2&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; tr&#58;extract&#58;p1&#58; unresolved transformation origin; tr&#58;extract&#58;p2&#58; unresolved transformation origin; tr&#58;internal&#58;p1&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; internal target mismatch; tr&#58;summary&#58;cf1&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;6d020e5031ef715763f9c317 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;0bdfa0464f93b6e77bce307a |
| projected object fingerprint | 0d99ef879232237f167d5412e2c9d67597c62cfb6988ae12f529ac460e561901 |
| proposition ids | No entries recorded |
| reason | empty or missing declared required proposition set; ev1&#58; identification argument is not source-bound; ev2&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; tr&#58;extract&#58;p1&#58; unresolved transformation origin; tr&#58;extract&#58;p2&#58; unresolved transformation origin; tr&#58;internal&#58;p1&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; internal target mismatch; tr&#58;summary&#58;cf1&#58; transformed source mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; empty or missing declared required proposition set; ev1&#58; identification argument is not source-bound; ev2&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; tr&#58;extract&#58;p1&#58; unresolved transformation origin; tr&#58;extract&#58;p2&#58; unresolved transformation origin; tr&#58;internal&#58;p1&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; internal target mismatch; tr&#58;summary&#58;cf1&#58; transformed source mismatch; Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;7619c26a87a9c59c9943575b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1<br>ev2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;0bdfa0464f93b6e77bce307a |
| projected object fingerprint | 8ff3a88756a8cbb1bc6f88d1052427be241ddc37450a0ff775dc74bc5eda594b |
| proposition ids | claim&#58;p1<br>claim&#58;p2 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;b2a10de80de7702bca0aab40 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev2 |
| field | phase8.phase7&#95;controls.value&#95;origin&#95;provenance |
| mandatory | true |
| material | true |
| position ids | p9position&#58;0bdfa0464f93b6e77bce307a |
| projected object fingerprint | c9b23c29a83c797e220f9af49666ee9c4e3eabf5e304c2226f659577c94a33d9 |
| proposition ids | No entries recorded |
| reason | client-visible value &#x27;ev2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;b68cdd7f2a64bc260771e886 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; empty or missing declared required proposition set; ev1&#58; identification argument is not source-bound; ev2&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; tr&#58;extract&#58;p1&#58; unresolved transformation origin; tr&#58;extract&#58;p2&#58; unresolved transformation origin; tr&#58;internal&#58;p1&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; transformed source mismatch; tr&#58;internal&#58;p2&#58; internal target mismatch; tr&#58;summary&#58;cf1&#58; transformed source mismatch |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

### Findings&#58; value&#95;origin&#95;provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / check | VF |
|  / 1 / client finding id | cf&#58;claim&#58;p1 |
|  / 1 / code | unresolved&#95;value&#95;origin |
|  / 1 / detail | client-visible value &#x27;ev2&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
|  / 1 / refs | ev2 |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 786a0cb8aab5a03b32d06746ceb07d6ced04d6900e607803242a490b388d0e66 |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 8b74d47167c59c87aa995751beb1043b50c644e54c3574c5395840a8ff1ad61e |
| execution evidence / 1 / attempt ids | attempt-004 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 3a0259ff710386648302c669e97fbb0176d92d45b2026cd0c6ac16b10968cfc5 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 8856 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 57941 |
| execution evidence / 1 / message id | msg&#95;011CfuRwogFot61eYAgyKwiA |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011CfuRwnxr5Ha4V1dVUXdUW |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 10896 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-haiku-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11032 |
| execution evidence / 1 / usage / output tokens | 15505 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 77c95aed75c1d8563c7cf5f03b5c1a0345cdd58b50d13563d519cc2dd49284bb |
| ledger fingerprint | c5658f3b01f4bb2e0699e3710ecdd5d8cfad446549f059220c3aea9e10676754 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11032 |
| providers / 1 / usage / output tokens | 15505 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 1b9ea45528ea60738a96156decd1f10d05048f5a529c0f2cf621bb45fee64c76 |
| run id | c5d23b46-2bdd-4219-972c-11a793e12863 |
| selected position id | p9position&#58;0bdfa0464f93b6e77bce307a |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

