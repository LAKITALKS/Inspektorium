# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;35&#58;44.101309+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 26d636cef3ae5c9302ffaea64684c2427e6e0cfab2556b90a5ff259dd2bc4564 |
| revision | f1708c7b-f7b1-4c31-97b5-c6ab624d07cc |
| selected position id | p9position&#58;7c9fbbc10e8619e7c3dc83b5 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-006 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | dbc6e3ed2b0fb3aa32017cc972c658ea76cb7808b7af6cd92ed46b65fbf887da |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 6672 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 40939 |
|  / 1 / message id | msg&#95;011CfuS4xS4DBx22vo7WmKXF |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;1 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011CfuS4x6UYKNasEaPtE7VV |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 10916 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-haiku-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11142 |
|  / 1 / usage / output tokens | 11115 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Eating a good breakfast every morning makes you lose weight.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 609ee28c8d2fb302457ee4550b78e951b6c05250ac44fdaf263f5cdc58dd02e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | correlation&#95;vs&#95;causation |
| raw response sha256 | 3aa9e25a88a0554e3cf2a1dabac0b7e60eb9c0706cb09b15e27db69d01a7af52 |
| reasons | ev2&#58; identification argument is not source-bound<br>claim&#58;p1&#58; invalid material dimension<br>t1&#58; unresolved transformation origin<br>t2&#58; transformed source mismatch<br>t3&#58; transformed source mismatch<br>t4&#58; transformed source mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; ev2&#58; identification argument is not source-bound; claim&#58;p1&#58; invalid material dimension; t1&#58; unresolved transformation origin; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch |
| record fingerprint | def986bf4575f7d16f995e3b8b0a8b963654ea86348cc43f72b774242cc763e1 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | correlation&#95;vs&#95;causation |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | causal&#95;inference |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev1<br>ev2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | true |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The causal weight-loss claim rests on an observational association between breakfast skipping and weight; the RCT evidence in the context contradicts the causal claim. No biological mechanism is described in the supplied material. |
| represented trigger analysis / trigger evidence id | ev1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | cross-sectional and prospective OBSERVATIONAL studies (breakfast skippers differ from eaters in many health and lifestyle behaviours) |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single causal proposition extracted from the task prompt; context used only for bound evidence. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | causal relation<br>intervention<br>endpoint |
| materiality | required |
| not applicable / comparator | not stated in the original claim |
| observation target | contradiction |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| reason | The causal weight-loss claim is contradicted by RCT evidence and rests on noncausal observational association. |
| reported verdict | unknown |
| required bridge ids | bridge&#58;p1&#58;causal |
| search question | Within the supplied context, does any evidence show that assigning or eating breakfast causes weight loss? |
| search scope ids | sc1 |
| uncertainty | &#x27;good breakfast&#x27; undefined<br>supplied material only |

Quoted proposition; this is represented input, not a release assertion.

```
Eating a good breakfast every morning causes weight loss.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 60 |
| start | 0 |
| text | Eating a good breakfast every morning makes you lose weight. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparator | Not supplied |
| comparison | Not supplied |
| effect direction | loss |
| endpoint | weight loss |
| endpoint type | body weight |
| intervention | eating a good breakfast every morning |
| population | Not supplied |
| relation | causal (makes) |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p1&#58;ev1 |
|  / 1 / directness | indirect |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Observational association of breakfast skipping with weight cannot identify a causal effect of eating breakfast. |
|  / 1 / search scope id | sc1 |
|  / 2 / binding id | bind&#58;p1&#58;ev2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | ev2 |
|  / 2 / observation | contradiction |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | RCT meta-analysis found assigning breakfast did not cause weight loss. |
|  / 2 / search scope id | sc1 |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | bridge&#58;p1&#58;causal |
|  / 1 / conclusion proposition id | claim&#58;p1 |
|  / 1 / dimensions | causal identification<br>confounding |
|  / 1 / evidence ids | ev1 |
|  / 1 / kind | causal&#95;identification |
|  / 1 / premise proposition ids | No entries recorded |
|  / 1 / reason | Observational association does not identify a causal effect of eating breakfast on weight. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | true |
| from attributes | No entries recorded |
| from proposition ids | No entries recorded |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | Restates the claim as a single causal proposition without changing its meaning. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / endpoint | weight loss |
| to attributes / relation | causal (makes) |
| to text | Eating a good breakfast every morning causes weight loss. |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes / endpoint | weight loss |
| from attributes / relation | causal (makes) |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning causes weight loss. |
| reason | Search question scoped to supplied material only; no external search executed. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to attributes / comparison | breakfast vs skipping breakfast |
| to attributes / endpoint | weight loss |
| to attributes / relation | causal test |
| to text | Within the supplied context, does any evidence show that assigning or eating breakfast causes weight loss? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| asserts whole claim | true |
| from and to attributes (identical) / endpoint | weight loss |
| from and to attributes (identical) / relation | causal (makes) |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | Internal finding with verdict summary matching the bound evidence. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Eating a good breakfast every morning causes weight loss.<br>Contradicted&#58; the supplied RCT meta-analysis found assigning breakfast did not cause weight loss; the supporting observational association cannot establish causation. |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| asserts whole claim | true |
| from and to attributes (identical) / endpoint | weight loss |
| from and to attributes (identical) / relation | causal (makes) |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning causes weight loss. |
| reason | Client summary restates the internal contradicted verdict and does not add stronger claims. |
| stage | summary |
| target id | client&#58;1 |
| to text | The claim that eating a good breakfast every morning makes you lose weight is contradicted by the supplied randomized trial evidence.<br>The supporting observational association does not establish causation; the supplied meta-analysis of RCTs found assigning breakfast did not cause weight loss. |
| transformation id | t4 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | body weight (association) |
| evidence id | ev1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
cross-sectional and prospective OBSERVATIONAL studies (breakfast skippers differ from eaters in many health and lifestyle behaviours)
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / effect direction | breakfast skippers weigh more |
| attributes / endpoint | body weight |
| attributes / relation | association |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | confounding by health and lifestyle behaviours |
| evidence id | ev1 |
| evidence type | observational |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | false |
| source role | context&#58; cross-sectional and prospective observational studies |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | weight loss |
| evidence id | ev2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | contradictory |
| source id | context |
| value origin | source&#95;reported |

Evidence text&#58;

```
a systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) found that assigning people to eat breakfast did not cause weight loss
```

Exact source reference&#58;

```
assigning people to eat breakfast did not cause weight loss
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | assigned to skip breakfast |
| attributes / comparison | breakfast vs skipping breakfast |
| attributes / effect direction | no weight loss; slightly more weight with breakfast |
| attributes / endpoint | weight |
| attributes / intervention | assigned to eat breakfast |
| attributes / population | adults |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No entries recorded |
| evidence id | ev2 |
| evidence type | controlled&#95;intervention |
| identification argument | randomized assignment |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | context&#58; systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | breakfast<br>weight loss<br>causal effect |
|  / 1 / resources | task&#95;context |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied material only; no external search executed |
|  / 1 / search scope id | sc1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A nutrition feature advises: "Breakfast is the most important meal of the day. Studies show people who skip breakfast weigh more, so skipping breakfast makes you gain weight — eat a good breakfast every morning and you will lose weight."

The "people who skip breakfast weigh more" finding comes from cross-sectional and prospective OBSERVATIONAL studies (breakfast skippers differ from eaters in many health and lifestyle behaviours). Randomized controlled trials tell a different story: a systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) found that assigning people to eat breakfast did not cause weight loss — adults assigned to eat breakfast consumed more total daily calories and, if anything, weighed slightly more than those assigned to skip it — providing no support for eating breakfast as a weight-loss strategy.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | moderate; supplied material only |
|  / 1 / contrary evidence ids | ev2 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | Eating a good breakfast every morning causes weight loss. |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / supporting evidence ids | ev1 |
|  / 1 / verdict summary | Contradicted&#58; the supplied RCT meta-analysis found assigning breakfast did not cause weight loss; the supporting observational association cannot establish causation. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The supporting observational association does not establish causation; the supplied meta-analysis of RCTs found assigning breakfast did not cause weight loss. |
|  / 1 / client finding id | client&#58;1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The claim that eating a good breakfast every morning makes you lose weight is contradicted by the supplied randomized trial evidence. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / referenced evidence ids | ev1<br>ev2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 72e083db935b45e346519c3ef1682117a9b422cfab5f316eae467f7ba400be21 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;7c9fbbc10e8619e7c3dc83b5

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | correlation&#95;vs&#95;causation |
| position id | p9position&#58;7c9fbbc10e8619e7c3dc83b5 |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 3aa9e25a88a0554e3cf2a1dabac0b7e60eb9c0706cb09b15e27db69d01a7af52 |
| run id | 1b68df8c-e022-41b8-a8aa-7f3faefacf2d |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11142 |
| usage / output tokens | 11115 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1<br>ev2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7c9fbbc10e8619e7c3dc83b5 |
| projected object fingerprint | 46db1e94209ef83a497b8495ce8c478006f934047bdca24e47c9854c33b8af48 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;1009ea987b975fb48851b10a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7c9fbbc10e8619e7c3dc83b5 |
| projected object fingerprint | 4710cf80dba1112c72799b618d97ff4b35a0dedfeb7ebfd9fb5190694e6af193 |
| proposition ids | No entries recorded |
| reason | ev2&#58; identification argument is not source-bound; claim&#58;p1&#58; invalid material dimension; t1&#58; unresolved transformation origin; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; ev2&#58; identification argument is not source-bound; claim&#58;p1&#58; invalid material dimension; t1&#58; unresolved transformation origin; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;160c0a6b3928e186ff42c042 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7c9fbbc10e8619e7c3dc83b5 |
| projected object fingerprint | f31c6ef64ece24da990a2e35aae74c5815826fc977af2aa42a71228d19145c06 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; ev2&#58; identification argument is not source-bound; claim&#58;p1&#58; invalid material dimension; t1&#58; unresolved transformation origin; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;fd358a97b7a43feee1637d51 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; ev2&#58; identification argument is not source-bound; claim&#58;p1&#58; invalid material dimension; t1&#58; unresolved transformation origin; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | eb9b4169351b92621e693927d6601d0f57611c81c7798ec82a9fb1c350e739dc |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 3db2b2de237206f93932716ba161d047dbdbde74ca7885e0790eff40a889bc46 |
| execution evidence / 1 / attempt ids | attempt-006 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | dbc6e3ed2b0fb3aa32017cc972c658ea76cb7808b7af6cd92ed46b65fbf887da |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 6672 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 40939 |
| execution evidence / 1 / message id | msg&#95;011CfuS4xS4DBx22vo7WmKXF |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011CfuS4x6UYKNasEaPtE7VV |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 10916 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-haiku-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11142 |
| execution evidence / 1 / usage / output tokens | 11115 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 708e656386b9545c47cc8b478bddb08eea8281957c4ca503a0f284ce53b10632 |
| ledger fingerprint | d653cbc09c19741a83e3421c9d4de19f2934112379ee51dc097447e24887b6e9 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | correlation&#95;vs&#95;causation |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11142 |
| providers / 1 / usage / output tokens | 11115 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 72e083db935b45e346519c3ef1682117a9b422cfab5f316eae467f7ba400be21 |
| run id | 1b68df8c-e022-41b8-a8aa-7f3faefacf2d |
| selected position id | p9position&#58;7c9fbbc10e8619e7c3dc83b5 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

