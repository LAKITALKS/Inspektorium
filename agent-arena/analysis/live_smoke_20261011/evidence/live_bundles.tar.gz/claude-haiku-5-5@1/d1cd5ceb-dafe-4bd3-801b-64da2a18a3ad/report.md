# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;31&#58;28.886060+00&#58;00 |
| parent | Not supplied |
| record fingerprint | ca148d0bc6770a415c68a2540c927c1ad81003fa9a5e4bcd4fe62cd8ae84b9ef |
| revision | d1cd5ceb-dafe-4bd3-801b-64da2a18a3ad |
| selected position id | p9position&#58;b1c765ebb5e20588663161e9 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-001 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | f4605c9652b70685c2929b0350f4ca8af9942ea00837e470bb9eddc7ad29995d |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 5127 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 29216 |
|  / 1 / message id | msg&#95;011CfuRm2jH2qwVSj2AqHXcX |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;1 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011CfuRm1vQt9VhvmoGJ5cof |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 10899 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-haiku-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11024 |
|  / 1 / usage / output tokens | 8048 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | bcad0619601626df989bae99790e409d0881b3482c83b67dd502802c0feceb18 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | 2884326ff765ed860130d15697dc52084addbd979e5838e62684efcfb2ea4f66 |
| reasons | invalid ledger&#58; 2 validation errors for PropositionLedger<br>final&#95;answer<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;solid&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>confidence<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=0.82, input&#95;type=float&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 2 validation errors for PropositionLedger<br>final&#95;answer<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;solid&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>confidence<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=0.82, input&#95;type=float&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| record fingerprint | c742e299b75b557894d538431f3b3d2c29a99700b503da0de6e0dce4c935f622 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | solid |
| represented trigger analysis / causal claim | false |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev1<br>ev2 |
| represented trigger analysis / implies human benefit | Not supplied |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The claim reports an observed comparison from a randomized design and makes no causal-identification or mechanism-to-outcome inference. Whether the reading advantage counts as a human benefit is not settled by the claim, so that trigger is left unknown. |
| represented trigger analysis / trigger evidence id | ev1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | had better reading proficiency than students who received regular instruction |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single required proposition extracted from the full task prompt; the proposition restates the claim without change. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | population<br>intervention<br>comparison<br>endpoint |
| materiality | required |
| not applicable / dose | not stated in the claim |
| not applicable / follow up | claim makes no duration assertion |
| not applicable / route | not applicable to school-based instruction |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | The randomized design and the reported reading-proficiency advantage for the program group directly support the observed comparison stated in the claim. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Did the supplied randomized study report better reading proficiency for students receiving weekly supplementary literacy instruction than for students receiving regular instruction? |
| search scope ids | No entries recorded |
| uncertainty | The claim omits the effect size reported in the context.<br>Persistence at 26 months and subgroup stability are not part of the claim and were not assessed. |

Quoted proposition; this is represented input, not a release assertion.

```
In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 187 |
| start | 0 |
| text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparator | regular instruction |
| comparison | randomized comparison against regular instruction |
| effect direction | favors program |
| effect magnitude | Not supplied |
| endpoint | reading proficiency |
| endpoint type | outcome |
| intervention | weekly supplementary literacy instruction |
| population | elementary school students |
| relation | better than |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Reports the program group ahead of the comparison group on reading proficiency at end of year one. |
|  / 1 / search scope id | Not supplied |
|  / 2 / binding id | bind2 |
|  / 2 / directness | partial |
|  / 2 / evidence id | ev2 |
|  / 2 / observation | support |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | Establishes the randomized design that the claim&#x27;s &#x27;randomized study&#x27; wording relies on; it does not itself show the outcome. |
|  / 2 / search scope id | Not supplied |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation tx1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | true |
| from and to text (identical) | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| from attributes | No entries recorded |
| from proposition ids | No entries recorded |
| reason | Unchanged extraction of the full claim into one proposition. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / comparator | regular instruction |
| to attributes / endpoint | reading proficiency |
| to attributes / intervention | weekly supplementary literacy instruction |
| to attributes / population | elementary school students |
| transformation id | tx1 |

### Transformation tx2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes | No entries recorded |
| from proposition ids | claim&#58;p1 |
| from text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| reason | Restated as a question over supplied material only; no external search executed. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to attributes / comparator | regular instruction |
| to attributes / endpoint | reading proficiency |
| to text | Did the supplied randomized study report better reading proficiency for students receiving weekly supplementary literacy instruction than for students receiving regular instruction? |
| transformation id | tx2 |

### Transformation tx3

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) | No entries recorded |
| from proposition ids | claim&#58;p1 |
| from text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| reason | Internal finding text plus its verdict summary; the asserted state matches the bound evidence. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.<br>Supported&#58; randomized assignment and an observed reading-proficiency advantage for the program group are both reported in the context. |
| transformation id | tx3 |

### Transformation tx4

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) | No entries recorded |
| from and to text (identical) | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| from proposition ids | claim&#58;p1 |
| reason | Client display claim restates the proposition unchanged; the client explanation is empty, so no added wording is asserted. |
| stage | summary |
| target id | client1 |
| transformation id | tx4 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading proficiency |
| evidence id | ev1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | two and a half months ahead at end of year one |
| role | supporting |
| source id | context |
| value origin | reported&#95;by&#95;source |

Evidence text&#58;

```
By the end of the first year, participants' reading proficiency was on average two and a half months ahead of the comparison group, and this advantage was still detectable 26 months later.
```

Exact source reference&#58;

```
participants' reading proficiency was on average two and a half months ahead of the comparison group
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | regular instruction |
| attributes / comparison | randomized comparison group |
| attributes / effect direction | favors program |
| attributes / effect magnitude | two and a half months ahead at end of year one |
| attributes / endpoint | reading proficiency |
| attributes / endpoint type | outcome |
| attributes / follow up | 26 months after end of year one |
| attributes / intervention | weekly supplementary literacy instruction over two school years |
| attributes / population | elementary school students |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Context does not give the attrition or analysis details. |
| evidence id | ev1 |
| evidence type | controlled&#95;intervention |
| identification argument | Random assignment to program or regular instruction. |
| identification evidence ids | ev2 |
| quality | Not supplied |
| randomized | true |
| source role | reported result of randomized comparison |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | design&#58; random assignment |
| evidence id | ev2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | reported&#95;by&#95;source |

Evidence text and exact source reference (identical)&#58;

```
Students were randomly assigned to either the program or regular instruction.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | regular instruction |
| attributes / comparison | random assignment |
| attributes / intervention | program assignment |
| attributes / population | students in the study |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No entries recorded |
| evidence id | ev2 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | design description |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A large-scale study investigated a literacy support program in which elementary school students received weekly supplementary instruction over two school years. Students were randomly assigned to either the program or regular instruction. By the end of the first year, participants' reading proficiency was on average two and a half months ahead of the comparison group, and this advantage was still detectable 26 months later. The researchers note that the effect remained stable across all age groups and that no systematic disadvantages were observed.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | high for the observed comparison as stated |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | supported |
|  / 1 / proposition | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | ev1<br>ev2 |
|  / 1 / verdict summary | Supported&#58; randomized assignment and an observed reading-proficiency advantage for the program group are both reported in the context. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | client1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | ev1<br>ev2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 093412b9e015e099236b7610fbe5b047260bda9174ab924a424050d6ae01fcb1 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;b1c765ebb5e20588663161e9

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;b1c765ebb5e20588663161e9 |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 2884326ff765ed860130d15697dc52084addbd979e5838e62684efcfb2ea4f66 |
| run id | e0719049-0ddd-40d1-8a91-406d76ad8433 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11024 |
| usage / output tokens | 8048 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1<br>ev2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;b1c765ebb5e20588663161e9 |
| projected object fingerprint | 941c288e8b773980b995510aa14431d6aabe4cf2c62de31c68c726cc0e5fe008 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;05405dd868bd453c7557d368 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1 |
| field | phase8.phase7&#95;controls.value&#95;origin&#95;provenance |
| mandatory | true |
| material | true |
| position ids | p9position&#58;b1c765ebb5e20588663161e9 |
| projected object fingerprint | 04e32bf35fc40964de0663cbd0442a0b6c8cfded5376a4ae2bf98d071f5fbc7e |
| proposition ids | No entries recorded |
| reason | client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;3b95fc1989db500011da19e9 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;b1c765ebb5e20588663161e9 |
| projected object fingerprint | 82388ba451bfc1a90f1956454e5285d42a964bb69b43b15edd7ae50f739f08d9 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; invalid ledger&#58; 2 validation errors for PropositionLedger<br>final&#95;answer<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;solid&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>confidence<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=0.82, input&#95;type=float&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;77ef2272f1088128dc0441a8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;b1c765ebb5e20588663161e9 |
| projected object fingerprint | 307d9a4af7b6c32b415ca59a0aa377722742c9b3bbb181d1b7562bae1b5c1343 |
| proposition ids | No entries recorded |
| reason | invalid ledger&#58; 2 validation errors for PropositionLedger<br>final&#95;answer<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;solid&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>confidence<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=0.82, input&#95;type=float&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 2 validation errors for PropositionLedger<br>final&#95;answer<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;solid&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>confidence<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=0.82, input&#95;type=float&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden; Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;f76b3d69d7561c64a56b0eea |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; invalid ledger&#58; 2 validation errors for PropositionLedger<br>final&#95;answer<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;solid&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>confidence<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=0.82, input&#95;type=float&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

### Findings&#58; value&#95;origin&#95;provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / check | VF |
|  / 1 / client finding id | client1 |
|  / 1 / code | unresolved&#95;value&#95;origin |
|  / 1 / detail | client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
|  / 1 / refs | ev1 |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 79a667081fb2175e5521e235f67b8b06d4bc9b7c156e388530400d80851a553c |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 4979ac0f192e4fc341d587bd27d0f095dd19980fde27d3505b156586310e1c54 |
| execution evidence / 1 / attempt ids | attempt-001 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | f4605c9652b70685c2929b0350f4ca8af9942ea00837e470bb9eddc7ad29995d |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 5127 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 29216 |
| execution evidence / 1 / message id | msg&#95;011CfuRm2jH2qwVSj2AqHXcX |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011CfuRm1vQt9VhvmoGJ5cof |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 10899 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-haiku-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11024 |
| execution evidence / 1 / usage / output tokens | 8048 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 623dce11258f5e614550f971b4e8d2f4541e6fdae2d08453bc8d0044fc3a5b7e |
| ledger fingerprint | 79dedfaa744e0c76afeecede12777e1843aff3bee749bfe307979fa531779813 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11024 |
| providers / 1 / usage / output tokens | 8048 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 093412b9e015e099236b7610fbe5b047260bda9174ab924a424050d6ae01fcb1 |
| run id | e0719049-0ddd-40d1-8a91-406d76ad8433 |
| selected position id | p9position&#58;b1c765ebb5e20588663161e9 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

