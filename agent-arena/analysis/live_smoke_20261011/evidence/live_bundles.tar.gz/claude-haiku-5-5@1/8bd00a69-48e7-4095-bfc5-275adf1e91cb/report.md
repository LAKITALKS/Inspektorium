# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;32&#58;36.543031+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 2c57013de295f040f083f84af2d3bcfd57723c680f30ced7fd84192500101f28 |
| revision | 8bd00a69-48e7-4095-bfc5-275adf1e91cb |
| selected position id | p9position&#58;2e9c44e4df02b8224de2e708 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-002 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | c37b777a18b6cf9870155d765c6051d417842918a61751edd8e7e504b168231e |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 6348 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 39348 |
|  / 1 / message id | msg&#95;011CfuRqFaZ4dpt6sLV8KjDU |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;1 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011CfuRqF7XNoL5W3Dw3mU1c |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 10859 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-haiku-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 10947 |
|  / 1 / usage / output tokens | 10505 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Compound X treats cancer in patients.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 112163c5e3b414878531e3c67842192acd46632c8d8f17f708205804341958e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | ea328dc46c89a8d06560aadd480c7d7e89cf5a08a535b2c0dca2602a7fa562ee |
| reasons | claim&#58;p1&#58; internal finding/evidence trace mismatch<br>claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace<br>t1&#58; unresolved transformation origin<br>t3&#58; internal target mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;cf&#58;claim&#58;p1&#x27; references evidence &#x27;ev2&#x27; that is not bound to parent finding &#x27;claim&#58;p1&#x27; (evidence used out of context)<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; t1&#58; unresolved transformation origin; t3&#58; internal target mismatch<br>Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| record fingerprint | e946abca15f740a6adb4535f468b51db68f195109d8ad73b8e0dc972f40f34e0 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev1<br>ev2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The claim asserts a patient treatment effect (causal and implying human benefit) from a single in vitro cell-killing result. The core error is overstatement of an in vitro result as clinical efficacy. No biological mechanism is described, so mechanism&#95;to&#95;outcome is not the core error. The noncausal-result field is unresolved because the source does not give the study design. |
| represented trigger analysis / trigger evidence id | ev1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | killed up to 90% of cultured human tumour cells in a petri dish within 48 hours |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single required proposition extracted from the task prompt; context used only for evidence and design description. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | population<br>endpoint |
| materiality | required |
| not applicable / comparator | no comparator stated in the claim |
| not applicable / dose | not stated in the claim |
| not applicable / route | not stated in the claim |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| reason | The only result is in vitro cytotoxicity, and no patient-level evidence is described. |
| reported verdict | unsupported |
| required bridge ids | bridge&#58;invitro&#95;to&#95;patient |
| search question | Is there patient-level clinical evidence in the supplied material that Compound X treats cancer in patients? |
| search scope ids | ss&#58;supplied |
| uncertainty | Study design, dose, controls and replication are not described in the press summary.<br>The claim may be true, but the supplied material does not establish it. |

Quoted proposition; this is represented input, not a release assertion.

```
Compound X treats cancer in patients.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 37 |
| start | 0 |
| text | Compound X treats cancer in patients. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| endpoint | cancer treatment |
| intervention | Compound X |
| population | patients |
| relation | treats |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | indirect |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | In vitro cell killing does not directly show treatment of cancer in patients. |
|  / 1 / search scope id | Not supplied |
|  / 2 / binding id | b2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | ev2 |
|  / 2 / observation | no&#95;evidence&#95;found |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | The supplied material states that no animal or human data are described. |
|  / 2 / search scope id | ss&#58;supplied |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | bridge&#58;invitro&#95;to&#95;patient |
|  / 1 / conclusion proposition id | claim&#58;p1 |
|  / 1 / dimensions | population<br>endpoint<br>intervention |
|  / 1 / evidence ids | ev1 |
|  / 1 / kind | semantic&#95;transfer |
|  / 1 / premise proposition ids | No entries recorded |
|  / 1 / reason | No documented transfer from cultured cells in a dish to patients with cancer is described in the supplied material. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | true |
| from attributes | No entries recorded |
| from proposition ids | No entries recorded |
| from text | concludes that Compound X &#x27;treats cancer&#x27; |
| reason | The press write-up says only &#x27;treats cancer&#x27; with no population; the prompt adds &#x27;in patients&#x27;, which narrows the scope to humans and is evaluated as stated. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / endpoint | cancer treatment |
| to attributes / intervention | Compound X |
| to attributes / population | patients |
| to attributes / relation | treats |
| to text | Compound X treats cancer in patients. |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | treats |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | Search question is restricted to the reviewed&#95;set of supplied material; no external search was executed. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Is there patient-level clinical evidence in the supplied material that Compound X treats cancer in patients? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | treats |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | Internal verdict is unsupported. The in vitro result does not establish patient treatment. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Compound X treats cancer in patients.<br>Unsupported&#58; the supplied material reports only in vitro cell killing and describes no animal or human data. |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from attributes / endpoint | cancer treatment |
| from attributes / intervention | Compound X |
| from attributes / population | patients |
| from attributes / relation | treats |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | Client summary states the source-local result without asserting that the compound is ineffective, which would be a proven-zero or disproof claim the evidence does not support. |
| stage | summary |
| target id | cf&#58;claim&#58;p1 |
| to attributes / endpoint | cancer treatment |
| to attributes / intervention | Compound X |
| to attributes / population | patients |
| to attributes / relation | not shown |
| to text | Compound X has not been shown to treat cancer in patients.<br>The supplied press summary reports only that Compound X killed cultured human tumour cells in a petri dish; it describes no animal or human data. |
| transformation id | t4 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | cell killing in vitro |
| evidence id | ev1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | up to 90% |
| role | supporting |
| source id | context |
| value origin | reported by source |

Evidence text and exact source reference (identical)&#58;

```
killed up to 90% of cultured human tumour cells in a petri dish within 48 hours
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / effect basis | press summary |
| attributes / effect direction | reduction in viable cells |
| attributes / effect magnitude | up to 90% |
| attributes / endpoint | cell killing up to 90% within 48 hours |
| attributes / endpoint type | in&#95;vitro |
| attributes / follow up | 48 hours |
| attributes / intervention | Compound X |
| attributes / population | cultured human tumour cells |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | no patients studied<br>design details not stated in source<br>press summary only |
| evidence id | ev1 |
| evidence type | in&#95;vitro |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | press summary reporting in vitro cytotoxicity |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | animal or human data |
| evidence id | ev2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | reported by source |

Evidence text and exact source reference (identical)&#58;

```
No animal or human data are described.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | animal or human data |
| attributes / relation | absence stated in source |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No entries recorded |
| evidence id | ev2 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | press summary statement that no animal or human data are described |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | supplied task context only |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied material only; no external search executed |
|  / 1 / search scope id | ss&#58;supplied |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg&#58;p1 |
|  / 1 / assertion scope | source&#95;local |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / proposition | No animal or human data are described in the supplied material. |
|  / 1 / search scope id | Not supplied |
|  / 1 / source local evidence ids | ev2 |

Captured context (source&#95;id&#58; context)&#58;

```
A press summary reports that Compound X, a plant-derived molecule, killed up to 90% of cultured human tumour cells in a petri dish within 48 hours. The write-up concludes that Compound X 'treats cancer' and could become a natural alternative to chemotherapy. No animal or human data are described.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Compound X treats cancer in patients. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | high for unsupported given supplied material |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | overclaim |
|  / 1 / proposition | Compound X treats cancer in patients. |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / supporting evidence ids | ev1 |
|  / 1 / verdict summary | Unsupported. The supplied material reports only in vitro cell killing and describes no animal or human data. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The supplied press summary reports only that Compound X killed cultured human tumour cells in a petri dish; it describes no animal or human data. |
|  / 1 / client finding id | cf&#58;claim&#58;p1 |
|  / 1 / client negative assertions / 1 / assertion id | neg&#58;p1 |
|  / 1 / client negative assertions / 1 / client scope | source&#95;local |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | Compound X has not been shown to treat cancer in patients. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / referenced evidence ids | ev1<br>ev2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 0eb56ee9891d4e83e814ce01a673422ec3b4adc2a98f6e67862abee0cf41bd25 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;2e9c44e4df02b8224de2e708

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;2e9c44e4df02b8224de2e708 |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | ea328dc46c89a8d06560aadd480c7d7e89cf5a08a535b2c0dca2602a7fa562ee |
| run id | 0675da1f-3734-4686-b85d-aca5f10bf756 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 10947 |
| usage / output tokens | 10505 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1<br>ev2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;2e9c44e4df02b8224de2e708 |
| projected object fingerprint | d5a642bf61dce2dcd9d35e2e0ab86f3086215b7c3e9fff8acb8e3db0eef9ddbe |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;412d651c5f11f75cdc632a45 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1 |
| field | phase8.phase7&#95;controls.value&#95;origin&#95;provenance |
| mandatory | true |
| material | true |
| position ids | p9position&#58;2e9c44e4df02b8224de2e708 |
| projected object fingerprint | aa5cb8287eb7060ea3ae8bd23cd3abe0a1124a4e8eab08f7e6caedec5d50262c |
| proposition ids | No entries recorded |
| reason | client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;76742ea28993ee487b62c341 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;2e9c44e4df02b8224de2e708 |
| projected object fingerprint | c7f3ff6a6fd460a2d4e92674ef508da9046004858b430aa05b1c22607311508e |
| proposition ids | No entries recorded |
| reason | claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; t1&#58; unresolved transformation origin; t3&#58; internal target mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;cf&#58;claim&#58;p1&#x27; references evidence &#x27;ev2&#x27; that is not bound to parent finding &#x27;claim&#58;p1&#x27; (evidence used out of context); Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; t1&#58; unresolved transformation origin; t3&#58; internal target mismatch; Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;c439195ac8a9bbe513595e95 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;2e9c44e4df02b8224de2e708 |
| projected object fingerprint | f275b1e67d7670f314bb038830dba881fe554601714f0d9b070bf7c0f6042939 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; t1&#58; unresolved transformation origin; t3&#58; internal target mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;d85c9c227a953fa49212daad |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;negative&#95;assertions |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | C |
|  / 1 / client finding id | cf&#58;claim&#58;p1 |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | client finding &#x27;cf&#58;claim&#58;p1&#x27; references evidence &#x27;ev2&#x27; that is not bound to parent finding &#x27;claim&#58;p1&#x27; (evidence used out of context) |
|  / 1 / refs | ev2 |
|  / 1 / severity | critical |
|  / 2 / check | P8 |
|  / 2 / client finding id |  |
|  / 2 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 2 / detail | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; t1&#58; unresolved transformation origin; t3&#58; internal target mismatch |
|  / 2 / refs | No entries recorded |
|  / 2 / severity | critical |

### Findings&#58; value&#95;origin&#95;provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / check | VF |
|  / 1 / client finding id | cf&#58;claim&#58;p1 |
|  / 1 / code | unresolved&#95;value&#95;origin |
|  / 1 / detail | client-visible value &#x27;ev1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
|  / 1 / refs | ev1 |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | e57ea4655c60080a6f3cd5bb76dd391b67cfe189ff82ca8b12991029ea0cd6de |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 5543e668eb115e136bf97af60c79d9e4ff403fafe5b2318bc501bd5bb94c0e21 |
| execution evidence / 1 / attempt ids | attempt-002 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | c37b777a18b6cf9870155d765c6051d417842918a61751edd8e7e504b168231e |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 6348 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 39348 |
| execution evidence / 1 / message id | msg&#95;011CfuRqFaZ4dpt6sLV8KjDU |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011CfuRqF7XNoL5W3Dw3mU1c |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 10859 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-haiku-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 10947 |
| execution evidence / 1 / usage / output tokens | 10505 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 4c7ea357ae5bc4fc582048c362f5bdffabeb031cf56306a5f1c0587bc8aaaad4 |
| ledger fingerprint | a2a09225f1929d573fa283a3b8a9ea54b2c5d726e0837bc4fe3b6dff5a662ce4 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 10947 |
| providers / 1 / usage / output tokens | 10505 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 0eb56ee9891d4e83e814ce01a673422ec3b4adc2a98f6e67862abee0cf41bd25 |
| run id | 0675da1f-3734-4686-b85d-aca5f10bf756 |
| selected position id | p9position&#58;2e9c44e4df02b8224de2e708 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

