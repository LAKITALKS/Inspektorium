# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;41&#58;08.951055+00&#58;00 |
| parent | Not supplied |
| record fingerprint | d6be41e29bf231ef8c9f7a47b70738c0847976cccbbef57b72c76bf500f1ebdb |
| revision | f810d231-2865-4168-ba7c-15ec9f634e07 |
| selected position id | p9position&#58;97225761a9bba7e5cbd1a238 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-007 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 8704cc3744274e7ba25067316fbcef4656fdc33f4480b573cb5006ff2fe174b1 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 77808 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 31185 |
|  / 1 / message id | msg&#95;011CfuS83F7wmf3ByHuvN6mB |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;1 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfuS82QWKZ1Jzy2rJcQjH |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 217978 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-sonnet-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11024 |
|  / 1 / usage / output tokens | 5576 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | bcad0619601626df989bae99790e409d0881b3482c83b67dd502802c0feceb18 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | 1ef2ca1cd874367a79f6d8c6b0fab4a8f1dbaf58a52deddd0f62b62aa345411b |
| reasons | claim&#58;p2&#58; original span mismatch<br>t1&#58; invalid product dimensions<br>e2&#58; identification argument is not source-bound<br>claim&#58;p2&#58; invalid not-applicable explanation<br>missing, duplicate or orphan mandatory transformation audit<br>tr1&#58; transformed source mismatch<br>tr2&#58; transformed source mismatch<br>tr3&#58; transformed source mismatch<br>tr4&#58; transformed source mismatch<br>tr5&#58; unresolved transformation origin<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;cf1&#x27; references evidence &#x27;e1&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context)<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p2&#58; original span mismatch; t1&#58; invalid product dimensions; e2&#58; identification argument is not source-bound; claim&#58;p2&#58; invalid not-applicable explanation; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; unresolved transformation origin |
| record fingerprint | fe07b557ee0a57b27124ea1400d30e28d73a6c7deb7cc846b87fec896cb0f549 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | solid |
| represented trigger analysis / causal claim | false |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e2 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p2 |
| represented trigger analysis / reason | The claim is a comparative group difference backed by randomized evidence. There is no causal inference from uncontrolled data, no mechanism-to-outcome leap and no evident inflation, so no error label applies. |
| represented trigger analysis / trigger evidence id | e2 |
| represented trigger analysis / trigger proposition id | claim&#58;p2 |
| represented trigger analysis / trigger quote | participants&#x27; reading proficiency was on average two and a half months ahead of the comparison group |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Extracted from the supplied task prompt only. |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | and |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | No entries recorded |
| materiality | required |
| not applicable | No entries recorded |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | Random assignment is stated directly. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Were students randomly assigned to the program or regular instruction? |
| search scope ids | ss1 |
| uncertainty | Randomization procedure details are not given. |

Quoted proposition; this is represented input, not a release assertion.

```
The study was randomized.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 21 |
| start | 0 |
| text | In a randomized study |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| relation | design |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The context states random assignment to the program or regular instruction. |
|  / 1 / search scope id | ss1 |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | population<br>intervention<br>comparator<br>endpoint |
| materiality | required |
| not applicable / mechanism | No mechanism is claimed. |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p2 |
| provenance id | prov1 |
| reason | The reported advantage matches the claimed direction, population, comparator and endpoint. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Did program participants have better reading proficiency than the regular-instruction group? |
| search scope ids | ss1 |
| uncertainty | Outcome measure, significance and sample size are not reported in the context. |

Quoted proposition; this is represented input, not a release assertion.

```
Elementary students who received weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 186 |
| start | 22 |
| text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparator | regular instruction |
| comparison | between-group |
| effect direction | favors program |
| endpoint | reading proficiency |
| endpoint type | clinical&#95;or&#95;functional |
| intervention | weekly supplementary literacy instruction |
| population | elementary school students |
| relation | better than |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b2 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e2 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The between-group reading proficiency difference favors the program group. |
|  / 1 / search scope id | ss1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b2 |
|  / 1 / dimensions | intervention<br>population<br>comparator |
|  / 1 / evidence ids | e2 |
|  / 1 / reason | The context describes the same weekly supplementary instruction, elementary students and regular-instruction comparator. The identification of the program with the claimed instruction is assumed from the context. |
|  / 1 / state | direct&#95;match |
|  / 1 / transfer id | t1 |

### Transformation tr1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / relation | design |
| from proposition ids | claim&#58;p1 |
| from text | In a randomized study |
| reason | Unchanged in meaning. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Were students randomly assigned to the program or regular instruction? |
| transformation id | tr1 |

### Transformation tr2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes / comparator | regular instruction |
| from attributes / endpoint | reading proficiency |
| from proposition ids | claim&#58;p2 |
| from text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| reason | Unchanged in meaning. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to attributes / comparator | regular-instruction group |
| to attributes / endpoint | reading proficiency |
| to text | Did program participants have better reading proficiency than the regular-instruction group? |
| transformation id | tr2 |

### Transformation tr3

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / relation | design |
| from proposition ids | claim&#58;p1 |
| from text | In a randomized study |
| reason | Unchanged in meaning. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The study was randomized.<br>Supported by the context&#x27;s random assignment statement. |
| transformation id | tr3 |

### Transformation tr4

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / comparison | between-group |
| from and to attributes (identical) / endpoint | reading proficiency |
| from proposition ids | claim&#58;p2 |
| from text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| reason | Unchanged in meaning. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | Elementary students who received weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.<br>Supported&#58; the program group was on average about 2.5 months ahead after year one, and the advantage persisted. |
| transformation id | tr4 |

### Transformation tr5

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / comparison | between-group |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to text (identical) | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| from proposition ids | claim&#58;p1<br>claim&#58;p2 |
| reason | The display claim is identical to the original and the explanation is empty, so there is no change in strength, population, endpoint or comparator. |
| stage | summary |
| target id | cf1 |
| transformation id | tr5 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | randomized allocation |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
Students were randomly assigned to either the program or regular instruction.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | regular instruction |
| attributes / intervention | weekly supplementary literacy instruction |
| attributes / population | elementary school students |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Randomization details are not described. |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | context description of design |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading proficiency |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
participants' reading proficiency was on average two and a half months ahead of the comparison group
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparison | between-group |
| attributes / effect magnitude | about 2.5 months ahead on average at the end of year one |
| attributes / endpoint | reading proficiency |
| attributes / follow up | advantage still detectable 26 months later |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Only a summary is supplied. |
| evidence id | e2 |
| evidence type | controlled&#95;intervention |
| identification argument | Random assignment is stated in the context. |
| identification evidence ids | e1 |
| quality | Not supplied |
| randomized | true |
| source role | context description of result |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied&#95;material&#95;only |
|  / 1 / search scope id | ss1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A large-scale study investigated a literacy support program in which elementary school students received weekly supplementary instruction over two school years. Students were randomly assigned to either the program or regular instruction. By the end of the first year, participants' reading proficiency was on average two and a half months ahead of the comparison group, and this advantage was still detectable 26 months later. The researchers note that the effect remained stable across all age groups and that no systematic disadvantages were observed.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | adequate |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | solid |
|  / 1 / proposition | The study was randomized. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary | Supported by the context&#x27;s random assignment statement. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status | adequate |
|  / 2 / contrary evidence ids | No entries recorded |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | solid |
|  / 2 / proposition | Elementary students who received weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 2 / provenance id | prov1 |
|  / 2 / supporting evidence ids | e2 |
|  / 2 / verdict summary | Supported&#58; the program group was on average about 2.5 months ahead after year one, and the advantage persisted. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / parent finding id | claim&#58;p2 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | e1<br>e2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 2225cc6bd5ba912ceea15272bd73406f20775383c8a81277d0bc3e01f9042628 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;97225761a9bba7e5cbd1a238

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;97225761a9bba7e5cbd1a238 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 1ef2ca1cd874367a79f6d8c6b0fab4a8f1dbaf58a52deddd0f62b62aa345411b |
| run id | 1ad57871-9780-41d3-a7ff-c99c5c7a023a |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11024 |
| usage / output tokens | 5576 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;97225761a9bba7e5cbd1a238 |
| projected object fingerprint | 2cbdc7e4e331526e87445901ec5df5a2b6783a1e372176e6dbbf98c81cb3ab31 |
| proposition ids | No entries recorded |
| reason | claim&#58;p2&#58; original span mismatch; t1&#58; invalid product dimensions; e2&#58; identification argument is not source-bound; claim&#58;p2&#58; invalid not-applicable explanation; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; unresolved transformation origin; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;cf1&#x27; references evidence &#x27;e1&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context); Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p2&#58; original span mismatch; t1&#58; invalid product dimensions; e2&#58; identification argument is not source-bound; claim&#58;p2&#58; invalid not-applicable explanation; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; unresolved transformation origin |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;3f20ac50c80039944a432ad0 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;97225761a9bba7e5cbd1a238 |
| projected object fingerprint | 760e43e84c4c4a60e7be71cc7f2ff068544b182788f50699c46553dc963894de |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; claim&#58;p2&#58; original span mismatch; t1&#58; invalid product dimensions; e2&#58; identification argument is not source-bound; claim&#58;p2&#58; invalid not-applicable explanation; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; unresolved transformation origin |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;57062c8daa695c1513f576a4 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;97225761a9bba7e5cbd1a238 |
| projected object fingerprint | 407812e9d22eb74c841b4931614f90a2d59c118a7b4a66ca8d74af8af0b01ae5 |
| proposition ids | claim&#58;p2 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;6321422d56816116c1482bd1 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | C |
|  / 1 / client finding id | cf1 |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | client finding &#x27;cf1&#x27; references evidence &#x27;e1&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context) |
|  / 1 / refs | e1 |
|  / 1 / severity | critical |
|  / 2 / check | P8 |
|  / 2 / client finding id |  |
|  / 2 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 2 / detail | Phase-8 output binding incomplete&#58; claim&#58;p2&#58; original span mismatch; t1&#58; invalid product dimensions; e2&#58; identification argument is not source-bound; claim&#58;p2&#58; invalid not-applicable explanation; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; tr4&#58; transformed source mismatch; tr5&#58; unresolved transformation origin |
|  / 2 / refs | No entries recorded |
|  / 2 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 67d2b9b1bb4c26bafc7479ad16bcf23010b4a8fc2cabdf6572a33a333c4b5c27 |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 7699bc602ad1d54d1a536e63e67f7fb65e1e028e411791bfe2cd881807405ad3 |
| execution evidence / 1 / attempt ids | attempt-007 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 8704cc3744274e7ba25067316fbcef4656fdc33f4480b573cb5006ff2fe174b1 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 77808 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 31185 |
| execution evidence / 1 / message id | msg&#95;011CfuS83F7wmf3ByHuvN6mB |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfuS82QWKZ1Jzy2rJcQjH |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 217978 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-sonnet-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11024 |
| execution evidence / 1 / usage / output tokens | 5576 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 623dce11258f5e614550f971b4e8d2f4541e6fdae2d08453bc8d0044fc3a5b7e |
| ledger fingerprint | f00aa23b54426aee40568690acfc006816054b8ed91e99b12859f5c9f3044e94 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11024 |
| providers / 1 / usage / output tokens | 5576 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 2225cc6bd5ba912ceea15272bd73406f20775383c8a81277d0bc3e01f9042628 |
| run id | 1ad57871-9780-41d3-a7ff-c99c5c7a023a |
| selected position id | p9position&#58;97225761a9bba7e5cbd1a238 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

