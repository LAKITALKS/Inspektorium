# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;41&#58;11.156311+00&#58;00 |
| parent | Not supplied |
| record fingerprint | e04fe500052294c0995133731473bb1bbefee0b7c43b82a63d5dcec5871996a9 |
| revision | 82fe2113-b81c-4d88-a329-7d33148931ec |
| selected position id | p9position&#58;283b8d3fc75ebfda11061fc4 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-010 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 393d2a4a3db87fe496876b7816add479ec170e32a312df69b5cb5448085832f6 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 80284 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 34872 |
|  / 1 / message id | msg&#95;011CfuSKSf5HfXprZbszwG5P |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;1 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfuSKRm13b7yS5XZxRQeo |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 217904 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-sonnet-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11032 |
|  / 1 / usage / output tokens | 5822 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The virtual tutoring program improved struggling students' reading progress or reduced their school absenteeism.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 246cf9f13d09d7cdc83068f66b29e2050e3571e48998a839b807e29d8fba14ad |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | a16f171a62ff141ccb31bb65685e1043962e0c8b2c3a6d2c891408b07b67e2b9 |
| reasons | claim&#58;p1&#58; original span mismatch<br>claim&#58;p2&#58; original span mismatch<br>e1&#58; identification argument is not source-bound<br>claim&#58;p2&#58; internal finding/evidence trace mismatch<br>claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace<br>missing, duplicate or orphan mandatory transformation audit<br>t1&#58; transformed source mismatch<br>t2&#58; transformed source mismatch<br>t3&#58; transformed source mismatch<br>t4&#58; transformed source mismatch<br>t5&#58; transformed source mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; original span mismatch; claim&#58;p2&#58; original span mismatch; e1&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch; t5&#58; transformed source mismatch<br>Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;e1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| record fingerprint | 8c2d7e18622410da5252242f4d5230e816f511622dad02451ded15cb970d2ad0 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The causal wording is backed by a randomized comparison on the same endpoint. No mechanism is described, and the claim does not inflate magnitude or scope. The residual uncertainty is the completer-subgroup caveat, which does not rise to a taxonomy error. |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | gained roughly two additional months of reading progress compared with peers in the control condition |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Extracted from task prompt text; the OR was split into two alternative propositions. |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | or |
| provenance id | prov-claim |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | population<br>endpoint<br>comparator |
| materiality | required |
| not applicable | No entries recorded |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov-claim |
| reason | Randomized evidence directly on the reading endpoint supports this branch. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied context show the virtual tutoring program improved struggling students&#x27; reading progress? |
| search scope ids | sc1 |
| uncertainty | Completer/dose-subgroup comparison may not be randomized<br>No effect sizes or intention-to-treat result in the context |

Quoted proposition; this is represented input, not a release assertion.

```
The virtual tutoring program improved struggling students' reading progress
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 74 |
| start | 0 |
| text | The virtual tutoring program improved struggling students&#x27; reading progress |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparator | control condition |
| effect direction | improvement |
| endpoint | reading progress |
| endpoint type | clinical/educational outcome |
| intervention | virtual reading tutoring program |
| population | struggling elementary students |
| relation | causal |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Randomized trial reports additional reading progress versus control for students completing &#126;40 sessions (completer subgroup). |
|  / 2 / binding id | b2 |
|  / 2 / directness | partial |
|  / 2 / evidence id | e2 |
|  / 2 / observation | inconclusive |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | Modest gains for lower attendance are stated without a comparator or magnitude. |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | endpoint |
| materiality | required |
| not applicable | No entries recorded |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p2 |
| provenance id | prov-claim |
| reason | No absenteeism data in the supplied context. |
| reported verdict | unknown |
| required bridge ids | No entries recorded |
| search question | Does the supplied context show the virtual tutoring program reduced school absenteeism? |
| search scope ids | sc1 |
| uncertainty | Absenteeism may not have been measured; no evidence found in the reviewed set is not evidence of absence |

Quoted proposition; this is represented input, not a release assertion.

```
reduced their school absenteeism
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 110 |
| start | 78 |
| text | reduced their school absenteeism |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| effect direction | reduction |
| endpoint | school absenteeism |
| intervention | virtual tutoring program |
| population | struggling students |
| relation | causal |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b3 |
|  / 1 / directness | unknown |
|  / 1 / evidence id | e3 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The reviewed context describes a reading trial and reports no absenteeism outcome; this is not evidence of no effect. |
|  / 1 / search scope id | sc1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / relation | causal |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress |
| reason | Unchanged semantics; converted to a question. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the supplied context show the virtual tutoring program improved struggling students&#x27; reading progress? |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / relation | causal |
| from proposition ids | claim&#58;p2 |
| from text | reduced their school absenteeism |
| reason | Unchanged semantics. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Does the supplied context show the virtual tutoring program reduced school absenteeism? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| from and to attributes (identical) / endpoint | reading progress |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress |
| reason | Unchanged proposition; summary adds the supported verdict and the caveat. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The virtual tutoring program improved struggling students&#x27; reading progress<br>Supported by randomized trial evidence on reading progress; completer-dose caveat. |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| asserted state | unknown |
| from and to attributes (identical) / endpoint | school absenteeism |
| from proposition ids | claim&#58;p2 |
| from text | reduced their school absenteeism |
| reason | Unchanged proposition; verdict is unknown. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | reduced their school absenteeism<br>No absenteeism evidence in the supplied context; unresolved, not disproven. |
| transformation id | t4 |

### Transformation t5

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | reading progress |
| from and to text (identical) | The virtual tutoring program improved struggling students&#x27; reading progress |
| from proposition ids | claim&#58;p1 |
| reason | Client text matches the finding and asserts only the reading branch. Because of the OR logic, this branch alone satisfies the claim. |
| stage | summary |
| target id | cf1 |
| transformation id | t5 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading progress |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | roughly two additional months of reading progress |
| role | supporting |
| source id | context |
| value origin | reported |

Evidence text and exact source reference (identical)&#58;

```
Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | control condition |
| attributes / endpoint | reading progress |
| attributes / intervention | virtual reading tutoring, &#126;40 sessions |
| attributes / population | struggling elementary students, rural district |
| design limitations | completer subgroup; possible selection<br>no effect size or CI reported |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| identification argument | Context states a randomized controlled trial; whether this completer comparison preserves randomization is not stated. |
| quality | Not supplied |
| randomized | true |
| source role | reported trial result in context |
| study id | Not supplied |

### Evidence e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading progress |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | reported |

Evidence text and exact source reference (identical)&#58;

```
Even those attending fewer sessions showed modest gains.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | reading progress |
| attributes / population | students attending fewer sessions |
| design limitations | comparator and magnitude not stated |
| evidence id | e2 |
| evidence type | controlled&#95;intervention |
| randomized | Not supplied |
| source role | reported trial result in context |

### Evidence e3

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | school absenteeism |
| evidence id | e3 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized controlled trial tested a virtual reading tutoring program in a rural school district.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | reading progress |
| design limitations | no absenteeism outcome described |
| evidence id | e3 |
| evidence type | descriptive |
| randomized | true |
| source role | trial description in context |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | sc1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized controlled trial tested a virtual reading tutoring program in a rural school district. The program paired live online tutors with small groups of struggling elementary students for ten-week sessions. Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition. Even those attending fewer sessions showed modest gains. Researchers emphasised that consistent participation was critical and highlighted that the program delivered results at a lower cost than typical high-dose tutoring.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The virtual tutoring program improved struggling students&#x27; reading progress or reduced their school absenteeism. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov-claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | moderate |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | solid |
|  / 1 / proposition | The virtual tutoring program improved struggling students&#x27; reading progress |
|  / 1 / provenance id | prov-claim |
|  / 1 / supporting evidence ids | e1<br>e2 |
|  / 1 / verdict summary | Supported by randomized trial evidence on reading progress; completer-dose caveat. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status | unknown |
|  / 2 / contrary evidence ids | No entries recorded |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | Not supplied |
|  / 2 / proposition | reduced their school absenteeism |
|  / 2 / provenance id | prov-claim |
|  / 2 / supporting evidence ids | No entries recorded |
|  / 2 / verdict summary | No absenteeism evidence in the supplied context; unresolved, not disproven. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The virtual tutoring program improved struggling students&#x27; reading progress |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov-claim |
|  / 1 / referenced evidence ids | e1<br>e2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | ae4dbf41b704a934d9fa96aef8268efe42222f7abd0717c75c2dfe6e6d93f708 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;283b8d3fc75ebfda11061fc4

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;283b8d3fc75ebfda11061fc4 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | a16f171a62ff141ccb31bb65685e1043962e0c8b2c3a6d2c891408b07b67e2b9 |
| run id | 53ac0892-7a81-446d-8169-ea21e3f0cd2c |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11032 |
| usage / output tokens | 5822 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1 |
| field | phase8.phase7&#95;controls.value&#95;origin&#95;provenance |
| mandatory | true |
| material | true |
| position ids | p9position&#58;283b8d3fc75ebfda11061fc4 |
| projected object fingerprint | 7e1fc9c02baa53778ed690bfb136d54774bec1b8d2afb116f243f4bbaf485e60 |
| proposition ids | No entries recorded |
| reason | client-visible value &#x27;e1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;10cd182b9aa0cea262af5a45 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;283b8d3fc75ebfda11061fc4 |
| projected object fingerprint | 5b44b2c69fdfd0a9f1440fc72e8fe26155910b3ef5524c01fb7b2a04324ac5ea |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;5ba32332c8d43ff9c119cce8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;283b8d3fc75ebfda11061fc4 |
| projected object fingerprint | 295c1c9bbb62f3a3e0fdf4d6e7e1b71fd799fa1d25d9ef1986f02c84d5726efc |
| proposition ids | No entries recorded |
| reason | claim&#58;p1&#58; original span mismatch; claim&#58;p2&#58; original span mismatch; e1&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch; t5&#58; transformed source mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; original span mismatch; claim&#58;p2&#58; original span mismatch; e1&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch; t5&#58; transformed source mismatch; Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;e1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;81f2ed0a1b056c96423ba47d |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;283b8d3fc75ebfda11061fc4 |
| projected object fingerprint | 18c925ec70e1674234a887669bcb6a3980bb50f16a43fd57f89ec59cbb844548 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; original span mismatch; claim&#58;p2&#58; original span mismatch; e1&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch; t5&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;d14c85b184a2211479bbbbef |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; original span mismatch; claim&#58;p2&#58; original span mismatch; e1&#58; identification argument is not source-bound; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; t1&#58; transformed source mismatch; t2&#58; transformed source mismatch; t3&#58; transformed source mismatch; t4&#58; transformed source mismatch; t5&#58; transformed source mismatch |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

### Findings&#58; value&#95;origin&#95;provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / check | VF |
|  / 1 / client finding id | cf1 |
|  / 1 / code | unresolved&#95;value&#95;origin |
|  / 1 / detail | client-visible value &#x27;e1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
|  / 1 / refs | e1 |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 364b1456e5e015962ef9700c2c4e422c06b6ab94a3f90fba16744a49d0a1139b |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 7c1b4db3e356db094a103b305b08b4c8c2099f3521adbd7ce98c787742a07ac8 |
| execution evidence / 1 / attempt ids | attempt-010 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 393d2a4a3db87fe496876b7816add479ec170e32a312df69b5cb5448085832f6 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 80284 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 34872 |
| execution evidence / 1 / message id | msg&#95;011CfuSKSf5HfXprZbszwG5P |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfuSKRm13b7yS5XZxRQeo |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 217904 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-sonnet-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11032 |
| execution evidence / 1 / usage / output tokens | 5822 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 77c95aed75c1d8563c7cf5f03b5c1a0345cdd58b50d13563d519cc2dd49284bb |
| ledger fingerprint | 666b5849f4f0c4e27ccf04b0d02d4a44198e12f6645c1f474c41985710fd364a |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11032 |
| providers / 1 / usage / output tokens | 5822 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | ae4dbf41b704a934d9fa96aef8268efe42222f7abd0717c75c2dfe6e6d93f708 |
| run id | 53ac0892-7a81-446d-8169-ea21e3f0cd2c |
| selected position id | p9position&#58;283b8d3fc75ebfda11061fc4 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

