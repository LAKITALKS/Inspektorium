# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;41&#58;09.681465+00&#58;00 |
| parent | Not supplied |
| record fingerprint | f0bda023b97849deaf0d05170143e186f5013f3e9c989a3e9e10112bfdd27eec |
| revision | 301d6da3-ad92-4d7a-ab33-94c166cebd74 |
| selected position id | p9position&#58;bbffcc501283fc1179e87bef |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-008 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 451cd380acf5df76c637a3bb411c3c3c69b9abcd702e0399c74799d0e8709e97 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 74644 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 30918 |
|  / 1 / message id | msg&#95;011CfuSDefUvBTFbuebpZ1yb |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;1 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfuSDeHuDs6tymPZy52WF |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 217164 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-sonnet-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 10947 |
|  / 1 / usage / output tokens | 5275 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Compound X treats cancer in patients.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 112163c5e3b414878531e3c67842192acd46632c8d8f17f708205804341958e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | mechanism&#95;vs&#95;evidence |
| raw response sha256 | 0bafe5cfa4f5e63435ace1fef1a9c16d1fa0bcb2d96377672167b2c65a20c918 |
| reasons | br1&#58; mechanism bridge lacks premise<br>t1&#58; invalid product dimensions<br>orphan material evidence<br>claim&#58;p1&#58; internal finding/evidence trace mismatch<br>claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace<br>missing, duplicate or orphan mandatory transformation audit<br>tr1&#58; transformed source mismatch<br>tr2&#58; transformed source mismatch<br>tr3&#58; transformed source mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; br1&#58; mechanism bridge lacks premise; t1&#58; invalid product dimensions; orphan material evidence; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch |
| record fingerprint | c283c10c559632c5f75a15a502e2d12c596cb773bf2c10a4a03a50568200f7e2 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | mechanism&#95;vs&#95;evidence |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | mechanism&#95;to&#95;outcome |
| represented trigger analysis / described biological mechanism | true |
| represented trigger analysis / evidence ids | e1<br>e2<br>e3 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The preclinical in vitro cell-killing result is used to imply treatment of cancer in patients, with no animal or human data. The mechanism trigger is a loose fit, since only cytotoxicity is described and no specific mechanism. |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | killed up to 90% of cultured human tumour cells in a petri dish within 48 hours |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single required proposition extracted from the full claim text; no components were dropped. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | population<br>endpoint<br>species |
| materiality | required |
| not applicable | No entries recorded |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | There is no clinical evidence, and no bridge from cell culture to patient benefit. |
| reported verdict | unsupported |
| required bridge ids | br1 |
| search question | Does the supplied material show that Compound X treats cancer in patients? |
| search scope ids | s1 |
| uncertainty | Only the supplied press summary was reviewed. |

Quoted proposition; this is represented input, not a release assertion.

```
Compound X treats cancer in patients.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 37 |
| start | 0 |
| text | Compound X treats cancer in patients. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | unhedged |
| endpoint | cancer treatment |
| endpoint type | clinical |
| intervention | Compound X |
| population | patients |
| relation | treats |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | remote |
|  / 1 / evidence id | e1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | In vitro killing of cultured tumour cells does not address treatment in patients. |
|  / 2 / binding id | b2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | e2 |
|  / 2 / observation | no&#95;evidence&#95;found |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | The supplied context states that no animal or human data are described. |
|  / 2 / search scope id | s1 |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | br1 |
|  / 1 / conclusion proposition id | claim&#58;p1 |
|  / 1 / dimensions | species<br>population<br>endpoint<br>dose<br>route |
|  / 1 / evidence ids | e1<br>e2 |
|  / 1 / kind | mechanism&#95;to&#95;outcome |
|  / 1 / premise proposition ids | No entries recorded |
|  / 1 / reason | No animal or human data connect cell-culture cytotoxicity to patient benefit. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / dimensions | population<br>endpoint<br>dose<br>route<br>follow&#95;up |
|  / 1 / evidence ids | e1 |
|  / 1 / reason | The transfer from a petri-dish exposure to patients is not supported by the supplied material. |
|  / 1 / state | unsupported&#95;transfer |
|  / 1 / transfer id | t1 |

### Transformation tr1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes / certainty | unhedged |
| from attributes / endpoint | cancer treatment |
| from attributes / population | patients |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | The search question keeps the population, endpoint and intervention unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to attributes / certainty | question |
| to attributes / endpoint | cancer treatment |
| to attributes / population | patients |
| to text | Does the supplied material show that Compound X treats cancer in patients? |
| transformation id | tr1 |

### Transformation tr2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / population | patients |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | The proposition text is unchanged and the verdict is attached. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Compound X treats cancer in patients.<br>Unsupported&#58; only in vitro cell-culture cytotoxicity is described; no animal or human data. |
| transformation id | tr2 |

### Transformation tr3

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / population | patients |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | The summary is explicitly negated and does not strengthen the claim. |
| stage | summary |
| target id | cf1 |
| to text | Not supported&#58; Compound X treats cancer in patients.<br>Only cell-culture killing is described; no animal or human data. |
| transformation id | tr3 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | tumour cell death in vitro |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
killed up to 90% of cultured human tumour cells in a petri dish within 48 hours
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / effect magnitude | up to 90% |
| attributes / endpoint | tumour cell death |
| attributes / endpoint type | in vitro |
| attributes / follow up | 48 hours |
| attributes / intervention | Compound X |
| attributes / population | cultured human tumour cells |
| design limitations | in vitro only<br>primary study not described<br>press report |
| evidence id | e1 |
| evidence type | in&#95;vitro |
| randomized | Not supplied |
| source role | press summary of cell-culture result |

### Evidence e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | clinical or animal outcome |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
No animal or human data are described.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes | No entries recorded |
| evidence id | e2 |
| evidence type | descriptive |
| randomized | Not supplied |
| source role | press summary statement of absent data |

### Evidence e3

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | press conclusion |
| evidence id | e3 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
The write-up concludes that Compound X 'treats cancer' and could become a natural alternative to chemotherapy.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes | No entries recorded |
| evidence id | e3 |
| evidence type | descriptive |
| randomized | Not supplied |
| source role | press conclusion |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied material only; no external search |
|  / 1 / search scope id | s1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A press summary reports that Compound X, a plant-derived molecule, killed up to 90% of cultured human tumour cells in a petri dish within 48 hours. The write-up concludes that Compound X 'treats cancer' and could become a natural alternative to chemotherapy. No animal or human data are described.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Compound X treats cancer in patients. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | moderate |
|  / 1 / contrary evidence ids | e1<br>e2<br>e3 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | mechanism&#95;vs&#95;evidence |
|  / 1 / proposition | Compound X treats cancer in patients. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Unsupported&#58; only in vitro cell-culture cytotoxicity is described; no animal or human data. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | Only cell-culture killing is described; no animal or human data. |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | Not supported&#58; Compound X treats cancer in patients. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | e1<br>e2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 63fa52cb006a418cc6121219e8f75d0ecd3047b73ada3f1ddac65808b83cd4bc |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;bbffcc501283fc1179e87bef

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | mechanism&#95;vs&#95;evidence |
| position id | p9position&#58;bbffcc501283fc1179e87bef |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 0bafe5cfa4f5e63435ace1fef1a9c16d1fa0bcb2d96377672167b2c65a20c918 |
| run id | 0862e69f-4749-4b7d-b228-f7d56cdbc8cb |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 10947 |
| usage / output tokens | 5275 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1<br>e2<br>e3 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;bbffcc501283fc1179e87bef |
| projected object fingerprint | 3930bb662a42615ba9a202caf894fbc50b3206fce501b394a63fb2f16d83c586 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;47a958a1cccbe3d4cc1fd1fb |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;bbffcc501283fc1179e87bef |
| projected object fingerprint | f7cb3e6f5d13e63244bbbcdea17922553b9aa59cdc270d454aa09ec70767d169 |
| proposition ids | No entries recorded |
| reason | br1&#58; mechanism bridge lacks premise; t1&#58; invalid product dimensions; orphan material evidence; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; br1&#58; mechanism bridge lacks premise; t1&#58; invalid product dimensions; orphan material evidence; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;567d4d7cb8cfba00ff553c39 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;bbffcc501283fc1179e87bef |
| projected object fingerprint | 6f72d06aa538d7e804cbab3d989877987b5957c11c3022b00befd8ee9993eeb2 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; br1&#58; mechanism bridge lacks premise; t1&#58; invalid product dimensions; orphan material evidence; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;72b6b967207cba45158e061c |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; br1&#58; mechanism bridge lacks premise; t1&#58; invalid product dimensions; orphan material evidence; claim&#58;p1&#58; internal finding/evidence trace mismatch; claim&#58;p1&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; tr1&#58; transformed source mismatch; tr2&#58; transformed source mismatch; tr3&#58; transformed source mismatch |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | efe61f9148fb42ddd328222de8a9833c2cfa8b2e5fe9f86b14e775debc20b4c1 |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 946e17bb0e9cd20196801ab5e5d8474c7372705a23c5c49bb8572d7d247ede6e |
| execution evidence / 1 / attempt ids | attempt-008 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 451cd380acf5df76c637a3bb411c3c3c69b9abcd702e0399c74799d0e8709e97 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 74644 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 30918 |
| execution evidence / 1 / message id | msg&#95;011CfuSDefUvBTFbuebpZ1yb |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfuSDeHuDs6tymPZy52WF |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 217164 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-sonnet-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 10947 |
| execution evidence / 1 / usage / output tokens | 5275 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 4c7ea357ae5bc4fc582048c362f5bdffabeb031cf56306a5f1c0587bc8aaaad4 |
| ledger fingerprint | db38c04a5e1ba6d7b4d94431fb95d438b054e4bddef626f565f2e7152ccc72b3 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | mechanism&#95;vs&#95;evidence |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 10947 |
| providers / 1 / usage / output tokens | 5275 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 63fa52cb006a418cc6121219e8f75d0ecd3047b73ada3f1ddac65808b83cd4bc |
| run id | 0862e69f-4749-4b7d-b228-f7d56cdbc8cb |
| selected position id | p9position&#58;bbffcc501283fc1179e87bef |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

