# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;41&#58;11.874845+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 41dcc3ff07b505bd35ea5359128dd30ba8d23fbd7e3c19aa5d90d301d1fe815a |
| revision | 69428197-29bc-43b2-a639-0a1ec079f121 |
| selected position id | p9position&#58;f2c6722ff820d493b66e979f |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-011 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 4102edbd78a85903cac4178d53da488129479d54d2eeeea4e23f9928a95b2aa0 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 48042 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 15587 |
|  / 1 / message id | msg&#95;011CfuSN4wT48dKaQXwyp2QL |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;1 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfuSN4iZeUr2FQntDaXsW |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 217086 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-sonnet-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 10921 |
|  / 1 / usage / output tokens | 2620 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The supplement causes liver damage in long-term users.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | fdff1ae350dd42166846a038784e0a2acba7903f8b6ffbe2039bc333fbdad7b2 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | 348a55f43fc1e3c4911661092aa9964ccddba2257e46d6e15bfe4f2519ae259c |
| reasons | invalid ledger&#58; 8 validation errors for PropositionLedger<br>claim&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>provenance&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>required&#95;proposition&#95;ids<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>propositions<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>logic<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>extraction&#95;provenance<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>ledger<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#123;&#x27;contract&#95;version&#x27;&#58; &#x27;AA-...laim is unsupported.&#x27;&#125;&#93;&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>taxonomy<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=None, input&#95;type=NoneType&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 8 validation errors for PropositionLedger<br>claim&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>provenance&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>required&#95;proposition&#95;ids<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>propositions<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>logic<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>extraction&#95;provenance<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>ledger<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#123;&#x27;contract&#95;version&#x27;&#58; &#x27;AA-...laim is unsupported.&#x27;&#125;&#93;&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>taxonomy<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=None, input&#95;type=NoneType&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| record fingerprint | 82fd569451889f9a6c248fc4d47b41ecdee9f4247f84445b08b5dc9dd828075b |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The claim is an unhedged causal harm assertion for which no supporting evidence is supplied. No correlational or confounded evidence is cited, so the CvC trigger is not shown. No mechanism is described, so the mechanism trigger is absent. The core error is overstatement. |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | A supplement trial in 60 participants over four weeks reports no serious adverse events. |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | Not supplied |
| extraction provenance | Not supplied |
| logic | Not supplied |
| provenance id | Not supplied |
| required proposition ids | Not supplied |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | serious adverse events / liver |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| Value | Not supplied |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied material only |
|  / 1 / search scope id | ss1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events. The label now states the product is 'completely safe' and 'proven to have no side effects', suitable for everyone including pregnant women and children.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The supplement causes liver damage in long-term users. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | low |
|  / 1 / contrary evidence ids | e1 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | overclaim |
|  / 1 / proposition | The supplement causes liver damage in long-term users. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Unsupported by supplied material; no liver or long-term evidence is provided. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | Unsupported by supplied material; no liver or long-term evidence is provided. |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The supplement causes liver damage in long-term users. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 92506ce69fbf700001a69bcb44dcdb33a2c63c34177a49ca5628c40101889fe2 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;f2c6722ff820d493b66e979f

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id |  |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;f2c6722ff820d493b66e979f |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 348a55f43fc1e3c4911661092aa9964ccddba2257e46d6e15bfe4f2519ae259c |
| run id | 700cad32-5ab3-4957-94a3-a419e4edb830 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 10921 |
| usage / output tokens | 2620 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id |  |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f2c6722ff820d493b66e979f |
| projected object fingerprint | 30c4cbd7b007916044fd7f4ee6453ba96195c65201e425fb2fbf1437d9b03a8a |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; invalid ledger&#58; 8 validation errors for PropositionLedger<br>claim&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>provenance&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>required&#95;proposition&#95;ids<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>propositions<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>logic<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>extraction&#95;provenance<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>ledger<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#123;&#x27;contract&#95;version&#x27;&#58; &#x27;AA-...laim is unsupported.&#x27;&#125;&#93;&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>taxonomy<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=None, input&#95;type=NoneType&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;06017003c58c138eebf85ac2 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id |  |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f2c6722ff820d493b66e979f |
| projected object fingerprint | aca81991a17c9278e9ad0fa7973904f27f14b70ace75e782598f8d73a28e5632 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;5314a80a315479bf97afd70b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id |  |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f2c6722ff820d493b66e979f |
| projected object fingerprint | f3101b0eac8a0df459790c1de121305dd205913a5c562288b9e99664203e10ea |
| proposition ids | No entries recorded |
| reason | invalid ledger&#58; 8 validation errors for PropositionLedger<br>claim&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>provenance&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>required&#95;proposition&#95;ids<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>propositions<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>logic<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>extraction&#95;provenance<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>ledger<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#123;&#x27;contract&#95;version&#x27;&#58; &#x27;AA-...laim is unsupported.&#x27;&#125;&#93;&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>taxonomy<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=None, input&#95;type=NoneType&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 8 validation errors for PropositionLedger<br>claim&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>provenance&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>required&#95;proposition&#95;ids<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>propositions<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>logic<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>extraction&#95;provenance<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>ledger<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#123;&#x27;contract&#95;version&#x27;&#58; &#x27;AA-...laim is unsupported.&#x27;&#125;&#93;&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>taxonomy<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=None, input&#95;type=NoneType&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;706a2a73399562cb9d1c4581 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; invalid ledger&#58; 8 validation errors for PropositionLedger<br>claim&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>provenance&#95;id<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>required&#95;proposition&#95;ids<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>propositions<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>logic<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>extraction&#95;provenance<br>  Field required &#91;type=missing, input&#95;value=&#123;&#x27;original&#95;claim&#x27;&#58; &#x27;The s....&#x27;&#125;&#93;&#125;, &#x27;taxonomy&#x27;&#58; None&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/missing<br>ledger<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#123;&#x27;contract&#95;version&#x27;&#58; &#x27;AA-...laim is unsupported.&#x27;&#125;&#93;&#125;, input&#95;type=dict&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>taxonomy<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=None, input&#95;type=NoneType&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 15c1bb057f65fe0d352edb594235e4f60af5f22789eee4341669b85b8ad0c961 |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | c21bdd620259be64186b2532ba5991460f8ab4dfc8584b2ee8847bd9487d61ca |
| execution evidence / 1 / attempt ids | attempt-011 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 4102edbd78a85903cac4178d53da488129479d54d2eeeea4e23f9928a95b2aa0 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 48042 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 15587 |
| execution evidence / 1 / message id | msg&#95;011CfuSN4wT48dKaQXwyp2QL |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfuSN4iZeUr2FQntDaXsW |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 217086 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-sonnet-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 10921 |
| execution evidence / 1 / usage / output tokens | 2620 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 5b28ec01e3c549c5ec4d7647a9d518c0bb5ea0b9b8154bece21dcb0faf03fffd |
| ledger fingerprint | 626246e435d1c9d3cadd937f15dd8a9d90705f94dd9fa2a39a9dc4c51a5ce74b |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 10921 |
| providers / 1 / usage / output tokens | 2620 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 92506ce69fbf700001a69bcb44dcdb33a2c63c34177a49ca5628c40101889fe2 |
| run id | 700cad32-5ab3-4957-94a3-a419e4edb830 |
| selected position id | p9position&#58;f2c6722ff820d493b66e979f |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

