# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;41&#58;07.533171+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 439287a772df9ed5c8a2d40f0bf0ac467522d5cb9acc7507edd769534b7c04cf |
| revision | a8a0b69c-b08c-44e2-9a15-b99767f422a4 |
| selected position id | p9position&#58;c81c1fef5e74de0b2bb2bcbc |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-005 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | fee9af9b5722edb4d105a4326c97d90c3b2184e5662d7f19a925d42fdddc2b8a |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 6104 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 37444 |
|  / 1 / message id | msg&#95;011CfuS28tGkuBabgTrUBXak |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;1 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfuS28ePytqkkScZ5WGGX |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 10855 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-haiku-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 10921 |
|  / 1 / usage / output tokens | 10022 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The supplement causes liver damage in long-term users.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | fdff1ae350dd42166846a038784e0a2acba7903f8b6ffbe2039bc333fbdad7b2 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | 43c4a83161e6a623d09acbb40d8f0fd24eca21017232c9da06aafa9260000fe7 |
| reasons | claim&#58;p1&#58; invalid material dimension<br>tf&#58;extraction&#58;claim&#58;p1&#58; unresolved transformation origin<br>tf&#58;search&#58;claim&#58;p1&#58; transformed source mismatch<br>tf&#58;internal&#58;claim&#58;p1&#58; transformed source mismatch<br>tf&#58;summary&#58;client&#58;claim&#58;p1&#58; transformed source mismatch<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; tf&#58;extraction&#58;claim&#58;p1&#58; unresolved transformation origin; tf&#58;search&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;internal&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;summary&#58;client&#58;claim&#58;p1&#58; transformed source mismatch |
| record fingerprint | 0b11ac9d8dfe1e5137826ac4b484ef1a79707fd56d3ee6a57bae9b885c37ea89 |
| technical status | incomplete |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev1 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The claim asserts a causal liver harm in long-term users as fact, while the only supplied evidence is a short trial reporting no serious adverse events and no liver endpoint. Whether a noncausal result underlies the claim is unknown, so correlation&#95;vs&#95;causation is not established; no mechanism is described. |
| represented trigger analysis / trigger evidence id | ev1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | reports no serious adverse events |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Extracted from the supplied task prompt only; no external search executed. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | endpoint<br>population<br>duration<br>causal relation |
| materiality | required |
| not applicable | No entries recorded |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| reason | The claimed causal harm to the liver in long-term users is not supported by the supplied material. |
| reported verdict | unsupported |
| required bridge ids | bridge&#58;causal |
| search question | Is there evidence in the supplied material that the supplement causes liver damage in long-term users? |
| search scope ids | scope&#58;supplied |
| uncertainty | Trial randomization and comparator are not stated.<br>No liver-specific endpoint is reported in the supplied text. |

Quoted proposition; this is represented input, not a release assertion.

```
The supplement causes liver damage in long-term users.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 54 |
| start | 0 |
| text | The supplement causes liver damage in long-term users. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparison | Not supplied |
| effect direction | harm |
| endpoint | liver damage |
| endpoint type | harm |
| follow up | long-term |
| intervention | supplement |
| population | long-term users |
| relation | causes |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;claim&#58;p1&#58;ev1 |
|  / 1 / directness | remote |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | no&#95;effect&#95;observed |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The supplied four-week trial reports no serious adverse events. It does not measure liver damage or long-term exposure, so it is remote from the claimed harm. |
|  / 1 / search scope id | Not supplied |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | bridge&#58;causal |
|  / 1 / conclusion proposition id | claim&#58;p1 |
|  / 1 / dimensions | causal relation<br>endpoint<br>duration |
|  / 1 / evidence ids | ev1 |
|  / 1 / kind | causal&#95;identification |
|  / 1 / premise proposition ids | No entries recorded |
|  / 1 / reason | No supplied design identifies a causal effect of the supplement on liver damage in long-term users. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation tf&#58;extraction&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | true |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causes |
| from and to text (identical) | The supplement causes liver damage in long-term users. |
| from proposition ids | No entries recorded |
| reason | Unchanged extraction of the single claim proposition. |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | tf&#58;extraction&#58;claim&#58;p1 |

### Transformation tf&#58;search&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causes |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | Question form of the proposition with unchanged semantic attributes; searches limited to supplied material. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Is there evidence in the supplied material that the supplement causes liver damage in long-term users? |
| transformation id | tf&#58;search&#58;claim&#58;p1 |

### Transformation tf&#58;internal&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causes |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | Internal finding restates the proposition with the derived unsupported verdict; no stronger claim is added. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The supplement causes liver damage in long-term users.<br>Unsupported by supplied material. The only trial reports no serious adverse events over four weeks in 60 participants and does not report liver damage in long-term users. |
| transformation id | tf&#58;internal&#58;claim&#58;p1 |

### Transformation tf&#58;summary&#58;client&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causes |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | Client summary reports non-support of the claim without asserting it is false or that the product is proven safe. |
| stage | summary |
| target id | client&#58;claim&#58;p1 |
| to text | The supplied material does not support the claim that the supplement causes liver damage in long-term users.<br>The only supplied safety result is a four-week trial in 60 participants that reports no serious adverse events; it does not report liver damage in long-term users, so it is not evidence of harm. |
| transformation id | tf&#58;summary&#58;client&#58;claim&#58;p1 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | serious adverse events |
| evidence id | ev1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | Not supplied |
| attributes / comparison | Not supplied |
| attributes / endpoint | serious adverse events |
| attributes / endpoint type | safety |
| attributes / follow up | four weeks |
| attributes / intervention | supplement |
| attributes / population | 60 participants |
| attributes / relation | Not supplied |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Four-week duration, not long-term exposure.<br>No liver endpoint reported in the supplied text.<br>Randomization and comparator not stated. |
| evidence id | ev1 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | supplied trial report (context) |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | supplied task prompt and context only |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | limited to supplied material; no external search executed |
|  / 1 / search scope id | scope&#58;supplied |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events. The label now states the product is 'completely safe' and 'proven to have no side effects', suitable for everyone including pregnant women and children.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The supplement causes liver damage in long-term users. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | low |
|  / 1 / contrary evidence ids | ev1 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | The supplement causes liver damage in long-term users. |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Unsupported by supplied material. The only trial reports no serious adverse events over four weeks in 60 participants and does not report liver damage in long-term users. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The only supplied safety result is a four-week trial in 60 participants that reports no serious adverse events; it does not report liver damage in long-term users, so it is not evidence of harm. |
|  / 1 / client finding id | client&#58;claim&#58;p1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The supplied material does not support the claim that the supplement causes liver damage in long-term users. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / referenced evidence ids | ev1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 890be4b89f82dc4af07fbb612a6c2370c4a47b55a178877f602fac3e12a781a3 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;c81c1fef5e74de0b2bb2bcbc

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;c81c1fef5e74de0b2bb2bcbc |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 43c4a83161e6a623d09acbb40d8f0fd24eca21017232c9da06aafa9260000fe7 |
| run id | e3221b8d-e915-4dad-801a-07a4d6a82f92 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 10921 |
| usage / output tokens | 10022 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;c81c1fef5e74de0b2bb2bcbc |
| projected object fingerprint | 02e4d471d3416d22bd2eb76357b4f77adb631d3f9c4583ba464f848944528423 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; tf&#58;extraction&#58;claim&#58;p1&#58; unresolved transformation origin; tf&#58;search&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;internal&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;summary&#58;client&#58;claim&#58;p1&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;137e9b41ee620bf197960456 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;c81c1fef5e74de0b2bb2bcbc |
| projected object fingerprint | 15e5f63290b402bd72458ea77b55b3c0e7b6e460c005ed8c3aa79a09ed847da0 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;3929ef666f788424128ee0b6 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;c81c1fef5e74de0b2bb2bcbc |
| projected object fingerprint | 69b4e45cf37571b35e4d638b6641360183daabde55cf2c2b5f5fa619670b2f07 |
| proposition ids | No entries recorded |
| reason | claim&#58;p1&#58; invalid material dimension; tf&#58;extraction&#58;claim&#58;p1&#58; unresolved transformation origin; tf&#58;search&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;internal&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;summary&#58;client&#58;claim&#58;p1&#58; transformed source mismatch; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; tf&#58;extraction&#58;claim&#58;p1&#58; unresolved transformation origin; tf&#58;search&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;internal&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;summary&#58;client&#58;claim&#58;p1&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;f46eb8ca788bce21c152e52b |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; claim&#58;p1&#58; invalid material dimension; tf&#58;extraction&#58;claim&#58;p1&#58; unresolved transformation origin; tf&#58;search&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;internal&#58;claim&#58;p1&#58; transformed source mismatch; tf&#58;summary&#58;client&#58;claim&#58;p1&#58; transformed source mismatch |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 45839e566140374f155429c04af35ca10d9da4f05ef28d10013424911a8b515d |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 11d58851181e8520894f1bb0ad5ec5a739a8d3957720349efd375eeae9c0a47b |
| execution evidence / 1 / attempt ids | attempt-005 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | fee9af9b5722edb4d105a4326c97d90c3b2184e5662d7f19a925d42fdddc2b8a |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 6104 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 37444 |
| execution evidence / 1 / message id | msg&#95;011CfuS28tGkuBabgTrUBXak |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfuS28ePytqkkScZ5WGGX |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 10855 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-haiku-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 10921 |
| execution evidence / 1 / usage / output tokens | 10022 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 5b28ec01e3c549c5ec4d7647a9d518c0bb5ea0b9b8154bece21dcb0faf03fffd |
| ledger fingerprint | ef9dcd7ce453a2836792a0faf448c5ce2893456d36f18f90f41cc723f90b43ff |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 10921 |
| providers / 1 / usage / output tokens | 10022 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 890be4b89f82dc4af07fbb612a6c2370c4a47b55a178877f602fac3e12a781a3 |
| run id | e3221b8d-e915-4dad-801a-07a4d6a82f92 |
| selected position id | p9position&#58;c81c1fef5e74de0b2bb2bcbc |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

