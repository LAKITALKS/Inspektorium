# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-10T23&#58;41&#58;05.996952+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 1d1e3770b2f2772a00d2a76b6ed169e5e3bb12ee8a7b4b2774c4bdc4e482ad54 |
| revision | 37705084-52ae-45d0-801a-1fba015f0fa2 |
| selected position id | p9position&#58;62de4a34eb174e9d128e1f59 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-003 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 9365780abb36ebefabfc39f5ef3c32b4c4e1527c96706f73857d02f0508f3325 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 7960 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 47814 |
|  / 1 / message id | msg&#95;011CfuRtDKwqk68PtRUA1Vpn |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;1 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfuRtCkDanetwFAym46Sk |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 10909 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-haiku-5-5&#64;1&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 11105 |
|  / 1 / usage / output tokens | 13698 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 487aab0a628c1f44c2b48d2030d8802e758ab89deb04eac557bd486c70c2186f |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | 122387c57576d2d7eb335ebf6678a6926cdedc678639c9bfd8e16be0db2ac00e |
| reasons | Evidence ev&#58;2&#58; text is not bound to supplied material.<br>Evidence ev&#58;3&#58; text is not bound to supplied material.<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;client&#58;p2&#x27; references evidence &#x27;ev&#58;2&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context)<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;client&#58;p2&#x27; references evidence &#x27;ev&#58;3&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context)<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; trans&#58;extract&#58;p1&#58; unresolved transformation origin; trans&#58;extract&#58;p2&#58; unresolved transformation origin; trans&#58;search&#58;p2&#58; transformed source mismatch; trans&#58;internal&#58;p1&#58; transformed source mismatch; trans&#58;internal&#58;p2&#58; transformed source mismatch; trans&#58;summary&#58;p1&#58; transformed source mismatch; trans&#58;summary&#58;p2&#58; transformed source mismatch<br>Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev&#58;1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed)<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client negative assertion on &#x27;neg&#58;p2&#x27; has unknown client&#95;scope &#x27;supplied&#95;material&#95;only&#x27; |
| record fingerprint | 0b6525d4165733a99844c6960e47fc9abcde8aa8ca28e8661cc30bfce6580a6a |
| technical status | incomplete |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | Not supplied |
| represented trigger analysis / evidence ids | ev&#58;1<br>ev&#58;2<br>ev&#58;3 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1<br>claim&#58;p2 |
| represented trigger analysis / reason | The claim asserts a clinical outcome benefit (fewer heart attacks) from a lipid-only Phase 2 result with no cardiovascular events tracked. This inflates a biomarker finding into a clinical benefit, which is overstatement rather than a described mechanism error. Whether the lipid result was used as a noncausal surrogate is not determinable from the supplied material, so that trigger is left null. |
| represented trigger analysis / trigger evidence id | ev&#58;3 |
| represented trigger analysis / trigger proposition id | claim&#58;p2 |
| represented trigger analysis / trigger quote | reduced heart attacks |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Propositions extracted from the single task prompt; the context supplies the trial details used as evidence. |
| logic / children / 1 / children | No entries recorded |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / children | No entries recorded |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | and |
| logic / proposition id | Not supplied |
| provenance id | prov&#58;1 |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | endpoint<br>population<br>follow&#95;up<br>comparison |
| materiality | required |
| not applicable | No entries recorded |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;1 |
| reason | The lipid result supports the LDL-lowering proposition only. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied material report LDL cholesterol lowering by the drug in familial hypercholesterolaemia? |
| search scope ids | scope&#58;supplied |
| uncertainty | Comparator and randomisation not specified.<br>Relative rather than absolute magnitude reported.<br>Company-reported; no independent review in supplied material. |

Quoted proposition; this is represented input, not a release assertion.

```
The drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 47 |
| start | 24 |
| text | lowered LDL cholesterol |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparator | Not supplied |
| comparison | Not supplied |
| effect basis | company-reported Phase 2 result |
| effect direction | decrease |
| effect magnitude | 65 percent (relative) |
| endpoint | LDL cholesterol |
| endpoint type | biomarker (lipid) |
| follow up | 12 weeks |
| intervention | new injectable drug |
| population | patients with familial hypercholesterolaemia on maximum statin therapy |
| relation | reduction |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p1&#58;ev1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev&#58;1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Reports the LDL reduction in the claimed population; the endpoint is lipid, not clinical. |
|  / 1 / search scope id | Not supplied |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | endpoint<br>endpoint&#95;type<br>follow&#95;up |
| materiality | required |
| not applicable | No entries recorded |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | claim&#58;p1 |
| proposition id | claim&#58;p2 |
| provenance id | prov&#58;1 |
| reason | The clinical outcome claim has no outcome data in the supplied material. |
| reported verdict | unsupported |
| required bridge ids | bridge&#58;lipid&#95;to&#95;events |
| search question | Does the supplied material report any heart-attack or cardiovascular event outcome for the drug in familial hypercholesterolaemia? |
| search scope ids | scope&#58;supplied |
| uncertainty | Absence of supplied outcome data does not prove absence of an effect.<br>External outcome evidence was not searched. |

Quoted proposition; this is represented input, not a release assertion.

```
The drug reduced heart attacks in patients with familial hypercholesterolaemia.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 73 |
| start | 52 |
| text | reduced heart attacks |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparator | Not supplied |
| comparison | Not supplied |
| effect basis | Not supplied |
| effect direction | decrease |
| effect magnitude | Not supplied |
| endpoint | heart attacks |
| endpoint type | clinical event |
| follow up | Not supplied |
| intervention | new injectable drug |
| population | patients with familial hypercholesterolaemia |
| relation | reduction |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p2&#58;ev2 |
|  / 1 / directness | remote |
|  / 1 / evidence id | ev&#58;2 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The trial measured only lipid and liver safety endpoints, so no heart-attack outcome was assessed. |
|  / 1 / search scope id | scope&#58;supplied |
|  / 2 / binding id | bind&#58;p2&#58;ev3 |
|  / 2 / directness | remote |
|  / 2 / evidence id | ev&#58;3 |
|  / 2 / observation | no&#95;evidence&#95;found |
|  / 2 / proposition id | claim&#58;p2 |
|  / 2 / reason | No cardiovascular events were tracked and no outcomes trial is expected for at least four years. |
|  / 2 / search scope id | scope&#58;supplied |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | bridge&#58;lipid&#95;to&#95;events |
|  / 1 / conclusion proposition id | claim&#58;p2 |
|  / 1 / dimensions | surrogate endpoint to clinical event<br>LDL lowering to heart attack reduction |
|  / 1 / evidence ids | ev&#58;2<br>ev&#58;3 |
|  / 1 / kind | mechanism&#95;to&#95;outcome |
|  / 1 / premise proposition ids | claim&#58;p1 |
|  / 1 / reason | The supplied material provides no evidence that LDL lowering in this trial translated into fewer heart attacks. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation trans&#58;extract&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes / population | familial hypercholesterolaemia |
| from proposition ids | No entries recorded |
| from text | lowered LDL cholesterol |
| reason | Extracts the lipid proposition; population is restated without change in scope. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / endpoint | LDL cholesterol |
| to attributes / population | patients with familial hypercholesterolaemia |
| to text | The drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| transformation id | trans&#58;extract&#58;p1 |

### Transformation trans&#58;extract&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes / population | familial hypercholesterolaemia |
| from proposition ids | No entries recorded |
| from text | reduced heart attacks |
| reason | Extracts the clinical outcome proposition; the original wording is unchanged in substance. |
| stage | extraction |
| target id | claim&#58;p2 |
| to attributes / endpoint | heart attacks |
| to attributes / population | patients with familial hypercholesterolaemia |
| to text | The drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| transformation id | trans&#58;extract&#58;p2 |

### Transformation trans&#58;search&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from attributes / endpoint | heart attacks |
| from proposition ids | claim&#58;p2 |
| from text | reduced heart attacks |
| reason | Search question widens the endpoint to cardiovascular events within the supplied material only. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to attributes / endpoint | heart attacks or cardiovascular events |
| to text | Does the supplied material report any heart-attack or cardiovascular event outcome for the drug in familial hypercholesterolaemia? |
| transformation id | trans&#58;search&#58;p2 |

### Transformation trans&#58;internal&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from proposition ids | claim&#58;p1 |
| from text | The drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| reason | Internal finding for the lipid proposition; the verdict is limited to the lipid endpoint. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.<br>Supported by the company-reported Phase 2 lipid result; lipid endpoint only. |
| transformation id | trans&#58;internal&#58;p1 |

### Transformation trans&#58;internal&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / endpoint | heart attacks |
| from proposition ids | claim&#58;p2 |
| from text | The drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| reason | Internal finding for the clinical outcome proposition; no outcome data are present. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | The drug reduced heart attacks in patients with familial hypercholesterolaemia.<br>Unsupported; no cardiovascular events or outcomes data in the supplied material. |
| transformation id | trans&#58;internal&#58;p2 |

### Transformation trans&#58;summary&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from attributes / endpoint | LDL cholesterol |
| from proposition ids | claim&#58;p1 |
| from text | lowered LDL cholesterol |
| reason | Summary reports the supported lipid result and keeps the company-reported and relative-magnitude qualifiers. |
| stage | summary |
| target id | client&#58;p1 |
| to attributes / effect basis | company-reported |
| to attributes / effect magnitude | 65 percent (relative) |
| to attributes / endpoint | LDL cholesterol |
| to text | The drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.<br>Company-reported 65 percent LDL reduction in familial hypercholesterolaemia patients on maximum statin therapy, from a twelve-week Phase 2 lipid endpoint. |
| transformation id | trans&#58;summary&#58;p1 |

### Transformation trans&#58;summary&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from attributes / endpoint | heart attacks |
| from proposition ids | claim&#58;p2 |
| from text | reduced heart attacks |
| reason | Summary states the outcome claim as unsupported rather than contradicted, and it does not assert that the drug is ineffective. |
| stage | summary |
| target id | client&#58;p2 |
| to attributes / endpoint | cardiovascular events |
| to attributes / follow up | outcomes trial pending |
| to text | The drug has not been shown to reduce heart attacks; no cardiovascular events were tracked.<br>The supplied material reports only lipid and liver safety results over twelve weeks. No outcomes trial is expected for at least four more years. |
| transformation id | trans&#58;summary&#58;p2 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev&#58;1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | LDL cholesterol |
| evidence id | ev&#58;1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | 65 percent reduction in LDL cholesterol |
| role | supporting |
| source id | context |
| value origin | reported&#95;by&#95;source |

Evidence text&#58;

```
The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy.
```

Exact source reference&#58;

```
reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | Not supplied |
| attributes / effect basis | company-reported |
| attributes / effect magnitude | 65 percent (relative) |
| attributes / endpoint | LDL cholesterol |
| attributes / endpoint type | biomarker (lipid) |
| attributes / follow up | 12 weeks |
| attributes / intervention | new injectable drug |
| attributes / population | familial hypercholesterolaemia on maximum statin therapy |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | comparator not specified<br>company-reported<br>Phase 2 duration of 12 weeks |
| evidence id | ev&#58;1 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | company-announced Phase 2 trial results |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev&#58;2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | lipid levels and liver safety |
| evidence id | ev&#58;2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | reported&#95;by&#95;source |

Evidence text&#58;

```
The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked.
```

Exact source reference&#58;

```
The trial measured only lipid levels and liver safety over twelve weeks
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | lipid levels and liver safety |
| attributes / endpoint type | biomarker and safety |
| attributes / follow up | 12 weeks |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | no clinical endpoints measured |
| evidence id | ev&#58;2 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | description of trial measurements |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev&#58;3

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | cardiovascular events and outcomes |
| evidence id | ev&#58;3 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | reported&#95;by&#95;source |

Evidence text&#58;

```
No cardiovascular events were tracked and no outcomes trial is expected to report for at least four more years.
```

Exact source reference&#58;

```
no cardiovascular events were tracked and no outcomes trial is expected to report for at least four more years
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | cardiovascular events |
| attributes / endpoint type | clinical event |
| attributes / follow up | outcomes trial not expected for at least four more years |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | no cardiovascular events tracked<br>outcomes trial pending |
| evidence id | ev&#58;3 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | description of outcomes tracking and timeline |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | heart attack<br>cardiovascular events<br>outcomes trial |
|  / 1 / resources | supplied task context only |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied material only; no external search executed |
|  / 1 / search scope id | scope&#58;supplied |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg&#58;p2 |
|  / 1 / assertion scope | supplied&#95;material&#95;only |
|  / 1 / finding id | claim&#58;p2 |
|  / 1 / proposition | No heart-attack reduction evidence found in the supplied material. |
|  / 1 / search scope id | scope&#58;supplied |
|  / 1 / source local evidence ids | ev&#58;2<br>ev&#58;3 |

Captured context (source&#95;id&#58; context)&#58;

```
A pharmaceutical company announced results from its Phase 2 trial of a new injectable cholesterol-lowering agent. The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy. Company executives described the results as a major breakthrough in cardiovascular protection and said the drug would transform outcomes for patients at high risk of heart attack and stroke. They announced plans for an accelerated approval pathway based on the LDL reduction data. The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked and no outcomes trial is expected to report for at least four more years.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | moderate; company-reported Phase 2 lipid result |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | supported |
|  / 1 / proposition | The drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
|  / 1 / provenance id | prov&#58;1 |
|  / 1 / supporting evidence ids | ev&#58;1 |
|  / 1 / verdict summary | Supported by the company-reported Phase 2 lipid result; lipid endpoint only. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status | high that the supplied material does not support this outcome claim |
|  / 2 / contrary evidence ids | No entries recorded |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | unsupported |
|  / 2 / proposition | The drug reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 2 / provenance id | prov&#58;1 |
|  / 2 / supporting evidence ids | No entries recorded |
|  / 2 / verdict summary | Unsupported; no cardiovascular events or outcomes data in the supplied material. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | Company-reported 65 percent LDL reduction in familial hypercholesterolaemia patients on maximum statin therapy, from a twelve-week Phase 2 lipid endpoint. |
|  / 1 / client finding id | client&#58;p1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;1 |
|  / 1 / referenced evidence ids | ev&#58;1 |
|  / 1 / value claims | No entries recorded |
|  / 2 / client explanation | The supplied material reports only lipid and liver safety results over twelve weeks. No outcomes trial is expected for at least four more years. |
|  / 2 / client finding id | client&#58;p2 |
|  / 2 / client negative assertions / 1 / assertion id | neg&#58;p2 |
|  / 2 / client negative assertions / 1 / client scope | supplied&#95;material&#95;only |
|  / 2 / client strength | not&#95;assessed |
|  / 2 / display claim | The drug has not been shown to reduce heart attacks; no cardiovascular events were tracked. |
|  / 2 / parent finding id | claim&#58;p2 |
|  / 2 / provenance id | prov&#58;1 |
|  / 2 / referenced evidence ids | ev&#58;2<br>ev&#58;3 |
|  / 2 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | b7073ec645763e6f1cc5adfa8cade222c8688e2ceba3e6a44a7c8a351b0d6cd3 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;62de4a34eb174e9d128e1f59

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;62de4a34eb174e9d128e1f59 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 122387c57576d2d7eb335ebf6678a6926cdedc678639c9bfd8e16be0db2ac00e |
| run id | c3b1650e-79e3-4cad-a006-47957941ebb8 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 11105 |
| usage / output tokens | 13698 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev&#58;1 |
| field | phase8.phase7&#95;controls.value&#95;origin&#95;provenance |
| mandatory | true |
| material | true |
| position ids | p9position&#58;62de4a34eb174e9d128e1f59 |
| projected object fingerprint | f1b7a957d2bdf4d2f7d3ba5e394851def571a10ba4fc6bdcd9122ad9171b6650 |
| proposition ids | No entries recorded |
| reason | client-visible value &#x27;ev&#58;1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;4f3c87afa4c4ba2f8c7ae21c |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;62de4a34eb174e9d128e1f59 |
| projected object fingerprint | 2f6a8eb48fd964d43bbf8953fdf2ee61db2a1a7660a7401e71c7706ee635aa29 |
| proposition ids | No entries recorded |
| reason | Evidence ev&#58;2&#58; text is not bound to supplied material.; Evidence ev&#58;3&#58; text is not bound to supplied material.; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;client&#58;p2&#x27; references evidence &#x27;ev&#58;2&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context); Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client finding &#x27;client&#58;p2&#x27; references evidence &#x27;ev&#58;3&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context); Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; trans&#58;extract&#58;p1&#58; unresolved transformation origin; trans&#58;extract&#58;p2&#58; unresolved transformation origin; trans&#58;search&#58;p2&#58; transformed source mismatch; trans&#58;internal&#58;p1&#58; transformed source mismatch; trans&#58;internal&#58;p2&#58; transformed source mismatch; trans&#58;summary&#58;p1&#58; transformed source mismatch; trans&#58;summary&#58;p2&#58; transformed source mismatch; Phase 7 unresolved&#95;value&#95;origin&#58; client-visible value &#x27;ev&#58;1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed); Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; client negative assertion on &#x27;neg&#58;p2&#x27; has unknown client&#95;scope &#x27;supplied&#95;material&#95;only&#x27; |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;73075bb3f4ced96ae1685df3 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | neg&#58;p2 |
| field | phase8.phase7&#95;controls.search&#95;scope&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;62de4a34eb174e9d128e1f59 |
| projected object fingerprint | 2f8d4551b40e09c79ca18a943a0c30b9f2978ed2db2591ee583524dd6ca579b9 |
| proposition ids | No entries recorded |
| reason | client negative assertion on &#x27;neg&#58;p2&#x27; has unknown client&#95;scope &#x27;supplied&#95;material&#95;only&#x27; |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;a748ecb3bb575d8acdf63e40 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev&#58;1<br>ev&#58;2<br>ev&#58;3 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;62de4a34eb174e9d128e1f59 |
| projected object fingerprint | 0764943aa85a4252f57dfe1eb7e2d36ba17408b777990f69e0014fd6d36b750d |
| proposition ids | claim&#58;p1<br>claim&#58;p2 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;c9917b8e674dbd50c439a086 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;62de4a34eb174e9d128e1f59 |
| projected object fingerprint | dea2082027e2247ceca076d6cd63c63eded95e2e3cfca20956e7d1b9cd4d1641 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; trans&#58;extract&#58;p1&#58; unresolved transformation origin; trans&#58;extract&#58;p2&#58; unresolved transformation origin; trans&#58;search&#58;p2&#58; transformed source mismatch; trans&#58;internal&#58;p1&#58; transformed source mismatch; trans&#58;internal&#58;p2&#58; transformed source mismatch; trans&#58;summary&#58;p1&#58; transformed source mismatch; trans&#58;summary&#58;p2&#58; transformed source mismatch |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;d61e08adb925e2870aecac9b |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 3<br>Evaluated&#58; 3<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;negative&#95;assertions |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | C |
|  / 1 / client finding id | client&#58;p2 |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | client finding &#x27;client&#58;p2&#x27; references evidence &#x27;ev&#58;2&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context) |
|  / 1 / refs | ev&#58;2 |
|  / 1 / severity | critical |
|  / 2 / check | C |
|  / 2 / client finding id | client&#58;p2 |
|  / 2 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 2 / detail | client finding &#x27;client&#58;p2&#x27; references evidence &#x27;ev&#58;3&#x27; that is not bound to parent finding &#x27;claim&#58;p2&#x27; (evidence used out of context) |
|  / 2 / refs | ev&#58;3 |
|  / 2 / severity | critical |
|  / 3 / check | P8 |
|  / 3 / client finding id |  |
|  / 3 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 3 / detail | Phase-8 output binding incomplete&#58; claim&#58;p2&#58; internal finding/evidence trace mismatch; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; claim&#58;p2&#58; no-evidence observation lacks Phase-7 negative-assertion trace; missing, duplicate or orphan mandatory transformation audit; trans&#58;extract&#58;p1&#58; unresolved transformation origin; trans&#58;extract&#58;p2&#58; unresolved transformation origin; trans&#58;search&#58;p2&#58; transformed source mismatch; trans&#58;internal&#58;p1&#58; transformed source mismatch; trans&#58;internal&#58;p2&#58; transformed source mismatch; trans&#58;summary&#58;p1&#58; transformed source mismatch; trans&#58;summary&#58;p2&#58; transformed source mismatch |
|  / 3 / refs | No entries recorded |
|  / 3 / severity | critical |

### Findings&#58; value&#95;origin&#95;provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / check | VF |
|  / 1 / client finding id | client&#58;p1 |
|  / 1 / code | unresolved&#95;value&#95;origin |
|  / 1 / detail | client-visible value &#x27;ev&#58;1&#x27; has an unresolved internal value&#95;origin; a missing origin must not be treated as source-reported (fail closed) |
|  / 1 / refs | ev&#58;1 |
|  / 1 / severity | critical |

### Findings&#58; search&#95;scope&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | SA |
|  / 1 / client finding id | client&#58;p2 |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | client negative assertion on &#x27;neg&#58;p2&#x27; has unknown client&#95;scope &#x27;supplied&#95;material&#95;only&#x27; |
|  / 1 / refs | neg&#58;p2 |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 0293de7094a4ffe2a275ad69f8c52def0f8c713151b7468978bf25d5386b5656 |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| code / code fingerprint | c2ee88ba6e64db194fc38355ad34cba862f2fcce268e4e4f7d3edbba83efb737 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | a695f91d4e6850714952e70947171ae28c557554 |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 213244b8ee0e36e1534fe67145f6b33704cf7dd9f0258f2a9980dc18771e2b7f |
| execution evidence / 1 / attempt ids | attempt-003 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-002 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 9365780abb36ebefabfc39f5ef3c32b4c4e1527c96706f73857d02f0508f3325 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 7960 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 47814 |
| execution evidence / 1 / message id | msg&#95;011CfuRtDKwqk68PtRUA1Vpn |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;1 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfuRtCkDanetwFAym46Sk |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 10909 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-haiku-5-5&#64;1&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 11105 |
| execution evidence / 1 / usage / output tokens | 13698 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 38d25af7fe1fef7b110fbcad00f93f2a4948109f0ef5268dbbe1d74155b6a166 |
| ledger fingerprint | c8b112fda859b446c9a5955949d98445f99892d61c82b9b50a7ac4f83b5d0d6e |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 11105 |
| providers / 1 / usage / output tokens | 13698 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | b7073ec645763e6f1cc5adfa8cade222c8688e2ceba3e6a44a7c8a351b0d6cd3 |
| run id | c3b1650e-79e3-4cad-a006-47957941ebb8 |
| selected position id | p9position&#58;62de4a34eb174e9d128e1f59 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

