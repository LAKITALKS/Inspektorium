# Canonical local audit

## Execution and release

RELEASED — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | completed |
| local release | RELEASED |
| mandatory review | false |
| review execution | not&#95;executed |
| review route | AUTO&#95;RESOLVABLE |
| scientific judgment | supported |

### Explicit release intent

| Field | Recorded value |
| --- | --- |
| reason | AA-P10-LIVE smoke repair cycle R1&#58; test-only local release decision on a live bundle to exercise the release path; no publication, no human adjudication or signature |
| reviewer | TEST ONLY - Claude Code smoke harness (no human reviewer; not an approval by Lazaros Varvatis) |
| scope | local&#95;artifact&#95;only |

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;31.801641+00&#58;00 |
| parent / manifest fingerprint | bc4edda833b8896bc3477f5361d154d2d38de0fc9f469116c8dcc0b5cc8d75f9 |
| parent / revision id | 25268a68-2ee5-4fba-93f3-2b7634f87028 |
| record fingerprint | 9edec1098c7b18d3b30a4f75aa0cc8e774650e8487e2500e9fe44e68c6fb1ff8 |
| revision | 64e637fe-2d9c-44bc-84f5-894eef62e4d8 |
| selected position id | p9position&#58;bf2355d7589a708b3e3668da |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-007 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | fefb644ca90ebc0ad8d4bff5a6e68a80f3f0b5191b1e337743afd31b9ac52925 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 115368 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 48505 |
|  / 1 / message id | msg&#95;011Cfvg7yv5VeyP5QT74seCt |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;2 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011Cfvg7y6iYxs1G1JjJeon4 |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 240630 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-sonnet-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14799 |
|  / 1 / usage / output tokens | 8577 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | supported |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | supported |
| contract version | AA-P8/1.0 |
| derived label | solid |
| input sha256 | bcad0619601626df989bae99790e409d0881b3482c83b67dd502802c0feceb18 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | bbb02c7af189d49bc888b3b376fcc963c02b1d2f354310e3309975f12c2fe288 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0 |
| record fingerprint | 70e9751e93264a47b4018047007c0ce26e18885b74d6bbd095d2380465f315eb |
| technical status | completed |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | supported |
|  / 1 / evidence ids | claim&#58;e1<br>claim&#58;e2 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | The claim is limited to a between-group difference in a randomized study, and the context reports randomization and a reading advantage for the program group.<br>No statistical uncertainty is reported in the context.<br>The study identity is unknown.<br>claim&#58;b1&#58; The context states that students were randomly assigned to the program or to regular instruction, which matches the randomized design in the claim.<br>descriptive inference permitted<br>claim&#58;b2&#58; Reading proficiency was reported as ahead of the comparison group at the end of the first year, which matches the claimed between-group advantage.<br>descriptive inference permitted<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 1 / reported verdict | supported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | solid |
| original model label | solid |
| represented trigger analysis / causal claim | false |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | claim&#58;e2 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The claim reports a between-group difference from a randomized comparison that the context supports. It uses no mechanism and makes no unsupported causal or clinical leap, so no taxonomy error applies. |
| represented trigger analysis / trigger evidence id | claim&#58;e2 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | reading proficiency was on average two and a half months ahead of the comparison group |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | solid |
| taxonomy check / reasons | Honest reporting with supported represented propositions |
| taxonomy check / technical status | completed |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single-proposition extraction of the full task prompt by the analyst. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov-1 |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | supported |
| derived judgment / evidence ids | claim&#58;e1<br>claim&#58;e2 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | The claim is limited to a between-group difference in a randomized study, and the context reports randomization and a reading advantage for the program group.<br>No statistical uncertainty is reported in the context.<br>The study identity is unknown.<br>claim&#58;b1&#58; The context states that students were randomly assigned to the program or to regular instruction, which matches the randomized design in the claim.<br>descriptive inference permitted<br>claim&#58;b2&#58; Reading proficiency was reported as ahead of the comparison group at the end of the first year, which matches the claimed between-group advantage.<br>descriptive inference permitted<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | population<br>intervention<br>comparator<br>endpoint<br>comparison |
| materiality | required |
| not applicable / certainty | The claim contains no explicit certainty wording. |
| not applicable / dose | The claim states no dose beyond weekly frequency. |
| not applicable / effect basis | The claim states no effect basis. |
| not applicable / effect magnitude | The claim states no magnitude. |
| not applicable / follow up | The claim specifies no time point. |
| not applicable / formulation | Not applicable to an instructional program. |
| not applicable / route | Not applicable to an instructional program. |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov-1 |
| reason | The claim is limited to a between-group difference in a randomized study, and the context reports randomization and a reading advantage for the program group. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied context show that, in a randomized study, elementary school students receiving weekly supplementary literacy instruction had better reading proficiency than students receiving regular instruction? |
| search scope ids | scope-1 |
| uncertainty | No statistical uncertainty is reported in the context.<br>The study identity is unknown. |

Quoted proposition; this is represented input, not a release assertion.

```
In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 187 |
| start | 0 |
| text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | regular instruction |
| comparison | between |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | better |
| effect magnitude | Not supplied |
| endpoint | reading proficiency |
| endpoint type | functional |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | weekly supplementary literacy instruction |
| population | elementary school students |
| relation | description |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | claim&#58;b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | claim&#58;e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The context states that students were randomly assigned to the program or to regular instruction, which matches the randomized design in the claim. |
|  / 1 / search scope id | scope-1 |
|  / 2 / binding id | claim&#58;b2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | claim&#58;e2 |
|  / 2 / observation | support |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | Reading proficiency was reported as ahead of the comparison group at the end of the first year, which matches the claimed between-group advantage. |
|  / 2 / search scope id | scope-1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation claim&#58;t-extraction-p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to text (identical) | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| from attributes / comparator | regular instruction |
| from attributes / comparison | between |
| from attributes / effect direction | better |
| from attributes / endpoint | reading proficiency |
| from attributes / endpoint type | functional |
| from attributes / intervention | weekly supplementary literacy instruction |
| from attributes / population | elementary school students |
| from attributes / relation | description |
| from attributes / species | human |
| from proposition ids | claim&#58;p1 |
| reason | Unchanged extraction; the proposition is the full claim. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / certainty | Not supplied |
| to attributes / comparator | regular instruction |
| to attributes / comparison | between |
| to attributes / dose | Not supplied |
| to attributes / effect basis | Not supplied |
| to attributes / effect direction | better |
| to attributes / effect magnitude | Not supplied |
| to attributes / endpoint | reading proficiency |
| to attributes / endpoint type | functional |
| to attributes / follow up | Not supplied |
| to attributes / formulation | Not supplied |
| to attributes / intervention | weekly supplementary literacy instruction |
| to attributes / population | elementary school students |
| to attributes / relation | description |
| to attributes / route | Not supplied |
| to attributes / species | human |
| transformation id | claim&#58;t-extraction-p1 |

### Transformation claim&#58;t-search-p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | regular instruction |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | better |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to attributes (identical) / endpoint type | functional |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | weekly supplementary literacy instruction |
| from and to attributes (identical) / population | elementary school students |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| reason | The search question is a restatement with no attribute change. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the supplied context show that, in a randomized study, elementary school students receiving weekly supplementary literacy instruction had better reading proficiency than students receiving regular instruction? |
| transformation id | claim&#58;t-search-p1 |

### Transformation claim&#58;t-internal-p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | regular instruction |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | better |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to attributes (identical) / endpoint type | functional |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | weekly supplementary literacy instruction |
| from and to attributes (identical) / population | elementary school students |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from and to text (identical) | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| from proposition ids | claim&#58;p1 |
| reason | The internal finding repeats the proposition unchanged. |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | claim&#58;t-internal-p1 |

### Transformation claim&#58;t-summary-client1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | regular instruction |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | better |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to attributes (identical) / endpoint type | functional |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | weekly supplementary literacy instruction |
| from and to attributes (identical) / population | elementary school students |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from and to text (identical) | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| from proposition ids | claim&#58;p1 |
| reason | The client display repeats the claim unchanged, with no added strength, magnitude or scope. |
| stage | summary |
| target id | client&#58;1 |
| transformation id | claim&#58;t-summary-client1 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence claim&#58;e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading proficiency |
| evidence id | claim&#58;e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
Students were randomly assigned to either the program or regular instruction.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | regular instruction |
| attributes / comparison | between |
| attributes / dose | Not supplied |
| attributes / effect basis | Not supplied |
| attributes / effect direction | better |
| attributes / effect magnitude | Not supplied |
| attributes / endpoint | reading proficiency |
| attributes / endpoint type | functional |
| attributes / follow up | Not supplied |
| attributes / formulation | Not supplied |
| attributes / intervention | weekly supplementary literacy instruction |
| attributes / population | elementary school students |
| attributes / relation | description |
| attributes / route | Not supplied |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No entries recorded |
| evidence id | claim&#58;e1 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | context description of the randomized assignment design |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence claim&#58;e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading proficiency |
| evidence id | claim&#58;e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
By the end of the first year, participants' reading proficiency was on average two and a half months ahead of the comparison group
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | regular instruction |
| attributes / comparison | between |
| attributes / dose | Not supplied |
| attributes / effect basis | Not supplied |
| attributes / effect direction | better |
| attributes / effect magnitude | Not supplied |
| attributes / endpoint | reading proficiency |
| attributes / endpoint type | functional |
| attributes / follow up | Not supplied |
| attributes / formulation | Not supplied |
| attributes / intervention | weekly supplementary literacy instruction |
| attributes / population | elementary school students |
| attributes / relation | description |
| attributes / route | Not supplied |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No entries recorded |
| evidence id | claim&#58;e2 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | context description of the reported first-year outcome |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | scope-1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A large-scale study investigated a literacy support program in which elementary school students received weekly supplementary instruction over two school years. Students were randomly assigned to either the program or regular instruction. By the end of the first year, participants' reading proficiency was on average two and a half months ahead of the comparison group, and this advantage was still detectable 26 months later. The researchers note that the effect remained stable across all age groups and that no systematic disadvantages were observed.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov-1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | solid |
|  / 1 / proposition | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / provenance id | prov-1 |
|  / 1 / supporting evidence ids | claim&#58;e1<br>claim&#58;e2 |
|  / 1 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | client&#58;1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov-1 |
|  / 1 / referenced evidence ids | claim&#58;e1<br>claim&#58;e2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | false |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | not&#95;required |
| route | AUTO&#95;RESOLVABLE |
| technical status | completed |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | adcb2073d8fe06ab08349afe87795feaa8f0bf738972ee5f1a7e6b335ec2011e |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | AUTO&#95;RESOLVABLE |
| source reference | record.json&#35;/run&#95;record |
| technical status | completed |

### Position p9position&#58;bf2355d7589a708b3e3668da

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | solid |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;bf2355d7589a708b3e3668da |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | bbb02c7af189d49bc888b3b376fcc963c02b1d2f354310e3309975f12c2fe288 |
| run id | 7dd850c2-6d2f-472c-af73-e6235becc6a8 |
| scientific state | supported |
| selected | true |
| taxonomy status | completed |
| technical status | completed |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14799 |
| usage / output tokens | 8577 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 762ab0935d84f1bbb698049cf910f33bc73a6d51d7397b630778630f28b67d92 |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 7921607f90dd71dc618e73c43cee6f7c71061f0d09244f5c40ad78be5ac0d15e |
| execution evidence / 1 / attempt ids | attempt-007 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | fefb644ca90ebc0ad8d4bff5a6e68a80f3f0b5191b1e337743afd31b9ac52925 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 115368 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 48505 |
| execution evidence / 1 / message id | msg&#95;011Cfvg7yv5VeyP5QT74seCt |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011Cfvg7y6iYxs1G1JjJeon4 |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 240630 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-sonnet-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14799 |
| execution evidence / 1 / usage / output tokens | 8577 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 623dce11258f5e614550f971b4e8d2f4541e6fdae2d08453bc8d0044fc3a5b7e |
| ledger fingerprint | 42522db18e064256d358aa4f4d6ed6768bb615b40586858b3e281483f5e1155d |
| package version | 0.1.0 |
| phase8 summary / composite state | supported |
| phase8 summary / derived label | solid |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | completed |
| phase8 summary / technical status | completed |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | false |
| phase9 summary / review state | not&#95;required |
| phase9 summary / route | AUTO&#95;RESOLVABLE |
| phase9 summary / technical status | completed |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14799 |
| providers / 1 / usage / output tokens | 8577 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | adcb2073d8fe06ab08349afe87795feaa8f0bf738972ee5f1a7e6b335ec2011e |
| run id | 7dd850c2-6d2f-472c-af73-e6235becc6a8 |
| selected position id | p9position&#58;bf2355d7589a708b3e3668da |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

