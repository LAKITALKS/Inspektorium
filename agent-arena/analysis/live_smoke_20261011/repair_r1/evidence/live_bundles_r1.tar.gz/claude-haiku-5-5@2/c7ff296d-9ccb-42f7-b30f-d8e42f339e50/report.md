# Canonical local audit

## Execution and release

READY&#95;FOR&#95;RELEASE — local artifact status

LIVE MODEL GENERATION (AA-P10-LIVE/1.0). Actual provider calls produced the analysed responses; model, request IDs, attempts and cost are bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | completed |
| local release | READY&#95;FOR&#95;RELEASE |
| mandatory review | false |
| review execution | not&#95;executed |
| review route | AUTO&#95;RESOLVABLE |
| scientific judgment | supported |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;12&#58;08.259476+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 73eaa0c24e462e774fc44ef062ee9672cf11cf7e28937caf4d2384ffd02ebc4b |
| revision | c7ff296d-9ccb-42f7-b30f-d8e42f339e50 |
| selected position id | p9position&#58;f24390e67eec643f20556ac3 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-001 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 13a941f28f8e0840a489581aa31166b030cd94e480fc0077d7355cb04d32e509 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 14130 |
|  / 1 / current execution | live&#95;generation |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 94612 |
|  / 1 / message id | msg&#95;011CfvfQcDiJcYwPQwyoduH4 |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;2 |
|  / 1 / provider | anthropic-live |
|  / 1 / replay capture verified | Not supplied |
|  / 1 / replay request identical | Not supplied |
|  / 1 / request id | req&#95;011CfvfQasbgcGWxvhHabE3A |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 20032 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-haiku-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14799 |
|  / 1 / usage / output tokens | 25300 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | supported |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | supported |
| contract version | AA-P8/1.0 |
| derived label | solid |
| input sha256 | bcad0619601626df989bae99790e409d0881b3482c83b67dd502802c0feceb18 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | b63730bdeaefb47b41b84599be713d88cf65fa5db0c62714efbc96af001197d2 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0 |
| record fingerprint | 4d4354a13903a431ed7a1d400776fd2feb8908a8b401ad1b9ddc19374ac1705f |
| technical status | completed |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | supported |
|  / 1 / evidence ids | ev&#58;design |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | The randomized assignment is directly stated in the supplied context.<br>Sample size, allocation and attrition are not supplied.<br>bind&#58;p1&#58;design&#58; The context states that students were randomly assigned to the program or regular instruction, which is the randomized design named in the claim.<br>descriptive inference permitted<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 1 / reported verdict | supported |
|  / 2 / dependency status | unknown |
|  / 2 / derived state | supported |
|  / 2 / evidence ids | ev&#58;outcome |
|  / 2 / proposition id | claim&#58;p2 |
|  / 2 / reasons | The directional group difference in reading proficiency is directly reported in the supplied context.<br>The context does not give the sample size or variance of the difference.<br>The context&#x27;s population and intervention wording is taken from the study description as a whole.<br>bind&#58;p2&#58;outcome&#58; The context reports a between-group advantage in reading proficiency for the program group at the end of year one, matching population, intervention, comparator, endpoint and comparison as described in the context.<br>descriptive inference permitted<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 2 / reported verdict | supported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | solid |
| original model label | solid |
| represented trigger analysis / causal claim | false |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev&#58;design<br>ev&#58;outcome |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1<br>claim&#58;p2 |
| represented trigger analysis / reason | The claim reports a randomized between-group outcome difference with descriptive relation; it asserts no causal wording beyond the design, uses no noncausal result, and describes no biological mechanism, so no taxonomy error is present. The comparative outcome implies a benefit relative to regular instruction, which is recorded as implied but is not a mechanism-to-outcome inflation. |
| represented trigger analysis / trigger evidence id | ev&#58;outcome |
| represented trigger analysis / trigger proposition id | claim&#58;p2 |
| represented trigger analysis / trigger quote | had better reading proficiency than students who received regular instruction |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | solid |
| taxonomy check / reasons | Honest reporting with supported represented propositions |
| taxonomy check / technical status | completed |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Propositions extracted from the single input claim sentence by splitting the randomized-design qualifier from the comparative outcome; no external search executed. |
| logic / children / 1 / children | No entries recorded |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / children | No entries recorded |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | and |
| logic / proposition id | Not supplied |
| provenance id | prov&#58;claim |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | supported |
| derived judgment / evidence ids | ev&#58;design |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | The randomized assignment is directly stated in the supplied context.<br>Sample size, allocation and attrition are not supplied.<br>bind&#58;p1&#58;design&#58; The context states that students were randomly assigned to the program or regular instruction, which is the randomized design named in the claim.<br>descriptive inference permitted<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | comparison |
| materiality | required |
| not applicable / certainty | the claim states no certainty qualifier |
| not applicable / comparator | the design statement names no comparator |
| not applicable / endpoint | the design statement names no endpoint |
| not applicable / endpoint type | the design statement names no endpoint type |
| not applicable / follow up | the design statement names no follow-up |
| not applicable / intervention | the design statement names no intervention |
| not applicable / population | the design statement names no population |
| not applicable / species | the design statement names no species |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;claim |
| reason | The randomized assignment is directly stated in the supplied context. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied material show that students were randomly assigned to the program or regular instruction? |
| search scope ids | scope&#58;reviewed&#95;context |
| uncertainty | Sample size, allocation and attrition are not supplied. |

Quoted proposition; this is represented input, not a release assertion.

```
The study was randomized.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 21 |
| start | 0 |
| text | In a randomized study |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| comparison | between |
| relation | description |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p1&#58;design |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev&#58;design |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The context states that students were randomly assigned to the program or regular instruction, which is the randomized design named in the claim. |
|  / 1 / search scope id | scope&#58;reviewed&#95;context |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | supported |
| derived judgment / evidence ids | ev&#58;outcome |
| derived judgment / proposition id | claim&#58;p2 |
| derived judgment / reasons | The directional group difference in reading proficiency is directly reported in the supplied context.<br>The context does not give the sample size or variance of the difference.<br>The context&#x27;s population and intervention wording is taken from the study description as a whole.<br>bind&#58;p2&#58;outcome&#58; The context reports a between-group advantage in reading proficiency for the program group at the end of year one, matching population, intervention, comparator, endpoint and comparison as described in the context.<br>descriptive inference permitted<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | population<br>species<br>intervention<br>comparator<br>endpoint<br>endpoint&#95;type<br>effect&#95;direction<br>comparison |
| materiality | required |
| not applicable / certainty | the claim states no certainty qualifier |
| not applicable / dose | the claim states no dose |
| not applicable / effect basis | the claim states no effect basis |
| not applicable / effect magnitude | the claim states no magnitude |
| not applicable / follow up | the claim names no follow-up time |
| not applicable / formulation | the claim states no formulation |
| not applicable / route | the claim states no route |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p2 |
| provenance id | prov&#58;claim |
| reason | The directional group difference in reading proficiency is directly reported in the supplied context. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied material show that elementary school students receiving weekly supplementary literacy instruction had better reading proficiency than students receiving regular instruction? |
| search scope ids | scope&#58;reviewed&#95;context |
| uncertainty | The context does not give the sample size or variance of the difference.<br>The context&#x27;s population and intervention wording is taken from the study description as a whole. |

Quoted proposition; this is represented input, not a release assertion.

```
elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 186 |
| start | 23 |
| text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | regular instruction |
| comparison | between |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | favoring program |
| effect magnitude | Not supplied |
| endpoint | reading proficiency |
| endpoint type | educational&#95;assessment |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | weekly supplementary literacy instruction |
| population | elementary school students |
| relation | description |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p2&#58;outcome |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev&#58;outcome |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The context reports a between-group advantage in reading proficiency for the program group at the end of year one, matching population, intervention, comparator, endpoint and comparison as described in the context. |
|  / 1 / search scope id | scope&#58;reviewed&#95;context |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation tr&#58;extraction&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / relation | description |
| from proposition ids | claim&#58;p1 |
| from text | In a randomized study |
| reason | Extraction restates the design qualifier without changing its meaning; attributes unchanged. |
| stage | extraction |
| target id | claim&#58;p1 |
| to text | The study was randomized. |
| transformation id | tr&#58;extraction&#58;p1 |

### Transformation tr&#58;extraction&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | regular instruction |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | favoring program |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to attributes (identical) / endpoint type | educational&#95;assessment |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | weekly supplementary literacy instruction |
| from and to attributes (identical) / population | elementary school students |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from and to text (identical) | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction |
| from proposition ids | claim&#58;p2 |
| reason | Extraction copies the comparative outcome span unchanged. |
| stage | extraction |
| target id | claim&#58;p2 |
| transformation id | tr&#58;extraction&#58;p2 |

### Transformation tr&#58;search&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / relation | description |
| from proposition ids | claim&#58;p1 |
| from text | The study was randomized. |
| reason | Search question restates the design proposition as a question over the reviewed context; attributes unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the supplied material show that students were randomly assigned to the program or regular instruction? |
| transformation id | tr&#58;search&#58;p1 |

### Transformation tr&#58;search&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | regular instruction |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | favoring program |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to attributes (identical) / endpoint type | educational&#95;assessment |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | weekly supplementary literacy instruction |
| from and to attributes (identical) / population | elementary school students |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction |
| reason | Search question restates the outcome proposition as a question over the reviewed context; attributes unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Does the supplied material show that elementary school students receiving weekly supplementary literacy instruction had better reading proficiency than students receiving regular instruction? |
| transformation id | tr&#58;search&#58;p2 |

### Transformation tr&#58;internal&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / relation | description |
| from proposition ids | claim&#58;p1 |
| from text | The study was randomized. |
| reason | Internal finding carries the design proposition and its verdict summary; state matches host derivation. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The study was randomized.<br>Context states that students were randomly assigned to the program or regular instruction. |
| transformation id | tr&#58;internal&#58;p1 |

### Transformation tr&#58;internal&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | regular instruction |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | favoring program |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to attributes (identical) / endpoint type | educational&#95;assessment |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | weekly supplementary literacy instruction |
| from and to attributes (identical) / population | elementary school students |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction |
| reason | Internal finding carries the outcome proposition and its verdict summary; no magnitude or persistence is added to the claim. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction<br>Context reports reading proficiency about two and a half months ahead for the program group by the end of year one. |
| transformation id | tr&#58;internal&#58;p2 |

### Transformation tr&#58;summary&#58;cf&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / relation | description |
| from proposition ids | claim&#58;p1 |
| from text | The study was randomized. |
| reason | Client summary restates the randomized design as stated in the context; no hedge lost and no attribute changed. |
| stage | summary |
| target id | cf&#58;p1 |
| to text | The study was randomized&#58; students were randomly assigned to the program or regular instruction. |
| transformation id | tr&#58;summary&#58;cf&#58;p1 |

### Transformation tr&#58;summary&#58;cf&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | regular instruction |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | favoring program |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading proficiency |
| from and to attributes (identical) / endpoint type | educational&#95;assessment |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | weekly supplementary literacy instruction |
| from and to attributes (identical) / population | elementary school students |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction |
| reason | Client summary restates the outcome proposition with the same direction and no added magnitude, persistence or causal wording; the randomized design is carried by cf&#58;p1. |
| stage | summary |
| target id | cf&#58;p2 |
| to text | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
| transformation id | tr&#58;summary&#58;cf&#58;p2 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev&#58;design

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint |  |
| evidence id | ev&#58;design |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
Students were randomly assigned to either the program or regular instruction.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | regular instruction |
| attributes / comparison | between |
| attributes / intervention | weekly supplementary literacy instruction |
| attributes / population | elementary school students |
| attributes / relation | description |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | The context gives no sample size, allocation or attrition details. |
| evidence id | ev&#58;design |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | randomized assignment statement in the supplied context |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev&#58;outcome

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading proficiency |
| evidence id | ev&#58;outcome |
| input evidence ids | No entries recorded |
| material | true |
| reported value | two and a half months ahead of the comparison group |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
participants' reading proficiency was on average two and a half months ahead of the comparison group
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | regular instruction |
| attributes / comparison | between |
| attributes / effect basis | between-group difference |
| attributes / effect direction | favoring program |
| attributes / effect magnitude | two and a half months ahead |
| attributes / endpoint | reading proficiency |
| attributes / endpoint type | educational&#95;assessment |
| attributes / follow up | end of first year |
| attributes / intervention | weekly supplementary literacy instruction |
| attributes / population | elementary school students |
| attributes / relation | description |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | The context reports a single end-of-year-one difference without sample size or variance. |
| evidence id | ev&#58;outcome |
| evidence type | controlled&#95;intervention |
| identification argument | Students were randomly assigned to either the program or regular instruction. |
| identification evidence ids | ev&#58;design |
| quality | Not supplied |
| randomized | true |
| source role | reported end-of-first-year between-group difference in reading proficiency |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | randomly assigned<br>reading proficiency |
|  / 1 / resources | supplied task context |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied context only; no external search executed |
|  / 1 / search scope id | scope&#58;reviewed&#95;context |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A large-scale study investigated a literacy support program in which elementary school students received weekly supplementary instruction over two school years. Students were randomly assigned to either the program or regular instruction. By the end of the first year, participants' reading proficiency was on average two and a half months ahead of the comparison group, and this advantage was still detectable 26 months later. The researchers note that the effect remained stable across all age groups and that no systematic disadvantages were observed.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | In a randomized study, elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | The study was randomized. |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / supporting evidence ids | ev&#58;design |
|  / 1 / verdict summary | Context states that students were randomly assigned to the program or regular instruction. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status |  |
|  / 2 / contrary evidence ids | No entries recorded |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | Not supplied |
|  / 2 / proposition | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction |
|  / 2 / provenance id | prov&#58;claim |
|  / 2 / supporting evidence ids | ev&#58;outcome |
|  / 2 / verdict summary | Context reports reading proficiency about two and a half months ahead for the program group by the end of year one. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | cf&#58;p1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The study was randomized&#58; students were randomly assigned to the program or regular instruction. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;claim |
|  / 1 / referenced evidence ids | ev&#58;design |
|  / 1 / value claims | No entries recorded |
|  / 2 / client explanation |  |
|  / 2 / client finding id | cf&#58;p2 |
|  / 2 / client negative assertions | No entries recorded |
|  / 2 / client strength | not&#95;assessed |
|  / 2 / display claim | elementary school students who received the weekly supplementary literacy instruction had better reading proficiency than students who received regular instruction. |
|  / 2 / parent finding id | claim&#58;p2 |
|  / 2 / provenance id | prov&#58;claim |
|  / 2 / referenced evidence ids | ev&#58;outcome |
|  / 2 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | false |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | not&#95;required |
| route | AUTO&#95;RESOLVABLE |
| technical status | completed |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | e0b3ae9d1d28f6b32d913488759fc72322601fe724f42bcff4ff8cc68efae9d3 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | AUTO&#95;RESOLVABLE |
| source reference | record.json&#35;/run&#95;record |
| technical status | completed |

### Position p9position&#58;f24390e67eec643f20556ac3

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | solid |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;f24390e67eec643f20556ac3 |
| provider | anthropic-live |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | b63730bdeaefb47b41b84599be713d88cf65fa5db0c62714efbc96af001197d2 |
| run id | b74c0c1d-cbbc-434d-9cb8-53ca1158babd |
| scientific state | supported |
| selected | true |
| taxonomy status | completed |
| technical status | completed |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14799 |
| usage / output tokens | 25300 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | cba886de499887206b0b8fd3f6c48f231d66ece43c11c1c1631e42432c7069e7 |
| case id | p9case&#58;01c8f0d30d720f42d929fad7 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-anthropic-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | e9cdc5f519225bcc137c37c6a88f19e0f8c6784741521d4529ea3c5739e76338 |
| execution evidence / 1 / attempt ids | attempt-001 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 13a941f28f8e0840a489581aa31166b030cd94e480fc0077d7355cb04d32e509 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 14130 |
| execution evidence / 1 / current execution | live&#95;generation |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 94612 |
| execution evidence / 1 / message id | msg&#95;011CfvfQcDiJcYwPQwyoduH4 |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live |
| execution evidence / 1 / replay capture verified | Not supplied |
| execution evidence / 1 / replay request identical | Not supplied |
| execution evidence / 1 / request id | req&#95;011CfvfQasbgcGWxvhHabE3A |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 20032 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-01&#124;claude-haiku-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14799 |
| execution evidence / 1 / usage / output tokens | 25300 |
| execution mode | live&#95;generation |
| execution mode errors | No entries recorded |
| input fingerprint | 623dce11258f5e614550f971b4e8d2f4541e6fdae2d08453bc8d0044fc3a5b7e |
| ledger fingerprint | bcb3cc0dd09c5d56bbd9ac8a431a1db399d4395d43038877e33ed64f48369395 |
| package version | 0.1.0 |
| phase8 summary / composite state | supported |
| phase8 summary / derived label | solid |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | completed |
| phase8 summary / technical status | completed |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | false |
| phase9 summary / review state | not&#95;required |
| phase9 summary / route | AUTO&#95;RESOLVABLE |
| phase9 summary / technical status | completed |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14799 |
| providers / 1 / usage / output tokens | 25300 |
| recording notice | LIVE MODEL GENERATION (AA-P10-LIVE/1.0); see execution evidence for model, request IDs and cost |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | e0b3ae9d1d28f6b32d913488759fc72322601fe724f42bcff4ff8cc68efae9d3 |
| run id | b74c0c1d-cbbc-434d-9cb8-53ca1158babd |
| selected position id | p9position&#58;f24390e67eec643f20556ac3 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

