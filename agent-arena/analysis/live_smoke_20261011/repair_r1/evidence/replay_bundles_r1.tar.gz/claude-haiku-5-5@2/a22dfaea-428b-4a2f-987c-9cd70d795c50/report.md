# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;53.538499+00&#58;00 |
| parent | Not supplied |
| record fingerprint | bd980d47214ecc945750143f3e8f42d291b1d158392a8c3f652b1a101ff2373e |
| revision | a22dfaea-428b-4a2f-987c-9cd70d795c50 |
| selected position id | p9position&#58;ae88b98055d2af36471f0a9e |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-006 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 1971f8118fa603bee2edbc004b459be571c4e26a2fa855fab303587b1a8b28a3 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 12352 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 82988 |
|  / 1 / message id | msg&#95;011Cfvfwp1VCwEtR9gFoXWQF |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvfwoM3mXxWwFG7eqvzv |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 20049 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-haiku-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14917 |
|  / 1 / usage / output tokens | 21720 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Eating a good breakfast every morning makes you lose weight.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 609ee28c8d2fb302457ee4550b78e951b6c05250ac44fdaf263f5cdc58dd02e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | correlation&#95;vs&#95;causation |
| raw response sha256 | 2aab8c39e847f1af2e800b508e926ba16cb1de37d32fd3ffe5e5367d605680e1 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown<br>tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown |
| record fingerprint | bdb6e8fa92738e4f67ce59b654349caab3600703e33a39c9f9872adc4a0e76f1 |
| technical status | incomplete |
| transformation findings | tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown<br>tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | ev&#58;rct<br>ev&#58;observational |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | The direct RCT meta-analysis contradicts the causal claim that eating breakfast produces weight loss. The only support offered in the feature is observational and noncausal.<br>The RCT tested assignment to eat breakfast, not a &#x27;good&#x27; breakfast; the quality qualifier is untested.<br>The claim&#x27;s generic &#x27;you&#x27; is mapped to adults, which is a transfer assumption.<br>Follow-up duration and effect magnitude are not given in the context.<br>bind&#58;p1&#58;rct&#58; The RCT meta-analysis directly tests assigned breakfast eating on body weight in adults and found no weight loss, with slightly higher weight in the breakfast-assigned group. The effect&#95;direction difference is not counted for a contradiction binding. The &#x27;good breakfast&#x27; quality qualifier was not separately tested.<br>review underlying capability absent<br>bind&#58;p1&#58;observational&#58; Cross-sectional and prospective observational associations between breakfast skipping and weight are noncausal and do not establish that breakfast eating causes weight loss.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 1 / reported verdict | contradicted |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | correlation&#95;vs&#95;causation |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | causal&#95;inference |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev&#58;observational<br>ev&#58;rct |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | true |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The causal assertion that breakfast produces weight loss is supported in the feature by noncausal cross-sectional and prospective observational associations (breakfast skippers weigh more). The causal claim is the core error. No biological mechanism is described, and the claim implies human benefit (weight loss). The direct RCT evidence contradicts the causal claim, so this taxonomy check does not replace the scientific verdict. |
| represented trigger analysis / trigger evidence id | ev&#58;observational |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | cross-sectional and prospective OBSERVATIONAL studies |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single causal proposition extracted from the task prompt; the &#x27;good breakfast&#x27; qualifier and &#x27;every morning&#x27; frequency are kept in the proposition text, and the intervention attribute is reduced to &#x27;eating breakfast&#x27; for comparison with the RCT. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov&#58;input-claim |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | ev&#58;rct<br>ev&#58;observational |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | The direct RCT meta-analysis contradicts the causal claim that eating breakfast produces weight loss. The only support offered in the feature is observational and noncausal.<br>The RCT tested assignment to eat breakfast, not a &#x27;good&#x27; breakfast; the quality qualifier is untested.<br>The claim&#x27;s generic &#x27;you&#x27; is mapped to adults, which is a transfer assumption.<br>Follow-up duration and effect magnitude are not given in the context.<br>bind&#58;p1&#58;rct&#58; The RCT meta-analysis directly tests assigned breakfast eating on body weight in adults and found no weight loss, with slightly higher weight in the breakfast-assigned group. The effect&#95;direction difference is not counted for a contradiction binding. The &#x27;good breakfast&#x27; quality qualifier was not separately tested.<br>review underlying capability absent<br>bind&#58;p1&#58;observational&#58; Cross-sectional and prospective observational associations between breakfast skipping and weight are noncausal and do not establish that breakfast eating causes weight loss.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | contradicted |
| material dimensions | population<br>species<br>intervention<br>endpoint<br>endpoint&#95;type<br>relation<br>effect&#95;direction |
| materiality | required |
| not applicable / certainty | the claim is unhedged and certainty is not a compared dimension |
| not applicable / comparator | the claim names no comparator; the implied comparison is not eating a good breakfast |
| not applicable / comparison | the claim states no between-group or within-group comparison |
| not applicable / follow up | the claim states no follow-up duration |
| observation target | contradiction |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;input-claim |
| reason | The direct RCT meta-analysis contradicts the causal claim that eating breakfast produces weight loss. The only support offered in the feature is observational and noncausal. |
| reported verdict | contradicted |
| required bridge ids | No entries recorded |
| search question | Do randomized trials that assign adults to eat breakfast show body-weight loss compared with skipping breakfast? |
| search scope ids | scope&#58;context-reviewed |
| uncertainty | The RCT tested assignment to eat breakfast, not a &#x27;good&#x27; breakfast; the quality qualifier is untested.<br>The claim&#x27;s generic &#x27;you&#x27; is mapped to adults, which is a transfer assumption.<br>Follow-up duration and effect magnitude are not given in the context. |

Quoted proposition; this is represented input, not a release assertion.

```
Eating a good breakfast every morning makes you lose weight.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 60 |
| start | 0 |
| text | Eating a good breakfast every morning makes you lose weight. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | Not supplied |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | decrease |
| effect magnitude | Not supplied |
| endpoint | body weight |
| endpoint type | clinical |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | eating breakfast |
| population | adults |
| relation | causal |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p1&#58;rct |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev&#58;rct |
|  / 1 / observation | contradiction |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The RCT meta-analysis directly tests assigned breakfast eating on body weight in adults and found no weight loss, with slightly higher weight in the breakfast-assigned group. The effect&#95;direction difference is not counted for a contradiction binding. The &#x27;good breakfast&#x27; quality qualifier was not separately tested. |
|  / 1 / search scope id | scope&#58;context-reviewed |
|  / 2 / binding id | bind&#58;p1&#58;observational |
|  / 2 / directness | indirect |
|  / 2 / evidence id | ev&#58;observational |
|  / 2 / observation | inconclusive |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | Cross-sectional and prospective observational associations between breakfast skipping and weight are noncausal and do not establish that breakfast eating causes weight loss. |
|  / 2 / search scope id | scope&#58;context-reviewed |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation tx&#58;extraction&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | body weight |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | eating breakfast |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from and to text (identical) | Eating a good breakfast every morning makes you lose weight. |
| from proposition ids | claim&#58;p1 |
| reason | Extraction of the single causal proposition from the original claim span, with attributes unchanged from the proposition. |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | tx&#58;extraction&#58;claim&#58;p1 |

### Transformation tx&#58;search&#95;question&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | body weight |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | eating breakfast |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | Search question restated from the proposition over the supplied reviewed set only; attributes are unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Do randomized trials that assign adults to eat breakfast show body-weight loss compared with skipping breakfast? |
| transformation id | tx&#58;search&#95;question&#58;claim&#58;p1 |

### Transformation tx&#58;internal&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | body weight |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | eating breakfast |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | Internal finding restates the proposition and its verdict summary; the asserted state matches the evidence-derived state of the proposition. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Eating a good breakfast every morning makes you lose weight.<br>Contradicted by direct RCT evidence in the supplied context; observational association does not establish causation. |
| transformation id | tx&#58;internal&#58;claim&#58;p1 |

### Transformation tx&#58;summary&#58;client&#58;claim&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | body weight |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | eating breakfast |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | Client summary of the single proposition; the whole-claim state is contradicted because the only required proposition is contradicted. The explanation is scoped to the supplied context and states that observational association does not establish causation. |
| stage | summary |
| target id | client&#58;claim&#58;p1 |
| to text | Eating a good breakfast every morning makes you lose weight.<br>Randomized trial evidence in the supplied context found that assigning adults to eat breakfast did not cause weight loss and, if anything, was associated with slightly higher body weight. The observational finding that breakfast skippers weigh more does not establish that breakfast causes weight loss. |
| transformation id | tx&#58;summary&#58;client&#58;claim&#58;p1 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev&#58;observational

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | body weight |
| evidence id | ev&#58;observational |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | Not supplied |

Evidence text&#58;

```
cross-sectional and prospective OBSERVATIONAL studies (breakfast skippers differ from eaters in many health and lifestyle behaviours)
```

Exact source reference&#58;

```
cross-sectional and prospective OBSERVATIONAL studies
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | Not supplied |
| attributes / comparison | Not supplied |
| attributes / dose | Not supplied |
| attributes / effect basis | Not supplied |
| attributes / effect direction | skippers weigh more |
| attributes / effect magnitude | Not supplied |
| attributes / endpoint | body weight |
| attributes / endpoint type | clinical |
| attributes / follow up | Not supplied |
| attributes / formulation | Not supplied |
| attributes / intervention | breakfast skipping (observed exposure, not assigned) |
| attributes / population | Not supplied |
| attributes / relation | association |
| attributes / route | Not supplied |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | breakfast skippers differ from eaters in many health and lifestyle behaviours |
| evidence id | ev&#58;observational |
| evidence type | observational |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | false |
| source role | cross-sectional and prospective observational studies on breakfast skipping and weight, as cited in the supplied context |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev&#58;rct

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | body weight |
| evidence id | ev&#58;rct |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | contradictory |
| source id | context |
| value origin | Not supplied |

Evidence text&#58;

```
a systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) found that assigning people to eat breakfast did not cause weight loss — adults assigned to eat breakfast consumed more total daily calories and, if anything, weighed slightly more than those assigned to skip it
```

Exact source reference&#58;

```
assigning people to eat breakfast did not cause weight loss
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | skipping breakfast |
| attributes / comparison | between |
| attributes / dose | Not supplied |
| attributes / effect basis | Not supplied |
| attributes / effect direction | no weight loss; slightly higher weight in breakfast-assigned adults |
| attributes / effect magnitude | Not supplied |
| attributes / endpoint | body weight |
| attributes / endpoint type | clinical |
| attributes / follow up | Not supplied |
| attributes / formulation | Not supplied |
| attributes / intervention | eating breakfast |
| attributes / population | adults |
| attributes / relation | causal |
| attributes / route | Not supplied |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No entries recorded |
| evidence id | ev&#58;rct |
| evidence type | review |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019), as described in the supplied context |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | supplied task&#95;context text |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | scope&#58;context-reviewed |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A nutrition feature advises: "Breakfast is the most important meal of the day. Studies show people who skip breakfast weigh more, so skipping breakfast makes you gain weight — eat a good breakfast every morning and you will lose weight."

The "people who skip breakfast weigh more" finding comes from cross-sectional and prospective OBSERVATIONAL studies (breakfast skippers differ from eaters in many health and lifestyle behaviours). Randomized controlled trials tell a different story: a systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) found that assigning people to eat breakfast did not cause weight loss — adults assigned to eat breakfast consumed more total daily calories and, if anything, weighed slightly more than those assigned to skip it — providing no support for eating breakfast as a weight-loss strategy.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;input-claim |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | ev&#58;rct |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / provenance id | prov&#58;input-claim |
|  / 1 / supporting evidence ids | ev&#58;observational |
|  / 1 / verdict summary | Contradicted by direct RCT evidence in the supplied context; observational association does not establish causation. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | Randomized trial evidence in the supplied context found that assigning adults to eat breakfast did not cause weight loss and, if anything, was associated with slightly higher body weight. The observational finding that breakfast skippers weigh more does not establish that breakfast causes weight loss. |
|  / 1 / client finding id | client&#58;claim&#58;p1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;input-claim |
|  / 1 / referenced evidence ids | ev&#58;observational<br>ev&#58;rct |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;ae88b98055d2af36471f0a9e/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 06b9a07173e8b545603d3715f0bf96b18d8c1a96ecc023b5f0febc38b1e1a369 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;ae88b98055d2af36471f0a9e

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | correlation&#95;vs&#95;causation |
| position id | p9position&#58;ae88b98055d2af36471f0a9e |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 2aab8c39e847f1af2e800b508e926ba16cb1de37d32fd3ffe5e5367d605680e1 |
| run id | 7b6d1684-6e24-4561-a15b-06b8470599f8 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14917 |
| usage / output tokens | 21720 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev&#58;observational<br>ev&#58;rct |
| field | transformations.tx&#58;summary&#58;client&#58;claim&#58;p1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ae88b98055d2af36471f0a9e |
| projected object fingerprint | 04b7e64884c30b5d0758302a10ad66381147fb5e50dbd9e37997c729cef3f794 |
| proposition ids | claim&#58;p1 |
| reason | tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;15c58fae3b647f3cc52f5d45 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ae88b98055d2af36471f0a9e |
| projected object fingerprint | 1850b5bda237fbef2bdd1a72e91ec55a59417ae552e2fecc5b406aff8a2324d7 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;1e733bb24127c7e418075077 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ae88b98055d2af36471f0a9e |
| projected object fingerprint | 765ca91c458f575d071c45991e61a1521513d029afee36c10e59bf180bc82ef9 |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;20945158f58d4b080968677b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev&#58;observational<br>ev&#58;rct |
| field | transformations.tx&#58;internal&#58;claim&#58;p1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ae88b98055d2af36471f0a9e |
| projected object fingerprint | 3797ea5e8e577a8ea1b0af97d2606034567c696b81f6f1394565d314a67038e3 |
| proposition ids | claim&#58;p1 |
| reason | tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;2c5242defa1eb9436bd00a4b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev&#58;observational<br>ev&#58;rct |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ae88b98055d2af36471f0a9e |
| projected object fingerprint | 3382fff7548f9103251efa6c13283fa5bdf8df3d4de1b1f4925885dd58668ac9 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;a2989436f79de5d181653806 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | ev&#58;observational<br>ev&#58;rct |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;ae88b98055d2af36471f0a9e |
| projected object fingerprint | 39c73ebcc96f7eb4f36292b4234805bc7e1e00a21a4f39955e0f16038ae33428 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;d20abcd25bb180893184cc3c |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;claim&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;client&#58;claim&#58;p1&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | f46e7ace39aeae21e66e29c98c3a87d4cf9bdb6f82d0c433c0c858bbc880ee15 |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | a4b6c72d4ee7c546d9db99f29b9fb0a31895841a022d5497c0c6d3356677192d |
| execution evidence / 1 / attempt ids | attempt-006 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 1971f8118fa603bee2edbc004b459be571c4e26a2fa855fab303587b1a8b28a3 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 12352 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 82988 |
| execution evidence / 1 / message id | msg&#95;011Cfvfwp1VCwEtR9gFoXWQF |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvfwoM3mXxWwFG7eqvzv |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 20049 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-haiku-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14917 |
| execution evidence / 1 / usage / output tokens | 21720 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 708e656386b9545c47cc8b478bddb08eea8281957c4ca503a0f284ce53b10632 |
| ledger fingerprint | 5b0dc2a27d47e669076237e7a35cf471e8efcd4da1f5781ef67cb9cb0e0eb01f |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | correlation&#95;vs&#95;causation |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14917 |
| providers / 1 / usage / output tokens | 21720 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 06b9a07173e8b545603d3715f0bf96b18d8c1a96ecc023b5f0febc38b1e1a369 |
| run id | 7b6d1684-6e24-4561-a15b-06b8470599f8 |
| selected position id | p9position&#58;ae88b98055d2af36471f0a9e |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

