# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;52.861598+00&#58;00 |
| parent | Not supplied |
| record fingerprint | e465697bfbd9dd2f585041b1c9b7fc9e3e43db2f14c52e5f0dd68de3c0e29e6d |
| revision | 87a81476-2f6e-4f26-89e3-0b7ccc7dae92 |
| selected position id | p9position&#58;7f89bd2c37e96e9eb0c441d2 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-005 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | b1c10c33fdac770c6ed5e20db74038535798751a842c383af5e08459b9101e3b |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 7922 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 49154 |
|  / 1 / message id | msg&#95;011Cfvft8fYKPbdW2U4qv22t |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011Cfvft7fG4Xi8gf3ka6f6E |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 19987 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-haiku-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14696 |
|  / 1 / usage / output tokens | 12903 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The supplement causes liver damage in long-term users.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | fdff1ae350dd42166846a038784e0a2acba7903f8b6ffbe2039bc333fbdad7b2 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | bdd1fc3730fabd7d5c2cbbe3fc5d69a26887ad49894d7723b4c9a59524bb3ee7 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>t-internal-p1&#58; output state hides or changes unknown<br>t-summary-c1&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
| record fingerprint | 63cd20495c5568981ddd92f4eb254999ea971eda25476cecaa40a64cd0cc0d2c |
| technical status | incomplete |
| transformation findings | t-internal-p1&#58; output state hides or changes unknown<br>t-summary-c1&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | ev1 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | The only supplied evidence is indirect and inconclusive for liver damage in long-term users, so the causal claim is unsupported.<br>Trial design is not stated.<br>No liver endpoint or long-term exposure data are supplied.<br>b1&#58; The trial reports no serious adverse events over four weeks in 60 participants. It does not measure liver damage or long-term use, so it does not directly support or contradict the causal claim.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 1 / reported verdict | unsupported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev1 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The claim states a causal harm as established, while the only supplied evidence is an indirect, inconclusive short trial with no liver endpoint. The core error is an unsupported definitive causal statement (overstatement), not a correlation-to-causation inference from a noncausal result. |
| represented trigger analysis / trigger evidence id | ev1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | causes liver damage in long-term users |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Extracted from the task prompt sentence only; the context was used as the reviewed set. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov&#58;input |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | ev1 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | The only supplied evidence is indirect and inconclusive for liver damage in long-term users, so the causal claim is unsupported.<br>Trial design is not stated.<br>No liver endpoint or long-term exposure data are supplied.<br>b1&#58; The trial reports no serious adverse events over four weeks in 60 participants. It does not measure liver damage or long-term use, so it does not directly support or contradict the causal claim.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | unsupported |
| material dimensions | population<br>intervention<br>endpoint<br>relation<br>follow&#95;up |
| materiality | required |
| not applicable / comparator | claim names no comparator |
| not applicable / comparison | claim names no comparison |
| not applicable / dose | claim states no dose |
| not applicable / effect basis | claim states no effect basis |
| not applicable / effect magnitude | claim states no magnitude |
| not applicable / formulation | claim states no formulation |
| not applicable / route | claim states no route |
| observation target | inconclusive |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;input |
| reason | The only supplied evidence is indirect and inconclusive for liver damage in long-term users, so the causal claim is unsupported. |
| reported verdict | unsupported |
| required bridge ids | No entries recorded |
| search question | Does any reviewed source show that the supplement causes liver damage in long-term users? |
| search scope ids | scope&#58;context&#95;reviewed |
| uncertainty | Trial design is not stated.<br>No liver endpoint or long-term exposure data are supplied. |

Quoted proposition; this is represented input, not a release assertion.

```
The supplement causes liver damage in long-term users.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 54 |
| start | 0 |
| text | The supplement causes liver damage in long-term users. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | unqualified |
| comparator | Not supplied |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | harm |
| effect magnitude | Not supplied |
| endpoint | liver damage |
| endpoint type | clinical |
| follow up | long-term |
| formulation | Not supplied |
| intervention | supplement |
| population | long-term users |
| relation | causal |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | indirect |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The trial reports no serious adverse events over four weeks in 60 participants. It does not measure liver damage or long-term use, so it does not directly support or contradict the causal claim. |
|  / 1 / search scope id | scope&#58;context&#95;reviewed |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t-extraction-p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | unqualified |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from and to text (identical) | The supplement causes liver damage in long-term users. |
| from proposition ids | claim&#58;p1 |
| reason | Extraction keeps the original sentence and its causal, harm-directed wording unchanged. |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | t-extraction-p1 |

### Transformation t-search-p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | unqualified |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | The search question restates the claim as a question over the reviewed set without changing attributes. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does any reviewed source show that the supplement causes liver damage in long-term users? |
| transformation id | t-search-p1 |

### Transformation t-internal-p1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | unqualified |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | The internal finding keeps the causal claim and states that the only evidence is indirect and inconclusive, matching the derived unsupported state. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The supplement causes liver damage in long-term users.<br>Unsupported&#58; the reviewed trial reports no serious adverse events over four weeks in 60 participants and does not measure liver damage or long-term use. |
| transformation id | t-internal-p1 |

### Transformation t-summary-c1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | unqualified |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | harm |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | The client summary reports the causal claim as not established, matching the derived unsupported state; it does not assert the claim as supported or contradicted. |
| stage | summary |
| target id | client&#58;1 |
| to text | The evidence reviewed does not establish that the supplement causes liver damage in long-term users.<br>The reviewed context reports a 60-participant, four-week trial with no serious adverse events; it does not measure liver damage or long-term use. |
| transformation id | t-summary-c1 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | serious adverse events |
| evidence id | ev1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | serious adverse events |
| attributes / endpoint type | clinical&#95;event |
| attributes / follow up | four weeks |
| attributes / intervention | supplement |
| attributes / population | 60 participants |
| attributes / relation | description |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Four-week duration does not address long-term use.<br>No liver endpoint is reported.<br>Design features beyond sample size and duration are not stated. |
| evidence id | ev1 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | reported trial result in supplied context |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | supplement liver damage long-term users |
|  / 1 / resources | context |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | scope&#58;context&#95;reviewed |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events. The label now states the product is 'completely safe' and 'proven to have no side effects', suitable for everyone including pregnant women and children.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The supplement causes liver damage in long-term users. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;directly&#95;established |
|  / 1 / confidence status | moderate |
|  / 1 / contrary evidence ids | ev1 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | unsupported |
|  / 1 / proposition | The supplement causes liver damage in long-term users. |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Unsupported&#58; the reviewed trial reports no serious adverse events over four weeks in 60 participants and does not measure liver damage or long-term use. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The reviewed context reports a 60-participant, four-week trial with no serious adverse events; it does not measure liver damage or long-term use. |
|  / 1 / client finding id | client&#58;1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;directly&#95;established |
|  / 1 / display claim | The evidence reviewed does not establish that the supplement causes liver damage in long-term users. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / referenced evidence ids | ev1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;7f89bd2c37e96e9eb0c441d2/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 1357a4e5d1eb47d42c3c8fb687c229654a612aeb491cd539ff165500a45cec31 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;7f89bd2c37e96e9eb0c441d2

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;7f89bd2c37e96e9eb0c441d2 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | bdd1fc3730fabd7d5c2cbbe3fc5d69a26887ad49894d7723b4c9a59524bb3ee7 |
| run id | cb0e1c8b-ca9f-4672-9fbe-293868d48195 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14696 |
| usage / output tokens | 12903 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7f89bd2c37e96e9eb0c441d2 |
| projected object fingerprint | 4b4c3a87e457b8ae2b383779f843db1a05c54f704e63f7fd89daf3c4d6ccac43 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;08ede11a9b4c9a3ee9d69e12 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev1 |
| field | transformations.t-summary-c1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7f89bd2c37e96e9eb0c441d2 |
| projected object fingerprint | 3a65c01ad0c9701ae824760b2d3b1a6ee8f78f73d6a6f955857a3d3f40ed5a97 |
| proposition ids | claim&#58;p1 |
| reason | t-summary-c1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;20d4d38e232f259b233752c1 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7f89bd2c37e96e9eb0c441d2 |
| projected object fingerprint | c105de137523f14f1804d501e4223a8e93d6e28c09449df51c909aa8b113cc93 |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;71ee641ec3d425815787e70a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | ev1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7f89bd2c37e96e9eb0c441d2 |
| projected object fingerprint | ee50b740de9056ecb6204ad91b972df63e09a191a19b444b63aaaadae3a36c95 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;be617c59e929902023a66176 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev1 |
| field | transformations.t-internal-p1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7f89bd2c37e96e9eb0c441d2 |
| projected object fingerprint | faa627a4fab4bba7ca9752f70e69ee89d11cf2b155f86ac7e7a928a8bf5f2230 |
| proposition ids | claim&#58;p1 |
| reason | t-internal-p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;e55b593cd4798b39da0b9041 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7f89bd2c37e96e9eb0c441d2 |
| projected object fingerprint | 582ea77128cf178bc7e98b0cf124b1e688824a40ad45600949a4cc2d6ce83966 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;f53643dd64df7773b284d628 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 13c3bcd4e64b02fe0727a5f8ff07c7811fd2f69c08ae65a34fdb4148cc29900b |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | cc7063dbb52ebe07d1425dfd22e853f151a68000396d6a074531645d52c73fc9 |
| execution evidence / 1 / attempt ids | attempt-005 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | b1c10c33fdac770c6ed5e20db74038535798751a842c383af5e08459b9101e3b |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 7922 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 49154 |
| execution evidence / 1 / message id | msg&#95;011Cfvft8fYKPbdW2U4qv22t |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011Cfvft7fG4Xi8gf3ka6f6E |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 19987 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-haiku-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14696 |
| execution evidence / 1 / usage / output tokens | 12903 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 5b28ec01e3c549c5ec4d7647a9d518c0bb5ea0b9b8154bece21dcb0faf03fffd |
| ledger fingerprint | 7566dd16a53bcfadceb0b91a81e21a3dd3f2698afea25afb87ac1c3a71f954fb |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14696 |
| providers / 1 / usage / output tokens | 12903 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 1357a4e5d1eb47d42c3c8fb687c229654a612aeb491cd539ff165500a45cec31 |
| run id | cb0e1c8b-ca9f-4672-9fbe-293868d48195 |
| selected position id | p9position&#58;7f89bd2c37e96e9eb0c441d2 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

