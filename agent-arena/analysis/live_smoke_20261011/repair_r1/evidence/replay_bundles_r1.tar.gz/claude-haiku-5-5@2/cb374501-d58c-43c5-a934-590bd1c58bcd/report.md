# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;51.082721+00&#58;00 |
| parent | Not supplied |
| record fingerprint | e0f0a803fb008d2a23f65558cf6177e22642801e8d0972a5fa2d078aaec82f90 |
| revision | cb374501-d58c-43c5-a934-590bd1c58bcd |
| selected position id | p9position&#58;89ca8f223e03154a60991544 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-003 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | faf3440aa8b35c5bbca17627ede713be091385b1f3d4e0984d8516e69051ba4c |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 15469 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 104171 |
|  / 1 / message id | msg&#95;011CfvfbWDraukSPi9LHXraz |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvfbVQFHrNm9QUrR8cqE |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 20042 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-haiku-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14880 |
|  / 1 / usage / output tokens | 27962 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 487aab0a628c1f44c2b48d2030d8802e758ab89deb04eac557bd486c70c2186f |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | b101cd85e69037c39294c4975b22742590740b331899cb6c10fb887d90b86e1a |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>tx&#58;internal&#58;p1&#58; output state hides or changes unknown<br>tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown |
| record fingerprint | 4ddbd758640c18aa6f816c61c56b9550ea2fbc4cb2fed4561ab08a94295ffe17 |
| technical status | incomplete |
| transformation findings | tx&#58;internal&#58;p1&#58; output state hides or changes unknown<br>tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | ev&#58;1 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | Directly reported lipid-lowering result in the supplied context.<br>Biomarker result only; 12-week follow-up; control design and comparator not stated.<br>bind&#58;p1&#95;ev1&#58; The context directly reports a 65 percent LDL reduction in familial hypercholesterolaemia patients, matching population, intervention, endpoint and direction.<br>unresolved relation or evidence capability<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 1 / reported verdict | supported |
|  / 2 / dependency status | unknown |
|  / 2 / derived state | unsupported |
|  / 2 / evidence ids | ev&#58;2<br>ev&#58;3 |
|  / 2 / proposition id | claim&#58;p2 |
|  / 2 / reasons | No cardiovascular event data exist in the supplied material; the LDL result does not establish a clinical outcome effect.<br>Heart-attack benefit is untested in the supplied material.<br>Biomarker-to-outcome bridge is unsupported.<br>bind&#58;p2&#95;ev2&#58; The trial design tracked no cardiovascular events, so the supplied material contains no heart-attack data.<br>no evidence found does not prove absence or contradiction<br>bind&#58;p2&#95;ev3&#58; The outcomes trial that could test heart-attack reduction is not expected to report for at least four more years.<br>preserved observation&#58; inconclusive<br>bridge&#58;p2&#95;surrogate&#58; required bridge unsupported, capable evidence unresolved<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 2 / reported verdict | unsupported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev&#58;1<br>ev&#58;2<br>ev&#58;3 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | true |
| represented trigger analysis / proposition ids | claim&#58;p1<br>claim&#58;p2 |
| represented trigger analysis / reason | A lipid biomarker result (LDL reduction in a 12-week trial) is used to assert a clinical heart-attack reduction. The supplied trial tracked no cardiovascular events, so the outcome claim is inflated in scope and certainty; no mechanism is described in the source, and this is not a correlation-to-causation case. |
| represented trigger analysis / trigger evidence id | ev&#58;2 |
| represented trigger analysis / trigger proposition id | claim&#58;p2 |
| represented trigger analysis / trigger quote | no cardiovascular events were tracked |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Manual extraction from task&#95;prompt (source&#95;id input); the claim was split into an LDL-lowering component and a heart-attack-reduction component, with the shared population taken from the claim. |
| logic / children / 1 / children | No entries recorded |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / children | No entries recorded |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | and |
| logic / proposition id | Not supplied |
| provenance id | prov&#58;input |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | ev&#58;1 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | Directly reported lipid-lowering result in the supplied context.<br>Biomarker result only; 12-week follow-up; control design and comparator not stated.<br>bind&#58;p1&#95;ev1&#58; The context directly reports a 65 percent LDL reduction in familial hypercholesterolaemia patients, matching population, intervention, endpoint and direction.<br>unresolved relation or evidence capability<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | population<br>intervention<br>endpoint<br>endpoint&#95;type<br>effect&#95;direction |
| materiality | required |
| not applicable / certainty | claim states no certainty level |
| not applicable / comparator | claim names no comparator |
| not applicable / comparison | claim does not specify within-group or between-group comparison |
| not applicable / follow up | claim states no follow-up duration |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;input |
| reason | Directly reported lipid-lowering result in the supplied context. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied material report LDL cholesterol lowering with the new injectable drug in patients with familial hypercholesterolaemia? |
| search scope ids | scope&#58;ctx |
| uncertainty | Biomarker result only; 12-week follow-up; control design and comparator not stated. |

Quoted proposition; this is represented input, not a release assertion.

```
The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 47 |
| start | 24 |
| text | lowered LDL cholesterol |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| effect direction | decrease |
| endpoint | LDL cholesterol |
| endpoint type | biomarker |
| intervention | new injectable drug |
| population | patients with familial hypercholesterolaemia |
| relation | description |
| route | injectable |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p1&#95;ev1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev&#58;1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The context directly reports a 65 percent LDL reduction in familial hypercholesterolaemia patients, matching population, intervention, endpoint and direction. |
|  / 1 / search scope id | scope&#58;ctx |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unsupported |
| derived judgment / evidence ids | ev&#58;2<br>ev&#58;3 |
| derived judgment / proposition id | claim&#58;p2 |
| derived judgment / reasons | No cardiovascular event data exist in the supplied material; the LDL result does not establish a clinical outcome effect.<br>Heart-attack benefit is untested in the supplied material.<br>Biomarker-to-outcome bridge is unsupported.<br>bind&#58;p2&#95;ev2&#58; The trial design tracked no cardiovascular events, so the supplied material contains no heart-attack data.<br>no evidence found does not prove absence or contradiction<br>bind&#58;p2&#95;ev3&#58; The outcomes trial that could test heart-attack reduction is not expected to report for at least four more years.<br>preserved observation&#58; inconclusive<br>bridge&#58;p2&#95;surrogate&#58; required bridge unsupported, capable evidence unresolved<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | unsupported |
| material dimensions | population<br>intervention<br>endpoint<br>endpoint&#95;type<br>effect&#95;direction<br>relation |
| materiality | required |
| not applicable / certainty | claim states no certainty level |
| not applicable / comparator | claim names no comparator |
| not applicable / comparison | claim does not specify within-group or between-group comparison |
| not applicable / follow up | claim states no follow-up duration |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | claim&#58;p1 |
| proposition id | claim&#58;p2 |
| provenance id | prov&#58;input |
| reason | No cardiovascular event data exist in the supplied material; the LDL result does not establish a clinical outcome effect. |
| reported verdict | unsupported |
| required bridge ids | bridge&#58;p2&#95;surrogate |
| search question | Does the supplied material report a reduction in heart attacks with the new injectable drug in patients with familial hypercholesterolaemia? |
| search scope ids | scope&#58;ctx |
| uncertainty | Heart-attack benefit is untested in the supplied material.<br>Biomarker-to-outcome bridge is unsupported. |

Quoted proposition; this is represented input, not a release assertion.

```
The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 73 |
| start | 52 |
| text | reduced heart attacks |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| effect direction | decrease |
| endpoint | heart attacks |
| endpoint type | clinical&#95;event |
| intervention | new injectable drug |
| population | patients with familial hypercholesterolaemia |
| relation | human&#95;clinical&#95;benefit |
| route | injectable |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind&#58;p2&#95;ev2 |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev&#58;2 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The trial design tracked no cardiovascular events, so the supplied material contains no heart-attack data. |
|  / 1 / search scope id | scope&#58;ctx |
|  / 2 / binding id | bind&#58;p2&#95;ev3 |
|  / 2 / directness | indirect |
|  / 2 / evidence id | ev&#58;3 |
|  / 2 / observation | inconclusive |
|  / 2 / proposition id | claim&#58;p2 |
|  / 2 / reason | The outcomes trial that could test heart-attack reduction is not expected to report for at least four more years. |
|  / 2 / search scope id | scope&#58;ctx |

### Bridges

| Field | Recorded value |
| --- | --- |
|  / 1 / bridge id | bridge&#58;p2&#95;surrogate |
|  / 1 / conclusion proposition id | claim&#58;p2 |
|  / 1 / dimensions | endpoint<br>endpoint&#95;type |
|  / 1 / evidence ids | ev&#58;1<br>ev&#58;2 |
|  / 1 / kind | mechanism&#95;to&#95;outcome |
|  / 1 / premise proposition ids | claim&#58;p1 |
|  / 1 / reason | The LDL reduction is a lipid biomarker; the supplied material contains no cardiovascular event data linking it to fewer heart attacks. |
|  / 1 / state | unsupported |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation tx&#58;extraction&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | lowered LDL cholesterol |
| reason | Span extracted; the shared population phrase is taken from the claim&#x27;s scope. |
| stage | extraction |
| target id | claim&#58;p1 |
| to text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| transformation id | tx&#58;extraction&#58;p1 |

### Transformation tx&#58;extraction&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | reduced heart attacks |
| reason | Span extracted; the shared population phrase is taken from the claim&#x27;s scope. |
| stage | extraction |
| target id | claim&#58;p2 |
| to text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| transformation id | tx&#58;extraction&#58;p2 |

### Transformation tx&#58;search&#95;question&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| reason | Question form of the proposition; attributes unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the supplied material report LDL cholesterol lowering with the new injectable drug in patients with familial hypercholesterolaemia? |
| transformation id | tx&#58;search&#95;question&#58;p1 |

### Transformation tx&#58;search&#95;question&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| reason | Question form of the proposition; attributes unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Does the supplied material report a reduction in heart attacks with the new injectable drug in patients with familial hypercholesterolaemia? |
| transformation id | tx&#58;search&#95;question&#58;p2 |

### Transformation tx&#58;internal&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| reason | Internal finding for the lipid component; the state matches the host-derived state of claim&#58;p1. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.<br>Supported only as a 12-week lipid result&#58; a 65 percent LDL reduction is reported in the supplied context. |
| transformation id | tx&#58;internal&#58;p1 |

### Transformation tx&#58;internal&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| reason | Internal finding for the outcome component; the state matches the host-derived state of claim&#58;p2. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia.<br>Not supported in the supplied material&#58; no cardiovascular events were tracked and no outcomes trial is expected for at least four more years. |
| transformation id | tx&#58;internal&#58;p2 |

### Transformation tx&#58;summary&#58;cf&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | description |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
| reason | Summary states only the lipid component, which the host derives as supported; it does not assert the outcome component. |
| stage | summary |
| target id | cf&#58;p1 |
| to text | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia.<br>This is a 12-week Phase 2 lipid result (65 percent LDL reduction). It is a biomarker result only. |
| transformation id | tx&#58;summary&#58;cf&#58;p1 |

### Transformation tx&#58;summary&#58;cf&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | injectable |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| reason | Summary reports the outcome component as unsupported, matching the host-derived state of claim&#58;p2. |
| stage | summary |
| target id | cf&#58;p2 |
| to text | The supplied material does not show that the new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia.<br>The trial tracked no cardiovascular events, and an outcomes trial is not expected to report for at least four more years. |
| transformation id | tx&#58;summary&#58;cf&#58;p2 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev&#58;1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | LDL cholesterol |
| evidence id | ev&#58;1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | 65 percent |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / effect direction | decrease |
| attributes / endpoint | LDL cholesterol |
| attributes / endpoint type | biomarker |
| attributes / intervention | new injectable drug |
| attributes / population | patients with familial hypercholesterolaemia |
| attributes / relation | description |
| attributes / route | injectable |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Control arm, comparator and sample size not stated in context. |
| evidence id | ev&#58;1 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | context&#58; company trial announcement of Phase 2 results |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev&#58;2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | heart attacks |
| evidence id | ev&#58;2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | Not supplied |

Evidence text&#58;

```
The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked
```

Exact source reference&#58;

```
no cardiovascular events were tracked
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / effect direction | Not supplied |
| attributes / endpoint | heart attacks |
| attributes / endpoint type | clinical&#95;event |
| attributes / intervention | new injectable drug |
| attributes / population | patients with familial hypercholesterolaemia |
| attributes / relation | description |
| attributes / route | injectable |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Only lipid levels and liver safety were measured over twelve weeks.<br>Control design not stated. |
| evidence id | ev&#58;2 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | context&#58; trial measurement scope |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev&#58;3

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | heart attacks |
| evidence id | ev&#58;3 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
no outcomes trial is expected to report for at least four more years
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / effect direction | Not supplied |
| attributes / endpoint | heart attacks |
| attributes / endpoint type | clinical&#95;event |
| attributes / intervention | new injectable drug |
| attributes / population | patients with familial hypercholesterolaemia |
| attributes / relation | description |
| attributes / route | injectable |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No outcomes trial has reported; expected in at least four years. |
| evidence id | ev&#58;3 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | context&#58; outcomes trial timing |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | supplied task context |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied context only; no external search executed |
|  / 1 / search scope id | scope&#58;ctx |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg&#58;p2&#95;events |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p2 |
|  / 1 / proposition | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 1 / search scope id | scope&#58;ctx |
|  / 1 / source local evidence ids | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A pharmaceutical company announced results from its Phase 2 trial of a new injectable cholesterol-lowering agent. The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy. Company executives described the results as a major breakthrough in cardiovascular protection and said the drug would transform outcomes for patients at high risk of heart attack and stroke. They announced plans for an accelerated approval pathway based on the LDL reduction data. The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked and no outcomes trial is expected to report for at least four more years.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | high for the supplied context only |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / supporting evidence ids | ev&#58;1 |
|  / 1 / verdict summary | Supported only as a 12-week lipid result&#58; a 65 percent LDL reduction is reported in the supplied context. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status | high that the supplied material lacks outcome data |
|  / 2 / contrary evidence ids | ev&#58;2<br>ev&#58;3 |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | Not supplied |
|  / 2 / proposition | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 2 / provenance id | prov&#58;input |
|  / 2 / supporting evidence ids | No entries recorded |
|  / 2 / verdict summary | Not supported in the supplied material&#58; no cardiovascular events were tracked and no outcomes trial is expected for at least four more years. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | This is a 12-week Phase 2 lipid result (65 percent LDL reduction). It is a biomarker result only. |
|  / 1 / client finding id | cf&#58;p1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The new injectable drug lowered LDL cholesterol in patients with familial hypercholesterolaemia. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / referenced evidence ids | ev&#58;1 |
|  / 1 / value claims | No entries recorded |
|  / 2 / client explanation | The trial tracked no cardiovascular events, and an outcomes trial is not expected to report for at least four more years. |
|  / 2 / client finding id | cf&#58;p2 |
|  / 2 / client negative assertions / 1 / assertion id | neg&#58;p2&#95;events |
|  / 2 / client negative assertions / 1 / client scope | reviewed&#95;set |
|  / 2 / client strength | not&#95;assessed |
|  / 2 / display claim | The supplied material does not show that the new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 2 / parent finding id | claim&#58;p2 |
|  / 2 / provenance id | prov&#58;input |
|  / 2 / referenced evidence ids | ev&#58;2<br>ev&#58;3 |
|  / 2 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;89ca8f223e03154a60991544/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | e2b26cb83e5243ae9c4da6a34b595b94214efa38ff3f81d769f097f83e6727c4 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;89ca8f223e03154a60991544

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;89ca8f223e03154a60991544 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | b101cd85e69037c39294c4975b22742590740b331899cb6c10fb887d90b86e1a |
| run id | e059f3ce-c469-407a-b643-739cbb90765d |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14880 |
| usage / output tokens | 27962 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev&#58;1 |
| field | transformations.tx&#58;internal&#58;p1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;89ca8f223e03154a60991544 |
| projected object fingerprint | 760b25047d0b19c4a8cf3d41cfee7471469792572d9fe63f548398341ed0a4d6 |
| proposition ids | claim&#58;p1 |
| reason | tx&#58;internal&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;10d66baf719affa0d3c93b9a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | ev&#58;1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;89ca8f223e03154a60991544 |
| projected object fingerprint | c021f15348e076464addbc873780c5adbfe37a22a259fd6f98f4dfeba319fab3 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;204d871176f0d79367ada620 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev&#58;1 |
| field | transformations.tx&#58;summary&#58;cf&#58;p1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;89ca8f223e03154a60991544 |
| projected object fingerprint | 1388e96cd366ef29f9478e9eaa4bb6cb0b03f209130f18a60c3b09ffb3030969 |
| proposition ids | claim&#58;p1 |
| reason | tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;4d437ab50d1be2dc4ec239b8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;89ca8f223e03154a60991544 |
| projected object fingerprint | 1a787e66c5fe248bbcd7c4ade866b6daec16013226f439273d3fe6b949853268 |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;7ec7d9b5616ac022c9cc981a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;89ca8f223e03154a60991544 |
| projected object fingerprint | 3b7ac20499b87552e98668a1c10f8efdd15c9ef70f5d694c32a4ac176d6664ff |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;a7ff0b408d22c8baa56742b2 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev&#58;1<br>ev&#58;2<br>ev&#58;3 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;89ca8f223e03154a60991544 |
| projected object fingerprint | 81621439fa85b2ac18c4a97deb681a55ce618536322de5a2d62b0b31980bfe29 |
| proposition ids | claim&#58;p1<br>claim&#58;p2 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;e11065ff2852345f22e4519d |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 3<br>Evaluated&#58; 3<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;negative&#95;assertions |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tx&#58;internal&#58;p1&#58; output state hides or changes unknown; tx&#58;summary&#58;cf&#58;p1&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 9ffd5de8e39966d5537f879d38c86391e8ddcc37ab849e09ebe8fb741087e3b6 |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | c99078c608a00c9ffb2868297022f1247d35bfb5d4915562cdd7e8c385b192e6 |
| execution evidence / 1 / attempt ids | attempt-003 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | faf3440aa8b35c5bbca17627ede713be091385b1f3d4e0984d8516e69051ba4c |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 15469 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 104171 |
| execution evidence / 1 / message id | msg&#95;011CfvfbWDraukSPi9LHXraz |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvfbVQFHrNm9QUrR8cqE |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 20042 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-haiku-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14880 |
| execution evidence / 1 / usage / output tokens | 27962 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 38d25af7fe1fef7b110fbcad00f93f2a4948109f0ef5268dbbe1d74155b6a166 |
| ledger fingerprint | 037b0fe91ac92b88dc527c073d4afddfbc21033a0ed4421553d1b2c0a6f4b239 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14880 |
| providers / 1 / usage / output tokens | 27962 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | e2b26cb83e5243ae9c4da6a34b595b94214efa38ff3f81d769f097f83e6727c4 |
| run id | e059f3ce-c469-407a-b643-739cbb90765d |
| selected position id | p9position&#58;89ca8f223e03154a60991544 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

