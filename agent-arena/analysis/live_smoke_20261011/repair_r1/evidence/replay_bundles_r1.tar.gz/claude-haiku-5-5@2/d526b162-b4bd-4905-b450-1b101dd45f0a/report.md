# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;51.924086+00&#58;00 |
| parent | Not supplied |
| record fingerprint | b5557ff01493e00dac40f5ce6b09f97ba8ff77692afce24df835e0c30d25e26c |
| revision | d526b162-b4bd-4905-b450-1b101dd45f0a |
| selected position id | p9position&#58;8d619108af71f1e97992dbb8 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-004 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 14f0cfa63b3724c0e84732cb009f69a76e2b2391d890d3f4db392e7a8d0add08 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 17042 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 119264 |
|  / 1 / message id | msg&#95;011CfvfjFMdDFmtAVdtyaaJH |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvfjF3mHb8QFvw1xWYsd |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 20028 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-haiku-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14807 |
|  / 1 / usage / output tokens | 31121 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The virtual tutoring program improved struggling students' reading progress or reduced their school absenteeism.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 246cf9f13d09d7cdc83068f66b29e2050e3571e48998a839b807e29d8fba14ad |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | b6e44c141d7b7762ee7cba1980e658ecff833a2a2b8dca588e0543e716d5cf7a |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>tr&#58;internal&#58;p1&#58; output state hides or changes unknown<br>tr&#58;internal&#58;p2&#58; output state hides or changes unknown<br>tr&#58;summary&#58;cf1&#58; output state hides or changes unknown<br>tr&#58;summary&#58;cf2&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tr&#58;internal&#58;p1&#58; output state hides or changes unknown; tr&#58;internal&#58;p2&#58; output state hides or changes unknown; tr&#58;summary&#58;cf1&#58; output state hides or changes unknown; tr&#58;summary&#58;cf2&#58; output state hides or changes unknown |
| record fingerprint | ccb672825802edc106c26734ce6b73617365170a8e0021259ff0464f62fa5fce |
| technical status | incomplete |
| transformation findings | tr&#58;internal&#58;p1&#58; output state hides or changes unknown<br>tr&#58;internal&#58;p2&#58; output state hides or changes unknown<br>tr&#58;summary&#58;cf1&#58; output state hides or changes unknown<br>tr&#58;summary&#58;cf2&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | ev1<br>ev2 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | A randomized trial directly reports reading-progress gains versus controls, so the reading-progress alternative is supported.<br>Population is described as struggling elementary students in a rural district; the claim says struggling students.<br>Completer comparison may not be intention-to-treat; not stated in the supplied text.<br>b1&#58; The randomized trial reports a reading-progress gain of about two months versus controls for completers of about forty sessions. Population, endpoint, endpoint type and species match; the intervention difference is handled by a product transfer.<br>unsupported product/dose/formulation/route transfer<br>b2&#58; The modest gains for students attending fewer sessions are reported without a stated control comparison and are only partly relevant to the claim.<br>preserved observation&#58; inconclusive<br>unresolved material claim attributes&#58; certainty<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 1 / reported verdict | supported |
|  / 2 / dependency status | unknown |
|  / 2 / derived state | unknown |
|  / 2 / evidence ids | ev3 |
|  / 2 / proposition id | claim&#58;p2 |
|  / 2 / reasons | No absenteeism result appears in the reviewed material, so this alternative is unsupported. It does not make the whole &#x27;or&#x27; claim unsupported.<br>The supplied material does not measure absenteeism; the search covered only the supplied context.<br>b3&#58; The reviewed context reports participation and cost findings but no school absenteeism outcome. This is no evidence in the supplied material, not evidence of no effect.<br>no evidence found does not prove absence or contradiction<br>unresolved material claim attributes&#58; certainty, endpoint&#95;type<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 2 / reported verdict | unsupported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | ev1<br>ev2<br>ev3 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1<br>claim&#58;p2 |
| represented trigger analysis / reason | The causal wording &#x27;improved&#x27; is grounded in a randomized controlled trial with a control condition. No mechanism is described and no unsupported inference is made from noncausal results, so the core error is none. The noncausal-use field is unknown because the descriptive sentence ev2 is part of the same trial report. |
| represented trigger analysis / trigger evidence id | ev1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | gained roughly two additional months of reading progress |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Manual extraction from the supplied task prompt; no external source was consulted. |
| logic / children / 1 / children | No entries recorded |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / children | No entries recorded |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | or |
| logic / proposition id | Not supplied |
| provenance id | prov&#58;input |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | ev1<br>ev2 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | A randomized trial directly reports reading-progress gains versus controls, so the reading-progress alternative is supported.<br>Population is described as struggling elementary students in a rural district; the claim says struggling students.<br>Completer comparison may not be intention-to-treat; not stated in the supplied text.<br>b1&#58; The randomized trial reports a reading-progress gain of about two months versus controls for completers of about forty sessions. Population, endpoint, endpoint type and species match; the intervention difference is handled by a product transfer.<br>unsupported product/dose/formulation/route transfer<br>b2&#58; The modest gains for students attending fewer sessions are reported without a stated control comparison and are only partly relevant to the claim.<br>preserved observation&#58; inconclusive<br>unresolved material claim attributes&#58; certainty<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | population<br>intervention<br>endpoint<br>endpoint&#95;type<br>species<br>relation |
| materiality | required |
| not applicable / comparator | The claim states an improvement without naming a comparator; the trial&#x27;s control comparison is the evidence for it. |
| not applicable / follow up | The claim states no follow-up period. |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;input |
| reason | A randomized trial directly reports reading-progress gains versus controls, so the reading-progress alternative is supported. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the supplied material show that the virtual tutoring program improved struggling students&#x27; reading progress compared with a control? |
| search scope ids | ss1 |
| uncertainty | Population is described as struggling elementary students in a rural district; the claim says struggling students.<br>Completer comparison may not be intention-to-treat; not stated in the supplied text. |

Quoted proposition; this is represented input, not a release assertion.

```
The virtual tutoring program improved struggling students' reading progress.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 75 |
| start | 0 |
| text | The virtual tutoring program improved struggling students&#x27; reading progress |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | Not supplied |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | improvement |
| effect magnitude | Not supplied |
| endpoint | reading progress |
| endpoint type | educational&#95;outcome |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | virtual tutoring program |
| population | struggling students |
| relation | causal |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The randomized trial reports a reading-progress gain of about two months versus controls for completers of about forty sessions. Population, endpoint, endpoint type and species match; the intervention difference is handled by a product transfer. |
|  / 1 / search scope id | ss1 |
|  / 2 / binding id | b2 |
|  / 2 / directness | partial |
|  / 2 / evidence id | ev2 |
|  / 2 / observation | inconclusive |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | The modest gains for students attending fewer sessions are reported without a stated control comparison and are only partly relevant to the claim. |
|  / 2 / search scope id | ss1 |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | ev3 |
| derived judgment / proposition id | claim&#58;p2 |
| derived judgment / reasons | No absenteeism result appears in the reviewed material, so this alternative is unsupported. It does not make the whole &#x27;or&#x27; claim unsupported.<br>The supplied material does not measure absenteeism; the search covered only the supplied context.<br>b3&#58; The reviewed context reports participation and cost findings but no school absenteeism outcome. This is no evidence in the supplied material, not evidence of no effect.<br>no evidence found does not prove absence or contradiction<br>unresolved material claim attributes&#58; certainty, endpoint&#95;type<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | unsupported |
| material dimensions | population<br>intervention<br>endpoint<br>relation |
| materiality | required |
| not applicable / comparator | The claim names no comparator for absenteeism. |
| not applicable / follow up | The claim states no follow-up period. |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p2 |
| provenance id | prov&#58;input |
| reason | No absenteeism result appears in the reviewed material, so this alternative is unsupported. It does not make the whole &#x27;or&#x27; claim unsupported. |
| reported verdict | unsupported |
| required bridge ids | No entries recorded |
| search question | Does the supplied material show that the virtual tutoring program reduced school absenteeism? |
| search scope ids | ss1 |
| uncertainty | The supplied material does not measure absenteeism; the search covered only the supplied context. |

Quoted proposition; this is represented input, not a release assertion.

```
The virtual tutoring program reduced their school absenteeism.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 111 |
| start | 79 |
| text | reduced their school absenteeism |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | Not supplied |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | reduction |
| effect magnitude | Not supplied |
| endpoint | school absenteeism |
| endpoint type | Not supplied |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | virtual tutoring program |
| population | struggling students |
| relation | causal |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b3 |
|  / 1 / directness | direct |
|  / 1 / evidence id | ev3 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The reviewed context reports participation and cost findings but no school absenteeism outcome. This is no evidence in the supplied material, not evidence of no effect. |
|  / 1 / search scope id | ss1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / dimensions | intervention |
|  / 1 / evidence ids | ev1 |
|  / 1 / reason | The claim says &#x27;virtual tutoring program&#x27;; the trial tested a virtual reading tutoring program. The reading-specific form is treated as a supported narrower transfer for the reading-progress outcome. |
|  / 1 / state | supported&#95;transfer |
|  / 1 / transfer id | pt1 |

### Transformation tr&#58;extraction&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | educational&#95;outcome |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress |
| reason | Extraction of the first alternative from the original claim; the wording is unchanged apart from the terminal period. |
| stage | extraction |
| target id | claim&#58;p1 |
| to text | The virtual tutoring program improved struggling students&#x27; reading progress. |
| transformation id | tr&#58;extraction&#58;p1 |

### Transformation tr&#58;extraction&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | reduction |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | reduced their school absenteeism |
| reason | Extraction of the second alternative; the subject is carried over from the claim&#x27;s shared subject. |
| stage | extraction |
| target id | claim&#58;p2 |
| to text | The virtual tutoring program reduced their school absenteeism. |
| transformation id | tr&#58;extraction&#58;p2 |

### Transformation tr&#58;search&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | educational&#95;outcome |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress. |
| reason | Search question restates the proposition as a question over the reviewed set; the attributes are unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the supplied material show that the virtual tutoring program improved struggling students&#x27; reading progress compared with a control? |
| transformation id | tr&#58;search&#58;p1 |

### Transformation tr&#58;search&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | reduction |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The virtual tutoring program reduced their school absenteeism. |
| reason | Search question restates the absenteeism alternative; the attributes are unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Does the supplied material show that the virtual tutoring program reduced school absenteeism? |
| transformation id | tr&#58;search&#58;p2 |

### Transformation tr&#58;internal&#58;p1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | educational&#95;outcome |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress. |
| reason | Internal finding for the reading-progress alternative; the verdict matches the direct support binding. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The virtual tutoring program improved struggling students&#x27; reading progress.<br>Supported by the randomized trial for reading progress (completers of about forty sessions versus controls). Gains for fewer-session attendees are modest and inconclusive. |
| transformation id | tr&#58;internal&#58;p1 |

### Transformation tr&#58;internal&#58;p2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | reduction |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The virtual tutoring program reduced their school absenteeism. |
| reason | Internal finding for the absenteeism alternative; no result was found in the reviewed material. |
| stage | internal |
| target id | claim&#58;p2 |
| to text | The virtual tutoring program reduced their school absenteeism.<br>No absenteeism result is reported in the supplied material. |
| transformation id | tr&#58;internal&#58;p2 |

### Transformation tr&#58;summary&#58;cf1

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | educational&#95;outcome |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress. |
| reason | Client summary of the reading-progress alternative; the state matches the host-derived support, and the population and intervention scope is unchanged. |
| stage | summary |
| target id | client&#58;cf1 |
| to text | The virtual tutoring program improved struggling students&#x27; reading progress in a randomized controlled trial.<br>Students completing about forty sessions gained roughly two additional months of reading progress compared with controls, and students attending fewer sessions showed modest gains. |
| transformation id | tr&#58;summary&#58;cf1 |

### Transformation tr&#58;summary&#58;cf2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | reduction |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The virtual tutoring program reduced their school absenteeism. |
| reason | Client summary states only the absence of an absenteeism result in the reviewed material. It does not assert that the program had no effect. |
| stage | summary |
| target id | client&#58;cf2 |
| to text | The supplied material reports no result on school absenteeism for the virtual tutoring program. |
| transformation id | tr&#58;summary&#58;cf2 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading progress |
| evidence id | ev1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | control condition |
| attributes / comparison | between |
| attributes / dose | about forty tutoring sessions for completers |
| attributes / effect basis | completers of about forty sessions versus control |
| attributes / effect direction | improvement |
| attributes / effect magnitude | about two additional months |
| attributes / endpoint | reading progress |
| attributes / endpoint type | educational&#95;outcome |
| attributes / follow up | ten-week sessions |
| attributes / formulation | Not supplied |
| attributes / intervention | virtual reading tutoring program |
| attributes / population | struggling students |
| attributes / relation | causal |
| attributes / route | Not supplied |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | The supplied text does not state whether the completer comparison was intention-to-treat. |
| evidence id | ev1 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | true |
| source role | randomized controlled trial result for struggling elementary students in a rural district (context) |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading progress |
| evidence id | ev2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
Even those attending fewer sessions showed modest gains.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | Not supplied |
| attributes / comparison | Not supplied |
| attributes / dose | fewer than about forty tutoring sessions |
| attributes / effect basis | Not supplied |
| attributes / effect direction | improvement |
| attributes / effect magnitude | modest |
| attributes / endpoint | reading progress |
| attributes / endpoint type | educational&#95;outcome |
| attributes / follow up | ten-week sessions |
| attributes / formulation | Not supplied |
| attributes / intervention | virtual reading tutoring program |
| attributes / population | struggling students |
| attributes / relation | description |
| attributes / route | Not supplied |
| attributes / species | human |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | No control comparison is stated for this sentence. |
| evidence id | ev2 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | trial statement on fewer-session attendees (context) |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev3

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint |  |
| evidence id | ev3 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
Researchers emphasised that consistent participation was critical and highlighted that the program delivered results at a lower cost than typical high-dose tutoring.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | Not supplied |
| attributes / comparator | Not supplied |
| attributes / comparison | Not supplied |
| attributes / dose | Not supplied |
| attributes / effect basis | Not supplied |
| attributes / effect direction | Not supplied |
| attributes / effect magnitude | Not supplied |
| attributes / endpoint | Not supplied |
| attributes / endpoint type | Not supplied |
| attributes / follow up | Not supplied |
| attributes / formulation | Not supplied |
| attributes / intervention | Not supplied |
| attributes / population | Not supplied |
| attributes / relation | description |
| attributes / route | Not supplied |
| attributes / species | Not supplied |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Reports no absenteeism outcome. |
| evidence id | ev3 |
| evidence type | descriptive |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | context statement on participation and cost; no absenteeism outcome (context) |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | supplied task context |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied context only; no external search executed |
|  / 1 / search scope id | ss1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | na1 |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p2 |
|  / 1 / proposition | The virtual tutoring program reduced their school absenteeism. |
|  / 1 / search scope id | ss1 |
|  / 1 / source local evidence ids | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized controlled trial tested a virtual reading tutoring program in a rural school district. The program paired live online tutors with small groups of struggling elementary students for ten-week sessions. Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition. Even those attending fewer sessions showed modest gains. Researchers emphasised that consistent participation was critical and highlighted that the program delivered results at a lower cost than typical high-dose tutoring.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The virtual tutoring program improved struggling students&#x27; reading progress or reduced their school absenteeism. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | moderate |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | The virtual tutoring program improved struggling students&#x27; reading progress. |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / supporting evidence ids | ev1<br>ev2 |
|  / 1 / verdict summary | Supported by the randomized trial for reading progress (completers of about forty sessions versus controls). Gains for fewer-session attendees are modest and inconclusive. |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status | low |
|  / 2 / contrary evidence ids | ev3 |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | Not supplied |
|  / 2 / proposition | The virtual tutoring program reduced their school absenteeism. |
|  / 2 / provenance id | prov&#58;input |
|  / 2 / supporting evidence ids | No entries recorded |
|  / 2 / verdict summary | No absenteeism result is reported in the supplied material. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | Students completing about forty sessions gained roughly two additional months of reading progress compared with controls, and students attending fewer sessions showed modest gains. |
|  / 1 / client finding id | client&#58;cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The virtual tutoring program improved struggling students&#x27; reading progress in a randomized controlled trial. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;input |
|  / 1 / referenced evidence ids | ev1<br>ev2 |
|  / 1 / value claims | No entries recorded |
|  / 2 / client explanation |  |
|  / 2 / client finding id | client&#58;cf2 |
|  / 2 / client negative assertions / 1 / assertion id | na1 |
|  / 2 / client negative assertions / 1 / client scope | reviewed&#95;set |
|  / 2 / client strength | not&#95;assessed |
|  / 2 / display claim | The supplied material reports no result on school absenteeism for the virtual tutoring program. |
|  / 2 / parent finding id | claim&#58;p2 |
|  / 2 / provenance id | prov&#58;input |
|  / 2 / referenced evidence ids | ev3 |
|  / 2 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;8d619108af71f1e97992dbb8/claim&#58;p1&#58; scientific UNKNOWN<br>p9position&#58;8d619108af71f1e97992dbb8/claim&#58;p2&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | bbf1e05903c0ceb8b5a6b85cb5edf6b6f415867ec30ae9c72a3c9bcda324f549 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;8d619108af71f1e97992dbb8

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;8d619108af71f1e97992dbb8 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | b6e44c141d7b7762ee7cba1980e658ecff833a2a2b8dca588e0543e716d5cf7a |
| run id | 4b838496-6ba6-4ecf-969e-68e3172ef0a1 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14807 |
| usage / output tokens | 31121 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | ev3 |
| field | propositions.claim&#58;p2.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | e541d42dcf4b80a4d8086e1fd97c92a494e3642d2ccfa22714029b3c454ea695 |
| proposition ids | claim&#58;p2 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;295d2299fa25a5d102760d12 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | ev1<br>ev2 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | df928a772ca1f06cc2ff65858b3f53e08531028d2b2cf8899521f44931a6b7ba |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;301dec71ad0791da5302975d |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev1<br>ev2 |
| field | transformations.tr&#58;summary&#58;cf1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | 251595bd759f032e935d907d727807fc291ce6805e9101fc099195ce8db4852e |
| proposition ids | claim&#58;p1 |
| reason | tr&#58;summary&#58;cf1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;3a7969d0decd53bed356d27b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev3 |
| field | transformations.tr&#58;summary&#58;cf2 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | 6d3bb04c173149329c66445f3b732a63eb25ccdebaf30d10d9002f84c63efe46 |
| proposition ids | claim&#58;p2 |
| reason | tr&#58;summary&#58;cf2&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;42eddc8eca05243ee57a4ca1 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | a93b1c5ace293fbb474add6b4137282005b0c348ecfecccf5e21c7b5dc0d1c97 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tr&#58;internal&#58;p1&#58; output state hides or changes unknown; tr&#58;internal&#58;p2&#58; output state hides or changes unknown; tr&#58;summary&#58;cf1&#58; output state hides or changes unknown; tr&#58;summary&#58;cf2&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;51610e042901a41c39ff131c |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev1<br>ev2 |
| field | transformations.tr&#58;internal&#58;p1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | 81b508f72f7a8df15dee89a56a03530e20ea815794559c164bf8e1531fc0cbb7 |
| proposition ids | claim&#58;p1 |
| reason | tr&#58;internal&#58;p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;8bb77f9840772d66d42df9dc |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | 4a068c454d9d017ce15fd8a069b15e3bbe637f4f267658bf60d7a31a1db989da |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tr&#58;internal&#58;p1&#58; output state hides or changes unknown; tr&#58;internal&#58;p2&#58; output state hides or changes unknown; tr&#58;summary&#58;cf1&#58; output state hides or changes unknown; tr&#58;summary&#58;cf2&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tr&#58;internal&#58;p1&#58; output state hides or changes unknown; tr&#58;internal&#58;p2&#58; output state hides or changes unknown; tr&#58;summary&#58;cf1&#58; output state hides or changes unknown; tr&#58;summary&#58;cf2&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/6 |
| trigger id | p9trigger&#58;9ba09d3b84ffa214762d960e |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev3 |
| field | transformations.tr&#58;internal&#58;p2 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | 59e581660d3b979b21ed0e02001d983c6f8d2c1edb5f66f1826686a46427db9e |
| proposition ids | claim&#58;p2 |
| reason | tr&#58;internal&#58;p2&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/7 |
| trigger id | p9trigger&#58;b84b3a3e12206f8da536c394 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev1<br>ev2<br>ev3 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;8d619108af71f1e97992dbb8 |
| projected object fingerprint | 6205de39bf3f5f80948ec7b3a7968336a21029e9c33e298e770f8fecf4346ec0 |
| proposition ids | claim&#58;p1<br>claim&#58;p2 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/8 |
| trigger id | p9trigger&#58;d30c50ce0ae054d81861a9f0 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 3<br>Evaluated&#58; 3<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;negative&#95;assertions |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; tr&#58;internal&#58;p1&#58; output state hides or changes unknown; tr&#58;internal&#58;p2&#58; output state hides or changes unknown; tr&#58;summary&#58;cf1&#58; output state hides or changes unknown; tr&#58;summary&#58;cf2&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | bdd56ec49145383a83517e9b8f847f47c029b96bb3ddd203275cb342a4a3eb74 |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 9884de31bc2e60f128d66f9cda4a30779a592c52d1166cbdddf0878c6617bca7 |
| execution evidence / 1 / attempt ids | attempt-004 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 14f0cfa63b3724c0e84732cb009f69a76e2b2391d890d3f4db392e7a8d0add08 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 17042 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 119264 |
| execution evidence / 1 / message id | msg&#95;011CfvfjFMdDFmtAVdtyaaJH |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvfjF3mHb8QFvw1xWYsd |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 20028 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-haiku-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14807 |
| execution evidence / 1 / usage / output tokens | 31121 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 77c95aed75c1d8563c7cf5f03b5c1a0345cdd58b50d13563d519cc2dd49284bb |
| ledger fingerprint | 0b781d7ee11fd6ea96b079707765725bf79cfbc3b5e81255905a7f82351fda7d |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14807 |
| providers / 1 / usage / output tokens | 31121 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | bbf1e05903c0ceb8b5a6b85cb5edf6b6f415867ec30ae9c72a3c9bcda324f549 |
| run id | 4b838496-6ba6-4ecf-969e-68e3172ef0a1 |
| selected position id | p9position&#58;8d619108af71f1e97992dbb8 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

