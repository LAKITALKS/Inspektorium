# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;50.433406+00&#58;00 |
| parent | Not supplied |
| record fingerprint | bc13554b215a0eaea8ecd31db50b98c2823fb25d68265c071566bcc6a8bc36d9 |
| revision | d78abb21-908e-441a-bb72-509981edb882 |
| selected position id | p9position&#58;76ca8d3e65247949e2aa2551 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-002 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 0ec6ba875e4c18f175db5d3cdb694f57df2ccdb0c266bfb146910126aa20b243 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 8650 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 51815 |
|  / 1 / message id | msg&#95;011CfvfXcfSv6ZUm5hg29rXe |
|  / 1 / model | claude-haiku-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-haiku-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvfXcL6tSTk9a95Q498L |
|  / 1 / requested model | claude-haiku-5-5 |
|  / 1 / reserved microusd | 19991 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-haiku-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-haiku-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14722 |
|  / 1 / usage / output tokens | 14354 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Compound X treats cancer in patients.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 112163c5e3b414878531e3c67842192acd46632c8d8f17f708205804341958e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | mechanism&#95;vs&#95;evidence |
| raw response sha256 | c8b0fbf9f78380028467ca6f36e0dbda854cd2eee8d190606997acf7cbf8fed9 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>t-internal-p1&#58; output state hides or changes unknown<br>t-summary-c1&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
| record fingerprint | 5c0cb269d7be88cbd056267ac75d08ad04ee0889664f1ad5c0cc605bebd07b9f |
| technical status | incomplete |
| transformation findings | t-internal-p1&#58; output state hides or changes unknown<br>t-summary-c1&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | ev-1<br>ev-2 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | The only described evidence is a petri-dish cell-kill result. It is not evidence of treatment benefit in patients.<br>Only in vitro cell data are described in the source.<br>The source describes no animal or human data, so no clinical or in vivo evidence was assessed.<br>bind-1&#58; Petri-dish cytotoxicity in cultured cells is remote from treating cancer in patients and is not direct human evidence.<br>preserved observation&#58; inconclusive<br>bind-2&#58; The reviewed source states that no animal or human data are described.<br>no evidence found does not prove absence or contradiction<br>unresolved material claim attributes&#58; endpoint&#95;type<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 1 / reported verdict | unsupported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | mechanism&#95;vs&#95;evidence |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | mechanism&#95;to&#95;outcome |
| represented trigger analysis / described biological mechanism | true |
| represented trigger analysis / evidence ids | ev-1<br>ev-2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | true |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | A preclinical petri-dish cell-kill result is used to imply human clinical benefit. The source describes no animal or human data, so the mechanism-level result does not establish treatment in patients. causal&#95;claim is true because the proposition relation is human&#95;clinical&#95;benefit. |
| represented trigger analysis / trigger evidence id | ev-1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | killed up to 90% of cultured human tumour cells in a petri dish within 48 hours |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single claim taken verbatim from the task prompt; the context press summary is used as the only evidence source. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov&#58;input&#58;1 |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | ev-1<br>ev-2 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | The only described evidence is a petri-dish cell-kill result. It is not evidence of treatment benefit in patients.<br>Only in vitro cell data are described in the source.<br>The source describes no animal or human data, so no clinical or in vivo evidence was assessed.<br>bind-1&#58; Petri-dish cytotoxicity in cultured cells is remote from treating cancer in patients and is not direct human evidence.<br>preserved observation&#58; inconclusive<br>bind-2&#58; The reviewed source states that no animal or human data are described.<br>no evidence found does not prove absence or contradiction<br>unresolved material claim attributes&#58; endpoint&#95;type<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | unsupported |
| material dimensions | population<br>species<br>intervention<br>endpoint<br>relation |
| materiality | required |
| not applicable / certainty | The claim makes no certainty statement. |
| not applicable / comparator | The claim states no comparator. |
| not applicable / dose | The claim states no dose. |
| not applicable / follow up | The claim states no follow-up period. |
| not applicable / formulation | The claim states no formulation. |
| not applicable / route | The claim states no route of administration. |
| observation target | Not supplied |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov&#58;input&#58;1 |
| reason | The only described evidence is a petri-dish cell-kill result. It is not evidence of treatment benefit in patients. |
| reported verdict | unsupported |
| required bridge ids | No entries recorded |
| search question | Is there human clinical evidence that Compound X treats cancer in patients? |
| search scope ids | ss&#58;press |
| uncertainty | Only in vitro cell data are described in the source.<br>The source describes no animal or human data, so no clinical or in vivo evidence was assessed. |

Quoted proposition; this is represented input, not a release assertion.

```
Compound X treats cancer in patients.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 37 |
| start | 0 |
| text | Compound X treats cancer in patients. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | Not supplied |
| comparator | Not supplied |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | Not supplied |
| effect magnitude | Not supplied |
| endpoint | cancer treatment |
| endpoint type | Not supplied |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | Compound X |
| population | patients |
| relation | human&#95;clinical&#95;benefit |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | bind-1 |
|  / 1 / directness | remote |
|  / 1 / evidence id | ev-1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Petri-dish cytotoxicity in cultured cells is remote from treating cancer in patients and is not direct human evidence. |
|  / 1 / search scope id | ss&#58;press |
|  / 2 / binding id | bind-2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | ev-2 |
|  / 2 / observation | no&#95;evidence&#95;found |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | The reviewed source states that no animal or human data are described. |
|  / 2 / search scope id | ss&#58;press |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t-extraction-p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | Not supplied |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from and to text (identical) | Compound X treats cancer in patients. |
| from proposition ids | claim&#58;p1 |
| reason | Verbatim extraction of the single claim; no wording change. |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | t-extraction-p1 |

### Transformation t-search-p1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | Not supplied |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | Search question restates the claim as a question about human clinical evidence; no attribute change. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Is there human clinical evidence that Compound X treats cancer in patients? |
| transformation id | t-search-p1 |

### Transformation t-internal-p1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | Not supplied |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | Internal finding restates the claim with its verdict summary; the asserted state matches the host-derived unsupported state. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Compound X treats cancer in patients.<br>Only in vitro cell data are described; no animal or human data support a clinical benefit claim. |
| transformation id | t-internal-p1 |

### Transformation t-summary-c1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | Not supplied |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | Not supplied |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | Not supplied |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | human&#95;clinical&#95;benefit |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | Client summary states the whole claim is not supported by the reviewed press summary. This matches the host-derived unsupported state and does not claim global nonexistence. |
| stage | summary |
| target id | client&#58;c1 |
| to text | The reviewed press summary does not support that Compound X treats cancer in patients.<br>It reports a petri-dish result in cultured tumour cells and describes no animal or human data. |
| transformation id | t-summary-c1 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence ev-1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | tumour cell death in culture |
| evidence id | ev-1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
killed up to 90% of cultured human tumour cells in a petri dish within 48 hours
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | tumour cell death in culture |
| attributes / endpoint type | Not supplied |
| attributes / intervention | Not supplied |
| attributes / population | Not supplied |
| attributes / relation | description |
| attributes / species | cultured human tumour cells |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | Cell culture only; no animal or human exposure. |
| evidence id | ev-1 |
| evidence type | in&#95;vitro |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | press summary of a cultured-cell cytotoxicity result |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

### Evidence ev-2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | animal or human data |
| evidence id | ev-2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
No animal or human data are described.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | Not supplied |
| attributes / endpoint type | Not supplied |
| attributes / intervention | Not supplied |
| attributes / population | Not supplied |
| attributes / relation | description |
| attributes / species | Not supplied |
| cohort id | Not supplied |
| dataset id | Not supplied |
| design limitations | States that no animal or human data are described. |
| evidence id | ev-2 |
| evidence type | unknown |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| quality | Not supplied |
| randomized | Not supplied |
| source role | press summary statement on the scope of data described |
| study id | Not supplied |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | press summary |
|  / 1 / reviewed source ids | context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | ss&#58;press |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | na&#58;claim&#58;p1 |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / proposition | Compound X treats cancer in patients. |
|  / 1 / search scope id | ss&#58;press |
|  / 1 / source local evidence ids | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A press summary reports that Compound X, a plant-derived molecule, killed up to 90% of cultured human tumour cells in a petri dish within 48 hours. The write-up concludes that Compound X 'treats cancer' and could become a natural alternative to chemotherapy. No animal or human data are described.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Compound X treats cancer in patients. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov&#58;input&#58;1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status | low |
|  / 1 / contrary evidence ids | ev-1<br>ev-2 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | unsupported |
|  / 1 / proposition | Compound X treats cancer in patients. |
|  / 1 / provenance id | prov&#58;input&#58;1 |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Only in vitro cell data are described; no animal or human data support a clinical benefit claim. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | It reports a petri-dish result in cultured tumour cells and describes no animal or human data. |
|  / 1 / client finding id | client&#58;c1 |
|  / 1 / client negative assertions / 1 / assertion id | na&#58;claim&#58;p1 |
|  / 1 / client negative assertions / 1 / client scope | reviewed&#95;set |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The reviewed press summary does not support that Compound X treats cancer in patients. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov&#58;input&#58;1 |
|  / 1 / referenced evidence ids | ev-1<br>ev-2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;76ca8d3e65247949e2aa2551/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 0218c5730cf714840425bd0b985dce3cff2bbdbf0dbedf6e279d0b20c0a3a695 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;76ca8d3e65247949e2aa2551

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-haiku-5-5 |
| origin | original |
| original model label | mechanism&#95;vs&#95;evidence |
| position id | p9position&#58;76ca8d3e65247949e2aa2551 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | c8b0fbf9f78380028467ca6f36e0dbda854cd2eee8d190606997acf7cbf8fed9 |
| run id | c15ed49d-22de-42f4-9f1b-7ca30b9c5139 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14722 |
| usage / output tokens | 14354 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev-1<br>ev-2 |
| field | transformations.t-summary-c1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;76ca8d3e65247949e2aa2551 |
| projected object fingerprint | 41b8a40e1f154674a150dc3edf2f83f187015f4bb67033e65f725e4989794927 |
| proposition ids | claim&#58;p1 |
| reason | t-summary-c1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;209340c7798e5f7c57fe68e1 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | ev-1<br>ev-2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;76ca8d3e65247949e2aa2551 |
| projected object fingerprint | 6015859ad15cd04e5549a24536529bc858b1903986d2e8548da54e5ef69d99f6 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;89b84f1226155284db4661bb |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;76ca8d3e65247949e2aa2551 |
| projected object fingerprint | 1be2add93ef43ffcb6d6eab6e6e9c595b8542a3b1bcffa6c2cb89f108e6aa825 |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;938aad295d7f5c6f57d42043 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;76ca8d3e65247949e2aa2551 |
| projected object fingerprint | a67e2a2510d1618b886e26f1feced3fc7842951b250bb971b3312cb776c1373a |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;9a34607b22b819f23d10a38e |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | ev-1<br>ev-2 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;76ca8d3e65247949e2aa2551 |
| projected object fingerprint | 5352144d2c61fe3857aea57dcd2932a1e047c0f5df7d39ee3cd3bdd5b8e31f57 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;b1be15e5959f4334e7a8dbc8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | ev-1<br>ev-2 |
| field | transformations.t-internal-p1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;76ca8d3e65247949e2aa2551 |
| projected object fingerprint | 4f8e98185584cf0eb18d09bdf62b6bc70ed3259658360a4732e59b85368a2ae5 |
| proposition ids | claim&#58;p1 |
| reason | t-internal-p1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;e4118a98e210734e51ea3898 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;negative&#95;assertions |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t-internal-p1&#58; output state hides or changes unknown; t-summary-c1&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | a3840d1c8b9595fde1ea13bd6ccf7d47c97694c238ecc78a88dffe42d49c0599 |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | f1dc54bcba18393a4a19f8dc134490106a206ba811fd6137b50cf3b63dc67f4a |
| execution evidence / 1 / attempt ids | attempt-002 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 0ec6ba875e4c18f175db5d3cdb694f57df2ccdb0c266bfb146910126aa20b243 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 8650 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 51815 |
| execution evidence / 1 / message id | msg&#95;011CfvfXcfSv6ZUm5hg29rXe |
| execution evidence / 1 / model | claude-haiku-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-haiku-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvfXcL6tSTk9a95Q498L |
| execution evidence / 1 / requested model | claude-haiku-5-5 |
| execution evidence / 1 / reserved microusd | 19991 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-haiku-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-haiku-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14722 |
| execution evidence / 1 / usage / output tokens | 14354 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 4c7ea357ae5bc4fc582048c362f5bdffabeb031cf56306a5f1c0587bc8aaaad4 |
| ledger fingerprint | 132fa57a66395a8ebb3a3c6018c087f6265e3847901e171b652db8d583044fd9 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | mechanism&#95;vs&#95;evidence |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-haiku-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14722 |
| providers / 1 / usage / output tokens | 14354 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 0218c5730cf714840425bd0b985dce3cff2bbdbf0dbedf6e279d0b20c0a3a695 |
| run id | c15ed49d-22de-42f4-9f1b-7ca30b9c5139 |
| selected position id | p9position&#58;76ca8d3e65247949e2aa2551 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

