# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;55.764608+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 0f5cc0feaf4d2be4f5c6b5654b41d567cbc2a238b971e895d8b8af5c79c6668a |
| revision | 4de3faa1-624f-4075-97ed-f5f418c7e5d6 |
| selected position id | p9position&#58;f30bc642b8cc8228f430c056 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-009 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | d230b4edd9485a59b7c71d25f4580044f87553f33b5f52aecab8a9385dfeff6c |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 135450 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 60408 |
|  / 1 / message id | msg&#95;011CfvgEKELqnqvFqCvW5kr6 |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvgEJr2wTGqcHqMQC2so |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 240828 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-sonnet-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14880 |
|  / 1 / usage / output tokens | 10569 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 487aab0a628c1f44c2b48d2030d8802e758ab89deb04eac557bd486c70c2186f |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | 48a752a9887a8bb3cc9305f24ed9e22fe348596172bbb092a30bd09b7f0ba377 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>t1&#58; semantic transformation changes population<br>t1&#58; semantic transformation changes species<br>t1&#58; semantic transformation changes intervention<br>t1&#58; semantic transformation changes endpoint<br>t1&#58; semantic transformation changes endpoint&#95;type<br>t1&#58; semantic transformation changes relation<br>t1&#58; semantic transformation changes effect&#95;direction<br>t1&#58; semantic transformation changes certainty<br>t3&#58; output state hides or changes unknown<br>t4&#58; semantic transformation changes population<br>t4&#58; semantic transformation changes species<br>t4&#58; semantic transformation changes intervention<br>t4&#58; semantic transformation changes endpoint<br>t4&#58; semantic transformation changes endpoint&#95;type<br>t4&#58; semantic transformation changes relation<br>t4&#58; semantic transformation changes effect&#95;direction<br>t4&#58; semantic transformation changes certainty<br>t6&#58; output state hides or changes unknown<br>t7&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t6&#58; output state hides or changes unknown; t7&#58; output state hides or changes unknown |
| record fingerprint | 9dad20943a0b9a6e3cc1fdaf071beb30a8419fea448494dca9e6e30e0135a583 |
| technical status | incomplete |
| transformation findings | t1&#58; semantic transformation changes population<br>t1&#58; semantic transformation changes species<br>t1&#58; semantic transformation changes intervention<br>t1&#58; semantic transformation changes endpoint<br>t1&#58; semantic transformation changes endpoint&#95;type<br>t1&#58; semantic transformation changes relation<br>t1&#58; semantic transformation changes effect&#95;direction<br>t1&#58; semantic transformation changes certainty<br>t3&#58; output state hides or changes unknown<br>t4&#58; semantic transformation changes population<br>t4&#58; semantic transformation changes species<br>t4&#58; semantic transformation changes intervention<br>t4&#58; semantic transformation changes endpoint<br>t4&#58; semantic transformation changes endpoint&#95;type<br>t4&#58; semantic transformation changes relation<br>t4&#58; semantic transformation changes effect&#95;direction<br>t4&#58; semantic transformation changes certainty<br>t6&#58; output state hides or changes unknown<br>t7&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | e1 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | The LDL reduction is directly reported for this population.<br>The context does not say whether the trial had a control arm.<br>b1&#58; The Phase 2 result directly reports a 65 percent LDL reduction in this population.<br>unresolved relation or evidence capability<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 1 / reported verdict | supported |
|  / 2 / dependency status | unknown |
|  / 2 / derived state | unknown |
|  / 2 / evidence ids | e2 |
|  / 2 / proposition id | claim&#58;p2 |
|  / 2 / reasons | Only lipid and liver-safety endpoints were measured over twelve weeks. No heart-attack outcome evidence exists in the reviewed set.<br>No outcomes trial is expected to report for at least four more years.<br>b2&#58; The trial tracked no cardiovascular events, so there is no heart-attack evidence in the reviewed material.<br>no evidence found does not prove absence or contradiction<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 2 / reported verdict | unsupported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p2 |
| represented trigger analysis / reason | A biomarker (LDL) result from a twelve-week Phase 2 trial is presented as a reduction in heart attacks, and no cardiovascular events were tracked. This is endpoint inflation. No biological mechanism is described, and the error is not a correlation-to-causation inference, so the label is overstatement. |
| represented trigger analysis / trigger evidence id | e2 |
| represented trigger analysis / trigger proposition id | claim&#58;p2 |
| represented trigger analysis / trigger quote | reduced heart attacks |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Manual split of the claim into an LDL-lowering proposition and a heart-attack-reduction proposition, based only on the supplied prompt and context. |
| logic / children / 1 / children | No entries recorded |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / children | No entries recorded |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | and |
| logic / proposition id | Not supplied |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | e1 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | The LDL reduction is directly reported for this population.<br>The context does not say whether the trial had a control arm.<br>b1&#58; The Phase 2 result directly reports a 65 percent LDL reduction in this population.<br>unresolved relation or evidence capability<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | No entries recorded |
| materiality | required |
| not applicable / comparator | The claim names no comparator. |
| not applicable / follow up | The claim states no follow-up. |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | The LDL reduction is directly reported for this population. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Did the drug lower LDL cholesterol in patients with familial hypercholesterolaemia? |
| search scope ids | ss1 |
| uncertainty | The context does not say whether the trial had a control arm. |

Quoted proposition; this is represented input, not a release assertion.

```
The new injectable drug lowered LDL cholesterol
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 47 |
| start | 0 |
| text | The new injectable drug lowered LDL cholesterol |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | definitive |
| comparator | Not supplied |
| effect direction | decrease |
| endpoint | LDL cholesterol |
| endpoint type | biomarker |
| follow up | Not supplied |
| intervention | new injectable drug |
| population | patients with familial hypercholesterolaemia |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The Phase 2 result directly reports a 65 percent LDL reduction in this population. |
|  / 1 / search scope id | ss1 |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | e2 |
| derived judgment / proposition id | claim&#58;p2 |
| derived judgment / reasons | Only lipid and liver-safety endpoints were measured over twelve weeks. No heart-attack outcome evidence exists in the reviewed set.<br>No outcomes trial is expected to report for at least four more years.<br>b2&#58; The trial tracked no cardiovascular events, so there is no heart-attack evidence in the reviewed material.<br>no evidence found does not prove absence or contradiction<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | unsupported |
| material dimensions | No entries recorded |
| materiality | required |
| not applicable / comparator | The claim names no comparator. |
| not applicable / follow up | The claim states no follow-up. |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p2 |
| provenance id | prov1 |
| reason | Only lipid and liver-safety endpoints were measured over twelve weeks. No heart-attack outcome evidence exists in the reviewed set. |
| reported verdict | unsupported |
| required bridge ids | No entries recorded |
| search question | Is there evidence that the drug reduced heart attacks in patients with familial hypercholesterolaemia? |
| search scope ids | ss1 |
| uncertainty | No outcomes trial is expected to report for at least four more years. |

Quoted proposition; this is represented input, not a release assertion.

```
The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 121 |
| start | 52 |
| text | reduced heart attacks in patients with familial hypercholesterolaemia |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | definitive |
| comparator | Not supplied |
| effect direction | decrease |
| endpoint | heart attacks |
| endpoint type | clinical&#95;event |
| follow up | Not supplied |
| intervention | new injectable drug |
| population | patients with familial hypercholesterolaemia |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b2 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e2 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The trial tracked no cardiovascular events, so there is no heart-attack evidence in the reviewed material. |
|  / 1 / search scope id | ss1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| from and to text (identical) | The new injectable drug lowered LDL cholesterol |
| from attributes | No entries recorded |
| from proposition ids | claim&#58;p1 |
| reason | Extraction left the wording unchanged and added structured attributes. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / certainty | definitive |
| to attributes / comparator | Not supplied |
| to attributes / effect direction | decrease |
| to attributes / endpoint | LDL cholesterol |
| to attributes / endpoint type | biomarker |
| to attributes / follow up | Not supplied |
| to attributes / intervention | new injectable drug |
| to attributes / population | patients with familial hypercholesterolaemia |
| to attributes / relation | causal |
| to attributes / species | human |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | definitive |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The new injectable drug lowered LDL cholesterol |
| reason | The search question keeps the same meaning as the proposition. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Did the drug lower LDL cholesterol in patients with familial hypercholesterolaemia? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| from and to attributes (identical) / certainty | definitive |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | LDL cholesterol |
| from and to attributes (identical) / endpoint type | biomarker |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | The new injectable drug lowered LDL cholesterol |
| from proposition ids | claim&#58;p1 |
| reason | The internal finding is unchanged from the proposition. |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| from attributes | No entries recorded |
| from proposition ids | claim&#58;p2 |
| from text | reduced heart attacks in patients with familial hypercholesterolaemia |
| reason | The subject was restored from the first clause and structured attributes were added. |
| stage | extraction |
| target id | claim&#58;p2 |
| to attributes / certainty | definitive |
| to attributes / comparator | Not supplied |
| to attributes / effect direction | decrease |
| to attributes / endpoint | heart attacks |
| to attributes / endpoint type | clinical&#95;event |
| to attributes / follow up | Not supplied |
| to attributes / intervention | new injectable drug |
| to attributes / population | patients with familial hypercholesterolaemia |
| to attributes / relation | causal |
| to attributes / species | human |
| to text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia |
| transformation id | t4 |

### Transformation t5

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | definitive |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia |
| reason | The search question keeps the same meaning as the proposition. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Is there evidence that the drug reduced heart attacks in patients with familial hypercholesterolaemia? |
| transformation id | t5 |

### Transformation t6

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| from and to attributes (identical) / certainty | definitive |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia |
| from proposition ids | claim&#58;p2 |
| reason | The internal finding is unchanged from the proposition. |
| stage | internal |
| target id | claim&#58;p2 |
| transformation id | t6 |

### Transformation t7

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | definitive |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / endpoint | heart attacks |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | new injectable drug |
| from and to attributes (identical) / population | patients with familial hypercholesterolaemia |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia |
| reason | The summary reports that the heart-attack component is unsupported, which matches the finding. |
| stage | summary |
| target id | cf1 |
| to text | The Phase 2 trial did not show that the drug reduced heart attacks in patients with familial hypercholesterolaemia. |
| transformation id | t7 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | LDL cholesterol |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | Not supplied |
| attributes / effect direction | decrease |
| attributes / endpoint | LDL cholesterol |
| attributes / endpoint type | biomarker |
| attributes / follow up | twelve weeks |
| attributes / intervention | new injectable drug |
| attributes / population | patients with familial hypercholesterolaemia |
| attributes / species | human |
| design limitations | Phase 2 trial<br>lipid endpoint only<br>twelve weeks of follow-up |
| evidence id | e1 |
| evidence type | unknown |
| randomized | Not supplied |
| source role | company-announced Phase 2 trial result |

### Evidence e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | heart attacks |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | Not supplied |
| attributes / effect direction | decrease |
| attributes / endpoint | heart attacks |
| attributes / endpoint type | clinical&#95;event |
| attributes / follow up | twelve weeks |
| attributes / intervention | new injectable drug |
| attributes / population | patients with familial hypercholesterolaemia |
| attributes / species | human |
| design limitations | no cardiovascular events were tracked |
| evidence id | e2 |
| evidence type | descriptive |
| randomized | Not supplied |
| source role | trial scope statement |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | ss1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg1 |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p2 |
|  / 1 / proposition | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia |
|  / 1 / search scope id | ss1 |
|  / 1 / source local evidence ids | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A pharmaceutical company announced results from its Phase 2 trial of a new injectable cholesterol-lowering agent. The drug reduced LDL cholesterol by 65 percent in patients with familial hypercholesterolaemia who were already on maximum statin therapy. Company executives described the results as a major breakthrough in cardiovascular protection and said the drug would transform outcomes for patients at high risk of heart attack and stroke. They announced plans for an accelerated approval pathway based on the LDL reduction data. The trial measured only lipid levels and liver safety over twelve weeks; no cardiovascular events were tracked and no outcomes trial is expected to report for at least four more years.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The new injectable drug lowered LDL cholesterol and reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | The new injectable drug lowered LDL cholesterol |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary |  |
|  / 2 / allowed summary strength | not&#95;supported |
|  / 2 / confidence status |  |
|  / 2 / contrary evidence ids | e2 |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | Not supplied |
|  / 2 / proposition | The new injectable drug reduced heart attacks in patients with familial hypercholesterolaemia |
|  / 2 / provenance id | prov1 |
|  / 2 / supporting evidence ids | No entries recorded |
|  / 2 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;supported |
|  / 1 / display claim | The Phase 2 trial did not show that the drug reduced heart attacks in patients with familial hypercholesterolaemia. |
|  / 1 / parent finding id | claim&#58;p2 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | e2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;f30bc642b8cc8228f430c056/claim&#58;p1&#58; scientific UNKNOWN<br>p9position&#58;f30bc642b8cc8228f430c056/claim&#58;p2&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 8684c0fa6c398dba644c9c065fd27aced0f437d270aa49a3d061b8501693c361 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;f30bc642b8cc8228f430c056

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;f30bc642b8cc8228f430c056 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 48a752a9887a8bb3cc9305f24ed9e22fe348596172bbb092a30bd09b7f0ba377 |
| run id | 9e1fd12f-09a8-4a34-9672-213d2ad3c328 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14880 |
| usage / output tokens | 10569 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e1 |
| field | transformations.t1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | 131bd611b7cbcec628c63ef05f4b58b4d03a72c00852ca943a3eb45aa159318b |
| proposition ids | claim&#58;p1 |
| reason | t1&#58; semantic transformation changes certainty |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;65a4593c5380bc0e26e1e38d |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | 232c78d3ce8512a88fa8b79d76fbb1e3f79a23ef09c356e48eadc444a1516abf |
| proposition ids | claim&#58;p2 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;71db2990876e0521a4af2eff |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e2 |
| field | transformations.t6 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | a92cc771c03fd4ddf9276ec4f059b866aad3b4036f69083275748f0de6dd2cdf |
| proposition ids | claim&#58;p2 |
| reason | t6&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;9790a304f25b51653444642a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | 3fc1d6aca74f4ff46b025c1ab55f9ee8c4328b4ae3181d16e697350f2c2544de |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t6&#58; output state hides or changes unknown; t7&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;a9e2247f0259849518e69055 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e2 |
| field | transformations.t7 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | 257be567ecdf017e0dce1d1f26dc9807002e9153e393b804b3c374ba3e4d62da |
| proposition ids | claim&#58;p2 |
| reason | t7&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;ab1b0eb2a778f25ea52dedf6 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | 6ca142393bd3c5b4ed352d9730f96fc9d277804b3b144645ec9f0a750216da0d |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t6&#58; output state hides or changes unknown; t7&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t6&#58; output state hides or changes unknown; t7&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;b89a5882fbe27f2bd012573b |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | 35ee54af3b19ca468c350c8706c972797d94d53dc92c4ff54d439fbb09f1f68f |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/6 |
| trigger id | p9trigger&#58;e1e145ae1d5caf43c2a8e2f9 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e2 |
| field | transformations.t4 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | ea431cf0e0fb664745c980a3a67aa460d2c625d5f01073179a44fb119d1a9b70 |
| proposition ids | claim&#58;p2 |
| reason | t4&#58; semantic transformation changes certainty |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/7 |
| trigger id | p9trigger&#58;eb9bc04985e22ea662956330 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e2 |
| field | propositions.claim&#58;p2.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | b223795ee5eee20531fbcff2c4109e78382e3a112dc166bf89281e658e9a800b |
| proposition ids | claim&#58;p2 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/8 |
| trigger id | p9trigger&#58;f412da97fb1c8dde8dba3b4d |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e1 |
| field | transformations.t3 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;f30bc642b8cc8228f430c056 |
| projected object fingerprint | 1be73975c3cb6e58d9b8ff44fa85a9a701f26ed6ca944a9b4a7201476c67eebe |
| proposition ids | claim&#58;p1 |
| reason | t3&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/9 |
| trigger id | p9trigger&#58;f543c4fd7236078ece9cb4b2 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t6&#58; output state hides or changes unknown; t7&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | d530f5f74b6d283f99cef7ead7b5e1a867e9c8db87f9d6b22c03d8e29313ad04 |
| case id | p9case&#58;c4b6807c880b3053a0cd8f63 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 2ac97a23891c09a746426b8416e724802ec64c914677bc7bdcf3ecd85ea66da8 |
| execution evidence / 1 / attempt ids | attempt-009 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | d230b4edd9485a59b7c71d25f4580044f87553f33b5f52aecab8a9385dfeff6c |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 135450 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 60408 |
| execution evidence / 1 / message id | msg&#95;011CfvgEKELqnqvFqCvW5kr6 |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvgEJr2wTGqcHqMQC2so |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 240828 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-03&#124;claude-sonnet-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14880 |
| execution evidence / 1 / usage / output tokens | 10569 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 38d25af7fe1fef7b110fbcad00f93f2a4948109f0ef5268dbbe1d74155b6a166 |
| ledger fingerprint | b6e23a5c6aac1644d905d843422f2acc499fe394160911b36ea4fad0edb0e5bc |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14880 |
| providers / 1 / usage / output tokens | 10569 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 8684c0fa6c398dba644c9c065fd27aced0f437d270aa49a3d061b8501693c361 |
| run id | 9e1fd12f-09a8-4a34-9672-213d2ad3c328 |
| selected position id | p9position&#58;f30bc642b8cc8228f430c056 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

