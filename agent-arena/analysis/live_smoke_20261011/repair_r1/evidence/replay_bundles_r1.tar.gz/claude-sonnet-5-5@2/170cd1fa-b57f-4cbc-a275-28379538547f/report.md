# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;57.888414+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 9b3e3ac75909f9e01259fb2ad2232de2d94d3fa28d9595be03f6d197eb8ebad0 |
| revision | 170cd1fa-b57f-4cbc-a275-28379538547f |
| selected position id | p9position&#58;81f81504d87a6e4dbee2d1e4 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-012 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 84c764c898bc61b46307c9c5c5857d74622660d986b279a40db191b95388fa65 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 103674 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 40955 |
|  / 1 / message id | msg&#95;011CfvgSBbYvNPgrcouWA36w |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvgSB5HqDm3hHFC8gDBG |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 240970 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-sonnet-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14917 |
|  / 1 / usage / output tokens | 7384 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Eating a good breakfast every morning makes you lose weight.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 609ee28c8d2fb302457ee4550b78e951b6c05250ac44fdaf263f5cdc58dd02e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | correlation&#95;vs&#95;causation |
| raw response sha256 | 537c040ab653fff1d5381305faf55fdc28b3e757c14ae2f2130cccef8629a749 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>t1&#58; semantic transformation changes population<br>t1&#58; semantic transformation changes species<br>t1&#58; semantic transformation changes intervention<br>t1&#58; semantic transformation changes comparator<br>t1&#58; semantic transformation changes endpoint<br>t1&#58; semantic transformation changes endpoint&#95;type<br>t1&#58; semantic transformation changes relation<br>t1&#58; semantic transformation changes effect&#95;direction<br>t1&#58; semantic transformation changes certainty<br>t3&#58; output state hides or changes unknown<br>t4&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes comparator; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
| record fingerprint | 63f07811249118ae02026362d7e4ed5989d118e0285e536c02985a22cd5f4584 |
| technical status | incomplete |
| transformation findings | t1&#58; semantic transformation changes population<br>t1&#58; semantic transformation changes species<br>t1&#58; semantic transformation changes intervention<br>t1&#58; semantic transformation changes comparator<br>t1&#58; semantic transformation changes endpoint<br>t1&#58; semantic transformation changes endpoint&#95;type<br>t1&#58; semantic transformation changes relation<br>t1&#58; semantic transformation changes effect&#95;direction<br>t1&#58; semantic transformation changes certainty<br>t3&#58; output state hides or changes unknown<br>t4&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | e1<br>e2 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | Randomized evidence contradicts the causal claim; the observational association is confounded.<br>No effect sizes or trial details in the context.<br>b1&#58; Observational association with confounding; it cannot establish that breakfast causes weight loss.<br>preserved observation&#58; inconclusive<br>b2&#58; The RCT meta-analysis found that assigning people to eat breakfast did not cause weight loss.<br>review underlying capability absent<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 1 / reported verdict | contradicted |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | correlation&#95;vs&#95;causation |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | causal&#95;inference |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1<br>e2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | true |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | A causal weight-loss claim rests on an observational, confounded association, and the RCT evidence contradicts it. |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | Studies show people who skip breakfast weigh more |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single proposition extracted verbatim from the task prompt. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | e1<br>e2 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | Randomized evidence contradicts the causal claim; the observational association is confounded.<br>No effect sizes or trial details in the context.<br>b1&#58; Observational association with confounding; it cannot establish that breakfast causes weight loss.<br>preserved observation&#58; inconclusive<br>b2&#58; The RCT meta-analysis found that assigning people to eat breakfast did not cause weight loss.<br>review underlying capability absent<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | contradicted |
| material dimensions | population<br>intervention<br>comparator<br>endpoint |
| materiality | required |
| not applicable / comparison | the claim states no comparison type |
| not applicable / dose | no dose specified in the claim |
| not applicable / effect basis | the claim states no effect basis |
| not applicable / effect magnitude | the claim states no magnitude |
| not applicable / follow up | the claim states no follow-up |
| not applicable / formulation | not applicable to a dietary habit |
| not applicable / route | not applicable to a dietary habit |
| observation target | contradiction |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | Randomized evidence contradicts the causal claim; the observational association is confounded. |
| reported verdict | contradicted |
| required bridge ids | No entries recorded |
| search question | Do randomized trials show that eating breakfast every morning causes weight loss? |
| search scope ids | s1 |
| uncertainty | No effect sizes or trial details in the context. |

Quoted proposition; this is represented input, not a release assertion.

```
Eating a good breakfast every morning makes you lose weight.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 60 |
| start | 0 |
| text | Eating a good breakfast every morning makes you lose weight. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | definite |
| comparator | skipping breakfast |
| comparison | Not supplied |
| dose | Not supplied |
| effect basis | Not supplied |
| effect direction | decrease |
| effect magnitude | Not supplied |
| endpoint | body weight |
| endpoint type | anthropometric |
| follow up | Not supplied |
| formulation | Not supplied |
| intervention | eating breakfast |
| population | adults |
| relation | causal |
| route | Not supplied |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | indirect |
|  / 1 / evidence id | e1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Observational association with confounding; it cannot establish that breakfast causes weight loss. |
|  / 1 / search scope id | s1 |
|  / 2 / binding id | b2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | e2 |
|  / 2 / observation | contradiction |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | The RCT meta-analysis found that assigning people to eat breakfast did not cause weight loss. |
|  / 2 / search scope id | s1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| from and to text (identical) | Eating a good breakfast every morning makes you lose weight. |
| from attributes | No entries recorded |
| from proposition ids | claim&#58;p1 |
| reason | Verbatim extraction; the proposition text equals the original span. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / certainty | definite |
| to attributes / comparator | skipping breakfast |
| to attributes / comparison | Not supplied |
| to attributes / dose | Not supplied |
| to attributes / effect basis | Not supplied |
| to attributes / effect direction | decrease |
| to attributes / effect magnitude | Not supplied |
| to attributes / endpoint | body weight |
| to attributes / endpoint type | anthropometric |
| to attributes / follow up | Not supplied |
| to attributes / formulation | Not supplied |
| to attributes / intervention | eating breakfast |
| to attributes / population | adults |
| to attributes / relation | causal |
| to attributes / route | Not supplied |
| to attributes / species | human |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | definite |
| from and to attributes (identical) / comparator | skipping breakfast |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | body weight |
| from and to attributes (identical) / endpoint type | anthropometric |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | eating breakfast |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | Question form of the same causal proposition; attributes unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Do randomized trials show that eating breakfast every morning causes weight loss? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | definite |
| from and to attributes (identical) / comparator | skipping breakfast |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | body weight |
| from and to attributes (identical) / endpoint type | anthropometric |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | eating breakfast |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | The internal finding keeps the proposition and adds a contradicted verdict summary. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Eating a good breakfast every morning makes you lose weight.<br>Contradicted by RCT meta-analysis; the observational association does not establish causation. |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| asserted state | contradicted |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | definite |
| from and to attributes (identical) / comparator | skipping breakfast |
| from and to attributes (identical) / comparison | Not supplied |
| from and to attributes (identical) / dose | Not supplied |
| from and to attributes (identical) / effect basis | Not supplied |
| from and to attributes (identical) / effect direction | decrease |
| from and to attributes (identical) / effect magnitude | Not supplied |
| from and to attributes (identical) / endpoint | body weight |
| from and to attributes (identical) / endpoint type | anthropometric |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / formulation | Not supplied |
| from and to attributes (identical) / intervention | eating breakfast |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / route | Not supplied |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Eating a good breakfast every morning makes you lose weight. |
| reason | The client summary reports the claim as contradicted, matching the derived state. |
| stage | summary |
| target id | c1 |
| to text | Claim contradicted&#58; randomized trials found that assigning people to eat breakfast did not cause weight loss.<br>The link between skipping breakfast and higher weight comes from observational studies and does not show causation. |
| transformation id | t4 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | body weight |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
Studies show people who skip breakfast weigh more
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | definite |
| attributes / comparator | skipping breakfast |
| attributes / effect direction | increase |
| attributes / endpoint | body weight |
| attributes / endpoint type | anthropometric |
| attributes / intervention | eating breakfast |
| attributes / population | adults |
| attributes / relation | association |
| attributes / species | human |
| design limitations | confounding by health and lifestyle behaviours<br>cross-sectional or observational design |
| evidence id | e1 |
| evidence type | observational |
| randomized | false |
| source role | observational studies cited in the nutrition feature |

### Evidence e2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | body weight |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | contradictory |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
assigning people to eat breakfast did not cause weight loss
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | definite |
| attributes / comparator | skipping breakfast |
| attributes / effect direction | none |
| attributes / endpoint | body weight |
| attributes / endpoint type | anthropometric |
| attributes / intervention | eating breakfast |
| attributes / population | adults |
| attributes / relation | causal |
| attributes / species | human |
| design limitations | context gives no trial-level details |
| evidence id | e2 |
| evidence type | review |
| source role | systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | supplied material only |
|  / 1 / search scope id | s1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A nutrition feature advises: "Breakfast is the most important meal of the day. Studies show people who skip breakfast weigh more, so skipping breakfast makes you gain weight — eat a good breakfast every morning and you will lose weight."

The "people who skip breakfast weigh more" finding comes from cross-sectional and prospective OBSERVATIONAL studies (breakfast skippers differ from eaters in many health and lifestyle behaviours). Randomized controlled trials tell a different story: a systematic review and meta-analysis of RCTs (Sievert et al., BMJ, 2019) found that assigning people to eat breakfast did not cause weight loss — adults assigned to eat breakfast consumed more total daily calories and, if anything, weighed slightly more than those assigned to skip it — providing no support for eating breakfast as a weight-loss strategy.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | contradicted |
|  / 1 / confidence status | moderate |
|  / 1 / contrary evidence ids | e1<br>e2 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | correlation&#95;vs&#95;causation |
|  / 1 / proposition | Eating a good breakfast every morning makes you lose weight. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Contradicted by RCT meta-analysis; the observational association does not establish causation. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The link between skipping breakfast and higher weight comes from observational studies and does not show causation. |
|  / 1 / client finding id | c1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | contradicted |
|  / 1 / display claim | Claim contradicted&#58; randomized trials found that assigning people to eat breakfast did not cause weight loss. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | e2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;81f81504d87a6e4dbee2d1e4/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | d8011bd16e7d783bf68ff1e831634bb0094293b1e876022e6b3b5223a996ec6c |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;81f81504d87a6e4dbee2d1e4

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | correlation&#95;vs&#95;causation |
| position id | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 537c040ab653fff1d5381305faf55fdc28b3e757c14ae2f2130cccef8629a749 |
| run id | c038f9ec-411f-4c51-a0fe-0539102db74a |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14917 |
| usage / output tokens | 7384 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| projected object fingerprint | c34638bbf1f989883a919412118dc66b01f33d9fa4b945956fe323e8d3c21f2a |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes comparator; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;520463400195764959ce0330 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e1<br>e2 |
| field | transformations.t3 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| projected object fingerprint | 7c8285a86cdf6b0e65d576cae7033688d15196cb43c51fb23bf3872d538664cb |
| proposition ids | claim&#58;p1 |
| reason | t3&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;75407f52da7ac510ddabf79a |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| projected object fingerprint | 532f3ddb5614b6c777e79c6204bab7b2e4bdefa381a2a685cce46f22eb0a528c |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes comparator; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes comparator; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;7a7ffd5dbc0af26598e50603 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e1<br>e2 |
| field | transformations.t4 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| projected object fingerprint | 64b730ab930a85563de59c258b6a3e7798937379ded9117db049b9256e23d150 |
| proposition ids | claim&#58;p1 |
| reason | t4&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;af9f4b0fd14aab0ab065d382 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e1<br>e2 |
| field | transformations.t1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| projected object fingerprint | 73ce88cc3cf4367db617b8da61922bb2403fd31f5f4d3372744f568ca6640c75 |
| proposition ids | claim&#58;p1 |
| reason | t1&#58; semantic transformation changes certainty |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;b9b1b272f83209a78163cf34 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1<br>e2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| projected object fingerprint | c75c5c5b794b291202fb663064e95b236adae3e0baa106196e5465261f29ef7c |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;baedd1d6e3ec919433afa3c9 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1<br>e2 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;81f81504d87a6e4dbee2d1e4 |
| projected object fingerprint | f42763fe1158d6d1a313587add67057a2539a2a2df40421c35221d74921d4027 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/6 |
| trigger id | p9trigger&#58;ea7116ebae0cf50aaee20256 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes comparator; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes effect&#95;direction; t1&#58; semantic transformation changes certainty; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | ab6ec06981850d8b1e444e938b46d6a5cd6ff35b1a37103d3f5c19d04a4b28a4 |
| case id | p9case&#58;bf58d2e386ec58c1ecd287a3 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 98a0be1589471a92e30e70a9075ab5222a600ce71f38e5b58616239c672c3197 |
| execution evidence / 1 / attempt ids | attempt-012 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 84c764c898bc61b46307c9c5c5857d74622660d986b279a40db191b95388fa65 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 103674 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 40955 |
| execution evidence / 1 / message id | msg&#95;011CfvgSBbYvNPgrcouWA36w |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvgSB5HqDm3hHFC8gDBG |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 240970 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-06&#124;claude-sonnet-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14917 |
| execution evidence / 1 / usage / output tokens | 7384 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 708e656386b9545c47cc8b478bddb08eea8281957c4ca503a0f284ce53b10632 |
| ledger fingerprint | b4600b493d2a131952edccf36fb07b00dcc2a283f53e0c28e7cd7fc56be80015 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | correlation&#95;vs&#95;causation |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14917 |
| providers / 1 / usage / output tokens | 7384 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | d8011bd16e7d783bf68ff1e831634bb0094293b1e876022e6b3b5223a996ec6c |
| run id | c038f9ec-411f-4c51-a0fe-0539102db74a |
| selected position id | p9position&#58;81f81504d87a6e4dbee2d1e4 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

