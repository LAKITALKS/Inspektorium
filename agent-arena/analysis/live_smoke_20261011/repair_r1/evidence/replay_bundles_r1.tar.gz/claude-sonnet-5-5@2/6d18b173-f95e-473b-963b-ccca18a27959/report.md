# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;57.239913+00&#58;00 |
| parent | Not supplied |
| record fingerprint | d5f2f5dac6f621ca95b6ef2b8a586d2ee6ea6d1a9c120333f03ce0c2e3b1a100 |
| revision | 6d18b173-f95e-473b-963b-ccca18a27959 |
| selected position id | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-011 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | 762e75c9492ca7761bdd87bd0a51cdbd9b58f675809b65b42590178a65c30852 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 93372 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 38495 |
|  / 1 / message id | msg&#95;011CfvgPHXeiB7Rnih3bbSJ4 |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvgPH29VMWjACJHxX7S3 |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 239738 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-sonnet-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14696 |
|  / 1 / usage / output tokens | 6398 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The supplement causes liver damage in long-term users.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | fdff1ae350dd42166846a038784e0a2acba7903f8b6ffbe2039bc333fbdad7b2 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | 57f357e26869f9b60a5a88456dd6ab09c7cffc4d0f01dd3aac26c35a73d0502c |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>t1&#58; semantic transformation changes population<br>t1&#58; semantic transformation changes species<br>t1&#58; semantic transformation changes intervention<br>t1&#58; semantic transformation changes endpoint<br>t1&#58; semantic transformation changes endpoint&#95;type<br>t1&#58; semantic transformation changes relation<br>t1&#58; semantic transformation changes follow&#95;up<br>t1&#58; semantic transformation changes certainty<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes follow&#95;up; t1&#58; semantic transformation changes certainty |
| record fingerprint | 5ab1783d0d3b8a20c6a0f29aaa6003fed973b43db25e1a9c3bb0e97ba8bf9345 |
| technical status | incomplete |
| transformation findings | t1&#58; semantic transformation changes population<br>t1&#58; semantic transformation changes species<br>t1&#58; semantic transformation changes intervention<br>t1&#58; semantic transformation changes endpoint<br>t1&#58; semantic transformation changes endpoint&#95;type<br>t1&#58; semantic transformation changes relation<br>t1&#58; semantic transformation changes follow&#95;up<br>t1&#58; semantic transformation changes certainty |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | e1 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | No supplied evidence supports the causal harm claim, and the only trial is short and does not directly address it.<br>Follow-up of four weeks does not match long-term use.<br>Liver-specific outcomes are not reported.<br>b1&#58; The four-week trial reports no serious adverse events. This does not address long-term liver damage, so it neither supports nor refutes the claim.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported scientific UNKNOWN retained; guards cannot resolve it |
|  / 1 / reported verdict | unknown |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | Not supplied |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | A definite causal harm claim is made with no supporting evidence in the supplied material. The only trial is short and reports no serious adverse events. No noncausal result is used as a basis and no mechanism is described, so the core error is overstatement and not correlation-to-causation or mechanism-to-outcome. |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | causes liver damage |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single-proposition extraction of the whole claim by the analyst from the task prompt. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | e1 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | No supplied evidence supports the causal harm claim, and the only trial is short and does not directly address it.<br>Follow-up of four weeks does not match long-term use.<br>Liver-specific outcomes are not reported.<br>b1&#58; The four-week trial reports no serious adverse events. This does not address long-term liver damage, so it neither supports nor refutes the claim.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported scientific UNKNOWN retained; guards cannot resolve it |
| derived judgment / reported verdict | unknown |
| material dimensions | population<br>intervention<br>endpoint<br>follow&#95;up |
| materiality | required |
| not applicable / comparator | The claim states no comparator. |
| observation target | Not supplied |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | No supplied evidence supports the causal harm claim, and the only trial is short and does not directly address it. |
| reported verdict | unknown |
| required bridge ids | No entries recorded |
| search question | Does the supplied material show that the supplement causes liver damage in long-term users? |
| search scope ids | ss1 |
| uncertainty | Follow-up of four weeks does not match long-term use.<br>Liver-specific outcomes are not reported. |

Quoted proposition; this is represented input, not a release assertion.

```
The supplement causes liver damage in long-term users.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 54 |
| start | 0 |
| text | The supplement causes liver damage in long-term users. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | definite |
| comparator | Not supplied |
| endpoint | liver damage |
| endpoint type | clinical |
| follow up | long-term |
| intervention | supplement |
| population | long-term users |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | partial |
|  / 1 / evidence id | e1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | The four-week trial reports no serious adverse events. This does not address long-term liver damage, so it neither supports nor refutes the claim. |
|  / 1 / search scope id | ss1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| asserted state | unknown |
| from and to text (identical) | The supplement causes liver damage in long-term users. |
| from attributes | No entries recorded |
| from proposition ids | claim&#58;p1 |
| reason | Verbatim extraction; the wording is unchanged. |
| stage | extraction |
| target id | claim&#58;p1 |
| to attributes / certainty | definite |
| to attributes / comparator | Not supplied |
| to attributes / endpoint | liver damage |
| to attributes / endpoint type | clinical |
| to attributes / follow up | long-term |
| to attributes / intervention | supplement |
| to attributes / population | long-term users |
| to attributes / relation | causal |
| to attributes / species | human |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| asserted state | unknown |
| from and to attributes (identical) / certainty | definite |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | The question form keeps the same proposition attributes. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the supplied material show that the supplement causes liver damage in long-term users? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | unknown |
| from and to attributes (identical) / certainty | definite |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | The internal finding keeps the proposition text and attributes and adds an unknown verdict summary. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | The supplement causes liver damage in long-term users.<br>Unknown&#58; no direct evidence for or against long-term liver damage in the supplied material. |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| asserted state | unknown |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | definite |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | liver damage |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | long-term |
| from and to attributes (identical) / intervention | supplement |
| from and to attributes (identical) / population | long-term users |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The supplement causes liver damage in long-term users. |
| reason | The client wording states that the claim is not established and does not assert support or refutation. |
| stage | summary |
| target id | c1 |
| to text | Not established&#58; the supplied material contains no evidence that the supplement causes liver damage in long-term users.<br>The only trial reported (60 participants, four weeks) found no serious adverse events, which shows neither long-term harm nor long-term safety. |
| transformation id | t4 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | serious adverse events |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | reported |
| attributes / comparator | Not supplied |
| attributes / endpoint | serious adverse events |
| attributes / endpoint type | clinical |
| attributes / follow up | four weeks |
| attributes / intervention | supplement |
| attributes / population | trial participants |
| attributes / relation | description |
| attributes / species | human |
| design limitations | Design details not reported.<br>Only four weeks of follow-up.<br>Small sample (60 participants). |
| evidence id | e1 |
| evidence type | unknown |
| randomized | Not supplied |
| source role | Context report of a short supplement trial. |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | ss1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A supplement trial in 60 participants over four weeks reports no serious adverse events. The label now states the product is 'completely safe' and 'proven to have no side effects', suitable for everyone including pregnant women and children.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The supplement causes liver damage in long-term users. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;directly&#95;established |
|  / 1 / confidence status | low |
|  / 1 / contrary evidence ids | e1 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | overclaim |
|  / 1 / proposition | The supplement causes liver damage in long-term users. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Unknown&#58; no direct evidence for or against long-term liver damage in the supplied material. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The only trial reported (60 participants, four weeks) found no serious adverse events, which shows neither long-term harm nor long-term safety. |
|  / 1 / client finding id | c1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;directly&#95;established |
|  / 1 / display claim | Not established&#58; the supplied material contains no evidence that the supplement causes liver damage in long-term users. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;7b2e6830c9a83b51b7dc3ee9/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 1ee32c43c198db4e9c48413905617f94681b8a941d1f89a81818516289a03540 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;7b2e6830c9a83b51b7dc3ee9

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 57f357e26869f9b60a5a88456dd6ab09c7cffc4d0f01dd3aac26c35a73d0502c |
| run id | 9955e4ba-ccbb-41e1-882d-c724fc12551a |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14696 |
| usage / output tokens | 6398 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |
| projected object fingerprint | 735c91653e8f2fba0d6c1b157e8322a5056213e550835c4dc0c3e11efedde550 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;15142322a6d49396dd366139 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | e1 |
| field | transformations.t1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |
| projected object fingerprint | 7f9e12ed82c69b70aaa9528b330271ebe00ceb7559c48662091da04259d99a25 |
| proposition ids | claim&#58;p1 |
| reason | t1&#58; semantic transformation changes certainty |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;c4fd6542ca5749571c5960ce |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |
| projected object fingerprint | a32148e88d83cf2efdccd8ebe4aedff75f985852ba75ec2e542e6c1a992430e8 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;d0937aa3fe199331a22a42a1 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |
| projected object fingerprint | ee172980f3da878882a0808cd2082acfa84a42e34fd051d42f92232ef50e19bf |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes follow&#95;up; t1&#58; semantic transformation changes certainty; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes follow&#95;up; t1&#58; semantic transformation changes certainty |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;ea91561444a7eb5b2d03fe6d |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |
| projected object fingerprint | 23209355bb8af35d3ac11b23052516aea0c5869be5c824b1ebb28693a6965057 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes follow&#95;up; t1&#58; semantic transformation changes certainty |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;f4e10c5e90de7b719f5f44dc |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; semantic transformation changes population; t1&#58; semantic transformation changes species; t1&#58; semantic transformation changes intervention; t1&#58; semantic transformation changes endpoint; t1&#58; semantic transformation changes endpoint&#95;type; t1&#58; semantic transformation changes relation; t1&#58; semantic transformation changes follow&#95;up; t1&#58; semantic transformation changes certainty |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 93b4a28b03cc784d2782d7b6f11b08025c841d1d1669698435abadaead9d3315 |
| case id | p9case&#58;f22a15056fcc6f1640468ae3 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 73fbac40e861a4d20b6c9a33ee693dcabd0abec27fb050b9aac0ba93f9a1a7d3 |
| execution evidence / 1 / attempt ids | attempt-011 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | 762e75c9492ca7761bdd87bd0a51cdbd9b58f675809b65b42590178a65c30852 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 93372 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 38495 |
| execution evidence / 1 / message id | msg&#95;011CfvgPHXeiB7Rnih3bbSJ4 |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvgPH29VMWjACJHxX7S3 |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 239738 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-05&#124;claude-sonnet-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14696 |
| execution evidence / 1 / usage / output tokens | 6398 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 5b28ec01e3c549c5ec4d7647a9d518c0bb5ea0b9b8154bece21dcb0faf03fffd |
| ledger fingerprint | e1d848c23384c8cd0742cd3765798ec255a16c5d4dae3a2f0f26e09291928e6c |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14696 |
| providers / 1 / usage / output tokens | 6398 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 1ee32c43c198db4e9c48413905617f94681b8a941d1f89a81818516289a03540 |
| run id | 9955e4ba-ccbb-41e1-882d-c724fc12551a |
| selected position id | p9position&#58;7b2e6830c9a83b51b7dc3ee9 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

