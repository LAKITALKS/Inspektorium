# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;56.543980+00&#58;00 |
| parent | Not supplied |
| record fingerprint | b3deca403bd727a4140d8bff157d94c5112729b676fd4f89effaca8cb7190a32 |
| revision | 67c86f15-bda7-4c3e-ae1c-c4022de27209 |
| selected position id | p9position&#58;401b973d21c8777108a16507 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-010 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | d29af906ae4516c193e0167f5ac48412ab22503ad9951001129dfb94aef59a7e |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 133374 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 59360 |
|  / 1 / message id | msg&#95;011CfvgJrCYKFKbnu9UzLtb8 |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvgJqLTFatWry6NNZQFW |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 240556 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-sonnet-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14807 |
|  / 1 / usage / output tokens | 10376 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
The virtual tutoring program improved struggling students' reading progress or reduced their school absenteeism.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 246cf9f13d09d7cdc83068f66b29e2050e3571e48998a839b807e29d8fba14ad |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | solid |
| raw response sha256 | eb4b90f44585041c6b6477be4bd7cb7cac2d033f5470f29b136f8ce4c053ab2a |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>t4&#58; semantic transformation changes population<br>t4&#58; semantic transformation changes species<br>t4&#58; semantic transformation changes intervention<br>t4&#58; semantic transformation changes endpoint<br>t4&#58; semantic transformation changes endpoint&#95;type<br>t4&#58; semantic transformation changes relation<br>t4&#58; semantic transformation changes effect&#95;direction<br>t4&#58; semantic transformation changes certainty<br>t7&#58; output state hides or changes unsupported<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t7&#58; output state hides or changes unsupported |
| record fingerprint | 02c5f6b293d2f3c98d374b08ac46921e756b50ad3289ccee563ba4bbb321e979 |
| technical status | incomplete |
| transformation findings | t4&#58; semantic transformation changes population<br>t4&#58; semantic transformation changes species<br>t4&#58; semantic transformation changes intervention<br>t4&#58; semantic transformation changes endpoint<br>t4&#58; semantic transformation changes endpoint&#95;type<br>t4&#58; semantic transformation changes relation<br>t4&#58; semantic transformation changes effect&#95;direction<br>t4&#58; semantic transformation changes certainty<br>t7&#58; output state hides or changes unsupported |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unsupported |
|  / 1 / evidence ids | E1 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | A randomized controlled trial reports a reading gain versus control.<br>b1&#58; A randomized comparison with a control condition reports additional reading progress.<br>within-arm change cannot establish a between-arm causal effect<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 1 / reported verdict | supported |
|  / 2 / dependency status | unknown |
|  / 2 / derived state | unknown |
|  / 2 / evidence ids | E2 |
|  / 2 / proposition id | claim&#58;p2 |
|  / 2 / reasons | The context reports no absenteeism data.<br>Absence of absenteeism evidence in the reviewed set does not show there was no effect.<br>b2&#58; The reviewed context describes the trial but reports no absenteeism outcome.<br>no evidence found does not prove absence or contradiction<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 2 / reported verdict | unsupported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | E1 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The causal claim is backed by randomized controlled evidence. No mechanism-to-outcome or correlation-to-causation error is present, and the reading branch is not overstated. |
| represented trigger analysis / trigger evidence id | E1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | improved struggling students&#x27; reading progress |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Manual extraction from the task prompt. The claim is split at &#x27;or&#x27; into two alternative branches. |
| logic / children / 1 / children | No entries recorded |
| logic / children / 1 / operator | leaf |
| logic / children / 1 / proposition id | claim&#58;p1 |
| logic / children / 2 / children | No entries recorded |
| logic / children / 2 / operator | leaf |
| logic / children / 2 / proposition id | claim&#58;p2 |
| logic / operator | or |
| logic / proposition id | Not supplied |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1<br>claim&#58;p2 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unsupported |
| derived judgment / evidence ids | E1 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | A randomized controlled trial reports a reading gain versus control.<br>b1&#58; A randomized comparison with a control condition reports additional reading progress.<br>within-arm change cannot establish a between-arm causal effect<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| material dimensions | endpoint<br>intervention |
| materiality | required |
| not applicable | No entries recorded |
| observation target | support |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | A randomized controlled trial reports a reading gain versus control. |
| reported verdict | supported |
| required bridge ids | No entries recorded |
| search question | Does the context show the virtual tutoring program improved struggling students&#x27; reading progress? |
| search scope ids | S1 |
| uncertainty | No entries recorded |

Quoted proposition; this is represented input, not a release assertion.

```
The virtual tutoring program improved struggling students' reading progress
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 75 |
| start | 0 |
| text | The virtual tutoring program improved struggling students&#x27; reading progress |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | control condition |
| effect direction | improvement |
| endpoint | reading progress |
| endpoint type | functional |
| follow up | ten-week sessions |
| intervention | virtual tutoring program |
| population | struggling elementary students |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | E1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | A randomized comparison with a control condition reports additional reading progress. |
|  / 1 / search scope id | S1 |

### Proposition claim&#58;p2

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | E2 |
| derived judgment / proposition id | claim&#58;p2 |
| derived judgment / reasons | The context reports no absenteeism data.<br>Absence of absenteeism evidence in the reviewed set does not show there was no effect.<br>b2&#58; The reviewed context describes the trial but reports no absenteeism outcome.<br>no evidence found does not prove absence or contradiction<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | unsupported |
| material dimensions | endpoint |
| materiality | required |
| not applicable / comparator | No comparator is stated for the absenteeism branch. |
| not applicable / follow up | No follow-up is stated for the absenteeism branch. |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p2 |
| provenance id | prov1 |
| reason | The context reports no absenteeism data. |
| reported verdict | unsupported |
| required bridge ids | No entries recorded |
| search question | Does the context show the virtual tutoring program reduced struggling students&#x27; school absenteeism? |
| search scope ids | S1 |
| uncertainty | Absence of absenteeism evidence in the reviewed set does not show there was no effect. |

Quoted proposition; this is represented input, not a release assertion.

```
The virtual tutoring program reduced struggling students' school absenteeism
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 111 |
| start | 79 |
| text | reduced their school absenteeism |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | Not supplied |
| effect direction | reduction |
| endpoint | school absenteeism |
| endpoint type | attendance |
| follow up | Not supplied |
| intervention | virtual tutoring program |
| population | struggling elementary students |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b2 |
|  / 1 / directness | unknown |
|  / 1 / evidence id | E2 |
|  / 1 / observation | no&#95;evidence&#95;found |
|  / 1 / proposition id | claim&#58;p2 |
|  / 1 / reason | The reviewed context describes the trial but reports no absenteeism outcome. |
|  / 1 / search scope id | S1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | control condition |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | functional |
| from and to attributes (identical) / follow up | ten-week sessions |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling elementary students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | The virtual tutoring program improved struggling students&#x27; reading progress |
| from proposition ids | claim&#58;p1 |
| reason | Unchanged extraction of the first branch. |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | control condition |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | functional |
| from and to attributes (identical) / follow up | ten-week sessions |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling elementary students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress |
| reason | The proposition is turned into a question with its meaning unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the context show the virtual tutoring program improved struggling students&#x27; reading progress? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | control condition |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | functional |
| from and to attributes (identical) / follow up | ten-week sessions |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling elementary students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | The virtual tutoring program improved struggling students&#x27; reading progress |
| from proposition ids | claim&#58;p1 |
| reason | The internal finding is unchanged. |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| from attributes | No entries recorded |
| from proposition ids | claim&#58;p2 |
| from text | reduced their school absenteeism |
| reason | The elliptical second branch is expanded to a full proposition. The subject and population are carried over from the first branch. |
| stage | extraction |
| target id | claim&#58;p2 |
| to attributes / certainty | asserted |
| to attributes / comparator | Not supplied |
| to attributes / effect direction | reduction |
| to attributes / endpoint | school absenteeism |
| to attributes / endpoint type | attendance |
| to attributes / follow up | Not supplied |
| to attributes / intervention | virtual tutoring program |
| to attributes / population | struggling elementary students |
| to attributes / relation | causal |
| to attributes / species | human |
| to text | The virtual tutoring program reduced struggling students&#x27; school absenteeism |
| transformation id | t4 |

### Transformation t5

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / effect direction | reduction |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / endpoint type | attendance |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling elementary students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p2 |
| from text | The virtual tutoring program reduced struggling students&#x27; school absenteeism |
| reason | The proposition is turned into a question with its meaning unchanged. |
| stage | search&#95;question |
| target id | claim&#58;p2 |
| to text | Does the context show the virtual tutoring program reduced struggling students&#x27; school absenteeism? |
| transformation id | t5 |

### Transformation t6

| Field | Recorded value |
| --- | --- |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / effect direction | reduction |
| from and to attributes (identical) / endpoint | school absenteeism |
| from and to attributes (identical) / endpoint type | attendance |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling elementary students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | The virtual tutoring program reduced struggling students&#x27; school absenteeism |
| from proposition ids | claim&#58;p2 |
| reason | The internal finding is unchanged. |
| stage | internal |
| target id | claim&#58;p2 |
| transformation id | t6 |

### Transformation t7

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | control condition |
| from and to attributes (identical) / effect direction | improvement |
| from and to attributes (identical) / endpoint | reading progress |
| from and to attributes (identical) / endpoint type | functional |
| from and to attributes (identical) / follow up | ten-week sessions |
| from and to attributes (identical) / intervention | virtual tutoring program |
| from and to attributes (identical) / population | struggling elementary students |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | The virtual tutoring program improved struggling students&#x27; reading progress |
| reason | The summary asserts only the supported reading-progress branch. It does not claim the absenteeism branch. |
| stage | summary |
| target id | cf1 |
| to text | The virtual tutoring program improved struggling students&#x27; reading progress.<br>In the randomized trial, students completing around forty sessions gained roughly two additional months of reading progress versus control. |
| transformation id | t7 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence E1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | reading progress |
| evidence id | E1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / comparator | control condition |
| attributes / effect direction | improvement |
| attributes / endpoint | reading progress |
| attributes / endpoint type | functional |
| attributes / follow up | ten-week sessions |
| attributes / intervention | virtual tutoring program |
| attributes / population | struggling elementary students |
| attributes / relation | causal |
| attributes / species | human |
| design limitations | No entries recorded |
| evidence id | E1 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| randomized | true |
| source role | randomized trial result on reading progress |
| underlying evidence ids | No entries recorded |

### Evidence E2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | school absenteeism |
| evidence id | E2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized controlled trial tested a virtual reading tutoring program in a rural school district.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / intervention | virtual tutoring program |
| attributes / population | struggling elementary students |
| attributes / species | human |
| design limitations | No absenteeism outcome is reported. |
| evidence id | E2 |
| evidence type | controlled&#95;intervention |
| identification argument | Not supplied |
| identification evidence ids | No entries recorded |
| randomized | true |
| source role | trial description with no absenteeism outcome reported |
| underlying evidence ids | No entries recorded |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | S1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg1 |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p2 |
|  / 1 / proposition | The virtual tutoring program reduced struggling students&#x27; school absenteeism |
|  / 1 / search scope id | S1 |
|  / 1 / source local evidence ids | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized controlled trial tested a virtual reading tutoring program in a rural school district. The program paired live online tutors with small groups of struggling elementary students for ten-week sessions. Students who completed around forty tutoring sessions gained roughly two additional months of reading progress compared with peers in the control condition. Even those attending fewer sessions showed modest gains. Researchers emphasised that consistent participation was critical and highlighted that the program delivered results at a lower cost than typical high-dose tutoring.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | The virtual tutoring program improved struggling students&#x27; reading progress or reduced their school absenteeism. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | The virtual tutoring program improved struggling students&#x27; reading progress |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | E1 |
|  / 1 / verdict summary |  |
|  / 2 / allowed summary strength | not&#95;assessed |
|  / 2 / confidence status |  |
|  / 2 / contrary evidence ids | No entries recorded |
|  / 2 / finding id | claim&#58;p2 |
|  / 2 / predicted label | Not supplied |
|  / 2 / proposition | The virtual tutoring program reduced struggling students&#x27; school absenteeism |
|  / 2 / provenance id | prov1 |
|  / 2 / supporting evidence ids | E2 |
|  / 2 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | In the randomized trial, students completing around forty sessions gained roughly two additional months of reading progress versus control. |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | The virtual tutoring program improved struggling students&#x27; reading progress. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | E1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;401b973d21c8777108a16507/claim&#58;p2&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | f02436593034a1a748851da7bd63ae1ecdee389430809acff6e52a3e103e1dda |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;401b973d21c8777108a16507

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | solid |
| position id | p9position&#58;401b973d21c8777108a16507 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | eb4b90f44585041c6b6477be4bd7cb7cac2d033f5470f29b136f8ce4c053ab2a |
| run id | 0bc3a77a-dc1f-4e85-866b-66e6f2df5d7f |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14807 |
| usage / output tokens | 10376 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;401b973d21c8777108a16507 |
| projected object fingerprint | f5018b6be536196f43940b75a89213896afbfe8b6f9497d0396ef813df9d8525 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t7&#58; output state hides or changes unsupported |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;2ace6877fb02244255129934 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | E2 |
| field | transformations.t4 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;401b973d21c8777108a16507 |
| projected object fingerprint | ab3a1a72bfb4bd9b5a44f7106cddbd913ad68bb1f5ebea66396df22ddaab1fcf |
| proposition ids | claim&#58;p2 |
| reason | t4&#58; semantic transformation changes certainty |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;3f9c9ac8c380ad85bab9aa4c |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;401b973d21c8777108a16507 |
| projected object fingerprint | 50106c6559b87bc4b9c73fd95d88f2777b1885efcab6fa99dca68a55426cef68 |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t7&#58; output state hides or changes unsupported; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t7&#58; output state hides or changes unsupported |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;5090e076a3fdabd71da9362f |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | E1 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;401b973d21c8777108a16507 |
| projected object fingerprint | f6f07ef723e9098d9aedb464588ecc96fa8b8dfff922a90597a448a4bd63664a |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;7afce529d97cf19fc64ce9ba |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | E2 |
| field | propositions.claim&#58;p2.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;401b973d21c8777108a16507 |
| projected object fingerprint | b0291948988f7f6fc9c4977408b8ffe8916f4b60cb74b268a1efebf1f578ad49 |
| proposition ids | claim&#58;p2 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;82145fba9e406cafef1dafab |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | E1 |
| field | transformations.t7 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;401b973d21c8777108a16507 |
| projected object fingerprint | a1994341df6fc5c5a3641f68fd739686bf2135342b28eac9fb48c6e7980a5763 |
| proposition ids | claim&#58;p1 |
| reason | t7&#58; output state hides or changes unsupported |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;add45110a9011168af783083 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t4&#58; semantic transformation changes population; t4&#58; semantic transformation changes species; t4&#58; semantic transformation changes intervention; t4&#58; semantic transformation changes endpoint; t4&#58; semantic transformation changes endpoint&#95;type; t4&#58; semantic transformation changes relation; t4&#58; semantic transformation changes effect&#95;direction; t4&#58; semantic transformation changes certainty; t7&#58; output state hides or changes unsupported |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 083864242f8f5d627bddb44c97dd3cfd24b9e12e34dfb50c434397b8ae99abab |
| case id | p9case&#58;2ae364a84d1130822f50bbd0 |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 81049dc4662e4f35ae889a17f3b86169408cb222234b9f76fff4466341f92795 |
| execution evidence / 1 / attempt ids | attempt-010 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | d29af906ae4516c193e0167f5ac48412ab22503ad9951001129dfb94aef59a7e |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 133374 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 59360 |
| execution evidence / 1 / message id | msg&#95;011CfvgJrCYKFKbnu9UzLtb8 |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvgJqLTFatWry6NNZQFW |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 240556 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-04&#124;claude-sonnet-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14807 |
| execution evidence / 1 / usage / output tokens | 10376 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 77c95aed75c1d8563c7cf5f03b5c1a0345cdd58b50d13563d519cc2dd49284bb |
| ledger fingerprint | 59f93e315813b4dd7f90feca59bf9c4e3f86877464ff6855acf3b5d971404f7d |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14807 |
| providers / 1 / usage / output tokens | 10376 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | f02436593034a1a748851da7bd63ae1ecdee389430809acff6e52a3e103e1dda |
| run id | 0bc3a77a-dc1f-4e85-866b-66e6f2df5d7f |
| selected position id | p9position&#58;401b973d21c8777108a16507 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

