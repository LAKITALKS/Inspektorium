# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-11T15&#58;26&#58;54.890197+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 545c89b98214a95ac9dc00b8e40dc482c487af8d220b77201c7b46c890189704 |
| revision | 048cd615-5d9f-45f9-8fed-82e1aabc66f2 |
| selected position id | p9position&#58;4d8510c925389135d1c03694 |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-008 |
|  / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | de8d59f33fbe72cfe3cf91840916e9c19c652fcb1d31832877e2a450fc6207dc |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 92454 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 35900 |
|  / 1 / message id | msg&#95;011CfvgBcFCyW4tQvao2XZE6 |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;2 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfvgBbxLGCDxpHC9e6gFz |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 239816 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-sonnet-5-5&#64;2&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14722 |
|  / 1 / usage / output tokens | 6301 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
Compound X treats cancer in patients.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.0 |
| derived label | Not supplied |
| input sha256 | 112163c5e3b414878531e3c67842192acd46632c8d8f17f708205804341958e8 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| original model label | overclaim |
| raw response sha256 | f5e8746bb81d295d1a289ead0c77ac6224e97a4e840e3fc170b909d3c27e427f |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0<br>t1&#58; output state hides or changes unknown<br>t2&#58; output state hides or changes unknown<br>t3&#58; output state hides or changes unknown<br>t4&#58; output state hides or changes unknown<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; output state hides or changes unknown; t2&#58; output state hides or changes unknown; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
| record fingerprint | 4e92a4f3c0029be10fff9a8019a634bc7ee2eecdde21e559a799cce2ae94eeff |
| technical status | incomplete |
| transformation findings | t1&#58; output state hides or changes unknown<br>t2&#58; output state hides or changes unknown<br>t3&#58; output state hides or changes unknown<br>t4&#58; output state hides or changes unknown |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | E1<br>E2 |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | The claim concerns treatment in patients, but the only evidence is in vitro.<br>Only the supplied press summary was reviewed.<br>b1&#58; Cell-culture killing is a preclinical result and does not show treatment of cancer in patients.<br>preserved observation&#58; inconclusive<br>b2&#58; The supplied context states that no animal or human data are described.<br>no evidence found does not prove absence or contradiction<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
|  / 1 / reported verdict | unsupported |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | overclaim |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | overstatement |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | E1<br>E2 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | An in vitro cytotoxicity result is stated as treatment of cancer in patients. No biological mechanism is described, and no uncontrolled human data are used for a causal inference. The core error is overstatement of preclinical scope. |
| represented trigger analysis / trigger evidence id | E1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | killed up to 90% of cultured human tumour cells in a petri dish within 48 hours |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single proposition extracted verbatim from the task prompt. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov1 |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | E1<br>E2 |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | The claim concerns treatment in patients, but the only evidence is in vitro.<br>Only the supplied press summary was reviewed.<br>b1&#58; Cell-culture killing is a preclinical result and does not show treatment of cancer in patients.<br>preserved observation&#58; inconclusive<br>b2&#58; The supplied context states that no animal or human data are described.<br>no evidence found does not prove absence or contradiction<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>reported and evidence-derived scientific interpretations conflict |
| derived judgment / reported verdict | unsupported |
| material dimensions | population<br>species<br>intervention<br>endpoint<br>endpoint&#95;type |
| materiality | required |
| not applicable / comparator | No comparator is stated in the claim. |
| not applicable / follow up | No follow-up is stated in the claim. |
| observation target | no&#95;evidence&#95;found |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov1 |
| reason | The claim concerns treatment in patients, but the only evidence is in vitro. |
| reported verdict | unsupported |
| required bridge ids | No entries recorded |
| search question | Is there evidence in the supplied material that Compound X treats cancer in patients? |
| search scope ids | scope1 |
| uncertainty | Only the supplied press summary was reviewed. |

Quoted proposition; this is represented input, not a release assertion.

```
Compound X treats cancer in patients.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 37 |
| start | 0 |
| text | Compound X treats cancer in patients. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | stated as fact |
| comparator | Not supplied |
| endpoint | cancer treatment |
| endpoint type | clinical |
| follow up | Not supplied |
| intervention | Compound X |
| population | patients |
| relation | therapeutic |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | remote |
|  / 1 / evidence id | E1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Cell-culture killing is a preclinical result and does not show treatment of cancer in patients. |
|  / 1 / search scope id | scope1 |
|  / 2 / binding id | b2 |
|  / 2 / directness | direct |
|  / 2 / evidence id | E2 |
|  / 2 / observation | no&#95;evidence&#95;found |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | The supplied context states that no animal or human data are described. |
|  / 2 / search scope id | scope1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation t1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | stated as fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | therapeutic |
| from and to attributes (identical) / species | human |
| from and to text (identical) | Compound X treats cancer in patients. |
| from proposition ids | claim&#58;p1 |
| reason | Unchanged&#58; the proposition is the whole claim. |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | t1 |

### Transformation t2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | stated as fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | therapeutic |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | The question keeps the same population, endpoint and relation; only the form changes. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Is there evidence in the supplied material that Compound X treats cancer in patients? |
| transformation id | t2 |

### Transformation t3

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | stated as fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | therapeutic |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | The internal finding keeps the proposition and adds an unsupported verdict. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | Compound X treats cancer in patients.<br>Unsupported&#58; only in vitro cell-kill evidence; no animal or human data described. |
| transformation id | t3 |

### Transformation t4

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | stated as fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | cancer treatment |
| from and to attributes (identical) / endpoint type | clinical |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | Compound X |
| from and to attributes (identical) / population | patients |
| from and to attributes (identical) / relation | therapeutic |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | Compound X treats cancer in patients. |
| reason | The client wording reports the claim as unsupported and does not strengthen it. |
| stage | summary |
| target id | cf1 |
| to text | Compound X treating cancer in patients is not supported by the supplied evidence.<br>The supplied material reports only cell-culture killing of tumour cells and describes no animal or human data. |
| transformation id | t4 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence E1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | cultured tumour cell kill |
| evidence id | E1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
killed up to 90% of cultured human tumour cells in a petri dish within 48 hours
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | tumour cell kill in vitro |
| attributes / endpoint type | in&#95;vitro&#95;cell&#95;viability |
| attributes / intervention | Compound X |
| attributes / population | cultured human tumour cells |
| attributes / relation | description |
| attributes / species | human |
| design limitations | petri dish only<br>no animal or human data |
| evidence id | E1 |
| evidence type | in&#95;vitro |
| randomized | Not supplied |
| source role | press summary of cell-culture result |

### Evidence E2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | clinical outcome |
| evidence id | E2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
No animal or human data are described.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / relation | description |
| evidence id | E2 |
| evidence type | descriptive |
| randomized | Not supplied |
| source role | statement of missing animal and human data |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | reviewed supplied material only |
|  / 1 / search scope id | scope1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
|  / 1 / assertion id | neg1 |
|  / 1 / assertion scope | reviewed&#95;set |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / proposition | Compound X treats cancer in patients. |
|  / 1 / search scope id | scope1 |
|  / 1 / source local evidence ids | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A press summary reports that Compound X, a plant-derived molecule, killed up to 90% of cultured human tumour cells in a petri dish within 48 hours. The write-up concludes that Compound X 'treats cancer' and could become a natural alternative to chemotherapy. No animal or human data are described.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | Compound X treats cancer in patients. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;supported |
|  / 1 / confidence status | reviewed&#95;set |
|  / 1 / contrary evidence ids | E1<br>E2 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | overclaim |
|  / 1 / proposition | Compound X treats cancer in patients. |
|  / 1 / provenance id | prov1 |
|  / 1 / supporting evidence ids | No entries recorded |
|  / 1 / verdict summary | Unsupported&#58; only in vitro cell-kill evidence; no animal or human data described. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | The supplied material reports only cell-culture killing of tumour cells and describes no animal or human data. |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;supported |
|  / 1 / display claim | Compound X treating cancer in patients is not supported by the supplied evidence. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov1 |
|  / 1 / referenced evidence ids | E1<br>E2 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| contract version | AA-P9/1.0 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | p9position&#58;4d8510c925389135d1c03694/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | ba2381be74a1b25303fe00aa5c3e28590276280c5cfc4331f18eaecab4cfe9a4 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;4d8510c925389135d1c03694

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | overclaim |
| position id | p9position&#58;4d8510c925389135d1c03694 |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | f5e8746bb81d295d1a289ead0c77ac6224e97a4e840e3fc170b909d3c27e427f |
| run id | 29430a8a-a688-48a7-99b4-6c0ce5ab5029 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14722 |
| usage / output tokens | 6301 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | E1<br>E2 |
| field | transformations.t4 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | 961496858d0c8d1424a6a663a0433fb2c8de8a9f168e389b1fa9f824e3371b14 |
| proposition ids | claim&#58;p1 |
| reason | t4&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;3491196681dc96d04a55c805 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | E1<br>E2 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | 21355b92d430e222e74fa1314713c5c3d37f532421e30ad5a294b40806f8896c |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;377b7a441781406010cb92e7 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | E1<br>E2 |
| field | transformations.t1 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | 0760a8a648c8f6db5648763c23b2ee1bcbb531b6159633781839a11941cc3fd6 |
| proposition ids | claim&#58;p1 |
| reason | t1&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;464b0c855dd89fc43ce9b8d1 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | E1<br>E2 |
| field | transformations.t3 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | 333c913fcd6b8204a50a2e6e565fc7b9dc96484be0c5e1e1ccd46820ee3db908 |
| proposition ids | claim&#58;p1 |
| reason | t3&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;9cc3e68d408b1892f6fb2bcc |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | 52f4157f8072d798a10ab7327d77ce691f955ba874d8b1c9fe11e07bcbba0f5a |
| proposition ids | No entries recorded |
| reason | Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; output state hides or changes unknown; t2&#58; output state hides or changes unknown; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; output state hides or changes unknown; t2&#58; output state hides or changes unknown; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;a69a1202c924a265a4243d63 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | E1<br>E2 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | e206de6e067e26f9de93c18df1b73bfa79c0b7bfab74b3dd590a16173964ccc4 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;aecfad497501263c7b1a3e89 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | 45262458d7f0af5bbac395df2cc1d548fa435b12b805c6806a3c6f688987a8bc |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; output state hides or changes unknown; t2&#58; output state hides or changes unknown; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/6 |
| trigger id | p9trigger&#58;ec87693baead642ff40e9ad8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| claim id | claim |
| code | material&#95;transformation |
| evidence ids | E1<br>E2 |
| field | transformations.t2 |
| mandatory | true |
| material | true |
| position ids | p9position&#58;4d8510c925389135d1c03694 |
| projected object fingerprint | baa38f852a654f3ba25350fd6ab175d95014408fddf06e16263fe4dc7383764b |
| proposition ids | claim&#58;p1 |
| reason | t2&#58; output state hides or changes unknown |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/7 |
| trigger id | p9trigger&#58;fbc88ca949170724284f426e |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 2<br>Evaluated&#58; 2<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; Ledger, evidence constraints and transformations evaluated under AA-P8/1.0; t1&#58; output state hides or changes unknown; t2&#58; output state hides or changes unknown; t3&#58; output state hides or changes unknown; t4&#58; output state hides or changes unknown |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 6c6b5a9938919a49da79743b8dab10edbeb20c865aa5e71ce5ed0345987de533 |
| case id | p9case&#58;5b7e3045bb4f24684465144a |
| code / code fingerprint | 4d6c1711e61ea66d2cce6906b106a7bd82b90d1388f4b1eb25fc6616077f8aa3 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 6142dcd92d6399a74ad0174ad0cd2cc96cef45db |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | a24446ac0d56a23fa421873207eee1a235f3956de0f27ebd3bc8adbc499c5a02 |
| execution evidence / 1 / attempt ids | attempt-008 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-SMOKE-20261011-003 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | de8d59f33fbe72cfe3cf91840916e9c19c652fcb1d31832877e2a450fc6207dc |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 92454 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 35900 |
| execution evidence / 1 / message id | msg&#95;011CfvgBcFCyW4tQvao2XZE6 |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;2 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfvgBbxLGCDxpHC9e6gFz |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 239816 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-smoke-LS-02&#124;claude-sonnet-5-5&#64;2&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14722 |
| execution evidence / 1 / usage / output tokens | 6301 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 4c7ea357ae5bc4fc582048c362f5bdffabeb031cf56306a5f1c0587bc8aaaad4 |
| ledger fingerprint | ce2ee94d1ff042ba21edac067c7be72b59ee7889f816f11fe71076c6d890db45 |
| package version | 0.1.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | overclaim |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14722 |
| providers / 1 / usage / output tokens | 6301 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | ba2381be74a1b25303fe00aa5c3e28590276280c5cfc4331f18eaecab4cfe9a4 |
| run id | 29430a8a-a688-48a7-99b4-6c0ce5ab5029 |
| selected position id | p9position&#58;4d8510c925389135d1c03694 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

