# Canonical local audit

## Execution and release

REVIEW&#95;REQUIRED — local artifact status

RECORDED OFFLINE / SYNTHETIC. Local artifact decision only; no live model execution, scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | completed |
| host evidence derivation (composite) | supported |
| local release | REVIEW&#95;REQUIRED |
| mandatory review | true |
| model judgment (composite) | supported |
| model/host conflicts | selected judgment&#58; 1 open; mandatory review pending, release blocked |
| review execution | not&#95;executed |
| review route | REVIEW&#95;RECOMMENDED |
| scientific judgment | supported |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-13T08&#58;04&#58;41.710943+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 3c11bde2e71fa77511702e1253b2a81a9f2ebdae93e48282a3c5e82b356ee94e |
| revision | 37898bac-c5a3-4a0b-a646-1b3987232ac5 |
| selected position id | p9position&#58;1365df207ad4a1fe61d897b5 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
intervention X reduces event Q in adults.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | supported |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | supported |
| contract version | AA-P8/1.2 |
| derived label | solid |
| host composite state | supported |
| host derived copies | No entries recorded |
| host rule version | AA-P8-HOST/1.1 |
| input sha256 | d405ae6768246618b95a4d04eedcd9b6222fd78b607a902ace3a2e9ef0bebc71 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| model composite state | supported |
| model host conflicts / 1 / host rule version | AA-P8-HOST/1.1 |
| model host conflicts / 1 / host state | unknown |
| model host conflicts / 1 / model state | supported |
| model host conflicts / 1 / proposition id | claim&#58;optional |
| model host conflicts / 1 / reason | Model judgment and host evidence derivation differ; mandatory review decides, not either side |
| model host conflicts / 1 / required | false |
| model host conflicts / 1 / scope | proposition |
| original model label | solid |
| raw response sha256 | a2ea1b1ec5a2bb22ef470a3ae27fd55e8dedba5e2f14e7757b2e95a047170240 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.2 (AA-P8-HOST/1.1)<br>1 open model/host conflict(s); effective state unknown where they occur |
| record fingerprint | d23d4cd673b2422294f1dacb50742f9ecd406daddf07c04e3c75ee59d9a379b4 |
| technical status | completed |
| transformation findings | No entries recorded |

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | single&#95;source |
|  / 1 / derived state | supported |
|  / 1 / evidence ids | e1 |
|  / 1 / host reasons | binding 1&#58; identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
|  / 1 / host state | supported |
|  / 1 / model host conflict | false |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
|  / 1 / reported verdict | supported |
|  / 1 / required | true |
|  / 2 / dependency status | single&#95;source |
|  / 2 / derived state | unknown |
|  / 2 / evidence ids | e1 |
|  / 2 / host reasons | binding 1&#58; preserved observation&#58; inconclusive<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
|  / 2 / host state | unknown |
|  / 2 / model host conflict | true |
|  / 2 / proposition id | claim&#58;optional |
|  / 2 / reasons | Source reports the stated comparison<br>Optional contextual interpretation remains unresolved.<br>b-opt&#58; SYNTHETIC TEST FIXTURE binding<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred<br>model judgment supported differs from host evidence derivation unknown (AA-P8-HOST/1.1); open conflict, effective state unknown until a mandatory review resolves it |
|  / 2 / reported verdict | supported |
|  / 2 / required | false |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | solid |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | Generic represented core-error analysis |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks. |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | solid |
| taxonomy check / reasons | Honest reporting with supported represented propositions |
| taxonomy check / technical status | completed |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | offline extraction from supplied prompt and context |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | origin |
| required proposition ids | claim&#58;p1 |

### Proposition claim&#58;p1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | single&#95;source |
| derived judgment / derived state | supported |
| derived judgment / evidence ids | e1 |
| derived judgment / host reasons | binding 1&#58; identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| derived judgment / host state | supported |
| derived judgment / model host conflict | false |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| derived judgment / required | true |
| material dimensions | species<br>population<br>intervention<br>comparator<br>endpoint<br>endpoint&#95;type<br>relation<br>follow&#95;up<br>certainty<br>comparison |
| materiality | required |
| parent claim id | claim |
| premise proposition ids | claim&#58;optional |
| proposition id | claim&#58;p1 |
| provenance id | origin |
| reason | Source reports the stated comparison |
| reported verdict | supported |
| search question | What evidence supports&#58; intervention X reduces event Q in adults. |
| search scope ids | review |

Quoted proposition; this is represented input, not a release assertion.

```
intervention X reduces event Q in adults.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 41 |
| start | 0 |
| text | intervention X reduces event Q in adults. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | placebo |
| comparison | between |
| endpoint | event Q |
| endpoint type | clinical&#95;event |
| follow up | 12 weeks |
| intervention | intervention X |
| population | adults |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Matching trial |

### Proposition claim&#58;optional

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | single&#95;source |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | e1 |
| derived judgment / host reasons | binding 1&#58; preserved observation&#58; inconclusive<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| derived judgment / host state | unknown |
| derived judgment / model host conflict | true |
| derived judgment / proposition id | claim&#58;optional |
| derived judgment / reasons | Source reports the stated comparison<br>Optional contextual interpretation remains unresolved.<br>b-opt&#58; SYNTHETIC TEST FIXTURE binding<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred<br>model judgment supported differs from host evidence derivation unknown (AA-P8-HOST/1.1); open conflict, effective state unknown until a mandatory review resolves it |
| derived judgment / reported verdict | supported |
| derived judgment / required | false |
| material dimensions | species<br>population<br>intervention<br>comparator<br>endpoint<br>endpoint&#95;type<br>relation<br>follow&#95;up<br>certainty<br>comparison |
| materiality | optional |
| parent claim id | claim |
| proposition id | claim&#58;optional |
| provenance id | origin |
| reason | Source reports the stated comparison |
| reported verdict | supported |
| search question | What evidence supports&#58; intervention X reduces event Q in adults. |
| search scope ids | review |
| uncertainty | Optional contextual interpretation remains unresolved. |

Quoted proposition; this is represented input, not a release assertion.

```
intervention X reduces event Q in adults.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 41 |
| start | 0 |
| text | intervention X reduces event Q in adults. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | placebo |
| comparison | between |
| endpoint | event Q |
| endpoint type | clinical&#95;event |
| follow up | 12 weeks |
| intervention | intervention X |
| population | adults |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b-opt |
|  / 1 / directness | partial |
|  / 1 / evidence id | e1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;optional |
|  / 1 / reason | SYNTHETIC TEST FIXTURE binding |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation extraction

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | extraction |

### Transformation search&#95;question

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | intervention X reduces event Q in adults. |
| reason | Meaning retained |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | What evidence supports&#58; intervention X reduces event Q in adults. |
| transformation id | search&#95;question |

### Transformation internal

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | internal |

### Transformation summary

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | summary |
| target id | client1 |
| transformation id | summary |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence e1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | event Q |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | asserted |
| attributes / comparator | placebo |
| attributes / comparison | between |
| attributes / endpoint | event Q |
| attributes / endpoint type | clinical&#95;event |
| attributes / follow up | 12 weeks |
| attributes / intervention | intervention X |
| attributes / population | adults |
| attributes / relation | causal |
| attributes / species | human |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| randomized | true |
| source role | primary&#95;study |
| study id | synthetic-study-1 |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | review |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | intervention X reduces event Q in adults. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | origin |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | intervention X reduces event Q in adults. |
|  / 1 / provenance id | origin |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | client1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | intervention X reduces event Q in adults. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | origin |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| contract version | AA-P9/1.2 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | REVIEW&#95;RECOMMENDED |
| technical status | completed |
| uncertainty | p9position&#58;1365df207ad4a1fe61d897b5/claim&#58;optional&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | e678ad2e39807c65cd69f23464a72b5cdee09f0992a3fa909ba4261942bcf218 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | REVIEW&#95;RECOMMENDED |
| source reference | record.json&#35;/run&#95;record |
| technical status | completed |

### Position p9position&#58;1365df207ad4a1fe61d897b5

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | solid |
| model | offline-recording-no-live-model |
| origin | original |
| original model label | solid |
| position id | p9position&#58;1365df207ad4a1fe61d897b5 |
| provider | offline-recording-no-live-model |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | a2ea1b1ec5a2bb22ef470a3ae27fd55e8dedba5e2f14e7757b2e95a047170240 |
| run id | 116e7a95-188c-4aac-9aec-e5b33ae79a8c |
| scientific state | supported |
| selected | true |
| taxonomy status | completed |
| technical status | completed |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | model&#95;host&#95;conflict |
| evidence ids | e1 |
| field | propositions.claim&#58;optional.model&#95;host&#95;conflict |
| mandatory | true |
| material | true |
| position ids | p9position&#58;1365df207ad4a1fe61d897b5 |
| projected object fingerprint | 291ef0d98dd0a6f9e52931423ae34e7530d8fa5c90cdd6b407fd44677620e222 |
| proposition ids | claim&#58;optional |
| reason | Model judgment supported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;4c830881eb6a6d733a4ff20c |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1 |
| field | propositions.claim&#58;optional.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;1365df207ad4a1fe61d897b5 |
| projected object fingerprint | 9780d44a4c62d5f43bad99cf71fd50cad5af7c3edcc5a3e7028332d5e632b57b |
| proposition ids | claim&#58;optional |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;d28d4c4564a7d3b514b5f9e9 |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.1 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.2 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.2 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and offline configuration bound |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 419b6c15bb17c2bf0a2933ca9e83c7971c2ac1211ff322b210538f23ba12e160 |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| code / code fingerprint | a1654da6afd6991665f2e4d25824c4e21fc152d69eddef01fe9a9cacf64eb80d |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | installed bytes only; no verified tracked-source claim |
| code / verified source commit | Not supplied |
| config | offline-recording-v1 |
| contract | AA-P10/1.0 |
| evidence fingerprint | cea4af84c8fff4b5d9a8b2b09054e1cfe5ed96a978fae1752f5027d2f1dfea08 |
| input fingerprint | 3ed6c37cef5b16e6a8cd1e2a61f4133a4bc14a2777c9492cd85cbfa124b206d8 |
| ledger fingerprint | 2e7009c946562b82768be0d2785d38fa962a723c5899ce544148efbf1f4b034f |
| package version | 1.0.0 |
| phase8 summary / composite state | supported |
| phase8 summary / derived label | solid |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | completed |
| phase8 summary / technical status | completed |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | REVIEW&#95;RECOMMENDED |
| phase9 summary / technical status | completed |
| providers / 1 / model | offline-recording-no-live-model |
| providers / 1 / provider | offline-recording-no-live-model |
| providers / 1 / usage | Not supplied |
| recording notice | RECORDED OFFLINE / SYNTHETIC; no live model execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | e678ad2e39807c65cd69f23464a72b5cdee09f0992a3fa909ba4261942bcf218 |
| run id | 116e7a95-188c-4aac-9aec-e5b33ae79a8c |
| selected position id | p9position&#58;1365df207ad4a1fe61d897b5 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

