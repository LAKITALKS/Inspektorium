# Canonical local audit

## Execution and release

REVIEW&#95;REQUIRED — local artifact status

Automatic processing has ended. The result is not conclusively resolved and is not scientifically released. No human reviewer or review queue is assumed. This revision is immutable&#58; only a recorded human decision (agent-arena audit review) or a new, explicitly commissioned run creates a new revision.

OFFLINE REPLAY OF EARLIER LIVE MODEL OUTPUT (AA-P10-LIVE/1.0). This execution made no new model call; the original live origin is bound below and in record.json. Local artifact decision only; no scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | completed |
| automatic processing | ended |
| host evidence derivation (composite) | unknown |
| local release | REVIEW&#95;REQUIRED |
| mandatory review | true |
| model judgment (composite) | unsupported |
| model/host conflicts | selected judgment&#58; 2 open; mandatory review executed, conflict still open, release blocked; other positions&#58; 4 (open; see review route) |
| open cause | automatic reviews executed (counterreview completed; stability completed); the material conflict or UNKNOWN remains open |
| review execution | completed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-13T08&#58;01&#58;08.834846+00&#58;00 |
| parent | Not supplied |
| record fingerprint | a30d138a7f7fb5172b3f1405922fcb1dc85580a633ae5d227ffa90f54fcc32ae |
| revision | d1f6411d-b913-46c5-8195-b765f0a10f51 |
| selected position id | p9position&#58;6c94d19b6c08bda5b38f696f |

### Execution provenance per carrier

| Field | Recorded value |
| --- | --- |
|  / 1 / attempt ids | attempt-004 |
|  / 1 / authorization id | AA-P10-LIVE-RETEST-20261011-004 |
|  / 1 / billing | usage&#95;reported |
|  / 1 / capture sha256 | b01f10a117838692c3f8b6d39dd2b2a6dfc1a0dc6e64189767c06ac1e28680f2 |
|  / 1 / completion state | complete |
|  / 1 / confirmed cost microusd | 113148 |
|  / 1 / current execution | offline&#95;replay |
|  / 1 / denial reason | Not supplied |
|  / 1 / latency ms | 49127 |
|  / 1 / message id | msg&#95;011CfxZHYP9RVwrwWjSdAob5 |
|  / 1 / model | claude-sonnet-5-5 |
|  / 1 / origin | live&#95;generation |
|  / 1 / profile id | claude-sonnet-5-5&#64;3 |
|  / 1 / provider | anthropic-live-replay |
|  / 1 / replay capture verified | true |
|  / 1 / replay request identical | true |
|  / 1 / request id | req&#95;011CfxZHY8mDZhGVkTCkiWDU |
|  / 1 / requested model | claude-sonnet-5-5 |
|  / 1 / reserved microusd | 241756 |
|  / 1 / retry denied | Not supplied |
|  / 1 / returned model | claude-sonnet-5-5 |
|  / 1 / role | primary |
|  / 1 / slot key | aa-p10-live-retest-LR-03&#124;claude-sonnet-5-5&#64;3&#124;primary |
|  / 1 / stop reason | end&#95;turn |
|  / 1 / usage / cache creation input tokens | 0 |
|  / 1 / usage / cache read input tokens | 0 |
|  / 1 / usage / input tokens | 14984 |
|  / 1 / usage / output tokens | 8318 |
|  / 2 / attempt ids | attempt-005 |
|  / 2 / authorization id | AA-P10-LIVE-RETEST-20261011-004 |
|  / 2 / billing | usage&#95;reported |
|  / 2 / capture sha256 | 202af910bd11afc8dceb009edea5367bf513923a18eb83cfe8c6dd8d408848b1 |
|  / 2 / completion state | complete |
|  / 2 / confirmed cost microusd | 104884 |
|  / 2 / current execution | offline&#95;replay |
|  / 2 / denial reason | Not supplied |
|  / 2 / latency ms | 40985 |
|  / 2 / message id | msg&#95;011CfxZMAVNbwhcM7PBNP6oP |
|  / 2 / model | claude-sonnet-5-5 |
|  / 2 / origin | live&#95;generation |
|  / 2 / profile id | claude-sonnet-5-5&#64;3 |
|  / 2 / provider | anthropic-live-replay |
|  / 2 / replay capture verified | true |
|  / 2 / replay request identical | true |
|  / 2 / request id | req&#95;011CfxZMACGLj4HMqXdrjYkc |
|  / 2 / requested model | claude-sonnet-5-5 |
|  / 2 / reserved microusd | 248444 |
|  / 2 / retry denied | Not supplied |
|  / 2 / returned model | claude-sonnet-5-5 |
|  / 2 / role | model&#95;review |
|  / 2 / slot key | aa-p10-live-retest-LR-03&#124;claude-sonnet-5-5&#64;3&#124;counterreview |
|  / 2 / stop reason | end&#95;turn |
|  / 2 / usage / cache creation input tokens | 0 |
|  / 2 / usage / cache read input tokens | 0 |
|  / 2 / usage / input tokens | 16102 |
|  / 2 / usage / output tokens | 7268 |
|  / 3 / attempt ids | attempt-006 |
|  / 3 / authorization id | AA-P10-LIVE-RETEST-20261011-004 |
|  / 3 / billing | usage&#95;reported |
|  / 3 / capture sha256 | b4f73c5c4414127d7e9695a4cdcf196802fd7f93ea714e8a8a00d7568127c773 |
|  / 3 / completion state | complete |
|  / 3 / confirmed cost microusd | 102994 |
|  / 3 / current execution | offline&#95;replay |
|  / 3 / denial reason | Not supplied |
|  / 3 / latency ms | 39416 |
|  / 3 / message id | msg&#95;011CfxZQDHdX6hYdReAeRNw3 |
|  / 3 / model | claude-sonnet-5-5 |
|  / 3 / origin | live&#95;generation |
|  / 3 / profile id | claude-sonnet-5-5&#64;3 |
|  / 3 / provider | anthropic-live-replay |
|  / 3 / replay capture verified | true |
|  / 3 / replay request identical | true |
|  / 3 / request id | req&#95;011CfxZQCF8BMGius1n6U2o9 |
|  / 3 / requested model | claude-sonnet-5-5 |
|  / 3 / reserved microusd | 248444 |
|  / 3 / retry denied | Not supplied |
|  / 3 / returned model | claude-sonnet-5-5 |
|  / 3 / role | stability |
|  / 3 / slot key | aa-p10-live-retest-LR-03&#124;claude-sonnet-5-5&#64;3&#124;stability |
|  / 3 / stop reason | end&#95;turn |
|  / 3 / usage / cache creation input tokens | 0 |
|  / 3 / usage / cache read input tokens | 0 |
|  / 3 / usage / input tokens | 16102 |
|  / 3 / usage / output tokens | 7079 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
At a logistics company, introducing a four-day working week reduced recorded sick days among office staff.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.3 |
| derived label | Not supplied |
| host composite state | unknown |
| host derived copies | No entries recorded |
| host rule version | AA-P8-HOST/1.1 |
| input sha256 | 94baae779230fdad868aad0fda83766c984f41306343f519fc4840f8171e2bfc |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| model composite state | unsupported |
| model host conflicts / 1 / host rule version | AA-P8-HOST/1.1 |
| model host conflicts / 1 / host state | unknown |
| model host conflicts / 1 / model state | unsupported |
| model host conflicts / 1 / proposition id | claim&#58;p1 |
| model host conflicts / 1 / reason | Model judgment and host evidence derivation differ; mandatory review decides, not either side |
| model host conflicts / 1 / required | true |
| model host conflicts / 1 / scope | proposition |
| model host conflicts / 2 / host rule version | AA-P8-HOST/1.1 |
| model host conflicts / 2 / host state | unknown |
| model host conflicts / 2 / model state | unsupported |
| model host conflicts / 2 / proposition id | Not supplied |
| model host conflicts / 2 / reason | Composite of the model judgments differs from the composite of the host derivation |
| model host conflicts / 2 / required | true |
| model host conflicts / 2 / scope | composite |
| original model label | correlation&#95;vs&#95;causation |
| raw response sha256 | a604745bea589c91a23fc9a2ceb1eed07b41faeafb2b2689c9bc6b5e67319dc1 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.3 (AA-P8-HOST/1.1)<br>2 open model/host conflict(s); effective state unknown where they occur |
| record fingerprint | 13597195ee76181433f91e7e8e283fedf17bbc4fe1a593b5c493711fdccc28ab |
| technical status | completed |
| transformation findings | No entries recorded |

In &#x27;reasons&#x27;, model-supplied text (the proposition reason, uncertainty and binding reasons) is combined with host sentences; only &#x27;host reasons&#x27; is host-written.

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | unknown |
|  / 1 / derived state | unknown |
|  / 1 / evidence ids | e1<br>e2<br>e3 |
|  / 1 / host reasons | binding 1&#58; preserved observation&#58; inconclusive<br>binding 2&#58; preserved observation&#58; inconclusive<br>binding 3&#58; preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred |
|  / 1 / host state | unknown |
|  / 1 / model host conflict | true |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | A causal claim rests on a confounded before/after comparison with no control group.<br>The effect of the four-day week itself is unknown, not shown to be zero.<br>b1&#58; Shows lower sick days than the previous year, which is only a temporal association, not an identified causal effect.<br>preserved observation&#58; inconclusive<br>b2&#58; A severe influenza season in the prior year is a plausible alternative explanation for the drop.<br>preserved observation&#58; inconclusive<br>b3&#58; No concurrent comparison group (staff on a five-day week) is reported.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); open conflict, effective state unknown until a mandatory review resolves it |
|  / 1 / reported verdict | unsupported |
|  / 1 / required | true |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | correlation&#95;vs&#95;causation |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | causal&#95;inference |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1<br>e2<br>e3 |
| represented trigger analysis / implies human benefit | false |
| represented trigger analysis / noncausal result used | true |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | The claim asserts causation (&#x27;reduced&#x27;) from an uncontrolled before/after comparison. A severe influenza season in the prior year confounds it, and no five-day-week comparison group is reported. |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | recorded sick days among office staff were 20 percent lower that year than in the previous year |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | CvC trigger is not established by the linked evidence/result |
| taxonomy check / technical status | completed |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | Single causal proposition extracted from the full claim text; the descriptive and causal parts are inseparable in the wording. |
| logic / children | No entries recorded |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | prov-1 |
| required proposition ids | claim&#58;p1 |

### Proposition 1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | unknown |
| derived judgment / derived state | unknown |
| derived judgment / evidence ids | e1<br>e2<br>e3 |
| derived judgment / host reasons | binding 1&#58; preserved observation&#58; inconclusive<br>binding 2&#58; preserved observation&#58; inconclusive<br>binding 3&#58; preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| derived judgment / host state | unknown |
| derived judgment / model host conflict | true |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | A causal claim rests on a confounded before/after comparison with no control group.<br>The effect of the four-day week itself is unknown, not shown to be zero.<br>b1&#58; Shows lower sick days than the previous year, which is only a temporal association, not an identified causal effect.<br>preserved observation&#58; inconclusive<br>b2&#58; A severe influenza season in the prior year is a plausible alternative explanation for the drop.<br>preserved observation&#58; inconclusive<br>b3&#58; No concurrent comparison group (staff on a five-day week) is reported.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); open conflict, effective state unknown until a mandatory review resolves it |
| derived judgment / reported verdict | unsupported |
| derived judgment / required | true |
| material dimensions | population<br>intervention<br>endpoint |
| materiality | required |
| not applicable / comparator | The claim names no comparator. |
| not applicable / follow up | The claim states no follow-up period. |
| observation target | inconclusive |
| parent claim id | claim |
| premise proposition ids | No entries recorded |
| proposition id | claim&#58;p1 |
| provenance id | prov-1 |
| reason | A causal claim rests on a confounded before/after comparison with no control group. |
| reported verdict | unsupported |
| required bridge ids | No entries recorded |
| search question | Does the context show that introducing a four-day working week reduced recorded sick days among office staff, relative to a valid comparison? |
| search scope ids | ss1 |
| uncertainty | The effect of the four-day week itself is unknown, not shown to be zero. |

Quoted proposition; this is represented input, not a release assertion.

```
At a logistics company, introducing a four-day working week reduced recorded sick days among office staff.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 106 |
| start | 0 |
| text | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | stated as established fact |
| comparator | Not supplied |
| endpoint | recorded sick days |
| endpoint type | administrative |
| follow up | Not supplied |
| intervention | four-day working week |
| population | office staff at a logistics company |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | partial |
|  / 1 / evidence id | e1 |
|  / 1 / observation | inconclusive |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Shows lower sick days than the previous year, which is only a temporal association, not an identified causal effect. |
|  / 1 / search scope id | ss1 |
|  / 2 / binding id | b2 |
|  / 2 / directness | partial |
|  / 2 / evidence id | e2 |
|  / 2 / observation | inconclusive |
|  / 2 / proposition id | claim&#58;p1 |
|  / 2 / reason | A severe influenza season in the prior year is a plausible alternative explanation for the drop. |
|  / 2 / search scope id | ss1 |
|  / 3 / binding id | b3 |
|  / 3 / directness | partial |
|  / 3 / evidence id | e3 |
|  / 3 / observation | inconclusive |
|  / 3 / proposition id | claim&#58;p1 |
|  / 3 / reason | No concurrent comparison group (staff on a five-day week) is reported. |
|  / 3 / search scope id | ss1 |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation 1

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| from and to attributes (identical) / certainty | stated as established fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | recorded sick days |
| from and to attributes (identical) / endpoint type | administrative |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | four-day working week |
| from and to attributes (identical) / population | office staff at a logistics company |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff. |
| from proposition ids | claim&#58;p1 |
| reason | Unchanged extraction. |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | t1 |

### Transformation 2

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| from and to attributes (identical) / certainty | stated as established fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | recorded sick days |
| from and to attributes (identical) / endpoint type | administrative |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | four-day working week |
| from and to attributes (identical) / population | office staff at a logistics company |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff. |
| reason | The question keeps the same meaning and asks about the causal relation. |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | Does the context show that introducing a four-day working week reduced recorded sick days among office staff, relative to a valid comparison? |
| transformation id | t2 |

### Transformation 3

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| from and to attributes (identical) / certainty | stated as established fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | recorded sick days |
| from and to attributes (identical) / endpoint type | administrative |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | four-day working week |
| from and to attributes (identical) / population | office staff at a logistics company |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff. |
| reason | The internal finding restates the proposition with an unsupported verdict. |
| stage | internal |
| target id | claim&#58;p1 |
| to text | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff.<br>Unsupported&#58; only a before/after drop, confounded by a severe influenza season in the prior year, with no concurrent comparison group. |
| transformation id | t3 |

### Transformation 4

| Field | Recorded value |
| --- | --- |
| asserted state | unsupported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | stated as established fact |
| from and to attributes (identical) / comparator | Not supplied |
| from and to attributes (identical) / endpoint | recorded sick days |
| from and to attributes (identical) / endpoint type | administrative |
| from and to attributes (identical) / follow up | Not supplied |
| from and to attributes (identical) / intervention | four-day working week |
| from and to attributes (identical) / population | office staff at a logistics company |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff. |
| reason | The client summary states that the causal claim is not established, matching the judgment of unsupported. |
| stage | summary |
| target id | cf1 |
| to text | The data do not establish that the four-day week reduced sick days.<br>Sick days were 20 percent lower than the previous year. That year had a severe influenza season, and there is no comparison with staff who kept a five-day week. |
| transformation id | t4 |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence item 1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | recorded sick days |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | 20 percent lower |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
recorded sick days among office staff were 20 percent lower that year than in the previous year
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | recorded sick days |
| attributes / endpoint type | administrative |
| attributes / intervention | four-day working week |
| attributes / population | office staff at a logistics company |
| attributes / relation | association |
| attributes / species | human |
| design limitations | before/after comparison with the previous year<br>no concurrent control group<br>previous year affected by a severe influenza season |
| evidence id | e1 |
| evidence type | descriptive |
| quality | low for causal inference |
| randomized | Not supplied |
| source role | company annual report statement quoted in the context |

### Evidence item 2

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | recorded sick days |
| evidence id | e2 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | weakening |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
a severe influenza season had affected the previous year
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | recorded sick days |
| attributes / endpoint type | administrative |
| attributes / intervention | four-day working week |
| attributes / population | office staff at a logistics company |
| attributes / relation | description |
| attributes / species | human |
| design limitations | describes a confounder, not an outcome comparison |
| evidence id | e2 |
| evidence type | descriptive |
| randomized | Not supplied |
| source role | annual report note quoted in the context |

### Evidence item 3

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | recorded sick days |
| evidence id | e3 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | missing&#95;expected |
| source id | context |
| value origin | Not supplied |

Evidence text and exact source reference (identical)&#58;

```
gives no sick-day figures for staff who kept a five-day week
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / endpoint | recorded sick days |
| attributes / endpoint type | administrative |
| attributes / intervention | four-day working week |
| attributes / population | office staff at a logistics company |
| attributes / relation | description |
| attributes / species | human |
| design limitations | absence of a comparison group |
| evidence id | e3 |
| evidence type | descriptive |
| randomized | Not supplied |
| source role | annual report limitation quoted in the context |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | ss1 |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A logistics company introduced a four-day working week for all office staff in January. In its annual report, the company stated that recorded sick days among office staff were 20 percent lower that year than in the previous year. The report notes that a severe influenza season had affected the previous year and gives no sick-day figures for staff who kept a five-day week.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | prov-1 |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;directly&#95;established |
|  / 1 / confidence status | moderate |
|  / 1 / contrary evidence ids | e2<br>e3 |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | correlation&#95;vs&#95;causation |
|  / 1 / proposition | At a logistics company, introducing a four-day working week reduced recorded sick days among office staff. |
|  / 1 / provenance id | prov-1 |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary | Unsupported&#58; only a before/after drop, confounded by a severe influenza season in the prior year, with no concurrent comparison group. |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation | Sick days were 20 percent lower than the previous year. That year had a severe influenza season, and there is no comparison with staff who kept a five-day week. |
|  / 1 / client finding id | cf1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;directly&#95;established |
|  / 1 / display claim | The data do not establish that the four-day week reduced sick days. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | prov-1 |
|  / 1 / referenced evidence ids | e1<br>e2<br>e3 |
|  / 1 / value claims / 1 / claimed origin | source&#95;reported |
|  / 1 / value claims / 1 / claimed source ids | context |
|  / 1 / value claims / 1 / evidence id | e1 |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| contract version | AA-P9/1.3 |
| execution status | completed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | completed |
| uncertainty | p9position&#58;5ef8cd03bda5fc34e1cdb35d/claim&#58;p1&#58; scientific UNKNOWN<br>p9position&#58;6c94d19b6c08bda5b38f696f/claim&#58;p1&#58; scientific UNKNOWN<br>p9position&#58;92440760006ab5fd4ae9afce/claim&#58;p1&#58; scientific UNKNOWN |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 0fba4f7ef3758fb429e1cd7c9ee26f6098fb8b3f63bc54f2087c8f0b6cc4ec57 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | completed |

### Position p9position&#58;6c94d19b6c08bda5b38f696f

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | original |
| original model label | correlation&#95;vs&#95;causation |
| position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | a604745bea589c91a23fc9a2ceb1eed07b41faeafb2b2689c9bc6b5e67319dc1 |
| run id | 6150e80c-fa32-42fc-b9bc-acebd0df4fb8 |
| scientific state | unknown |
| selected | true |
| taxonomy status | completed |
| technical status | completed |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 14984 |
| usage / output tokens | 8318 |

### Position p9position&#58;92440760006ab5fd4ae9afce

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/1 |
| derived taxonomy | correlation&#95;vs&#95;causation |
| model | claude-sonnet-5-5 |
| origin | model&#95;review |
| original model label | correlation&#95;vs&#95;causation |
| position id | p9position&#58;92440760006ab5fd4ae9afce |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/1/agent&#95;result/raw&#95;output |
| raw sha256 | a5e4568fcfa232b504271e9b74007bea7c8a77fc7afa7f9e20a3269caae8dd37 |
| run id | 6150e80c-fa32-42fc-b9bc-acebd0df4fb8&#58;counterreview |
| scientific state | unknown |
| selected | false |
| taxonomy status | completed |
| technical status | completed |

### Position judgments and uncertainty

| Field | Recorded value |
| --- | --- |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| propositions / 1 / dependency status | unknown |
| propositions / 1 / derived state | unknown |
| propositions / 1 / evidence ids | e1<br>e2<br>e3 |
| propositions / 1 / host reasons | binding 1&#58; preserved observation&#58; inconclusive<br>binding 2&#58; preserved observation&#58; inconclusive<br>binding 3&#58; preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| propositions / 1 / host state | unknown |
| propositions / 1 / model host conflict | true |
| propositions / 1 / proposition id | claim&#58;p1 |
| propositions / 1 / reasons | A causal claim rests on a confounded before/after comparison with no control group.<br>The four-day week may have contributed to the drop, but the supplied evidence cannot separate its effect from the influenza season.<br>Evidence dependence is unknown.<br>b1&#58; It shows a lower number of sick days than the previous year, but it is a before/after comparison without a control group and cannot isolate the cause.<br>preserved observation&#58; inconclusive<br>b2&#58; A severe influenza season in the comparison year is a plausible alternative explanation for the lower figure.<br>preserved observation&#58; inconclusive<br>b3&#58; There are no sick-day figures for staff on a five-day week, so no concurrent comparator exists.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); open conflict, effective state unknown until a mandatory review resolves it |
| propositions / 1 / reported verdict | unsupported |
| propositions / 1 / required | true |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.3 (AA-P8-HOST/1.1)<br>2 open model/host conflict(s); effective state unknown where they occur |
| transformation findings | No entries recorded |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 16102 |
| usage / output tokens | 7268 |

### Position p9position&#58;5ef8cd03bda5fc34e1cdb35d

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/2 |
| derived taxonomy | Not supplied |
| model | claude-sonnet-5-5 |
| origin | stability |
| original model label | correlation&#95;vs&#95;causation |
| position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| provider | anthropic-live-replay |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/2/agent&#95;result/raw&#95;output |
| raw sha256 | 1408ca920fc7e9ada2a33c4ed8ec2ab3149aecd5e60047e6b05f5a9d94bf55a1 |
| run id | 6150e80c-fa32-42fc-b9bc-acebd0df4fb8&#58;stability |
| scientific state | unknown |
| selected | false |
| taxonomy status | completed |
| technical status | completed |

### Position judgments and uncertainty

| Field | Recorded value |
| --- | --- |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| propositions / 1 / dependency status | unknown |
| propositions / 1 / derived state | unknown |
| propositions / 1 / evidence ids | e1<br>e2<br>e3 |
| propositions / 1 / host reasons | binding 1&#58; preserved observation&#58; inconclusive<br>binding 2&#58; preserved observation&#58; inconclusive<br>binding 3&#58; preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred |
| propositions / 1 / host state | unknown |
| propositions / 1 / model host conflict | true |
| propositions / 1 / proposition id | claim&#58;p1 |
| propositions / 1 / reasons | A causal claim rests on a confounded before/after comparison with no control group.<br>A true effect is not excluded.<br>The size of the influenza effect is unknown.<br>b1&#58; Shows a before/after drop in recorded sick days, which is association only and does not identify causation.<br>preserved observation&#58; inconclusive<br>b2&#58; A severe influenza season in the previous year is a confounder that could explain the drop.<br>preserved observation&#58; inconclusive<br>b3&#58; No concurrent five-day-week comparison group is reported.<br>preserved observation&#58; inconclusive<br>evidence dependence&#58; unknown; no independent corroboration inferred<br>model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); open conflict, effective state unknown until a mandatory review resolves it |
| propositions / 1 / reported verdict | unsupported |
| propositions / 1 / required | true |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.3 (AA-P8-HOST/1.1)<br>2 open model/host conflict(s); effective state unknown where they occur |
| transformation findings | No entries recorded |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | stop |
| parse ok | true |
| usage / cache creation input tokens | 0 |
| usage / cache read input tokens | 0 |
| usage / input tokens | 16102 |
| usage / output tokens | 7079 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;00a6e226a433b623f7efa180 |
| field | propositions.claim&#58;p1.attributes.follow&#95;up |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | one calendar year |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | Not supplied |
| projected object fingerprint | 0dcf7af91cc193759e864b820e4694ffa5be05f7325264f892eaecccf82e586d |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/0 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;05d8db46f32db4602c3dd246 |
| field | propositions.claim&#58;p1.attributes.endpoint&#95;type |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | administrative |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | descriptive |
| projected object fingerprint | 9666dbe963ea8444baca7722669fd94844e45647e00195db43571afb4d5fb9ec |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/1 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;0fc70925733090feeb27b1e3 |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value / 1 | e1<br>inconclusive<br>partial |
| positions / 1 / value / 2 | e2<br>inconclusive<br>indirect |
| positions / 1 / value / 3 | e3<br>inconclusive<br>indirect |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value / 1 | e1<br>inconclusive<br>partial |
| positions / 2 / value / 2 | e2<br>inconclusive<br>partial |
| positions / 2 / value / 3 | e3<br>inconclusive<br>partial |
| projected object fingerprint | d22e9c86115ce1d62f9ef5196c196fbd611a130ddf84f5b1da8096cac52c19ba |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/2 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | causal&#95;strength |
| disagreement id | p9conflict&#58;1f95ad8d80ae5f2d84686763 |
| field | propositions.claim&#58;p1.attributes.certainty |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | definite |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value | stated as established fact |
| projected object fingerprint | 07eef0b52cb71bd5095f2a7a1931097d9031642213116bb533d1e90798cd4c2b |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/3 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;36743ca86ab9fb5c9e0fe579 |
| field | phase8.derived&#95;label |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 1 / value | Not supplied |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | correlation&#95;vs&#95;causation |
| projected object fingerprint | ce99b4aee460e317686d2946c0798ec7cdf9f4b093445fa1439d02b70b54b6fe |
| proposition ids | No entries recorded |
| provenance | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/4 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;3e28e849cb230da8daba0eed |
| field | propositions.claim&#58;p1.output&#95;transformations |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 1 / value / 1 / 1 | extraction |
| positions / 1 / value / 1 / 2 / certainty | stated as established fact |
| positions / 1 / value / 1 / 2 / comparator | Not supplied |
| positions / 1 / value / 1 / 2 / comparison | Not supplied |
| positions / 1 / value / 1 / 2 / dose | Not supplied |
| positions / 1 / value / 1 / 2 / effect basis | Not supplied |
| positions / 1 / value / 1 / 2 / effect direction | Not supplied |
| positions / 1 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 1 / 2 / endpoint type | administrative |
| positions / 1 / value / 1 / 2 / follow up | Not supplied |
| positions / 1 / value / 1 / 2 / formulation | Not supplied |
| positions / 1 / value / 1 / 2 / intervention | four-day working week |
| positions / 1 / value / 1 / 2 / population | office staff at a logistics company |
| positions / 1 / value / 1 / 2 / relation | causal |
| positions / 1 / value / 1 / 2 / route | Not supplied |
| positions / 1 / value / 1 / 2 / species | human |
| positions / 1 / value / 1 / 3 / certainty | stated as established fact |
| positions / 1 / value / 1 / 3 / comparator | Not supplied |
| positions / 1 / value / 1 / 3 / comparison | Not supplied |
| positions / 1 / value / 1 / 3 / dose | Not supplied |
| positions / 1 / value / 1 / 3 / effect basis | Not supplied |
| positions / 1 / value / 1 / 3 / effect direction | Not supplied |
| positions / 1 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 1 / 3 / endpoint type | administrative |
| positions / 1 / value / 1 / 3 / follow up | Not supplied |
| positions / 1 / value / 1 / 3 / formulation | Not supplied |
| positions / 1 / value / 1 / 3 / intervention | four-day working week |
| positions / 1 / value / 1 / 3 / population | office staff at a logistics company |
| positions / 1 / value / 1 / 3 / relation | causal |
| positions / 1 / value / 1 / 3 / route | Not supplied |
| positions / 1 / value / 1 / 3 / species | human |
| positions / 1 / value / 1 / 4 | unsupported |
| positions / 1 / value / 1 / 5 | false |
| positions / 1 / value / 2 / 1 | internal |
| positions / 1 / value / 2 / 2 / certainty | stated as established fact |
| positions / 1 / value / 2 / 2 / comparator | Not supplied |
| positions / 1 / value / 2 / 2 / comparison | Not supplied |
| positions / 1 / value / 2 / 2 / dose | Not supplied |
| positions / 1 / value / 2 / 2 / effect basis | Not supplied |
| positions / 1 / value / 2 / 2 / effect direction | Not supplied |
| positions / 1 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 2 / 2 / endpoint type | administrative |
| positions / 1 / value / 2 / 2 / follow up | Not supplied |
| positions / 1 / value / 2 / 2 / formulation | Not supplied |
| positions / 1 / value / 2 / 2 / intervention | four-day working week |
| positions / 1 / value / 2 / 2 / population | office staff at a logistics company |
| positions / 1 / value / 2 / 2 / relation | causal |
| positions / 1 / value / 2 / 2 / route | Not supplied |
| positions / 1 / value / 2 / 2 / species | human |
| positions / 1 / value / 2 / 3 / certainty | stated as established fact |
| positions / 1 / value / 2 / 3 / comparator | Not supplied |
| positions / 1 / value / 2 / 3 / comparison | Not supplied |
| positions / 1 / value / 2 / 3 / dose | Not supplied |
| positions / 1 / value / 2 / 3 / effect basis | Not supplied |
| positions / 1 / value / 2 / 3 / effect direction | Not supplied |
| positions / 1 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 2 / 3 / endpoint type | administrative |
| positions / 1 / value / 2 / 3 / follow up | Not supplied |
| positions / 1 / value / 2 / 3 / formulation | Not supplied |
| positions / 1 / value / 2 / 3 / intervention | four-day working week |
| positions / 1 / value / 2 / 3 / population | office staff at a logistics company |
| positions / 1 / value / 2 / 3 / relation | causal |
| positions / 1 / value / 2 / 3 / route | Not supplied |
| positions / 1 / value / 2 / 3 / species | human |
| positions / 1 / value / 2 / 4 | unsupported |
| positions / 1 / value / 2 / 5 | false |
| positions / 1 / value / 3 / 1 | search&#95;question |
| positions / 1 / value / 3 / 2 / certainty | stated as established fact |
| positions / 1 / value / 3 / 2 / comparator | Not supplied |
| positions / 1 / value / 3 / 2 / comparison | Not supplied |
| positions / 1 / value / 3 / 2 / dose | Not supplied |
| positions / 1 / value / 3 / 2 / effect basis | Not supplied |
| positions / 1 / value / 3 / 2 / effect direction | Not supplied |
| positions / 1 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 3 / 2 / endpoint type | administrative |
| positions / 1 / value / 3 / 2 / follow up | Not supplied |
| positions / 1 / value / 3 / 2 / formulation | Not supplied |
| positions / 1 / value / 3 / 2 / intervention | four-day working week |
| positions / 1 / value / 3 / 2 / population | office staff at a logistics company |
| positions / 1 / value / 3 / 2 / relation | causal |
| positions / 1 / value / 3 / 2 / route | Not supplied |
| positions / 1 / value / 3 / 2 / species | human |
| positions / 1 / value / 3 / 3 / certainty | stated as established fact |
| positions / 1 / value / 3 / 3 / comparator | Not supplied |
| positions / 1 / value / 3 / 3 / comparison | Not supplied |
| positions / 1 / value / 3 / 3 / dose | Not supplied |
| positions / 1 / value / 3 / 3 / effect basis | Not supplied |
| positions / 1 / value / 3 / 3 / effect direction | Not supplied |
| positions / 1 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 3 / 3 / endpoint type | administrative |
| positions / 1 / value / 3 / 3 / follow up | Not supplied |
| positions / 1 / value / 3 / 3 / formulation | Not supplied |
| positions / 1 / value / 3 / 3 / intervention | four-day working week |
| positions / 1 / value / 3 / 3 / population | office staff at a logistics company |
| positions / 1 / value / 3 / 3 / relation | causal |
| positions / 1 / value / 3 / 3 / route | Not supplied |
| positions / 1 / value / 3 / 3 / species | human |
| positions / 1 / value / 3 / 4 | unsupported |
| positions / 1 / value / 3 / 5 | false |
| positions / 1 / value / 4 / 1 | summary |
| positions / 1 / value / 4 / 2 / certainty | stated as established fact |
| positions / 1 / value / 4 / 2 / comparator | Not supplied |
| positions / 1 / value / 4 / 2 / comparison | Not supplied |
| positions / 1 / value / 4 / 2 / dose | Not supplied |
| positions / 1 / value / 4 / 2 / effect basis | Not supplied |
| positions / 1 / value / 4 / 2 / effect direction | Not supplied |
| positions / 1 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 4 / 2 / endpoint type | administrative |
| positions / 1 / value / 4 / 2 / follow up | Not supplied |
| positions / 1 / value / 4 / 2 / formulation | Not supplied |
| positions / 1 / value / 4 / 2 / intervention | four-day working week |
| positions / 1 / value / 4 / 2 / population | office staff at a logistics company |
| positions / 1 / value / 4 / 2 / relation | causal |
| positions / 1 / value / 4 / 2 / route | Not supplied |
| positions / 1 / value / 4 / 2 / species | human |
| positions / 1 / value / 4 / 3 / certainty | stated as established fact |
| positions / 1 / value / 4 / 3 / comparator | Not supplied |
| positions / 1 / value / 4 / 3 / comparison | Not supplied |
| positions / 1 / value / 4 / 3 / dose | Not supplied |
| positions / 1 / value / 4 / 3 / effect basis | Not supplied |
| positions / 1 / value / 4 / 3 / effect direction | Not supplied |
| positions / 1 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 4 / 3 / endpoint type | administrative |
| positions / 1 / value / 4 / 3 / follow up | Not supplied |
| positions / 1 / value / 4 / 3 / formulation | Not supplied |
| positions / 1 / value / 4 / 3 / intervention | four-day working week |
| positions / 1 / value / 4 / 3 / population | office staff at a logistics company |
| positions / 1 / value / 4 / 3 / relation | causal |
| positions / 1 / value / 4 / 3 / route | Not supplied |
| positions / 1 / value / 4 / 3 / species | human |
| positions / 1 / value / 4 / 4 | unsupported |
| positions / 1 / value / 4 / 5 | true |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value / 1 / 1 | extraction |
| positions / 2 / value / 1 / 2 / certainty | definite |
| positions / 2 / value / 1 / 2 / comparator | Not supplied |
| positions / 2 / value / 1 / 2 / comparison | Not supplied |
| positions / 2 / value / 1 / 2 / dose | Not supplied |
| positions / 2 / value / 1 / 2 / effect basis | Not supplied |
| positions / 2 / value / 1 / 2 / effect direction | decrease |
| positions / 2 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 1 / 2 / endpoint type | descriptive |
| positions / 2 / value / 1 / 2 / follow up | Not supplied |
| positions / 2 / value / 1 / 2 / formulation | Not supplied |
| positions / 2 / value / 1 / 2 / intervention | four-day working week |
| positions / 2 / value / 1 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 1 / 2 / relation | causal |
| positions / 2 / value / 1 / 2 / route | Not supplied |
| positions / 2 / value / 1 / 2 / species | human |
| positions / 2 / value / 1 / 3 / certainty | definite |
| positions / 2 / value / 1 / 3 / comparator | Not supplied |
| positions / 2 / value / 1 / 3 / comparison | Not supplied |
| positions / 2 / value / 1 / 3 / dose | Not supplied |
| positions / 2 / value / 1 / 3 / effect basis | Not supplied |
| positions / 2 / value / 1 / 3 / effect direction | decrease |
| positions / 2 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 1 / 3 / endpoint type | descriptive |
| positions / 2 / value / 1 / 3 / follow up | Not supplied |
| positions / 2 / value / 1 / 3 / formulation | Not supplied |
| positions / 2 / value / 1 / 3 / intervention | four-day working week |
| positions / 2 / value / 1 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 1 / 3 / relation | causal |
| positions / 2 / value / 1 / 3 / route | Not supplied |
| positions / 2 / value / 1 / 3 / species | human |
| positions / 2 / value / 1 / 4 | unsupported |
| positions / 2 / value / 1 / 5 | false |
| positions / 2 / value / 2 / 1 | internal |
| positions / 2 / value / 2 / 2 / certainty | definite |
| positions / 2 / value / 2 / 2 / comparator | Not supplied |
| positions / 2 / value / 2 / 2 / comparison | Not supplied |
| positions / 2 / value / 2 / 2 / dose | Not supplied |
| positions / 2 / value / 2 / 2 / effect basis | Not supplied |
| positions / 2 / value / 2 / 2 / effect direction | decrease |
| positions / 2 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 2 / 2 / endpoint type | descriptive |
| positions / 2 / value / 2 / 2 / follow up | Not supplied |
| positions / 2 / value / 2 / 2 / formulation | Not supplied |
| positions / 2 / value / 2 / 2 / intervention | four-day working week |
| positions / 2 / value / 2 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 2 / 2 / relation | causal |
| positions / 2 / value / 2 / 2 / route | Not supplied |
| positions / 2 / value / 2 / 2 / species | human |
| positions / 2 / value / 2 / 3 / certainty | definite |
| positions / 2 / value / 2 / 3 / comparator | Not supplied |
| positions / 2 / value / 2 / 3 / comparison | Not supplied |
| positions / 2 / value / 2 / 3 / dose | Not supplied |
| positions / 2 / value / 2 / 3 / effect basis | Not supplied |
| positions / 2 / value / 2 / 3 / effect direction | decrease |
| positions / 2 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 2 / 3 / endpoint type | descriptive |
| positions / 2 / value / 2 / 3 / follow up | Not supplied |
| positions / 2 / value / 2 / 3 / formulation | Not supplied |
| positions / 2 / value / 2 / 3 / intervention | four-day working week |
| positions / 2 / value / 2 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 2 / 3 / relation | causal |
| positions / 2 / value / 2 / 3 / route | Not supplied |
| positions / 2 / value / 2 / 3 / species | human |
| positions / 2 / value / 2 / 4 | unsupported |
| positions / 2 / value / 2 / 5 | false |
| positions / 2 / value / 3 / 1 | search&#95;question |
| positions / 2 / value / 3 / 2 / certainty | definite |
| positions / 2 / value / 3 / 2 / comparator | Not supplied |
| positions / 2 / value / 3 / 2 / comparison | Not supplied |
| positions / 2 / value / 3 / 2 / dose | Not supplied |
| positions / 2 / value / 3 / 2 / effect basis | Not supplied |
| positions / 2 / value / 3 / 2 / effect direction | decrease |
| positions / 2 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 3 / 2 / endpoint type | descriptive |
| positions / 2 / value / 3 / 2 / follow up | Not supplied |
| positions / 2 / value / 3 / 2 / formulation | Not supplied |
| positions / 2 / value / 3 / 2 / intervention | four-day working week |
| positions / 2 / value / 3 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 3 / 2 / relation | causal |
| positions / 2 / value / 3 / 2 / route | Not supplied |
| positions / 2 / value / 3 / 2 / species | human |
| positions / 2 / value / 3 / 3 / certainty | definite |
| positions / 2 / value / 3 / 3 / comparator | Not supplied |
| positions / 2 / value / 3 / 3 / comparison | Not supplied |
| positions / 2 / value / 3 / 3 / dose | Not supplied |
| positions / 2 / value / 3 / 3 / effect basis | Not supplied |
| positions / 2 / value / 3 / 3 / effect direction | decrease |
| positions / 2 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 3 / 3 / endpoint type | descriptive |
| positions / 2 / value / 3 / 3 / follow up | Not supplied |
| positions / 2 / value / 3 / 3 / formulation | Not supplied |
| positions / 2 / value / 3 / 3 / intervention | four-day working week |
| positions / 2 / value / 3 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 3 / 3 / relation | causal |
| positions / 2 / value / 3 / 3 / route | Not supplied |
| positions / 2 / value / 3 / 3 / species | human |
| positions / 2 / value / 3 / 4 | unsupported |
| positions / 2 / value / 3 / 5 | false |
| positions / 2 / value / 4 / 1 | summary |
| positions / 2 / value / 4 / 2 / certainty | definite |
| positions / 2 / value / 4 / 2 / comparator | Not supplied |
| positions / 2 / value / 4 / 2 / comparison | Not supplied |
| positions / 2 / value / 4 / 2 / dose | Not supplied |
| positions / 2 / value / 4 / 2 / effect basis | Not supplied |
| positions / 2 / value / 4 / 2 / effect direction | decrease |
| positions / 2 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 4 / 2 / endpoint type | descriptive |
| positions / 2 / value / 4 / 2 / follow up | Not supplied |
| positions / 2 / value / 4 / 2 / formulation | Not supplied |
| positions / 2 / value / 4 / 2 / intervention | four-day working week |
| positions / 2 / value / 4 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 4 / 2 / relation | causal |
| positions / 2 / value / 4 / 2 / route | Not supplied |
| positions / 2 / value / 4 / 2 / species | human |
| positions / 2 / value / 4 / 3 / certainty | definite |
| positions / 2 / value / 4 / 3 / comparator | Not supplied |
| positions / 2 / value / 4 / 3 / comparison | Not supplied |
| positions / 2 / value / 4 / 3 / dose | Not supplied |
| positions / 2 / value / 4 / 3 / effect basis | Not supplied |
| positions / 2 / value / 4 / 3 / effect direction | decrease |
| positions / 2 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 4 / 3 / endpoint type | descriptive |
| positions / 2 / value / 4 / 3 / follow up | Not supplied |
| positions / 2 / value / 4 / 3 / formulation | Not supplied |
| positions / 2 / value / 4 / 3 / intervention | four-day working week |
| positions / 2 / value / 4 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 4 / 3 / relation | causal |
| positions / 2 / value / 4 / 3 / route | Not supplied |
| positions / 2 / value / 4 / 3 / species | human |
| positions / 2 / value / 4 / 4 | unsupported |
| positions / 2 / value / 4 / 5 | true |
| projected object fingerprint | 3bbebf40f9e09df62b1fc91fae1f6fa228eed35267742c41ebfd6388a6d10c53 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/5 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | causal&#95;strength |
| disagreement id | p9conflict&#58;3ffb548b66194bc311be738d |
| field | propositions.claim&#58;p1.attributes.certainty |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 1 / value | stated as established fact |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | definite |
| projected object fingerprint | e31ebbca3a41adadc0ca7c4cce6a005878313fa965c81ef7330dc9382faa00f1 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/6 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;50347467c0a5549838e03971 |
| field | propositions.claim&#58;p1.attributes.comparator |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | previous year |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value | Not supplied |
| projected object fingerprint | fc2b8a279064e3927b4cbefeab819943e264dd0c689ddd479fde17c3f7ef2010 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/7 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | search&#95;scope |
| disagreement id | p9conflict&#58;5f52b28890c908038da41b06 |
| field | propositions.claim&#58;p1.search&#95;scope |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value / 1 / 1 | reviewed&#95;set |
| positions / 1 / value / 1 / 2 | context<br>input |
| positions / 1 / value / 1 / 3 | No entries recorded |
| positions / 1 / value / 1 / 4 | Not supplied |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value / 1 / 1 | reviewed&#95;set |
| positions / 2 / value / 1 / 2 | context |
| positions / 2 / value / 1 / 3 | No entries recorded |
| positions / 2 / value / 1 / 4 | Not supplied |
| projected object fingerprint | 46330b8d164fd35e6fa17415595ba107af67c143f644da4bbd5820390509a2c2 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/8 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;6dffaf2b54c9acb8d3ee2ee2 |
| field | propositions.claim&#58;p1.attributes.population |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | office staff |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value | office staff at a logistics company |
| projected object fingerprint | 7603e56858ed8e8a9f12e5521baab8202fef8e1e1bdab8c24f48a92c3092b6e5 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/9 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;8185812494684906faf499d2 |
| field | propositions.claim&#58;p1.attributes.effect&#95;direction |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | decrease |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value | Not supplied |
| projected object fingerprint | 0cf870e328f0ddd42f264c9a06aff7b95722b64ee009449507c249507d7a0162 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/10 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;841117bb57cab9fe7917ec7a |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value / 1 | e1<br>inconclusive<br>partial |
| positions / 1 / value / 2 | e2<br>inconclusive<br>indirect |
| positions / 1 / value / 3 | e3<br>inconclusive<br>indirect |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value / 1 | e1<br>inconclusive<br>partial |
| positions / 2 / value / 2 | e2<br>inconclusive<br>partial |
| positions / 2 / value / 3 | e3<br>inconclusive<br>partial |
| projected object fingerprint | 83ad17c7288f126b92b22c03579a4433edc7a2d266da41b8d62599263e073447 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/11 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;935b7c3a5e8a482611d113c3 |
| field | propositions.claim&#58;p1.attributes.comparator |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | previous year |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | Not supplied |
| projected object fingerprint | e4dffbbd1d59c634e3f14490c24607d89b56eb32a77ff59f3e1a64fc874896e9 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/12 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;94f2d3bb5826c1fbb7adc3ad |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value / 1 / attributes / certainty | reported |
| positions / 1 / value / 1 / attributes / comparator | previous year |
| positions / 1 / value / 1 / attributes / comparison | Not supplied |
| positions / 1 / value / 1 / attributes / dose | Not supplied |
| positions / 1 / value / 1 / attributes / effect basis | Not supplied |
| positions / 1 / value / 1 / attributes / effect direction | decrease |
| positions / 1 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 1 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 1 / attributes / endpoint type | administrative |
| positions / 1 / value / 1 / attributes / follow up | one calendar year |
| positions / 1 / value / 1 / attributes / formulation | Not supplied |
| positions / 1 / value / 1 / attributes / intervention | four-day working week |
| positions / 1 / value / 1 / attributes / population | office staff |
| positions / 1 / value / 1 / attributes / relation | association |
| positions / 1 / value / 1 / attributes / route | Not supplied |
| positions / 1 / value / 1 / attributes / species | human |
| positions / 1 / value / 1 / cohort id | Not supplied |
| positions / 1 / value / 1 / dataset id | Not supplied |
| positions / 1 / value / 1 / design limitations | before/after comparison<br>no concurrent control group<br>confounded by influenza season |
| positions / 1 / value / 1 / evidence id | e1 |
| positions / 1 / value / 1 / evidence type | descriptive |
| positions / 1 / value / 1 / identification argument | Not supplied |
| positions / 1 / value / 1 / identification evidence ids | No entries recorded |
| positions / 1 / value / 1 / randomized | false |
| positions / 1 / value / 1 / source role | company annual report statement of year-on-year change |
| positions / 1 / value / 1 / study id | Not supplied |
| positions / 1 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 1 / value / 2 / attributes / certainty | Not supplied |
| positions / 1 / value / 2 / attributes / comparator | previous year |
| positions / 1 / value / 2 / attributes / comparison | Not supplied |
| positions / 1 / value / 2 / attributes / dose | Not supplied |
| positions / 1 / value / 2 / attributes / effect basis | Not supplied |
| positions / 1 / value / 2 / attributes / effect direction | Not supplied |
| positions / 1 / value / 2 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 2 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 2 / attributes / endpoint type | administrative |
| positions / 1 / value / 2 / attributes / follow up | one calendar year |
| positions / 1 / value / 2 / attributes / formulation | Not supplied |
| positions / 1 / value / 2 / attributes / intervention | four-day working week |
| positions / 1 / value / 2 / attributes / population | office staff |
| positions / 1 / value / 2 / attributes / relation | description |
| positions / 1 / value / 2 / attributes / route | Not supplied |
| positions / 1 / value / 2 / attributes / species | human |
| positions / 1 / value / 2 / cohort id | Not supplied |
| positions / 1 / value / 2 / dataset id | Not supplied |
| positions / 1 / value / 2 / design limitations | No entries recorded |
| positions / 1 / value / 2 / evidence id | e2 |
| positions / 1 / value / 2 / evidence type | descriptive |
| positions / 1 / value / 2 / identification argument | Not supplied |
| positions / 1 / value / 2 / identification evidence ids | No entries recorded |
| positions / 1 / value / 2 / randomized | Not supplied |
| positions / 1 / value / 2 / source role | company report note on a confounder |
| positions / 1 / value / 2 / study id | Not supplied |
| positions / 1 / value / 2 / underlying evidence ids | No entries recorded |
| positions / 1 / value / 3 / attributes / certainty | Not supplied |
| positions / 1 / value / 3 / attributes / comparator | previous year |
| positions / 1 / value / 3 / attributes / comparison | Not supplied |
| positions / 1 / value / 3 / attributes / dose | Not supplied |
| positions / 1 / value / 3 / attributes / effect basis | Not supplied |
| positions / 1 / value / 3 / attributes / effect direction | Not supplied |
| positions / 1 / value / 3 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 3 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 3 / attributes / endpoint type | administrative |
| positions / 1 / value / 3 / attributes / follow up | one calendar year |
| positions / 1 / value / 3 / attributes / formulation | Not supplied |
| positions / 1 / value / 3 / attributes / intervention | four-day working week |
| positions / 1 / value / 3 / attributes / population | office staff |
| positions / 1 / value / 3 / attributes / relation | description |
| positions / 1 / value / 3 / attributes / route | Not supplied |
| positions / 1 / value / 3 / attributes / species | human |
| positions / 1 / value / 3 / cohort id | Not supplied |
| positions / 1 / value / 3 / dataset id | Not supplied |
| positions / 1 / value / 3 / design limitations | No entries recorded |
| positions / 1 / value / 3 / evidence id | e3 |
| positions / 1 / value / 3 / evidence type | descriptive |
| positions / 1 / value / 3 / identification argument | Not supplied |
| positions / 1 / value / 3 / identification evidence ids | No entries recorded |
| positions / 1 / value / 3 / randomized | Not supplied |
| positions / 1 / value / 3 / source role | company report omission of a control group |
| positions / 1 / value / 3 / study id | Not supplied |
| positions / 1 / value / 3 / underlying evidence ids | No entries recorded |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value / 1 / attributes / certainty | definite |
| positions / 2 / value / 1 / attributes / comparator | previous year |
| positions / 2 / value / 1 / attributes / comparison | Not supplied |
| positions / 2 / value / 1 / attributes / dose | Not supplied |
| positions / 2 / value / 1 / attributes / effect basis | Not supplied |
| positions / 2 / value / 1 / attributes / effect direction | decrease |
| positions / 2 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 1 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 1 / attributes / endpoint type | descriptive |
| positions / 2 / value / 1 / attributes / follow up | one year |
| positions / 2 / value / 1 / attributes / formulation | Not supplied |
| positions / 2 / value / 1 / attributes / intervention | four-day working week |
| positions / 2 / value / 1 / attributes / population | office staff at a logistics company |
| positions / 2 / value / 1 / attributes / relation | association |
| positions / 2 / value / 1 / attributes / route | Not supplied |
| positions / 2 / value / 1 / attributes / species | human |
| positions / 2 / value / 1 / cohort id | Not supplied |
| positions / 2 / value / 1 / dataset id | Not supplied |
| positions / 2 / value / 1 / design limitations | Year-over-year comparison without a concurrent control group<br>The previous year was affected by a severe influenza season |
| positions / 2 / value / 1 / evidence id | e1 |
| positions / 2 / value / 1 / evidence type | observational |
| positions / 2 / value / 1 / identification argument | Not supplied |
| positions / 2 / value / 1 / identification evidence ids | No entries recorded |
| positions / 2 / value / 1 / randomized | false |
| positions / 2 / value / 1 / source role | company annual report&#58; before/after sick-day figures |
| positions / 2 / value / 1 / study id | Not supplied |
| positions / 2 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 2 / value / 2 / attributes / certainty | Not supplied |
| positions / 2 / value / 2 / attributes / comparator | Not supplied |
| positions / 2 / value / 2 / attributes / comparison | Not supplied |
| positions / 2 / value / 2 / attributes / dose | Not supplied |
| positions / 2 / value / 2 / attributes / effect basis | Not supplied |
| positions / 2 / value / 2 / attributes / effect direction | Not supplied |
| positions / 2 / value / 2 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 2 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 2 / attributes / endpoint type | Not supplied |
| positions / 2 / value / 2 / attributes / follow up | Not supplied |
| positions / 2 / value / 2 / attributes / formulation | Not supplied |
| positions / 2 / value / 2 / attributes / intervention | Not supplied |
| positions / 2 / value / 2 / attributes / population | Not supplied |
| positions / 2 / value / 2 / attributes / relation | description |
| positions / 2 / value / 2 / attributes / route | Not supplied |
| positions / 2 / value / 2 / attributes / species | human |
| positions / 2 / value / 2 / cohort id | Not supplied |
| positions / 2 / value / 2 / dataset id | Not supplied |
| positions / 2 / value / 2 / design limitations | No entries recorded |
| positions / 2 / value / 2 / evidence id | e2 |
| positions / 2 / value / 2 / evidence type | descriptive |
| positions / 2 / value / 2 / identification argument | Not supplied |
| positions / 2 / value / 2 / identification evidence ids | No entries recorded |
| positions / 2 / value / 2 / randomized | Not supplied |
| positions / 2 / value / 2 / source role | company annual report&#58; confounder note |
| positions / 2 / value / 2 / study id | Not supplied |
| positions / 2 / value / 2 / underlying evidence ids | No entries recorded |
| positions / 2 / value / 3 / attributes / certainty | Not supplied |
| positions / 2 / value / 3 / attributes / comparator | Not supplied |
| positions / 2 / value / 3 / attributes / comparison | Not supplied |
| positions / 2 / value / 3 / attributes / dose | Not supplied |
| positions / 2 / value / 3 / attributes / effect basis | Not supplied |
| positions / 2 / value / 3 / attributes / effect direction | Not supplied |
| positions / 2 / value / 3 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 3 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 3 / attributes / endpoint type | Not supplied |
| positions / 2 / value / 3 / attributes / follow up | Not supplied |
| positions / 2 / value / 3 / attributes / formulation | Not supplied |
| positions / 2 / value / 3 / attributes / intervention | Not supplied |
| positions / 2 / value / 3 / attributes / population | Not supplied |
| positions / 2 / value / 3 / attributes / relation | description |
| positions / 2 / value / 3 / attributes / route | Not supplied |
| positions / 2 / value / 3 / attributes / species | human |
| positions / 2 / value / 3 / cohort id | Not supplied |
| positions / 2 / value / 3 / dataset id | Not supplied |
| positions / 2 / value / 3 / design limitations | No entries recorded |
| positions / 2 / value / 3 / evidence id | e3 |
| positions / 2 / value / 3 / evidence type | descriptive |
| positions / 2 / value / 3 / identification argument | Not supplied |
| positions / 2 / value / 3 / identification evidence ids | No entries recorded |
| positions / 2 / value / 3 / randomized | Not supplied |
| positions / 2 / value / 3 / source role | company annual report&#58; absence of a comparison group |
| positions / 2 / value / 3 / study id | Not supplied |
| positions / 2 / value / 3 / underlying evidence ids | No entries recorded |
| projected object fingerprint | bb7b15ad994b09788d9021246048c90526e2e34d7fece48a25a7ed56eda52ad6 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/13 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;962d9abdbb9dfa2997be0ca2 |
| field | propositions.claim&#58;p1.attributes.effect&#95;direction |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 1 / value | Not supplied |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | decrease |
| projected object fingerprint | 65704a2b1f9965d8cd2abeeb609993eea538bee5deb68140d8c17ae1e1a40a13 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/14 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;ad14c1ffd3aea4098f9d429d |
| field | propositions.claim&#58;p1.attributes.follow&#95;up |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | one calendar year |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value | Not supplied |
| projected object fingerprint | 198b939c4702dbcfdb37e462162efa66ae5c5e1ba128ff99b7fa96726ac6649a |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/15 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;be713c26f092fbb6b65c263e |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value / 1 / attributes / certainty | reported |
| positions / 1 / value / 1 / attributes / comparator | previous year |
| positions / 1 / value / 1 / attributes / comparison | Not supplied |
| positions / 1 / value / 1 / attributes / dose | Not supplied |
| positions / 1 / value / 1 / attributes / effect basis | Not supplied |
| positions / 1 / value / 1 / attributes / effect direction | decrease |
| positions / 1 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 1 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 1 / attributes / endpoint type | administrative |
| positions / 1 / value / 1 / attributes / follow up | one calendar year |
| positions / 1 / value / 1 / attributes / formulation | Not supplied |
| positions / 1 / value / 1 / attributes / intervention | four-day working week |
| positions / 1 / value / 1 / attributes / population | office staff |
| positions / 1 / value / 1 / attributes / relation | association |
| positions / 1 / value / 1 / attributes / route | Not supplied |
| positions / 1 / value / 1 / attributes / species | human |
| positions / 1 / value / 1 / cohort id | Not supplied |
| positions / 1 / value / 1 / dataset id | Not supplied |
| positions / 1 / value / 1 / design limitations | before/after comparison<br>no concurrent control group<br>confounded by influenza season |
| positions / 1 / value / 1 / evidence id | e1 |
| positions / 1 / value / 1 / evidence type | descriptive |
| positions / 1 / value / 1 / identification argument | Not supplied |
| positions / 1 / value / 1 / identification evidence ids | No entries recorded |
| positions / 1 / value / 1 / randomized | false |
| positions / 1 / value / 1 / source role | company annual report statement of year-on-year change |
| positions / 1 / value / 1 / study id | Not supplied |
| positions / 1 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 1 / value / 2 / attributes / certainty | Not supplied |
| positions / 1 / value / 2 / attributes / comparator | previous year |
| positions / 1 / value / 2 / attributes / comparison | Not supplied |
| positions / 1 / value / 2 / attributes / dose | Not supplied |
| positions / 1 / value / 2 / attributes / effect basis | Not supplied |
| positions / 1 / value / 2 / attributes / effect direction | Not supplied |
| positions / 1 / value / 2 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 2 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 2 / attributes / endpoint type | administrative |
| positions / 1 / value / 2 / attributes / follow up | one calendar year |
| positions / 1 / value / 2 / attributes / formulation | Not supplied |
| positions / 1 / value / 2 / attributes / intervention | four-day working week |
| positions / 1 / value / 2 / attributes / population | office staff |
| positions / 1 / value / 2 / attributes / relation | description |
| positions / 1 / value / 2 / attributes / route | Not supplied |
| positions / 1 / value / 2 / attributes / species | human |
| positions / 1 / value / 2 / cohort id | Not supplied |
| positions / 1 / value / 2 / dataset id | Not supplied |
| positions / 1 / value / 2 / design limitations | No entries recorded |
| positions / 1 / value / 2 / evidence id | e2 |
| positions / 1 / value / 2 / evidence type | descriptive |
| positions / 1 / value / 2 / identification argument | Not supplied |
| positions / 1 / value / 2 / identification evidence ids | No entries recorded |
| positions / 1 / value / 2 / randomized | Not supplied |
| positions / 1 / value / 2 / source role | company report note on a confounder |
| positions / 1 / value / 2 / study id | Not supplied |
| positions / 1 / value / 2 / underlying evidence ids | No entries recorded |
| positions / 1 / value / 3 / attributes / certainty | Not supplied |
| positions / 1 / value / 3 / attributes / comparator | previous year |
| positions / 1 / value / 3 / attributes / comparison | Not supplied |
| positions / 1 / value / 3 / attributes / dose | Not supplied |
| positions / 1 / value / 3 / attributes / effect basis | Not supplied |
| positions / 1 / value / 3 / attributes / effect direction | Not supplied |
| positions / 1 / value / 3 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 3 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 3 / attributes / endpoint type | administrative |
| positions / 1 / value / 3 / attributes / follow up | one calendar year |
| positions / 1 / value / 3 / attributes / formulation | Not supplied |
| positions / 1 / value / 3 / attributes / intervention | four-day working week |
| positions / 1 / value / 3 / attributes / population | office staff |
| positions / 1 / value / 3 / attributes / relation | description |
| positions / 1 / value / 3 / attributes / route | Not supplied |
| positions / 1 / value / 3 / attributes / species | human |
| positions / 1 / value / 3 / cohort id | Not supplied |
| positions / 1 / value / 3 / dataset id | Not supplied |
| positions / 1 / value / 3 / design limitations | No entries recorded |
| positions / 1 / value / 3 / evidence id | e3 |
| positions / 1 / value / 3 / evidence type | descriptive |
| positions / 1 / value / 3 / identification argument | Not supplied |
| positions / 1 / value / 3 / identification evidence ids | No entries recorded |
| positions / 1 / value / 3 / randomized | Not supplied |
| positions / 1 / value / 3 / source role | company report omission of a control group |
| positions / 1 / value / 3 / study id | Not supplied |
| positions / 1 / value / 3 / underlying evidence ids | No entries recorded |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value / 1 / attributes / certainty | Not supplied |
| positions / 2 / value / 1 / attributes / comparator | Not supplied |
| positions / 2 / value / 1 / attributes / comparison | Not supplied |
| positions / 2 / value / 1 / attributes / dose | Not supplied |
| positions / 2 / value / 1 / attributes / effect basis | Not supplied |
| positions / 2 / value / 1 / attributes / effect direction | Not supplied |
| positions / 2 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 1 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 1 / attributes / endpoint type | administrative |
| positions / 2 / value / 1 / attributes / follow up | Not supplied |
| positions / 2 / value / 1 / attributes / formulation | Not supplied |
| positions / 2 / value / 1 / attributes / intervention | four-day working week |
| positions / 2 / value / 1 / attributes / population | office staff at a logistics company |
| positions / 2 / value / 1 / attributes / relation | association |
| positions / 2 / value / 1 / attributes / route | Not supplied |
| positions / 2 / value / 1 / attributes / species | human |
| positions / 2 / value / 1 / cohort id | Not supplied |
| positions / 2 / value / 1 / dataset id | Not supplied |
| positions / 2 / value / 1 / design limitations | before/after comparison with the previous year<br>no concurrent control group<br>previous year affected by a severe influenza season |
| positions / 2 / value / 1 / evidence id | e1 |
| positions / 2 / value / 1 / evidence type | descriptive |
| positions / 2 / value / 1 / identification argument | Not supplied |
| positions / 2 / value / 1 / identification evidence ids | No entries recorded |
| positions / 2 / value / 1 / randomized | Not supplied |
| positions / 2 / value / 1 / source role | company annual report statement quoted in the context |
| positions / 2 / value / 1 / study id | Not supplied |
| positions / 2 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 2 / value / 2 / attributes / certainty | Not supplied |
| positions / 2 / value / 2 / attributes / comparator | Not supplied |
| positions / 2 / value / 2 / attributes / comparison | Not supplied |
| positions / 2 / value / 2 / attributes / dose | Not supplied |
| positions / 2 / value / 2 / attributes / effect basis | Not supplied |
| positions / 2 / value / 2 / attributes / effect direction | Not supplied |
| positions / 2 / value / 2 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 2 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 2 / attributes / endpoint type | administrative |
| positions / 2 / value / 2 / attributes / follow up | Not supplied |
| positions / 2 / value / 2 / attributes / formulation | Not supplied |
| positions / 2 / value / 2 / attributes / intervention | four-day working week |
| positions / 2 / value / 2 / attributes / population | office staff at a logistics company |
| positions / 2 / value / 2 / attributes / relation | description |
| positions / 2 / value / 2 / attributes / route | Not supplied |
| positions / 2 / value / 2 / attributes / species | human |
| positions / 2 / value / 2 / cohort id | Not supplied |
| positions / 2 / value / 2 / dataset id | Not supplied |
| positions / 2 / value / 2 / design limitations | absence of a comparison group |
| positions / 2 / value / 2 / evidence id | e3 |
| positions / 2 / value / 2 / evidence type | descriptive |
| positions / 2 / value / 2 / identification argument | Not supplied |
| positions / 2 / value / 2 / identification evidence ids | No entries recorded |
| positions / 2 / value / 2 / randomized | Not supplied |
| positions / 2 / value / 2 / source role | annual report limitation quoted in the context |
| positions / 2 / value / 2 / study id | Not supplied |
| positions / 2 / value / 2 / underlying evidence ids | No entries recorded |
| positions / 2 / value / 3 / attributes / certainty | Not supplied |
| positions / 2 / value / 3 / attributes / comparator | Not supplied |
| positions / 2 / value / 3 / attributes / comparison | Not supplied |
| positions / 2 / value / 3 / attributes / dose | Not supplied |
| positions / 2 / value / 3 / attributes / effect basis | Not supplied |
| positions / 2 / value / 3 / attributes / effect direction | Not supplied |
| positions / 2 / value / 3 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 3 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 3 / attributes / endpoint type | administrative |
| positions / 2 / value / 3 / attributes / follow up | Not supplied |
| positions / 2 / value / 3 / attributes / formulation | Not supplied |
| positions / 2 / value / 3 / attributes / intervention | four-day working week |
| positions / 2 / value / 3 / attributes / population | office staff at a logistics company |
| positions / 2 / value / 3 / attributes / relation | description |
| positions / 2 / value / 3 / attributes / route | Not supplied |
| positions / 2 / value / 3 / attributes / species | human |
| positions / 2 / value / 3 / cohort id | Not supplied |
| positions / 2 / value / 3 / dataset id | Not supplied |
| positions / 2 / value / 3 / design limitations | describes a confounder, not an outcome comparison |
| positions / 2 / value / 3 / evidence id | e2 |
| positions / 2 / value / 3 / evidence type | descriptive |
| positions / 2 / value / 3 / identification argument | Not supplied |
| positions / 2 / value / 3 / identification evidence ids | No entries recorded |
| positions / 2 / value / 3 / randomized | Not supplied |
| positions / 2 / value / 3 / source role | annual report note quoted in the context |
| positions / 2 / value / 3 / study id | Not supplied |
| positions / 2 / value / 3 / underlying evidence ids | No entries recorded |
| projected object fingerprint | c335ad57ee5a962f9c8c5301020c5938f73fce74084c22319a2e3878cc1fb68d |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/16 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;d7054e912d2730d2d27955d8 |
| field | propositions.claim&#58;p1.output&#95;transformations |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value / 1 / 1 | extraction |
| positions / 1 / value / 1 / 2 / certainty | definite |
| positions / 1 / value / 1 / 2 / comparator | previous year |
| positions / 1 / value / 1 / 2 / comparison | Not supplied |
| positions / 1 / value / 1 / 2 / dose | Not supplied |
| positions / 1 / value / 1 / 2 / effect basis | Not supplied |
| positions / 1 / value / 1 / 2 / effect direction | decrease |
| positions / 1 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 1 / 2 / endpoint type | administrative |
| positions / 1 / value / 1 / 2 / follow up | one calendar year |
| positions / 1 / value / 1 / 2 / formulation | Not supplied |
| positions / 1 / value / 1 / 2 / intervention | four-day working week |
| positions / 1 / value / 1 / 2 / population | office staff |
| positions / 1 / value / 1 / 2 / relation | causal |
| positions / 1 / value / 1 / 2 / route | Not supplied |
| positions / 1 / value / 1 / 2 / species | human |
| positions / 1 / value / 1 / 3 / certainty | definite |
| positions / 1 / value / 1 / 3 / comparator | previous year |
| positions / 1 / value / 1 / 3 / comparison | Not supplied |
| positions / 1 / value / 1 / 3 / dose | Not supplied |
| positions / 1 / value / 1 / 3 / effect basis | Not supplied |
| positions / 1 / value / 1 / 3 / effect direction | decrease |
| positions / 1 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 1 / 3 / endpoint type | administrative |
| positions / 1 / value / 1 / 3 / follow up | one calendar year |
| positions / 1 / value / 1 / 3 / formulation | Not supplied |
| positions / 1 / value / 1 / 3 / intervention | four-day working week |
| positions / 1 / value / 1 / 3 / population | office staff |
| positions / 1 / value / 1 / 3 / relation | causal |
| positions / 1 / value / 1 / 3 / route | Not supplied |
| positions / 1 / value / 1 / 3 / species | human |
| positions / 1 / value / 1 / 4 | unsupported |
| positions / 1 / value / 1 / 5 | false |
| positions / 1 / value / 2 / 1 | internal |
| positions / 1 / value / 2 / 2 / certainty | definite |
| positions / 1 / value / 2 / 2 / comparator | previous year |
| positions / 1 / value / 2 / 2 / comparison | Not supplied |
| positions / 1 / value / 2 / 2 / dose | Not supplied |
| positions / 1 / value / 2 / 2 / effect basis | Not supplied |
| positions / 1 / value / 2 / 2 / effect direction | decrease |
| positions / 1 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 2 / 2 / endpoint type | administrative |
| positions / 1 / value / 2 / 2 / follow up | one calendar year |
| positions / 1 / value / 2 / 2 / formulation | Not supplied |
| positions / 1 / value / 2 / 2 / intervention | four-day working week |
| positions / 1 / value / 2 / 2 / population | office staff |
| positions / 1 / value / 2 / 2 / relation | causal |
| positions / 1 / value / 2 / 2 / route | Not supplied |
| positions / 1 / value / 2 / 2 / species | human |
| positions / 1 / value / 2 / 3 / certainty | definite |
| positions / 1 / value / 2 / 3 / comparator | previous year |
| positions / 1 / value / 2 / 3 / comparison | Not supplied |
| positions / 1 / value / 2 / 3 / dose | Not supplied |
| positions / 1 / value / 2 / 3 / effect basis | Not supplied |
| positions / 1 / value / 2 / 3 / effect direction | decrease |
| positions / 1 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 2 / 3 / endpoint type | administrative |
| positions / 1 / value / 2 / 3 / follow up | one calendar year |
| positions / 1 / value / 2 / 3 / formulation | Not supplied |
| positions / 1 / value / 2 / 3 / intervention | four-day working week |
| positions / 1 / value / 2 / 3 / population | office staff |
| positions / 1 / value / 2 / 3 / relation | causal |
| positions / 1 / value / 2 / 3 / route | Not supplied |
| positions / 1 / value / 2 / 3 / species | human |
| positions / 1 / value / 2 / 4 | unsupported |
| positions / 1 / value / 2 / 5 | false |
| positions / 1 / value / 3 / 1 | search&#95;question |
| positions / 1 / value / 3 / 2 / certainty | definite |
| positions / 1 / value / 3 / 2 / comparator | previous year |
| positions / 1 / value / 3 / 2 / comparison | Not supplied |
| positions / 1 / value / 3 / 2 / dose | Not supplied |
| positions / 1 / value / 3 / 2 / effect basis | Not supplied |
| positions / 1 / value / 3 / 2 / effect direction | decrease |
| positions / 1 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 3 / 2 / endpoint type | administrative |
| positions / 1 / value / 3 / 2 / follow up | one calendar year |
| positions / 1 / value / 3 / 2 / formulation | Not supplied |
| positions / 1 / value / 3 / 2 / intervention | four-day working week |
| positions / 1 / value / 3 / 2 / population | office staff |
| positions / 1 / value / 3 / 2 / relation | causal |
| positions / 1 / value / 3 / 2 / route | Not supplied |
| positions / 1 / value / 3 / 2 / species | human |
| positions / 1 / value / 3 / 3 / certainty | definite |
| positions / 1 / value / 3 / 3 / comparator | previous year |
| positions / 1 / value / 3 / 3 / comparison | Not supplied |
| positions / 1 / value / 3 / 3 / dose | Not supplied |
| positions / 1 / value / 3 / 3 / effect basis | Not supplied |
| positions / 1 / value / 3 / 3 / effect direction | decrease |
| positions / 1 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 3 / 3 / endpoint type | administrative |
| positions / 1 / value / 3 / 3 / follow up | one calendar year |
| positions / 1 / value / 3 / 3 / formulation | Not supplied |
| positions / 1 / value / 3 / 3 / intervention | four-day working week |
| positions / 1 / value / 3 / 3 / population | office staff |
| positions / 1 / value / 3 / 3 / relation | causal |
| positions / 1 / value / 3 / 3 / route | Not supplied |
| positions / 1 / value / 3 / 3 / species | human |
| positions / 1 / value / 3 / 4 | unsupported |
| positions / 1 / value / 3 / 5 | false |
| positions / 1 / value / 4 / 1 | summary |
| positions / 1 / value / 4 / 2 / certainty | definite |
| positions / 1 / value / 4 / 2 / comparator | previous year |
| positions / 1 / value / 4 / 2 / comparison | Not supplied |
| positions / 1 / value / 4 / 2 / dose | Not supplied |
| positions / 1 / value / 4 / 2 / effect basis | Not supplied |
| positions / 1 / value / 4 / 2 / effect direction | decrease |
| positions / 1 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 4 / 2 / endpoint type | administrative |
| positions / 1 / value / 4 / 2 / follow up | one calendar year |
| positions / 1 / value / 4 / 2 / formulation | Not supplied |
| positions / 1 / value / 4 / 2 / intervention | four-day working week |
| positions / 1 / value / 4 / 2 / population | office staff |
| positions / 1 / value / 4 / 2 / relation | causal |
| positions / 1 / value / 4 / 2 / route | Not supplied |
| positions / 1 / value / 4 / 2 / species | human |
| positions / 1 / value / 4 / 3 / certainty | definite |
| positions / 1 / value / 4 / 3 / comparator | previous year |
| positions / 1 / value / 4 / 3 / comparison | Not supplied |
| positions / 1 / value / 4 / 3 / dose | Not supplied |
| positions / 1 / value / 4 / 3 / effect basis | Not supplied |
| positions / 1 / value / 4 / 3 / effect direction | decrease |
| positions / 1 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 4 / 3 / endpoint type | administrative |
| positions / 1 / value / 4 / 3 / follow up | one calendar year |
| positions / 1 / value / 4 / 3 / formulation | Not supplied |
| positions / 1 / value / 4 / 3 / intervention | four-day working week |
| positions / 1 / value / 4 / 3 / population | office staff |
| positions / 1 / value / 4 / 3 / relation | causal |
| positions / 1 / value / 4 / 3 / route | Not supplied |
| positions / 1 / value / 4 / 3 / species | human |
| positions / 1 / value / 4 / 4 | unsupported |
| positions / 1 / value / 4 / 5 | true |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 2 / value / 1 / 1 | extraction |
| positions / 2 / value / 1 / 2 / certainty | stated as established fact |
| positions / 2 / value / 1 / 2 / comparator | Not supplied |
| positions / 2 / value / 1 / 2 / comparison | Not supplied |
| positions / 2 / value / 1 / 2 / dose | Not supplied |
| positions / 2 / value / 1 / 2 / effect basis | Not supplied |
| positions / 2 / value / 1 / 2 / effect direction | Not supplied |
| positions / 2 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 1 / 2 / endpoint type | administrative |
| positions / 2 / value / 1 / 2 / follow up | Not supplied |
| positions / 2 / value / 1 / 2 / formulation | Not supplied |
| positions / 2 / value / 1 / 2 / intervention | four-day working week |
| positions / 2 / value / 1 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 1 / 2 / relation | causal |
| positions / 2 / value / 1 / 2 / route | Not supplied |
| positions / 2 / value / 1 / 2 / species | human |
| positions / 2 / value / 1 / 3 / certainty | stated as established fact |
| positions / 2 / value / 1 / 3 / comparator | Not supplied |
| positions / 2 / value / 1 / 3 / comparison | Not supplied |
| positions / 2 / value / 1 / 3 / dose | Not supplied |
| positions / 2 / value / 1 / 3 / effect basis | Not supplied |
| positions / 2 / value / 1 / 3 / effect direction | Not supplied |
| positions / 2 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 1 / 3 / endpoint type | administrative |
| positions / 2 / value / 1 / 3 / follow up | Not supplied |
| positions / 2 / value / 1 / 3 / formulation | Not supplied |
| positions / 2 / value / 1 / 3 / intervention | four-day working week |
| positions / 2 / value / 1 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 1 / 3 / relation | causal |
| positions / 2 / value / 1 / 3 / route | Not supplied |
| positions / 2 / value / 1 / 3 / species | human |
| positions / 2 / value / 1 / 4 | unsupported |
| positions / 2 / value / 1 / 5 | false |
| positions / 2 / value / 2 / 1 | internal |
| positions / 2 / value / 2 / 2 / certainty | stated as established fact |
| positions / 2 / value / 2 / 2 / comparator | Not supplied |
| positions / 2 / value / 2 / 2 / comparison | Not supplied |
| positions / 2 / value / 2 / 2 / dose | Not supplied |
| positions / 2 / value / 2 / 2 / effect basis | Not supplied |
| positions / 2 / value / 2 / 2 / effect direction | Not supplied |
| positions / 2 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 2 / 2 / endpoint type | administrative |
| positions / 2 / value / 2 / 2 / follow up | Not supplied |
| positions / 2 / value / 2 / 2 / formulation | Not supplied |
| positions / 2 / value / 2 / 2 / intervention | four-day working week |
| positions / 2 / value / 2 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 2 / 2 / relation | causal |
| positions / 2 / value / 2 / 2 / route | Not supplied |
| positions / 2 / value / 2 / 2 / species | human |
| positions / 2 / value / 2 / 3 / certainty | stated as established fact |
| positions / 2 / value / 2 / 3 / comparator | Not supplied |
| positions / 2 / value / 2 / 3 / comparison | Not supplied |
| positions / 2 / value / 2 / 3 / dose | Not supplied |
| positions / 2 / value / 2 / 3 / effect basis | Not supplied |
| positions / 2 / value / 2 / 3 / effect direction | Not supplied |
| positions / 2 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 2 / 3 / endpoint type | administrative |
| positions / 2 / value / 2 / 3 / follow up | Not supplied |
| positions / 2 / value / 2 / 3 / formulation | Not supplied |
| positions / 2 / value / 2 / 3 / intervention | four-day working week |
| positions / 2 / value / 2 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 2 / 3 / relation | causal |
| positions / 2 / value / 2 / 3 / route | Not supplied |
| positions / 2 / value / 2 / 3 / species | human |
| positions / 2 / value / 2 / 4 | unsupported |
| positions / 2 / value / 2 / 5 | false |
| positions / 2 / value / 3 / 1 | search&#95;question |
| positions / 2 / value / 3 / 2 / certainty | stated as established fact |
| positions / 2 / value / 3 / 2 / comparator | Not supplied |
| positions / 2 / value / 3 / 2 / comparison | Not supplied |
| positions / 2 / value / 3 / 2 / dose | Not supplied |
| positions / 2 / value / 3 / 2 / effect basis | Not supplied |
| positions / 2 / value / 3 / 2 / effect direction | Not supplied |
| positions / 2 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 3 / 2 / endpoint type | administrative |
| positions / 2 / value / 3 / 2 / follow up | Not supplied |
| positions / 2 / value / 3 / 2 / formulation | Not supplied |
| positions / 2 / value / 3 / 2 / intervention | four-day working week |
| positions / 2 / value / 3 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 3 / 2 / relation | causal |
| positions / 2 / value / 3 / 2 / route | Not supplied |
| positions / 2 / value / 3 / 2 / species | human |
| positions / 2 / value / 3 / 3 / certainty | stated as established fact |
| positions / 2 / value / 3 / 3 / comparator | Not supplied |
| positions / 2 / value / 3 / 3 / comparison | Not supplied |
| positions / 2 / value / 3 / 3 / dose | Not supplied |
| positions / 2 / value / 3 / 3 / effect basis | Not supplied |
| positions / 2 / value / 3 / 3 / effect direction | Not supplied |
| positions / 2 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 3 / 3 / endpoint type | administrative |
| positions / 2 / value / 3 / 3 / follow up | Not supplied |
| positions / 2 / value / 3 / 3 / formulation | Not supplied |
| positions / 2 / value / 3 / 3 / intervention | four-day working week |
| positions / 2 / value / 3 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 3 / 3 / relation | causal |
| positions / 2 / value / 3 / 3 / route | Not supplied |
| positions / 2 / value / 3 / 3 / species | human |
| positions / 2 / value / 3 / 4 | unsupported |
| positions / 2 / value / 3 / 5 | false |
| positions / 2 / value / 4 / 1 | summary |
| positions / 2 / value / 4 / 2 / certainty | stated as established fact |
| positions / 2 / value / 4 / 2 / comparator | Not supplied |
| positions / 2 / value / 4 / 2 / comparison | Not supplied |
| positions / 2 / value / 4 / 2 / dose | Not supplied |
| positions / 2 / value / 4 / 2 / effect basis | Not supplied |
| positions / 2 / value / 4 / 2 / effect direction | Not supplied |
| positions / 2 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 4 / 2 / endpoint type | administrative |
| positions / 2 / value / 4 / 2 / follow up | Not supplied |
| positions / 2 / value / 4 / 2 / formulation | Not supplied |
| positions / 2 / value / 4 / 2 / intervention | four-day working week |
| positions / 2 / value / 4 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 4 / 2 / relation | causal |
| positions / 2 / value / 4 / 2 / route | Not supplied |
| positions / 2 / value / 4 / 2 / species | human |
| positions / 2 / value / 4 / 3 / certainty | stated as established fact |
| positions / 2 / value / 4 / 3 / comparator | Not supplied |
| positions / 2 / value / 4 / 3 / comparison | Not supplied |
| positions / 2 / value / 4 / 3 / dose | Not supplied |
| positions / 2 / value / 4 / 3 / effect basis | Not supplied |
| positions / 2 / value / 4 / 3 / effect direction | Not supplied |
| positions / 2 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 4 / 3 / endpoint type | administrative |
| positions / 2 / value / 4 / 3 / follow up | Not supplied |
| positions / 2 / value / 4 / 3 / formulation | Not supplied |
| positions / 2 / value / 4 / 3 / intervention | four-day working week |
| positions / 2 / value / 4 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 4 / 3 / relation | causal |
| positions / 2 / value / 4 / 3 / route | Not supplied |
| positions / 2 / value / 4 / 3 / species | human |
| positions / 2 / value / 4 / 4 | unsupported |
| positions / 2 / value / 4 / 5 | true |
| projected object fingerprint | 95b55fa99143ac7499e704c47dea4896660471ca4653a3b80b659a5829ebc745 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/17 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;d98d70e6688977568be5d67c |
| field | propositions.claim&#58;p1.output&#95;transformations |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value / 1 / 1 | extraction |
| positions / 1 / value / 1 / 2 / certainty | definite |
| positions / 1 / value / 1 / 2 / comparator | previous year |
| positions / 1 / value / 1 / 2 / comparison | Not supplied |
| positions / 1 / value / 1 / 2 / dose | Not supplied |
| positions / 1 / value / 1 / 2 / effect basis | Not supplied |
| positions / 1 / value / 1 / 2 / effect direction | decrease |
| positions / 1 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 1 / 2 / endpoint type | administrative |
| positions / 1 / value / 1 / 2 / follow up | one calendar year |
| positions / 1 / value / 1 / 2 / formulation | Not supplied |
| positions / 1 / value / 1 / 2 / intervention | four-day working week |
| positions / 1 / value / 1 / 2 / population | office staff |
| positions / 1 / value / 1 / 2 / relation | causal |
| positions / 1 / value / 1 / 2 / route | Not supplied |
| positions / 1 / value / 1 / 2 / species | human |
| positions / 1 / value / 1 / 3 / certainty | definite |
| positions / 1 / value / 1 / 3 / comparator | previous year |
| positions / 1 / value / 1 / 3 / comparison | Not supplied |
| positions / 1 / value / 1 / 3 / dose | Not supplied |
| positions / 1 / value / 1 / 3 / effect basis | Not supplied |
| positions / 1 / value / 1 / 3 / effect direction | decrease |
| positions / 1 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 1 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 1 / 3 / endpoint type | administrative |
| positions / 1 / value / 1 / 3 / follow up | one calendar year |
| positions / 1 / value / 1 / 3 / formulation | Not supplied |
| positions / 1 / value / 1 / 3 / intervention | four-day working week |
| positions / 1 / value / 1 / 3 / population | office staff |
| positions / 1 / value / 1 / 3 / relation | causal |
| positions / 1 / value / 1 / 3 / route | Not supplied |
| positions / 1 / value / 1 / 3 / species | human |
| positions / 1 / value / 1 / 4 | unsupported |
| positions / 1 / value / 1 / 5 | false |
| positions / 1 / value / 2 / 1 | internal |
| positions / 1 / value / 2 / 2 / certainty | definite |
| positions / 1 / value / 2 / 2 / comparator | previous year |
| positions / 1 / value / 2 / 2 / comparison | Not supplied |
| positions / 1 / value / 2 / 2 / dose | Not supplied |
| positions / 1 / value / 2 / 2 / effect basis | Not supplied |
| positions / 1 / value / 2 / 2 / effect direction | decrease |
| positions / 1 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 2 / 2 / endpoint type | administrative |
| positions / 1 / value / 2 / 2 / follow up | one calendar year |
| positions / 1 / value / 2 / 2 / formulation | Not supplied |
| positions / 1 / value / 2 / 2 / intervention | four-day working week |
| positions / 1 / value / 2 / 2 / population | office staff |
| positions / 1 / value / 2 / 2 / relation | causal |
| positions / 1 / value / 2 / 2 / route | Not supplied |
| positions / 1 / value / 2 / 2 / species | human |
| positions / 1 / value / 2 / 3 / certainty | definite |
| positions / 1 / value / 2 / 3 / comparator | previous year |
| positions / 1 / value / 2 / 3 / comparison | Not supplied |
| positions / 1 / value / 2 / 3 / dose | Not supplied |
| positions / 1 / value / 2 / 3 / effect basis | Not supplied |
| positions / 1 / value / 2 / 3 / effect direction | decrease |
| positions / 1 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 2 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 2 / 3 / endpoint type | administrative |
| positions / 1 / value / 2 / 3 / follow up | one calendar year |
| positions / 1 / value / 2 / 3 / formulation | Not supplied |
| positions / 1 / value / 2 / 3 / intervention | four-day working week |
| positions / 1 / value / 2 / 3 / population | office staff |
| positions / 1 / value / 2 / 3 / relation | causal |
| positions / 1 / value / 2 / 3 / route | Not supplied |
| positions / 1 / value / 2 / 3 / species | human |
| positions / 1 / value / 2 / 4 | unsupported |
| positions / 1 / value / 2 / 5 | false |
| positions / 1 / value / 3 / 1 | search&#95;question |
| positions / 1 / value / 3 / 2 / certainty | definite |
| positions / 1 / value / 3 / 2 / comparator | previous year |
| positions / 1 / value / 3 / 2 / comparison | Not supplied |
| positions / 1 / value / 3 / 2 / dose | Not supplied |
| positions / 1 / value / 3 / 2 / effect basis | Not supplied |
| positions / 1 / value / 3 / 2 / effect direction | decrease |
| positions / 1 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 3 / 2 / endpoint type | administrative |
| positions / 1 / value / 3 / 2 / follow up | one calendar year |
| positions / 1 / value / 3 / 2 / formulation | Not supplied |
| positions / 1 / value / 3 / 2 / intervention | four-day working week |
| positions / 1 / value / 3 / 2 / population | office staff |
| positions / 1 / value / 3 / 2 / relation | causal |
| positions / 1 / value / 3 / 2 / route | Not supplied |
| positions / 1 / value / 3 / 2 / species | human |
| positions / 1 / value / 3 / 3 / certainty | definite |
| positions / 1 / value / 3 / 3 / comparator | previous year |
| positions / 1 / value / 3 / 3 / comparison | Not supplied |
| positions / 1 / value / 3 / 3 / dose | Not supplied |
| positions / 1 / value / 3 / 3 / effect basis | Not supplied |
| positions / 1 / value / 3 / 3 / effect direction | decrease |
| positions / 1 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 3 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 3 / 3 / endpoint type | administrative |
| positions / 1 / value / 3 / 3 / follow up | one calendar year |
| positions / 1 / value / 3 / 3 / formulation | Not supplied |
| positions / 1 / value / 3 / 3 / intervention | four-day working week |
| positions / 1 / value / 3 / 3 / population | office staff |
| positions / 1 / value / 3 / 3 / relation | causal |
| positions / 1 / value / 3 / 3 / route | Not supplied |
| positions / 1 / value / 3 / 3 / species | human |
| positions / 1 / value / 3 / 4 | unsupported |
| positions / 1 / value / 3 / 5 | false |
| positions / 1 / value / 4 / 1 | summary |
| positions / 1 / value / 4 / 2 / certainty | definite |
| positions / 1 / value / 4 / 2 / comparator | previous year |
| positions / 1 / value / 4 / 2 / comparison | Not supplied |
| positions / 1 / value / 4 / 2 / dose | Not supplied |
| positions / 1 / value / 4 / 2 / effect basis | Not supplied |
| positions / 1 / value / 4 / 2 / effect direction | decrease |
| positions / 1 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 2 / endpoint | recorded sick days |
| positions / 1 / value / 4 / 2 / endpoint type | administrative |
| positions / 1 / value / 4 / 2 / follow up | one calendar year |
| positions / 1 / value / 4 / 2 / formulation | Not supplied |
| positions / 1 / value / 4 / 2 / intervention | four-day working week |
| positions / 1 / value / 4 / 2 / population | office staff |
| positions / 1 / value / 4 / 2 / relation | causal |
| positions / 1 / value / 4 / 2 / route | Not supplied |
| positions / 1 / value / 4 / 2 / species | human |
| positions / 1 / value / 4 / 3 / certainty | definite |
| positions / 1 / value / 4 / 3 / comparator | previous year |
| positions / 1 / value / 4 / 3 / comparison | Not supplied |
| positions / 1 / value / 4 / 3 / dose | Not supplied |
| positions / 1 / value / 4 / 3 / effect basis | Not supplied |
| positions / 1 / value / 4 / 3 / effect direction | decrease |
| positions / 1 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 1 / value / 4 / 3 / endpoint | recorded sick days |
| positions / 1 / value / 4 / 3 / endpoint type | administrative |
| positions / 1 / value / 4 / 3 / follow up | one calendar year |
| positions / 1 / value / 4 / 3 / formulation | Not supplied |
| positions / 1 / value / 4 / 3 / intervention | four-day working week |
| positions / 1 / value / 4 / 3 / population | office staff |
| positions / 1 / value / 4 / 3 / relation | causal |
| positions / 1 / value / 4 / 3 / route | Not supplied |
| positions / 1 / value / 4 / 3 / species | human |
| positions / 1 / value / 4 / 4 | unsupported |
| positions / 1 / value / 4 / 5 | true |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value / 1 / 1 | extraction |
| positions / 2 / value / 1 / 2 / certainty | definite |
| positions / 2 / value / 1 / 2 / comparator | Not supplied |
| positions / 2 / value / 1 / 2 / comparison | Not supplied |
| positions / 2 / value / 1 / 2 / dose | Not supplied |
| positions / 2 / value / 1 / 2 / effect basis | Not supplied |
| positions / 2 / value / 1 / 2 / effect direction | decrease |
| positions / 2 / value / 1 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 1 / 2 / endpoint type | descriptive |
| positions / 2 / value / 1 / 2 / follow up | Not supplied |
| positions / 2 / value / 1 / 2 / formulation | Not supplied |
| positions / 2 / value / 1 / 2 / intervention | four-day working week |
| positions / 2 / value / 1 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 1 / 2 / relation | causal |
| positions / 2 / value / 1 / 2 / route | Not supplied |
| positions / 2 / value / 1 / 2 / species | human |
| positions / 2 / value / 1 / 3 / certainty | definite |
| positions / 2 / value / 1 / 3 / comparator | Not supplied |
| positions / 2 / value / 1 / 3 / comparison | Not supplied |
| positions / 2 / value / 1 / 3 / dose | Not supplied |
| positions / 2 / value / 1 / 3 / effect basis | Not supplied |
| positions / 2 / value / 1 / 3 / effect direction | decrease |
| positions / 2 / value / 1 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 1 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 1 / 3 / endpoint type | descriptive |
| positions / 2 / value / 1 / 3 / follow up | Not supplied |
| positions / 2 / value / 1 / 3 / formulation | Not supplied |
| positions / 2 / value / 1 / 3 / intervention | four-day working week |
| positions / 2 / value / 1 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 1 / 3 / relation | causal |
| positions / 2 / value / 1 / 3 / route | Not supplied |
| positions / 2 / value / 1 / 3 / species | human |
| positions / 2 / value / 1 / 4 | unsupported |
| positions / 2 / value / 1 / 5 | false |
| positions / 2 / value / 2 / 1 | internal |
| positions / 2 / value / 2 / 2 / certainty | definite |
| positions / 2 / value / 2 / 2 / comparator | Not supplied |
| positions / 2 / value / 2 / 2 / comparison | Not supplied |
| positions / 2 / value / 2 / 2 / dose | Not supplied |
| positions / 2 / value / 2 / 2 / effect basis | Not supplied |
| positions / 2 / value / 2 / 2 / effect direction | decrease |
| positions / 2 / value / 2 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 2 / 2 / endpoint type | descriptive |
| positions / 2 / value / 2 / 2 / follow up | Not supplied |
| positions / 2 / value / 2 / 2 / formulation | Not supplied |
| positions / 2 / value / 2 / 2 / intervention | four-day working week |
| positions / 2 / value / 2 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 2 / 2 / relation | causal |
| positions / 2 / value / 2 / 2 / route | Not supplied |
| positions / 2 / value / 2 / 2 / species | human |
| positions / 2 / value / 2 / 3 / certainty | definite |
| positions / 2 / value / 2 / 3 / comparator | Not supplied |
| positions / 2 / value / 2 / 3 / comparison | Not supplied |
| positions / 2 / value / 2 / 3 / dose | Not supplied |
| positions / 2 / value / 2 / 3 / effect basis | Not supplied |
| positions / 2 / value / 2 / 3 / effect direction | decrease |
| positions / 2 / value / 2 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 2 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 2 / 3 / endpoint type | descriptive |
| positions / 2 / value / 2 / 3 / follow up | Not supplied |
| positions / 2 / value / 2 / 3 / formulation | Not supplied |
| positions / 2 / value / 2 / 3 / intervention | four-day working week |
| positions / 2 / value / 2 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 2 / 3 / relation | causal |
| positions / 2 / value / 2 / 3 / route | Not supplied |
| positions / 2 / value / 2 / 3 / species | human |
| positions / 2 / value / 2 / 4 | unsupported |
| positions / 2 / value / 2 / 5 | false |
| positions / 2 / value / 3 / 1 | search&#95;question |
| positions / 2 / value / 3 / 2 / certainty | definite |
| positions / 2 / value / 3 / 2 / comparator | Not supplied |
| positions / 2 / value / 3 / 2 / comparison | Not supplied |
| positions / 2 / value / 3 / 2 / dose | Not supplied |
| positions / 2 / value / 3 / 2 / effect basis | Not supplied |
| positions / 2 / value / 3 / 2 / effect direction | decrease |
| positions / 2 / value / 3 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 3 / 2 / endpoint type | descriptive |
| positions / 2 / value / 3 / 2 / follow up | Not supplied |
| positions / 2 / value / 3 / 2 / formulation | Not supplied |
| positions / 2 / value / 3 / 2 / intervention | four-day working week |
| positions / 2 / value / 3 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 3 / 2 / relation | causal |
| positions / 2 / value / 3 / 2 / route | Not supplied |
| positions / 2 / value / 3 / 2 / species | human |
| positions / 2 / value / 3 / 3 / certainty | definite |
| positions / 2 / value / 3 / 3 / comparator | Not supplied |
| positions / 2 / value / 3 / 3 / comparison | Not supplied |
| positions / 2 / value / 3 / 3 / dose | Not supplied |
| positions / 2 / value / 3 / 3 / effect basis | Not supplied |
| positions / 2 / value / 3 / 3 / effect direction | decrease |
| positions / 2 / value / 3 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 3 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 3 / 3 / endpoint type | descriptive |
| positions / 2 / value / 3 / 3 / follow up | Not supplied |
| positions / 2 / value / 3 / 3 / formulation | Not supplied |
| positions / 2 / value / 3 / 3 / intervention | four-day working week |
| positions / 2 / value / 3 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 3 / 3 / relation | causal |
| positions / 2 / value / 3 / 3 / route | Not supplied |
| positions / 2 / value / 3 / 3 / species | human |
| positions / 2 / value / 3 / 4 | unsupported |
| positions / 2 / value / 3 / 5 | false |
| positions / 2 / value / 4 / 1 | summary |
| positions / 2 / value / 4 / 2 / certainty | definite |
| positions / 2 / value / 4 / 2 / comparator | Not supplied |
| positions / 2 / value / 4 / 2 / comparison | Not supplied |
| positions / 2 / value / 4 / 2 / dose | Not supplied |
| positions / 2 / value / 4 / 2 / effect basis | Not supplied |
| positions / 2 / value / 4 / 2 / effect direction | decrease |
| positions / 2 / value / 4 / 2 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 2 / endpoint | recorded sick days |
| positions / 2 / value / 4 / 2 / endpoint type | descriptive |
| positions / 2 / value / 4 / 2 / follow up | Not supplied |
| positions / 2 / value / 4 / 2 / formulation | Not supplied |
| positions / 2 / value / 4 / 2 / intervention | four-day working week |
| positions / 2 / value / 4 / 2 / population | office staff at a logistics company |
| positions / 2 / value / 4 / 2 / relation | causal |
| positions / 2 / value / 4 / 2 / route | Not supplied |
| positions / 2 / value / 4 / 2 / species | human |
| positions / 2 / value / 4 / 3 / certainty | definite |
| positions / 2 / value / 4 / 3 / comparator | Not supplied |
| positions / 2 / value / 4 / 3 / comparison | Not supplied |
| positions / 2 / value / 4 / 3 / dose | Not supplied |
| positions / 2 / value / 4 / 3 / effect basis | Not supplied |
| positions / 2 / value / 4 / 3 / effect direction | decrease |
| positions / 2 / value / 4 / 3 / effect magnitude | Not supplied |
| positions / 2 / value / 4 / 3 / endpoint | recorded sick days |
| positions / 2 / value / 4 / 3 / endpoint type | descriptive |
| positions / 2 / value / 4 / 3 / follow up | Not supplied |
| positions / 2 / value / 4 / 3 / formulation | Not supplied |
| positions / 2 / value / 4 / 3 / intervention | four-day working week |
| positions / 2 / value / 4 / 3 / population | office staff at a logistics company |
| positions / 2 / value / 4 / 3 / relation | causal |
| positions / 2 / value / 4 / 3 / route | Not supplied |
| positions / 2 / value / 4 / 3 / species | human |
| positions / 2 / value / 4 / 4 | unsupported |
| positions / 2 / value / 4 / 5 | true |
| projected object fingerprint | 6de932336f2c37171f9ee5ee4c5f21b5f8b67f8d2482c81ec26b99bdeb7dc928 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/18 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | search&#95;scope |
| disagreement id | p9conflict&#58;e2939d5406c8e8fad0ecc5d6 |
| field | propositions.claim&#58;p1.search&#95;scope |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 1 / value / 1 / 1 | reviewed&#95;set |
| positions / 1 / value / 1 / 2 | context<br>input |
| positions / 1 / value / 1 / 3 | No entries recorded |
| positions / 1 / value / 1 / 4 | Not supplied |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value / 1 / 1 | reviewed&#95;set |
| positions / 2 / value / 1 / 2 | context |
| positions / 2 / value / 1 / 3 | No entries recorded |
| positions / 2 / value / 1 / 4 | Not supplied |
| projected object fingerprint | d72dd9e14f87315cb156c3e2a1502ed4e636aaff5f96c5a917f3f603427509fb |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/19 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | label |
| disagreement id | p9conflict&#58;f0edbd6ee71ebcce9431bdb2 |
| field | phase8.derived&#95;label |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | Not supplied |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | correlation&#95;vs&#95;causation |
| projected object fingerprint | f5fd5da13a24b7af0d1b3db10207f0bd02b92f87d7398fb7ca33562743d83e20 |
| proposition ids | No entries recorded |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/20 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | evidence |
| disagreement id | p9conflict&#58;f14dfb3c7a4710b6b704ad08 |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 1 / value / 1 / attributes / certainty | Not supplied |
| positions / 1 / value / 1 / attributes / comparator | Not supplied |
| positions / 1 / value / 1 / attributes / comparison | Not supplied |
| positions / 1 / value / 1 / attributes / dose | Not supplied |
| positions / 1 / value / 1 / attributes / effect basis | Not supplied |
| positions / 1 / value / 1 / attributes / effect direction | Not supplied |
| positions / 1 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 1 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 1 / attributes / endpoint type | administrative |
| positions / 1 / value / 1 / attributes / follow up | Not supplied |
| positions / 1 / value / 1 / attributes / formulation | Not supplied |
| positions / 1 / value / 1 / attributes / intervention | four-day working week |
| positions / 1 / value / 1 / attributes / population | office staff at a logistics company |
| positions / 1 / value / 1 / attributes / relation | association |
| positions / 1 / value / 1 / attributes / route | Not supplied |
| positions / 1 / value / 1 / attributes / species | human |
| positions / 1 / value / 1 / cohort id | Not supplied |
| positions / 1 / value / 1 / dataset id | Not supplied |
| positions / 1 / value / 1 / design limitations | before/after comparison with the previous year<br>no concurrent control group<br>previous year affected by a severe influenza season |
| positions / 1 / value / 1 / evidence id | e1 |
| positions / 1 / value / 1 / evidence type | descriptive |
| positions / 1 / value / 1 / identification argument | Not supplied |
| positions / 1 / value / 1 / identification evidence ids | No entries recorded |
| positions / 1 / value / 1 / randomized | Not supplied |
| positions / 1 / value / 1 / source role | company annual report statement quoted in the context |
| positions / 1 / value / 1 / study id | Not supplied |
| positions / 1 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 1 / value / 2 / attributes / certainty | Not supplied |
| positions / 1 / value / 2 / attributes / comparator | Not supplied |
| positions / 1 / value / 2 / attributes / comparison | Not supplied |
| positions / 1 / value / 2 / attributes / dose | Not supplied |
| positions / 1 / value / 2 / attributes / effect basis | Not supplied |
| positions / 1 / value / 2 / attributes / effect direction | Not supplied |
| positions / 1 / value / 2 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 2 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 2 / attributes / endpoint type | administrative |
| positions / 1 / value / 2 / attributes / follow up | Not supplied |
| positions / 1 / value / 2 / attributes / formulation | Not supplied |
| positions / 1 / value / 2 / attributes / intervention | four-day working week |
| positions / 1 / value / 2 / attributes / population | office staff at a logistics company |
| positions / 1 / value / 2 / attributes / relation | description |
| positions / 1 / value / 2 / attributes / route | Not supplied |
| positions / 1 / value / 2 / attributes / species | human |
| positions / 1 / value / 2 / cohort id | Not supplied |
| positions / 1 / value / 2 / dataset id | Not supplied |
| positions / 1 / value / 2 / design limitations | absence of a comparison group |
| positions / 1 / value / 2 / evidence id | e3 |
| positions / 1 / value / 2 / evidence type | descriptive |
| positions / 1 / value / 2 / identification argument | Not supplied |
| positions / 1 / value / 2 / identification evidence ids | No entries recorded |
| positions / 1 / value / 2 / randomized | Not supplied |
| positions / 1 / value / 2 / source role | annual report limitation quoted in the context |
| positions / 1 / value / 2 / study id | Not supplied |
| positions / 1 / value / 2 / underlying evidence ids | No entries recorded |
| positions / 1 / value / 3 / attributes / certainty | Not supplied |
| positions / 1 / value / 3 / attributes / comparator | Not supplied |
| positions / 1 / value / 3 / attributes / comparison | Not supplied |
| positions / 1 / value / 3 / attributes / dose | Not supplied |
| positions / 1 / value / 3 / attributes / effect basis | Not supplied |
| positions / 1 / value / 3 / attributes / effect direction | Not supplied |
| positions / 1 / value / 3 / attributes / effect magnitude | Not supplied |
| positions / 1 / value / 3 / attributes / endpoint | recorded sick days |
| positions / 1 / value / 3 / attributes / endpoint type | administrative |
| positions / 1 / value / 3 / attributes / follow up | Not supplied |
| positions / 1 / value / 3 / attributes / formulation | Not supplied |
| positions / 1 / value / 3 / attributes / intervention | four-day working week |
| positions / 1 / value / 3 / attributes / population | office staff at a logistics company |
| positions / 1 / value / 3 / attributes / relation | description |
| positions / 1 / value / 3 / attributes / route | Not supplied |
| positions / 1 / value / 3 / attributes / species | human |
| positions / 1 / value / 3 / cohort id | Not supplied |
| positions / 1 / value / 3 / dataset id | Not supplied |
| positions / 1 / value / 3 / design limitations | describes a confounder, not an outcome comparison |
| positions / 1 / value / 3 / evidence id | e2 |
| positions / 1 / value / 3 / evidence type | descriptive |
| positions / 1 / value / 3 / identification argument | Not supplied |
| positions / 1 / value / 3 / identification evidence ids | No entries recorded |
| positions / 1 / value / 3 / randomized | Not supplied |
| positions / 1 / value / 3 / source role | annual report note quoted in the context |
| positions / 1 / value / 3 / study id | Not supplied |
| positions / 1 / value / 3 / underlying evidence ids | No entries recorded |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value / 1 / attributes / certainty | definite |
| positions / 2 / value / 1 / attributes / comparator | previous year |
| positions / 2 / value / 1 / attributes / comparison | Not supplied |
| positions / 2 / value / 1 / attributes / dose | Not supplied |
| positions / 2 / value / 1 / attributes / effect basis | Not supplied |
| positions / 2 / value / 1 / attributes / effect direction | decrease |
| positions / 2 / value / 1 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 1 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 1 / attributes / endpoint type | descriptive |
| positions / 2 / value / 1 / attributes / follow up | one year |
| positions / 2 / value / 1 / attributes / formulation | Not supplied |
| positions / 2 / value / 1 / attributes / intervention | four-day working week |
| positions / 2 / value / 1 / attributes / population | office staff at a logistics company |
| positions / 2 / value / 1 / attributes / relation | association |
| positions / 2 / value / 1 / attributes / route | Not supplied |
| positions / 2 / value / 1 / attributes / species | human |
| positions / 2 / value / 1 / cohort id | Not supplied |
| positions / 2 / value / 1 / dataset id | Not supplied |
| positions / 2 / value / 1 / design limitations | Year-over-year comparison without a concurrent control group<br>The previous year was affected by a severe influenza season |
| positions / 2 / value / 1 / evidence id | e1 |
| positions / 2 / value / 1 / evidence type | observational |
| positions / 2 / value / 1 / identification argument | Not supplied |
| positions / 2 / value / 1 / identification evidence ids | No entries recorded |
| positions / 2 / value / 1 / randomized | false |
| positions / 2 / value / 1 / source role | company annual report&#58; before/after sick-day figures |
| positions / 2 / value / 1 / study id | Not supplied |
| positions / 2 / value / 1 / underlying evidence ids | No entries recorded |
| positions / 2 / value / 2 / attributes / certainty | Not supplied |
| positions / 2 / value / 2 / attributes / comparator | Not supplied |
| positions / 2 / value / 2 / attributes / comparison | Not supplied |
| positions / 2 / value / 2 / attributes / dose | Not supplied |
| positions / 2 / value / 2 / attributes / effect basis | Not supplied |
| positions / 2 / value / 2 / attributes / effect direction | Not supplied |
| positions / 2 / value / 2 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 2 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 2 / attributes / endpoint type | Not supplied |
| positions / 2 / value / 2 / attributes / follow up | Not supplied |
| positions / 2 / value / 2 / attributes / formulation | Not supplied |
| positions / 2 / value / 2 / attributes / intervention | Not supplied |
| positions / 2 / value / 2 / attributes / population | Not supplied |
| positions / 2 / value / 2 / attributes / relation | description |
| positions / 2 / value / 2 / attributes / route | Not supplied |
| positions / 2 / value / 2 / attributes / species | human |
| positions / 2 / value / 2 / cohort id | Not supplied |
| positions / 2 / value / 2 / dataset id | Not supplied |
| positions / 2 / value / 2 / design limitations | No entries recorded |
| positions / 2 / value / 2 / evidence id | e2 |
| positions / 2 / value / 2 / evidence type | descriptive |
| positions / 2 / value / 2 / identification argument | Not supplied |
| positions / 2 / value / 2 / identification evidence ids | No entries recorded |
| positions / 2 / value / 2 / randomized | Not supplied |
| positions / 2 / value / 2 / source role | company annual report&#58; confounder note |
| positions / 2 / value / 2 / study id | Not supplied |
| positions / 2 / value / 2 / underlying evidence ids | No entries recorded |
| positions / 2 / value / 3 / attributes / certainty | Not supplied |
| positions / 2 / value / 3 / attributes / comparator | Not supplied |
| positions / 2 / value / 3 / attributes / comparison | Not supplied |
| positions / 2 / value / 3 / attributes / dose | Not supplied |
| positions / 2 / value / 3 / attributes / effect basis | Not supplied |
| positions / 2 / value / 3 / attributes / effect direction | Not supplied |
| positions / 2 / value / 3 / attributes / effect magnitude | Not supplied |
| positions / 2 / value / 3 / attributes / endpoint | recorded sick days |
| positions / 2 / value / 3 / attributes / endpoint type | Not supplied |
| positions / 2 / value / 3 / attributes / follow up | Not supplied |
| positions / 2 / value / 3 / attributes / formulation | Not supplied |
| positions / 2 / value / 3 / attributes / intervention | Not supplied |
| positions / 2 / value / 3 / attributes / population | Not supplied |
| positions / 2 / value / 3 / attributes / relation | description |
| positions / 2 / value / 3 / attributes / route | Not supplied |
| positions / 2 / value / 3 / attributes / species | human |
| positions / 2 / value / 3 / cohort id | Not supplied |
| positions / 2 / value / 3 / dataset id | Not supplied |
| positions / 2 / value / 3 / design limitations | No entries recorded |
| positions / 2 / value / 3 / evidence id | e3 |
| positions / 2 / value / 3 / evidence type | descriptive |
| positions / 2 / value / 3 / identification argument | Not supplied |
| positions / 2 / value / 3 / identification evidence ids | No entries recorded |
| positions / 2 / value / 3 / randomized | Not supplied |
| positions / 2 / value / 3 / source role | company annual report&#58; absence of a comparison group |
| positions / 2 / value / 3 / study id | Not supplied |
| positions / 2 / value / 3 / underlying evidence ids | No entries recorded |
| projected object fingerprint | 2de7ad869ef994625920e25a7f8440e665c46f81ba83298d5433749d28a4c0f2 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/21 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;f3e40f6817f59af5a52475c4 |
| field | propositions.claim&#58;p1.attributes.endpoint&#95;type |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| positions / 1 / value | administrative |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | descriptive |
| projected object fingerprint | 04d66e7b8e516865b0a2002b94065b55bf268518a68cf5b615b4dc1cd1e07e72 |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/22 |

### Conflict

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| dimension | proposition |
| disagreement id | p9conflict&#58;f68b099ec7f23fb1c7ed3175 |
| field | propositions.claim&#58;p1.attributes.population |
| material | true |
| positions / 1 / evidence ids | e1<br>e2<br>e3 |
| positions / 1 / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| positions / 1 / value | office staff |
| positions / 2 / evidence ids | e1<br>e2<br>e3 |
| positions / 2 / position id | p9position&#58;92440760006ab5fd4ae9afce |
| positions / 2 / value | office staff at a logistics company |
| projected object fingerprint | aef2dd3f4d26c42c2a5d0f268c56d20ceb99a75b3b5b42a399e3ef5662f73e1d |
| proposition ids | claim&#58;p1 |
| provenance | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| reason | Same-dimension positions change admissible output |
| resolution | unresolved |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/conflicts/23 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | label&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | phase8.derived&#95;label |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 28a4f1e588055973ec81c4cf5a86d08e3251bd36b008ddb8b04e7596361c6f06 |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;0cfd0aea1114f55a3830a75e |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | model&#95;host&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | phase8.composite&#95;model&#95;host&#95;conflict |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| projected object fingerprint | c08f0804acfeb7c41ef59d1dbbc40b4e51a3fc0b48c0eb6dee3bd9cab38eef9c |
| proposition ids | No entries recorded |
| reason | Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;10c214edec2880b40755d34e |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.follow&#95;up |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | 8a7f502c2bc8e89ed5c671c89fbaf1421dd6575e2d5972b71e369ecaf8782d1e |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;165c176911b954366cbb2ee7 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.comparator |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 21cd17643719c44e6433a5f88a7fe28f602d42e455f4b2d8067f9d472202a034 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/3 |
| trigger id | p9trigger&#58;25a004c68a6827d93691f655 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.output&#95;transformations |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | 665aa1e1c7320b489385319b643debb4971555b035b3b6bcf7e0f3421dd6c6da |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/4 |
| trigger id | p9trigger&#58;2fcfe75ab30a94ab0f570b83 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | model&#95;host&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | phase8.composite&#95;model&#95;host&#95;conflict |
| mandatory | true |
| material | true |
| position ids | p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 5acfa1e8188f108e67e936898d1db254a6177ae32af07219ac3c36adf9997806 |
| proposition ids | No entries recorded |
| reason | Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/5 |
| trigger id | p9trigger&#58;304fd5b14dd957d01f418440 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.comparator |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | 1a6bc99675ede3c43e225dd8a766aaf6e47d5629c3a47f7b963a59c42c360817 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/6 |
| trigger id | p9trigger&#58;33588b3f966674e7cdf25dd9 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | search&#95;scope&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.search&#95;scope |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 75ee7b72f9c8a4f11ff8febc7d6df9002a2452fdb56c9ad1c894fb8ff038d8d2 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/7 |
| trigger id | p9trigger&#58;4b941df61d5fe837a7304710 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.population |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 6714edcbaab4efec75253fe6665e58674a4aae311ac3cf75f5f6c010f1afa915 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/8 |
| trigger id | p9trigger&#58;553bc5765d0bb96d5812ff3d |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | 2074cfd601a28c8413bd197c621b72daa8e2aebc3d1ee3d5730ee72a482ec22f |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/9 |
| trigger id | p9trigger&#58;590158decb416b7c696cf518 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | model&#95;host&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.model&#95;host&#95;conflict |
| mandatory | true |
| material | true |
| position ids | p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 6ce32a826d592d6c61e2fafd9915de7eec1e6d27f7cb62e74383f075f9aeb8a5 |
| proposition ids | claim&#58;p1 |
| reason | Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/10 |
| trigger id | p9trigger&#58;5a15555d7d8baed215397f45 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | causality&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.certainty |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | c8262aae7035a38a6ee3f79d5f9ab2a11e3d6f549485d1a851ee7bd19789e8b8 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/11 |
| trigger id | p9trigger&#58;5a19be06d9217277b2ff4eb8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | model&#95;host&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.model&#95;host&#95;conflict |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | e17adbbf3cf73c2397bcb9221889c7c3b95c027bac6bbe2de0a0127f4c8bffe4 |
| proposition ids | claim&#58;p1 |
| reason | Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/12 |
| trigger id | p9trigger&#58;5a6ea61cbb22cf2b4da64493 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | e7edd0cff64372b6ce8578b1a3a4eba4549973e54e4999b1b9b99f9bf0908ac7 |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/13 |
| trigger id | p9trigger&#58;5bd1cda0f33ef5d497c72a79 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | search&#95;scope&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.search&#95;scope |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 69d6bb6bd6aaaf2c66265b538c531635d7c49bb34c2e7682acbacd7b28814b76 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/14 |
| trigger id | p9trigger&#58;638ab235e072c1983620e12c |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | model&#95;host&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.model&#95;host&#95;conflict |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| projected object fingerprint | e7fadff4d1ebfb658bcd0b57cb76aff2513d85f852b56e75d38c1ca821803043 |
| proposition ids | claim&#58;p1 |
| reason | Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/15 |
| trigger id | p9trigger&#58;745844e13e5c6c497001588f |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.output&#95;transformations |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 92b0c0723247a0348ed88abaa3aa24f40d4968ada840f08ba7c489bb883d67ef |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/16 |
| trigger id | p9trigger&#58;754cb511617993b67c9572c6 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.endpoint&#95;type |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 588c731f1fbe8477c423e830fd693d57f4d3af1fe33673d1eb8eabb3539ecbfd |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/17 |
| trigger id | p9trigger&#58;781751e16b1b92577495e8e1 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.follow&#95;up |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | c07fffb29a7f2c45ef5faebfa47390fd0c1363462bcc4cea644bc1d83ac4b826 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/18 |
| trigger id | p9trigger&#58;842bd2e1afc7b339ad6d8bc8 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | label&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | phase8.derived&#95;label |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | fbb38febc508e1e08ca13ac14250a52cc2678377282b973d0f5c11860b93d3dc |
| proposition ids | No entries recorded |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/19 |
| trigger id | p9trigger&#58;87222273cd34086f811b8e22 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.endpoint&#95;type |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 04f072c9db6ab9b0cb72ba8c23829bf0a19116a58b6bcc201cb09deba1d607b3 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/20 |
| trigger id | p9trigger&#58;8894280fac3a9868504e6aed |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | model&#95;host&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | phase8.composite&#95;model&#95;host&#95;conflict |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | c40a84adb1be59b90e3ad60521d2d10d4aa5a3017df6c44997060cb4b8808301 |
| proposition ids | No entries recorded |
| reason | Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/21 |
| trigger id | p9trigger&#58;9731933fa676e4a1d7605d29 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | b7ebd6d42fdf288b1843c4085b1c97acab34a1e244c26d009fbe8f86c486bca7 |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/22 |
| trigger id | p9trigger&#58;a4046e561063dc736d3689ab |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| projected object fingerprint | 80656d7f1b96bd148013a46c53fd37e4f5f119ab624611be12b7358bb545b58b |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/23 |
| trigger id | p9trigger&#58;b691184ec5d85c65c4ae6260 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | necessary&#95;unknown |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.derived&#95;state |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | 3c9033c4d0203f4d7dffde54a6747e347e24ac3e08870524a6626e3cb5c921ea |
| proposition ids | claim&#58;p1 |
| reason | Scientific UNKNOWN affects admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/24 |
| trigger id | p9trigger&#58;b7d89029212f3f5cc786d580 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.effect&#95;direction |
| mandatory | true |
| material | true |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 88210d9506e0fa7a54ce26e6ce813203928b70aeee1946abd9949821f6f2d6fb |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/25 |
| trigger id | p9trigger&#58;b86057f0b3bb631adca8eb96 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.evidence&#95;interpretation |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 28d7f9ee1901bff382bb82654aefffa7a5d34230589b80c418f72e327f04ca1c |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/26 |
| trigger id | p9trigger&#58;c22a9c293a73346965490bc4 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | proposition&#95;conflict |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.attributes.population |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f |
| projected object fingerprint | 4a11c30b7a19b9ed2e89a5b4caa8b1b8cfcf9045d1aaa697ad144b5c56e0684c |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/27 |
| trigger id | p9trigger&#58;d63aa4152c81cf964ddf0303 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code | evidence&#95;direction&#95;or&#95;selection |
| evidence ids | e1<br>e2<br>e3 |
| field | propositions.claim&#58;p1.evidence&#95;bindings |
| mandatory | true |
| material | true |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 6f9630644f8c6751eeefde8bdd40a9e4812d81f8a264356be923977311d0db4c |
| proposition ids | claim&#58;p1 |
| reason | Same-dimension positions change admissible output |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/28 |
| trigger id | p9trigger&#58;f97f350b2825efb0feb73141 |

### Adjudication

| Field | Recorded value |
| --- | --- |
| adjudication id | p9decision&#58;fa4dbe3b2c88b6a5e70ee1cf |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code version | b8322a3632ebdcf1a416b9749111c82055e677c71d88089eff8f4ecc3dbff068 |
| conflict ids | p9conflict&#58;36743ca86ab9fb5c9e0fe579<br>p9conflict&#58;3e28e849cb230da8daba0eed<br>p9conflict&#58;3ffb548b66194bc311be738d<br>p9conflict&#58;962d9abdbb9dfa2997be0ca2<br>p9conflict&#58;e2939d5406c8e8fad0ecc5d6<br>p9conflict&#58;f14dfb3c7a4710b6b704ad08<br>p9conflict&#58;f3e40f6817f59af5a52475c4 |
| conflict types | causal&#95;strength<br>evidence<br>label<br>proposition<br>search&#95;scope |
| contract version | AA-P9/1.3 |
| corrected parent position id | Not supplied |
| evidence ids | e1<br>e2<br>e3 |
| independence | Host comparison of a replayed live model review&#58; model and host positions of the open conflicts supplied as untrusted data, shared source/extraction basis; no empirical model independence or human approval. |
| origin | offline&#95;comparison |
| original decisions / 1 / derived label | Not supplied |
| original decisions / 1 / original model label | correlation&#95;vs&#95;causation |
| original decisions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| original decisions / 1 / raw sha256 | a604745bea589c91a23fc9a2ceb1eed07b41faeafb2b2689c9bc6b5e67319dc1 |
| original decisions / 1 / scientific state | unknown |
| original decisions / 1 / technical status | completed |
| original position ids | p9position&#58;6c94d19b6c08bda5b38f696f |
| outcome | considered |
| position binding reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/0/position&#95;fingerprints |
| position ids | p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | e61ad22c988e5c95dec4c785d3446ab8ad2a2b275111ce3bf68faf89e442aaaf |
| proposition ids | claim&#58;p1 |
| reason | Targeted comparison&#58; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Scientific UNKNOWN affects admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Same-dimension positions change admissible output; Scientific UNKNOWN affects admissible output; Same-dimension positions change admissible output |
| review decision / derived label | correlation&#95;vs&#95;causation |
| review decision / original model label | correlation&#95;vs&#95;causation |
| review decision / position id | p9position&#58;92440760006ab5fd4ae9afce |
| review decision / raw sha256 | a5e4568fcfa232b504271e9b74007bea7c8a77fc7afa7f9e20a3269caae8dd37 |
| review decision / scientific state | unknown |
| review decision / technical status | completed |
| reviewer provenance | Offline replay of a recorded live model review under AA-P10-LIVE/1.0 (claude-sonnet-5-5) |
| reviewer type | model |
| run id | 6150e80c-fa32-42fc-b9bc-acebd0df4fb8&#58;counterreview |
| selected position id | p9position&#58;92440760006ab5fd4ae9afce |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/0 |
| timestamp | 2026-10-13T08&#58;01&#58;08.238157+00&#58;00 |

### Adjudication

| Field | Recorded value |
| --- | --- |
| adjudication id | p9decision&#58;5e05f0de9f697694831ec0a8 |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| claim id | claim |
| code version | b8322a3632ebdcf1a416b9749111c82055e677c71d88089eff8f4ecc3dbff068 |
| conflict ids | p9conflict&#58;00a6e226a433b623f7efa180<br>p9conflict&#58;05d8db46f32db4602c3dd246<br>p9conflict&#58;0fc70925733090feeb27b1e3<br>p9conflict&#58;1f95ad8d80ae5f2d84686763<br>p9conflict&#58;36743ca86ab9fb5c9e0fe579<br>p9conflict&#58;3e28e849cb230da8daba0eed<br>p9conflict&#58;3ffb548b66194bc311be738d<br>p9conflict&#58;50347467c0a5549838e03971<br>p9conflict&#58;5f52b28890c908038da41b06<br>p9conflict&#58;6dffaf2b54c9acb8d3ee2ee2<br>p9conflict&#58;8185812494684906faf499d2<br>p9conflict&#58;841117bb57cab9fe7917ec7a<br>p9conflict&#58;935b7c3a5e8a482611d113c3<br>p9conflict&#58;94f2d3bb5826c1fbb7adc3ad<br>p9conflict&#58;962d9abdbb9dfa2997be0ca2<br>p9conflict&#58;ad14c1ffd3aea4098f9d429d<br>p9conflict&#58;be713c26f092fbb6b65c263e<br>p9conflict&#58;d7054e912d2730d2d27955d8<br>p9conflict&#58;d98d70e6688977568be5d67c<br>p9conflict&#58;e2939d5406c8e8fad0ecc5d6<br>p9conflict&#58;f0edbd6ee71ebcce9431bdb2<br>p9conflict&#58;f14dfb3c7a4710b6b704ad08<br>p9conflict&#58;f3e40f6817f59af5a52475c4<br>p9conflict&#58;f68b099ec7f23fb1c7ed3175 |
| conflict types | causal&#95;strength<br>evidence<br>label<br>proposition<br>search&#95;scope |
| contract version | AA-P9/1.3 |
| corrected parent position id | Not supplied |
| evidence ids | e1<br>e2<br>e3 |
| independence | Host comparison of a replayed live model review&#58; model and host positions of the open conflicts supplied as untrusted data, shared source/extraction basis; no empirical model independence or human approval. |
| origin | offline&#95;comparison |
| original decisions / 1 / derived label | Not supplied |
| original decisions / 1 / original model label | correlation&#95;vs&#95;causation |
| original decisions / 1 / position id | p9position&#58;6c94d19b6c08bda5b38f696f |
| original decisions / 1 / raw sha256 | a604745bea589c91a23fc9a2ceb1eed07b41faeafb2b2689c9bc6b5e67319dc1 |
| original decisions / 1 / scientific state | unknown |
| original decisions / 1 / technical status | completed |
| original position ids | p9position&#58;6c94d19b6c08bda5b38f696f |
| outcome | considered |
| position binding reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/1/position&#95;fingerprints |
| position ids | p9position&#58;5ef8cd03bda5fc34e1cdb35d<br>p9position&#58;6c94d19b6c08bda5b38f696f<br>p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 810e3981c1323ee461bc9895cb415a4459688bb038f2fb7d0bdc15a8417fe967 |
| proposition ids | claim&#58;p1 |
| reason | Targeted comparison&#58; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Scientific UNKNOWN affects admissible output; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Model judgment unsupported differs from host evidence derivation unknown (AA-P8-HOST/1.1); mandatory review; neither side is adopted automatically; Same-dimension positions change admissible output; Scientific UNKNOWN affects admissible output; Scientific UNKNOWN affects admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output; Same-dimension positions change admissible output |
| review decision / derived label | Not supplied |
| review decision / original model label | correlation&#95;vs&#95;causation |
| review decision / position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| review decision / raw sha256 | 1408ca920fc7e9ada2a33c4ed8ec2ab3149aecd5e60047e6b05f5a9d94bf55a1 |
| review decision / scientific state | unknown |
| review decision / technical status | completed |
| reviewer provenance | Offline replay of a recorded live model review under AA-P10-LIVE/1.0 (claude-sonnet-5-5) |
| reviewer type | model |
| run id | 6150e80c-fa32-42fc-b9bc-acebd0df4fb8&#58;stability |
| selected position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/adjudications/1 |
| timestamp | 2026-10-13T08&#58;01&#58;08.391482+00&#58;00 |

### Attempt

| Field | Recorded value |
| --- | --- |
| attempt id | attempt-001 |
| code version | b8322a3632ebdcf1a416b9749111c82055e677c71d88089eff8f4ecc3dbff068 |
| contract version | AA-P9/1.3 |
| independence | Model and host positions of the open conflicts supplied as untrusted data; shared original sources and extraction IDs. Offline replay of an earlier live output; no new generation and no empirical model independence established. |
| kind | counterreview |
| packet sha256 | 60fa578cfdaf27d64063a3a2c2c9c13bee3f2b4991f65d3d97d512e66407df10 |
| position id | p9position&#58;92440760006ab5fd4ae9afce |
| projected object fingerprint | 9fa6cb57baedee262fc5fd30cf623b4bdccf23a1dcc62b7190cdde5720e50ae6 |
| reason |  |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/attempts/0 |
| status | completed |
| timestamp | 2026-10-13T08&#58;01&#58;08.217116+00&#58;00 |

### Attempt

| Field | Recorded value |
| --- | --- |
| attempt id | attempt-002 |
| code version | b8322a3632ebdcf1a416b9749111c82055e677c71d88089eff8f4ecc3dbff068 |
| contract version | AA-P9/1.3 |
| independence | Model and host positions of the open conflicts supplied as untrusted data; shared original sources and extraction IDs. Offline replay of an earlier live output; no new generation and no empirical model independence established. |
| kind | stability |
| packet sha256 | aefb1b3c7ce08b4ee44b79d3ad1669d56c4b7681274eb53c6369321569e7f9ad |
| position id | p9position&#58;5ef8cd03bda5fc34e1cdb35d |
| projected object fingerprint | 0a3f532955e483b23ae1b91a45a267dc9cd966cb86bac9bd98de6da16f57cb26 |
| reason |  |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/attempts/1 |
| status | completed |
| timestamp | 2026-10-13T08&#58;01&#58;08.362616+00&#58;00 |

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.1 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.1 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 3<br>Evaluated&#58; 3<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.3 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.3 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Review open&#58; automatic reviews executed (counterreview completed; stability completed); the material conflict or UNKNOWN remains open |
| provenance / live-1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and live execution evidence bound (AA-P10-LIVE/1.0) |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Control, bidirectional and invisible format characters in displayed text are shown as ⟦U+XXXX⟧, and the brackets themselves as ⟦U+27E6⟧ and ⟦U+27E7⟧; record.json keeps the exact characters.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 7536da844ebb3739efa390df92a16b8ec3af3f76f953e6d9cffea2e843059775 |
| case id | p9case&#58;a8aa0c2842890a7656506234 |
| code / code fingerprint | 03984bd436b852be4953aa77ed0a65b2f16bb1e4bc8e0a2432926bc080b221e1 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 5560e950af20cee8c35fb2c8e2bfb38807043fab |
| config | live-replay-v1 |
| contract | AA-P10/1.0 |
| contract addendum | AA-P10-LIVE/1.0 |
| evidence fingerprint | 800808247b5d830d2790bf35ff46c6dccabb959ddbce4374c7c32b49e6f11848 |
| execution evidence / 1 / attempt ids | attempt-004 |
| execution evidence / 1 / authorization id | AA-P10-LIVE-RETEST-20261011-004 |
| execution evidence / 1 / billing | usage&#95;reported |
| execution evidence / 1 / capture sha256 | b01f10a117838692c3f8b6d39dd2b2a6dfc1a0dc6e64189767c06ac1e28680f2 |
| execution evidence / 1 / completion state | complete |
| execution evidence / 1 / confirmed cost microusd | 113148 |
| execution evidence / 1 / current execution | offline&#95;replay |
| execution evidence / 1 / denial reason | Not supplied |
| execution evidence / 1 / latency ms | 49127 |
| execution evidence / 1 / message id | msg&#95;011CfxZHYP9RVwrwWjSdAob5 |
| execution evidence / 1 / model | claude-sonnet-5-5 |
| execution evidence / 1 / origin | live&#95;generation |
| execution evidence / 1 / profile id | claude-sonnet-5-5&#64;3 |
| execution evidence / 1 / provider | anthropic-live-replay |
| execution evidence / 1 / replay capture verified | true |
| execution evidence / 1 / replay request identical | true |
| execution evidence / 1 / request id | req&#95;011CfxZHY8mDZhGVkTCkiWDU |
| execution evidence / 1 / requested model | claude-sonnet-5-5 |
| execution evidence / 1 / reserved microusd | 241756 |
| execution evidence / 1 / retry denied | Not supplied |
| execution evidence / 1 / returned model | claude-sonnet-5-5 |
| execution evidence / 1 / role | primary |
| execution evidence / 1 / slot key | aa-p10-live-retest-LR-03&#124;claude-sonnet-5-5&#64;3&#124;primary |
| execution evidence / 1 / stop reason | end&#95;turn |
| execution evidence / 1 / usage / cache creation input tokens | 0 |
| execution evidence / 1 / usage / cache read input tokens | 0 |
| execution evidence / 1 / usage / input tokens | 14984 |
| execution evidence / 1 / usage / output tokens | 8318 |
| execution evidence / 2 / attempt ids | attempt-005 |
| execution evidence / 2 / authorization id | AA-P10-LIVE-RETEST-20261011-004 |
| execution evidence / 2 / billing | usage&#95;reported |
| execution evidence / 2 / capture sha256 | 202af910bd11afc8dceb009edea5367bf513923a18eb83cfe8c6dd8d408848b1 |
| execution evidence / 2 / completion state | complete |
| execution evidence / 2 / confirmed cost microusd | 104884 |
| execution evidence / 2 / current execution | offline&#95;replay |
| execution evidence / 2 / denial reason | Not supplied |
| execution evidence / 2 / latency ms | 40985 |
| execution evidence / 2 / message id | msg&#95;011CfxZMAVNbwhcM7PBNP6oP |
| execution evidence / 2 / model | claude-sonnet-5-5 |
| execution evidence / 2 / origin | live&#95;generation |
| execution evidence / 2 / profile id | claude-sonnet-5-5&#64;3 |
| execution evidence / 2 / provider | anthropic-live-replay |
| execution evidence / 2 / replay capture verified | true |
| execution evidence / 2 / replay request identical | true |
| execution evidence / 2 / request id | req&#95;011CfxZMACGLj4HMqXdrjYkc |
| execution evidence / 2 / requested model | claude-sonnet-5-5 |
| execution evidence / 2 / reserved microusd | 248444 |
| execution evidence / 2 / retry denied | Not supplied |
| execution evidence / 2 / returned model | claude-sonnet-5-5 |
| execution evidence / 2 / role | model&#95;review |
| execution evidence / 2 / slot key | aa-p10-live-retest-LR-03&#124;claude-sonnet-5-5&#64;3&#124;counterreview |
| execution evidence / 2 / stop reason | end&#95;turn |
| execution evidence / 2 / usage / cache creation input tokens | 0 |
| execution evidence / 2 / usage / cache read input tokens | 0 |
| execution evidence / 2 / usage / input tokens | 16102 |
| execution evidence / 2 / usage / output tokens | 7268 |
| execution evidence / 3 / attempt ids | attempt-006 |
| execution evidence / 3 / authorization id | AA-P10-LIVE-RETEST-20261011-004 |
| execution evidence / 3 / billing | usage&#95;reported |
| execution evidence / 3 / capture sha256 | b4f73c5c4414127d7e9695a4cdcf196802fd7f93ea714e8a8a00d7568127c773 |
| execution evidence / 3 / completion state | complete |
| execution evidence / 3 / confirmed cost microusd | 102994 |
| execution evidence / 3 / current execution | offline&#95;replay |
| execution evidence / 3 / denial reason | Not supplied |
| execution evidence / 3 / latency ms | 39416 |
| execution evidence / 3 / message id | msg&#95;011CfxZQDHdX6hYdReAeRNw3 |
| execution evidence / 3 / model | claude-sonnet-5-5 |
| execution evidence / 3 / origin | live&#95;generation |
| execution evidence / 3 / profile id | claude-sonnet-5-5&#64;3 |
| execution evidence / 3 / provider | anthropic-live-replay |
| execution evidence / 3 / replay capture verified | true |
| execution evidence / 3 / replay request identical | true |
| execution evidence / 3 / request id | req&#95;011CfxZQCF8BMGius1n6U2o9 |
| execution evidence / 3 / requested model | claude-sonnet-5-5 |
| execution evidence / 3 / reserved microusd | 248444 |
| execution evidence / 3 / retry denied | Not supplied |
| execution evidence / 3 / returned model | claude-sonnet-5-5 |
| execution evidence / 3 / role | stability |
| execution evidence / 3 / slot key | aa-p10-live-retest-LR-03&#124;claude-sonnet-5-5&#64;3&#124;stability |
| execution evidence / 3 / stop reason | end&#95;turn |
| execution evidence / 3 / usage / cache creation input tokens | 0 |
| execution evidence / 3 / usage / cache read input tokens | 0 |
| execution evidence / 3 / usage / input tokens | 16102 |
| execution evidence / 3 / usage / output tokens | 7079 |
| execution mode | offline&#95;replay&#95;of&#95;live |
| execution mode errors | No entries recorded |
| input fingerprint | 43fbbd8e7678360ebbe6ab2adc5ad06677304370cb688a603dc7c8f910061c50 |
| ledger fingerprint | da5fdd87db4afee8ed1dce3eb25695de9644ed07575b7218900de0cff2a79314 |
| package version | 1.0.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | correlation&#95;vs&#95;causation |
| phase8 summary / taxonomy status | completed |
| phase8 summary / technical status | completed |
| phase9 summary / execution status | completed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | completed |
| providers / 1 / model | claude-sonnet-5-5 |
| providers / 1 / provider | anthropic-live-replay |
| providers / 1 / usage / cache creation input tokens | 0 |
| providers / 1 / usage / cache read input tokens | 0 |
| providers / 1 / usage / input tokens | 14984 |
| providers / 1 / usage / output tokens | 8318 |
| recording notice | OFFLINE REPLAY of an earlier live model generation (AA-P10-LIVE/1.0); no new model call in this execution |
| review counts / adjudications | 2 |
| review counts / attempts | 2 |
| review counts / conflicts | 24 |
| review counts / positions | 3 |
| review fingerprint | 0fba4f7ef3758fb429e1cd7c9ee26f6098fb8b3f63bc54f2087c8f0b6cc4ec57 |
| run id | 6150e80c-fa32-42fc-b9bc-acebd0df4fb8 |
| selected position id | p9position&#58;6c94d19b6c08bda5b38f696f |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

