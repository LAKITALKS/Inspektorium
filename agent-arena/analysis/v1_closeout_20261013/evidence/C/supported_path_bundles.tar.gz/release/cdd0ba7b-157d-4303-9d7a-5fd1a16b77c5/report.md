# Canonical local audit

## Execution and release

RELEASED — local artifact status

Automatic processing has ended. This is an explicitly released local artifact; its controls are technical and do not establish scientific truth.

RECORDED OFFLINE / SYNTHETIC. Local artifact decision only; no live model execution, scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | completed |
| automatic processing | ended |
| host evidence derivation (composite) | supported |
| local release | RELEASED |
| mandatory review | false |
| model judgment (composite) | supported |
| model/host conflicts | none recorded |
| open cause | no blocking cause recorded |
| review execution | not&#95;executed |
| review route | AUTO&#95;RESOLVABLE |
| scientific judgment | supported |

### Explicit release intent

| Field | Recorded value |
| --- | --- |
| reason | v1 closeout area C supported-path demonstration (offline recorded example) |
| reviewer | area-c-evidence |
| scope | local&#95;artifact&#95;only |

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-13T08&#58;01&#58;08.316146+00&#58;00 |
| parent / manifest fingerprint | 4c115cbb09f26b937e723de44fdd8f061b652380405efe95f58ec31a59b9a82a |
| parent / revision id | e58ce16c-ea05-4b89-a364-e91b61111be6 |
| record fingerprint | 2534d908a673717034db0b2e8d363d8fd9ae67ceb37086a5d9342639ac7246d3 |
| revision | cdd0ba7b-157d-4303-9d7a-5fd1a16b77c5 |
| selected position id | p9position&#58;14ab5569b301029bc1c9d402 |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
intervention X reduces event Q in adults.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | supported |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | supported |
| contract version | AA-P8/1.3 |
| derived label | solid |
| host composite state | supported |
| host derived copies | No entries recorded |
| host rule version | AA-P8-HOST/1.1 |
| input sha256 | d405ae6768246618b95a4d04eedcd9b6222fd78b607a902ace3a2e9ef0bebc71 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| model composite state | supported |
| model host conflicts | No entries recorded |
| original model label | solid |
| raw response sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| reasons | Ledger, evidence constraints and transformations evaluated under AA-P8/1.3 (AA-P8-HOST/1.1) |
| record fingerprint | 3e4b5fd9192394ce9a4fb8753007c9167f65dd211a06bd3390e080a8a3982d99 |
| technical status | completed |
| transformation findings | No entries recorded |

In &#x27;reasons&#x27;, model-supplied text (the proposition reason, uncertainty and binding reasons) is combined with host sentences; only &#x27;host reasons&#x27; is host-written.

### Proposition judgments

| Field | Recorded value |
| --- | --- |
|  / 1 / dependency status | single&#95;source |
|  / 1 / derived state | supported |
|  / 1 / evidence ids | e1 |
|  / 1 / host reasons | binding 1&#58; identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
|  / 1 / host state | supported |
|  / 1 / model host conflict | false |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
|  / 1 / reported verdict | supported |
|  / 1 / required | true |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | solid |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | Generic represented core-error analysis |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks. |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | solid |
| taxonomy check / reasons | Honest reporting with supported represented propositions |
| taxonomy check / technical status | completed |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | offline extraction from supplied prompt and context |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | origin |
| required proposition ids | claim&#58;p1 |

### Proposition 1

| Field | Recorded value |
| --- | --- |
| derived judgment / dependency status | single&#95;source |
| derived judgment / derived state | supported |
| derived judgment / evidence ids | e1 |
| derived judgment / host reasons | binding 1&#58; identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| derived judgment / host state | supported |
| derived judgment / model host conflict | false |
| derived judgment / proposition id | claim&#58;p1 |
| derived judgment / reasons | Source reports the stated comparison<br>b1&#58; Matching trial<br>identified effect in studied setting permitted<br>evidence dependence&#58; single&#95;source; no independent corroboration inferred |
| derived judgment / reported verdict | supported |
| derived judgment / required | true |
| material dimensions | species<br>population<br>intervention<br>comparator<br>endpoint<br>endpoint&#95;type<br>relation<br>follow&#95;up<br>certainty<br>comparison |
| materiality | required |
| parent claim id | claim |
| proposition id | claim&#58;p1 |
| provenance id | origin |
| reason | Source reports the stated comparison |
| reported verdict | supported |
| search question | What evidence supports&#58; intervention X reduces event Q in adults. |
| search scope ids | review |

Quoted proposition; this is represented input, not a release assertion.

```
intervention X reduces event Q in adults.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 41 |
| start | 0 |
| text | intervention X reduces event Q in adults. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | placebo |
| comparison | between |
| endpoint | event Q |
| endpoint type | clinical&#95;event |
| follow up | 12 weeks |
| intervention | intervention X |
| population | adults |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Matching trial |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation 1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | extraction |

### Transformation 2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | intervention X reduces event Q in adults. |
| reason | Meaning retained |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | What evidence supports&#58; intervention X reduces event Q in adults. |
| transformation id | search&#95;question |

### Transformation 3

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | internal |

### Transformation 4

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | summary |
| target id | client1 |
| transformation id | summary |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence item 1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | event Q |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | asserted |
| attributes / comparator | placebo |
| attributes / comparison | between |
| attributes / endpoint | event Q |
| attributes / endpoint type | clinical&#95;event |
| attributes / follow up | 12 weeks |
| attributes / intervention | intervention X |
| attributes / population | adults |
| attributes / relation | causal |
| attributes / species | human |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| randomized | true |
| source role | primary&#95;study |
| study id | synthetic-study-1 |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | review |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | intervention X reduces event Q in adults. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | origin |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | intervention X reduces event Q in adults. |
|  / 1 / provenance id | origin |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | client1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | intervention X reduces event Q in adults. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | origin |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| contract version | AA-P9/1.3 |
| execution status | not&#95;executed |
| mandatory | false |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | not&#95;required |
| route | AUTO&#95;RESOLVABLE |
| technical status | completed |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 27ec5341338c0bbf6b7901cedcd3a2ff957fc5465ecd170c5b0f8e64256e2cd0 |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | AUTO&#95;RESOLVABLE |
| source reference | record.json&#35;/run&#95;record |
| technical status | completed |

### Position p9position&#58;14ab5569b301029bc1c9d402

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | solid |
| model | offline-recording-no-live-model |
| origin | original |
| original model label | solid |
| position id | p9position&#58;14ab5569b301029bc1c9d402 |
| provider | offline-recording-no-live-model |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 7c38ae8815370440e444cbbcabca683b859f79338da2bb1712788000f321dca7 |
| run id | d8218c5b-2674-493a-8703-156f7924730d |
| scientific state | supported |
| selected | true |
| taxonomy status | completed |
| technical status | completed |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

Current assessment contains no recorded conflicts. This is not evidence of scientific truth.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.1 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.1 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Reparsed raw, supplied source spans and nonempty claim/evidence/output traces checked |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.3 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current semantic and separate taxonomy analysis required |
| phase9&#95;history&#95;review / 1.3 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; All original/review/adjudication carriers and mandatory review revalidated |
| provenance / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and offline configuration bound |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Control, bidirectional and invisible format characters in displayed text are shown as ⟦U+XXXX⟧, and the brackets themselves as ⟦U+27E6⟧ and ⟦U+27E7⟧; record.json keeps the exact characters.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 552858f7d60d7d5644604595bc64f3475d67e2de580b66a1509c4bdf7774f54d |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| code / code fingerprint | 03984bd436b852be4953aa77ed0a65b2f16bb1e4bc8e0a2432926bc080b221e1 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 5560e950af20cee8c35fb2c8e2bfb38807043fab |
| config | offline-recording-v1 |
| contract | AA-P10/1.0 |
| evidence fingerprint | cea4af84c8fff4b5d9a8b2b09054e1cfe5ed96a978fae1752f5027d2f1dfea08 |
| input fingerprint | 3ed6c37cef5b16e6a8cd1e2a61f4133a4bc14a2777c9492cd85cbfa124b206d8 |
| ledger fingerprint | b82403260c8afdbc7d321ff53a22693ef1741414b800847a3cc61936a1b22e56 |
| package version | 1.0.0 |
| phase8 summary / composite state | supported |
| phase8 summary / derived label | solid |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | completed |
| phase8 summary / technical status | completed |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | false |
| phase9 summary / review state | not&#95;required |
| phase9 summary / route | AUTO&#95;RESOLVABLE |
| phase9 summary / technical status | completed |
| providers / 1 / model | offline-recording-no-live-model |
| providers / 1 / provider | offline-recording-no-live-model |
| providers / 1 / usage | Not supplied |
| recording notice | RECORDED OFFLINE / SYNTHETIC; no live model execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 27ec5341338c0bbf6b7901cedcd3a2ff957fc5465ecd170c5b0f8e64256e2cd0 |
| run id | d8218c5b-2674-493a-8703-156f7924730d |
| selected position id | p9position&#58;14ab5569b301029bc1c9d402 |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

