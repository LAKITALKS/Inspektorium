"""evidence-D: per-page verdicts (dom.json + static.json + runs.jsonl) -> dom_results.json and release_independence.json.
usage: python3 -I aggregate.py <workdir> <outdir>"""
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

W, OUT = Path(sys.argv[1]), Path(sys.argv[2])
dom = json.loads((W / "dom.json").read_text())
static = json.loads((W / "static.json").read_text())
payloads = json.loads((W / "payloads.json").read_text())
runs = {r["variant"]: r for r in map(json.loads, (W / "runs.jsonl").read_text().splitlines())}
ORDINAL = re.compile(r"(Proposition|Evidence item|Transformation) \d+|Position p9position:[0-9a-f]+|"
                     r"Findings: [a-z0-9_]+|Trigger|Conflict|Attempt|Adjudication|Stored (metadata|result) carrier.*")
plain = {n for n, m in payloads["variants"].items() if m["class"] in {"plain", "clean"}}
host_captions = {c for p in dom["pages"] if p["variant"] in plain and p["renderer"] == "canonical-html"
                 for c in p["captions"] if not ORDINAL.fullmatch(c)}

CHECKS = ["h2_equals_12_titles", "one_status_paragraph_equal_real_status", "executed_controls_rows_equal_decision",
          "automatic_processing_ended_sentence_visible", "notice_visible", "limits_visible", "display_note_visible",
          "open_cause_row_visible", "failing_control_rows_visible",
          "executed_controls_cells_exactly_five_host_lines_real_outcome", "open_cause_one_line",
          "open_cause_lf_token_one_line",  "all_host_text_blocks_visible_once",
          "no_active_elements", "no_on_attributes", "only_canonical_style", "no_comment_nodes", "tag_whitelist",
          "payload_only_text_nodes_in_cells_or_code", "payload_visible_as_text", "tokens_visible",
          "no_raw_hidden_chars_in_dom", "host_h3_captions_only_host_or_ordinal", "no_dialog_or_script_effect",
          "static_no_raw_hidden_chars_md_html", "static_tokens_in_md_and_html", "static_record_keeps_exact_chars",
          "static_validate_files", "static_exec_rows_equal_independent_md_html",
          "static_exec_cells_five_host_lines_md_html", "static_open_cause_one_line_md_html", "static_cli_json_ascii",
          "static_lfpid_quoted_inline_in_cause_and_failing_reasons", "static_model_keys_marked_model_supplied"]
rows, per_renderer = [], defaultdict(Counter)
for p in dom["pages"]:
    st = static[f"{p['variant']}/{p['bundle']}"]
    w = p["warnings"]
    res = {
        "h2_equals_12_titles": p["h2Ok"],
        "one_status_paragraph_equal_real_status": p["statusOk"],
        "executed_controls_rows_equal_decision": p["execOk"],
        "automatic_processing_ended_sentence_visible": w["ended_sentence"] and w["ended_sentence_starts"],
        "notice_visible": w["notice"], "limits_visible": w["limits"], "display_note_visible": w["display_note"],
        "open_cause_row_visible": w["open_cause"],
        "executed_controls_cells_exactly_five_host_lines_real_outcome": p["fiveLines"],
        "open_cause_one_line": p["causeOneLine"],
        "open_cause_lf_token_one_line": p["causeLfToken"],  # None unless the cause quotes a multi-line model id
        "failing_control_rows_visible": w["failing_control_rows"],  # None when no control fails
        "all_host_text_blocks_visible_once": p["hostTextsOk"],
        "no_active_elements": not p["active"], "no_on_attributes": not p["onAttrs"],
        "only_canonical_style": p["styleOk"] and not p["bodyStyleAttrs"] and not p["hiddenAttrs"],
        "no_comment_nodes": p["comments"] == 0, "tag_whitelist": not p["extraTags"],
        "payload_only_text_nodes_in_cells_or_code": (p["markParentsOk"] and p["markInAttr"] == 0) if p.get("markCount") else None,
        "payload_visible_as_text": p["payloadVisible"],
        "tokens_visible": p["tokensVisible"] if st["payload_displayed"] else None,
        "no_raw_hidden_chars_in_dom": not p["rawHidden"],
        "host_h3_captions_only_host_or_ordinal": all(c in host_captions or ORDINAL.fullmatch(c) for c in p["captions"])
                                                 and not p["captionsWithMark"],
        "no_dialog_or_script_effect": not p["dialogs"] and not p["pageErrors"] and p["pwned"] is None,
        "static_no_raw_hidden_chars_md_html": not st["raw_hidden_in_report_md"] and not st["raw_hidden_in_report_html"],
        "static_tokens_in_md_and_html": (not st["tokens_missing"]) if st["payload_displayed"] else None,
        "static_record_keeps_exact_chars": st["record_keeps_exact_payload"],
        "static_validate_files": st["validate_files"] and st["projection_texts_without_payload_mark"],
        "static_exec_rows_equal_independent_md_html": st["projection_rows_equal_independent"]
            and st["md_exec_rows_equal_independent"] and st["html_exec_rows_equal_independent"],
        "static_exec_cells_five_host_lines_md_html": st["md_exec_cells_five_host_lines"] and st["html_exec_cells_five_host_lines"],
        "static_open_cause_one_line_md_html": st["md_open_cause_one_line"] and st["html_open_cause_one_line"],
        "static_cli_json_ascii": st["cli_stdout_ascii"],
        "static_lfpid_quoted_inline_in_cause_and_failing_reasons": (st["cause_quotes_payload_inline"] and all(
            st["failing_reasons_quote_payload_inline"].values())) if st["cause_quotes_payload_inline"] is not None else None,
        "static_model_keys_marked_model_supplied": (all(st["model_key"]["shown_with_model_supplied_prefix"].values())
            and not st["model_key"]["unprefixed_model_rows_in_proposition_1"]) if st["model_key"] else None,
    }
    failed = [k for k, v in res.items() if v is False]
    verdict = "PASS" if not failed else "FAIL"
    per_renderer[p["renderer"]][verdict] += 1
    rows.append([p["variant"], p["bundle"], p["renderer"], p["status"], verdict, failed,
                 [k for k, v in res.items() if v is None], p.get("execMode"), len(p["captions"]), p.get("markCount", 0), res])

# Release decision independent of payload: payload variant vs its plain counterpart.
indep = []
for name, meta in sorted(payloads["variants"].items()):
    cp = meta.get("counterpart")
    if not cp:
        continue
    a, b = runs[name], runs[cp]
    sa, sb = static[f"{name}/run"], static[f"{cp}/run"]
    same_status = a["run"]["status"] == b["run"]["status"]
    same_outcomes = sa["control_outcomes"] == sb["control_outcomes"]
    if sa.get("no_bundle_written"):  # preflight refused the task file: no controls were evaluated at all
        sa = {**sa, "control_outcomes": [[c, "not_evaluated"] for c, _ in sb["control_outcomes"]]}
    rel_a = (a.get("release") or {}).get("status")
    rel_b = (b.get("release") or {}).get("status")
    indep.append({"variant": name, "counterpart": cp, "class": meta["class"], "field": meta["field"],
                  "status": a["run"]["status"], "counterpart_status": b["run"]["status"],
                  "release": rel_a, "counterpart_release": rel_b,
                  "same_status": same_status, "same_control_outcomes": same_outcomes, "same_release": rel_a == rel_b,
                  "differing_controls": [x for x, y in zip(sa["control_outcomes"], sb["control_outcomes"]) if x != y],
                  "stricter_only": (len(sa["control_outcomes"]) == len(sb["control_outcomes"]) and all(
                      x[1] in {"fail", "not_evaluated"} and y[1] != "fail" for x, y in zip(sa["control_outcomes"], sb["control_outcomes"]) if x != y)
                      and (same_status or a["run"]["status"] not in {"READY_FOR_RELEASE", "RELEASED"})),
                  "first_error": (a["run"].get("errors") or [None])[0]})
diff = [x for x in indep if not (x["same_status"] and x["same_control_outcomes"] and x["same_release"])]
summary = {
    "pages": len(rows), "pages_pass": sum(r[4] == "PASS" for r in rows), "pages_fail": sum(r[4] == "FAIL" for r in rows),
    "per_renderer": {k: dict(v) for k, v in sorted(per_renderer.items())},
    "bundles": len(static), "variants": len(runs),
    "cli_stdout_ascii_all_calls": all(r["run_stdout_ascii"] is not False and r.get("release_stdout_ascii") is not False for r in runs.values()),
    "cli_calls": sum(1 + (r["release"] is not None) for r in runs.values()),
    "check_true_false_na_counts": {c: dict(Counter("NA" if r[10][c] is None else bool(r[10][c]) for r in rows)) for c in CHECKS},
    "chrome": dom["chrome"], "playwright_core": dom["playwright_core"],
    "file_requests": dom["file_requests"], "external_requests_aborted": len(dom["external_requests"]),
    "host_captions_from_plain_variants": sorted(host_captions),
    "release_independence": {"pairs": len(indep), "identical": len(indep) - len(diff),
                             "all_differences_stricter_only": all(x["stricter_only"] for x in diff),
                             "payload_variant_more_permissive_than_counterpart": [x["variant"] for x in indep if not x["stricter_only"]],
                             "different": [{k: x[k] for k in ("variant", "status", "counterpart_status",
                                                              "differing_controls", "first_error")} for x in diff]},
}
(OUT / "dom_results.json").write_text(json.dumps({
    "fixture": "SYNTHETIC TEST FIXTURE — not an empirical model response",
    "candidate": "5560e95",
    "summary": summary, "checks": CHECKS,
    "columns": ["variant", "bundle", "renderer", "status", "verdict", "failed_checks", "not_applicable_checks",
                "exec_controls_mode", "h3_count", "payload_text_nodes"],
    "pages": [r[:10] for r in rows]}, ensure_ascii=True, separators=(",", ":")).replace('],["', '],\n["'))
(OUT / "release_independence.json").write_text(json.dumps({"pairs": indep}, ensure_ascii=True, indent=1))
print(json.dumps(summary, ensure_ascii=False, indent=1)[:4000])
