// evidence-D screenshots (headless local Chrome, non-file requests aborted).
// usage: node shots.mjs <jobs.json>   jobs: [{file, out, mode: 'top'|'h3'|'mark'|'forged', arg, height, md: bool}]
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire('__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/verify-D/node/');
const { chromium } = require('playwright-core');
const jobs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', headless: true });
const ctx = await browser.newContext({ offline: true, viewport: { width: 1100, height: 2000 }, deviceScaleFactor: 1 });
let external = 0;
await ctx.route('**/*', r => { if (r.request().url().startsWith('file:')) return r.continue(); external++; return r.abort(); });
for (const job of jobs) {
  const page = await ctx.newPage();
  await page.goto('file://' + job.file);
  if (job.md) await page.addStyleTag({ content: 'body{font-family:-apple-system,Helvetica,Arial,sans-serif;max-width:1040px;margin:16px;font-size:13px} table{border-collapse:collapse} td,th{border:1px solid #bbb;padding:3px 6px;vertical-align:top} h2{border-bottom:1px solid #ccc} pre{background:#f4f4f4;padding:6px;white-space:pre-wrap}' });
  const y = await page.evaluate((job) => {
    const flat = s => (s || '').replace(/\s+/g, ' ').trim();
    let el = null;
    if (job.mode === 'top') el = document.querySelector('h2');
    if (job.mode === 'h3') el = [...document.querySelectorAll('h3')].find(e => flat(e.textContent) === job.arg);
    if (job.mode === 'mark') { const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      while (w.nextNode()) if (w.currentNode.data.includes(job.arg)) { el = w.currentNode.parentElement.closest('tr') || w.currentNode.parentElement; break; } }
    if (job.mode === 'forged') el = [...document.querySelectorAll('p')].filter(p => flat(p.textContent) === 'RELEASED — local artifact status')[0];
    if (!el) return null;
    return el.getBoundingClientRect().top + scrollY - (job.before || 40);
  }, job);
  if (y === null) { console.log('not found', job.out); await page.close(); continue; }
  await page.screenshot({ path: job.out, fullPage: true, clip: { x: 0, y: Math.max(0, y), width: 1100, height: job.height || 900 } });
  console.log('ok', job.out);
  await page.close();
}
await browser.close();
console.log('external', external);
