#!/bin/bash
# evidence-D pre-fix contrast: same SYNTHETIC inputs through `git archive <commit> src` (PYTHONPATH, guarded CLI).
E=__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/evidence-D
R=__LOCAL_HOME__/Documents/Projects/agent-arena; PY=$R/.venv/bin/python
: > $E/prefix/commands.log; : > $E/prefix/runs.jsonl
for c in 558e920 fd1ad7c; do
 if [ $c = 558e920 ]; then VS="clean reason--cr claim--cr binding_reason--crlf spanfail--payload spanfail--lfpid spanfail--lfpid_mixed"
 else VS="clean reason--cr spanfail--lfpid spanfail--lfpid_mixed modelkey--derived_judgment_flat"; fi
 for v in $VS; do
  o=$E/prefix/$c/out/$v; rm -rf $o; mkdir -p $o
  echo "PYTHONPATH=prefix/$c/code/src python -B -s tools/cli_prefix.py $c audit run --offline --task in/$v/task.json --recording in/$v/recording.json --output-root prefix/$c/out/$v/run" >> $E/prefix/commands.log
  (cd $E/work && env -u ANTHROPIC_API_KEY -u OPENAI_API_KEY PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$E/prefix/$c/code/src $PY -B -s $E/tools/cli_prefix.py $c audit run --offline --task $E/in/$v/task.json --recording $E/in/$v/recording.json --output-root $o/run > $o/run.stdout 2> $o/run.stderr); rc=$?
  python3 -I -c 'import json,sys
c,v,rc,o=sys.argv[1:5]; b=open(o+"/run.stdout","rb").read()
print(json.dumps({"commit":c,"variant":v,"rc":int(rc),"run":json.loads(b),"stdout_ascii":all(x<128 for x in b),"stderr":open(o+"/run.stderr").read()[:300]},ensure_ascii=True))' $c $v $rc $o >> $E/prefix/runs.jsonl
 done
done
