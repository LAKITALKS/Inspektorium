"""evidence-D: protected-state snapshot (read only). usage: python3 -I protected.py <out.json>"""
import hashlib, json, subprocess, sys
from pathlib import Path
R = Path("__LOCAL_HOME__/Documents/Projects/agent-arena")
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def tree(root):
    h = hashlib.sha256()
    for p in sorted(x for x in root.rglob("*") if x.is_file()):
        h.update(str(p.relative_to(root)).encode() + b"\0" + sha(p).encode() + b"\n")
    return h.hexdigest()
lr = R / "analysis/c25_p9_20261011/live_retest"
git = lambda *a: subprocess.run(["git", "-C", str(R), *a], capture_output=True, text=True).stdout
out = {"ledger_sha256": sha(lr / "ledger.json"),
       "successor_claim_sha256": sha(R / "analysis/live_smoke_20261011/repair_r1/successor_claim.json"),
       "live_retest_file_count": sum(1 for x in lr.rglob("*") if x.is_file()),
       "tree_live_retest_sha256": tree(lr), "tree_live_smoke_sha256": tree(R / "analysis/live_smoke_20261011"),
       "git_head": git("rev-parse", "HEAD").strip(),
       "git_tracked_changes": [l for l in git("status", "--porcelain").splitlines() if not l.startswith("??")],
       "git_staged": git("diff", "--cached", "--name-only").split(),
       "git_diff_tracked_sha256": hashlib.sha256(git("diff").encode()).hexdigest(),
       "note": "the 4 modified tracked files were already modified at session start (not by evidence-D); unchanged by this work"}
Path(sys.argv[1]).write_text(json.dumps(out, indent=1))
print(json.dumps(out, indent=1))
