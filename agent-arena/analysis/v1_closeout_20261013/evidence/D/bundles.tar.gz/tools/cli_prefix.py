"""Guarded CLI for the PRE-FIX contrast: agent_arena from `git archive <commit> src` via PYTHONPATH (not the editable 5560e95).
usage: PYTHONPATH=<prefix>/<commit>/code/src python -B -s cli_prefix.py <commit> audit run ..."""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import guard  # noqa: E402,F401
commit = sys.argv.pop(1)
import agent_arena  # noqa: E402
assert f"/evidence-D/prefix/{commit}/code/src/" in agent_arena.__file__, agent_arena.__file__
sys.stderr.write(f"prefix {commit} agent_arena {agent_arena.__version__} from {agent_arena.__file__}\n")
from agent_arena.cli import cli  # noqa: E402
if __name__ == "__main__":
    sys.argv[0] = "agent-arena"
    cli(standalone_mode=True)
