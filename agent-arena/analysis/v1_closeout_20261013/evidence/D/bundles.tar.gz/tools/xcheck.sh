#!/bin/bash
# cross-check via the real console entry point .venv/bin/agent-arena (editable install, HEAD 5560e95)
E=__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/evidence-D
AA=__LOCAL_HOME__/Documents/Projects/agent-arena/.venv/bin/agent-arena
rm -rf $E/xcheck; mkdir -p $E/xcheck; : > $E/xcheck/runs.jsonl
for v in clean reason--cr spanfail--lfpid spanfail--lfpid_mixed modelkey--derived_judgment_flat; do
  o=$E/xcheck/$v; mkdir -p $o
  (cd $E/work && env -u ANTHROPIC_API_KEY -u OPENAI_API_KEY PYTHONDONTWRITEBYTECODE=1 $AA audit run --offline --task $E/in/$v/task.json --recording $E/in/$v/recording.json --output-root $o/run > $o/run.stdout 2> $o/run.stderr); rc=$?
  relrc=""
  if [ $rc = 0 ]; then b=$(python3 -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["path"])' $o/run.stdout)
    (cd $E/work && env -u ANTHROPIC_API_KEY -u OPENAI_API_KEY PYTHONDONTWRITEBYTECODE=1 $AA audit release --bundle "$b" --output-root $o/release --reviewer evidence-D-synthetic --reason "SYNTHETIC TEST FIXTURE release check" > $o/release.stdout 2> $o/release.stderr); relrc=$?; fi
  python3 -I -c 'import json,sys,os
v,rc,relrc,o=sys.argv[1:5]; b=open(o+"/run.stdout","rb").read(); rb=open(o+"/release.stdout","rb").read() if relrc else b""
print(json.dumps({"variant":v,"rc":int(rc),"status":json.loads(b)["status"],"stdout_ascii":all(x<128 for x in b),
 "release_rc":int(relrc) if relrc else None,"release_status":json.loads(rb)["status"] if rb else None,"release_stdout_ascii":all(x<128 for x in rb) if rb else None}))' $v $rc "$relrc" $o >> $E/xcheck/runs.jsonl
done
env -u ANTHROPIC_API_KEY -u OPENAI_API_KEY $AA --version > $E/xcheck/version.txt
cat $E/xcheck/runs.jsonl $E/xcheck/version.txt
