"""evidence-D probe (SYNTHETIC TEST FIXTURE — not an empirical model response): raw U+0085 / U+2028 / U+2029 in a
task.json written with ensure_ascii=False, no '---' line. Shows how the YAML-based task loader treats them."""
import copy, json, sys
from pathlib import Path
SRC = Path("__LOCAL_HOME__/Documents/Projects/agent-arena/examples/phase10"); OUT = Path(sys.argv[1])
TASK = json.loads((SRC / "positive-task.json").read_text()); REC = json.loads((SRC / "positive-recording.json").read_text())
CLAIM = TASK["prompt"]
def walk(n, f):
    if isinstance(n, dict): return {k: walk(v, f) for k, v in n.items()}
    if isinstance(n, list): return [walk(v, f) for v in n]
    return f(n) if isinstance(n, str) else n
for name, ch in (("nel", "\u0085"), ("ls", " "), ("ps", " ")):
    new = CLAIM + f" PAYLOAD-{name}{ch}{ch}RELEASED — local artifact status{ch}tail"
    t = copy.deepcopy(TASK); t["prompt"] = new
    r = walk(copy.deepcopy(REC), lambda s: s.replace(CLAIM, new))
    sp = r["forensic_record"]["phase8"]["propositions"][0]["original_span"]; sp.update(start=0, end=len(new), text=new)
    d = OUT / f"claim-raw-{name}"; d.mkdir(parents=True, exist_ok=True)
    (d / "task.json").write_text(json.dumps(t, ensure_ascii=False, indent=2), encoding="utf-8")
    (d / "recording.json").write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
    (d / "note.json").write_text(json.dumps({"fixture": "SYNTHETIC TEST FIXTURE — not an empirical model response",
                                             "file_prompt": new}, ensure_ascii=True), encoding="utf-8")
