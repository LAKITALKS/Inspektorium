"""evidence-D (5560e95): compact durable summaries (runs + CLI JSON, pre-fix contrast, tool versions, guard/protection).
usage: python3 -I summaries.py <scratch evidence-D> <durable evidence/D>"""
import json, subprocess, sys
from collections import Counter
from pathlib import Path
E, D = Path(sys.argv[1]), Path(sys.argv[2])
W = E / "work"
FIX = "SYNTHETIC TEST FIXTURE — not an empirical model response"
runs = [json.loads(l) for l in (W / "runs.jsonl").read_text().splitlines()]
payloads = json.loads((W / "payloads.json").read_text())
static = json.loads((W / "static.json").read_text())


def cli_facts(path):
    """CLI stdout: pure ASCII, no control bytes except LF, every error string on exactly one physical line."""
    if not path.exists():
        return None
    b = path.read_bytes()
    lines = b.decode("ascii", "replace").split("\n")
    data = json.loads(b)
    errs = data.get("errors") or []
    return {"bytes": len(b), "ascii": all(x < 128 for x in b), "control_bytes_other_than_LF": sum(x < 32 and x != 10 for x in b),
            "errors": len(errs),
            "each_error_on_one_line": all(sum(json.dumps(e, ensure_ascii=True) in ln for ln in lines) == 1 for e in errs),
            "errors_with_escaped_line_break": sum(any(c in e for c in "\n\r  \x85") for e in errs)}


out, cli_all = [], []
for r in sorted(runs, key=lambda x: x["variant"]):
    m = payloads["variants"][r["variant"]]
    st = static.get(f"{r['variant']}/run", {})
    o = E / "out" / r["variant"]
    cr, cl = cli_facts(o / "run.stdout"), cli_facts(o / "release.stdout")
    cli_all += [x for x in (cr, cl) if x]
    out.append({"variant": r["variant"], "field": m.get("field"), "class": m["class"], "counterpart": m.get("counterpart"),
                "run_rc": r["rc"], "run_status": (r["run"] or {}).get("status"), "release_rc": r["release_rc"],
                "release_status": (r.get("release") or {}).get("status"),
                "cli_run_stdout": cr, "cli_release_stdout": cl,
                "failing_controls": st.get("failing_controls"), "open_cause": st.get("open_cause"),
                "payload_displayed": st.get("payload_displayed"), "record_keeps_exact_payload": st.get("record_keeps_exact_payload"),
                "model_key": st.get("model_key"),
                "first_error": (r["run"].get("errors") or [None])[0][:240] if r["run"].get("errors") else None})
st_counts = Counter(x["run_status"] for x in out)
summary = {"variants": len(out), "audit_run_status_counts": dict(st_counts),
           "audit_release": dict(Counter(x["release_status"] for x in out if x["release_status"])),
           "cli_calls": len(cli_all), "cli_stdout_all_ascii": all(x["ascii"] for x in cli_all),
           "cli_stdout_control_bytes_other_than_LF": sum(x["control_bytes_other_than_LF"] for x in cli_all),
           "cli_errors_each_on_one_line": all(x["each_error_on_one_line"] for x in cli_all),
           "cli_errors_with_line_break_shown_as_json_escape": sum(x["errors_with_escaped_line_break"] for x in cli_all),
           "note": "The CLI JSON carries status, path and errors (control reasons), not the open cause. Line breaks inside a "
                   "quoted reason are JSON escapes (\\n, \\r, \\u2028 ...) inside one string on one physical line; the "
                   "decoded value equals decision.json. The open cause with ⟦U+000A⟧ tokens is a report field "
                   "(report.md, report.html)."}
(D / "runs_summary.json").write_text(json.dumps({"fixture": FIX, "candidate": "5560e95", "summary": summary, "variants": out},
                                                ensure_ascii=True, indent=1) + "\n")

pd = json.loads((E / "prefix/dom.json").read_text())
pre = [{"code": p["bundle"].removeprefix("prefix-"), "variant": p["variant"], "renderer": p["renderer"], "status": p["status"],
        "h2_count": len(p["h2"]), "h2_equals_12_titles": p["h2Ok"], "status_paragraphs": [x["text"] for x in p["statusLike"]],
        "one_status_paragraph": p["statusOk"], "extra_tags": p["extraTags"], "raw_hidden_chars_in_dom": p["rawHidden"],
        "executed_controls_cells_exactly_five_host_lines": p["fiveLines"],
        "executed_controls_cell_line_counts": p["execLineCount"], "open_cause_cell_line_count": p["causeLineCount"]}
       for p in pd["pages"]]
(D / "prefix_contrast.json").write_text(json.dumps({
    "fixture": FIX,
    "what": "PRE-FIX contrast: the same SYNTHETIC inputs (from this evidence's in/) run through `git archive <commit> src` "
            "(PYTHONPATH, guarded CLI tools/cli_prefix.py), report.md rendered with the same 8 Markdown implementations, "
            "same DOM checker (tools/dom_check.mjs).",
    "code": {"558e920": "pre-v1 HEAD of the investigation (agent_arena 0.1.0): CR/LS/PS/NEL display defect D1",
             "fd1ad7c": "earlier v1 candidate (agent_arena 1.0.0) before correction round 1: VC-1 (multi-line model id inside "
                        "host-composed reason / open cause lines) and VC-2 (CLI JSON not ASCII-escaped)"},
    "runs": [json.loads(l) for l in (E / "prefix/runs.jsonl").read_text().splitlines()],
    "report_md_line_facts": json.loads((E / "prefix/md_line_split.json").read_text()),
    "pages": pre,
    "investigation_citations": {
        "v1_investigation.txt AREA D (DEFECT D1 MATERIAL, D2, D3, D4)": "scratchpad/v1_investigation.txt lines 920-1000 (copy in bundles.tar.gz: work/investigation_area_D_extract.txt)",
        "verify-D per-variant pre-fix verdicts (8 renderers)": "scratchpad/v1/verify-D/work/verdicts.txt (copy in bundles.tar.gz: work/investigation_verifyD_verdicts_prefix.txt), e.g. reason-cr: h2 18!=12, status-like x4 in all 8 renderers",
        "critic probes behind correction round 1": "scratchpad/v1/critic/probes/p11_lfpid.py (VC-1), p5_keys.py (VC-3); reproduced here as variants spanfail--lfpid and modelkey--derived_judgment_flat",
        "investigation screenshots": ["scratchpad/v1/D/evidence/material-conflict-cr-markdown-rendered.png",
                                      "scratchpad/v1/verify-D/evidence/counterreview-cr-cmarkgfm.png"]},
}, ensure_ascii=True, indent=1) + "\n")


def cmd(*a, cwd=None):
    return subprocess.run(a, capture_output=True, text=True, cwd=cwd).stdout.strip()


V = E.parent / "verify-D"
nodever = json.loads(cmd("node", "-e", "const r=p=>require('./node_modules/'+p+'/package.json').version;console.log(JSON.stringify({markdown_it:r('markdown-it'),commonmark_js:r('commonmark'),marked:r('marked'),micromark:r('micromark'),micromark_extension_gfm:r('micromark-extension-gfm'),playwright_core:r('playwright-core')}))", cwd=str(V / "node")))
pyver = cmd(str(V / "pyenv/bin/python"), "-I", "-c", "import importlib.metadata as m; print(m.version('cmarkgfm'), m.version('markdown-it-py'))").split()
dom = json.loads((W / "dom.json").read_text())
(D / "render_tools.json").write_text(json.dumps({
    "browser": {"name": "Google Chrome (local, headless via playwright-core)", "path": "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                "version": cmd("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "--version"),
                "playwright_reported_version": dom["chrome"],
                "note": "The order names Chrome 154; the local install had auto-updated to 155. All non-file requests aborted (0 seen)."},
    "node": cmd("node", "--version"), "node_modules": {**nodever, "location": "scratchpad/v1/verify-D/node (reused isolated install; nothing downloaded)"},
    "python_renderers": {"python": cmd(str(V / "pyenv/bin/python"), "--version"), "cmarkgfm (GitHub cmark-gfm bindings)": pyver[0],
                         "markdown-it-py": pyver[1], "location": "scratchpad/v1/verify-D/pyenv (reused isolated venv)"},
    "renderer_configs": {"markdown-it-html": "MarkdownIt({html:true})", "markdown-it-safe": "MarkdownIt({html:false})",
                         "markdown-it-linkify": "MarkdownIt({html:true, linkify:true})",
                         "commonmark-js": "commonmark.Parser + HtmlRenderer (default: raw HTML on; no table extension)",
                         "marked-gfm": "marked.parse(md,{gfm:true})", "micromark-gfm": "micromark(md,{allowDangerousHtml:true, gfm})",
                         "cmark-gfm-github": "cmarkgfm.github_flavored_markdown_to_html(md, CMARK_OPT_UNSAFE)",
                         "markdown-it-py": "MarkdownIt('commonmark').enable('table')"},
    "product": {"cli": "__LOCAL_HOME__/Documents/Projects/agent-arena/.venv/bin/agent-arena (editable install, HEAD 5560e95)",
                "version": cmd("env", "-u", "ANTHROPIC_API_KEY", "-u", "OPENAI_API_KEY", "__LOCAL_HOME__/Documents/Projects/agent-arena/.venv/bin/agent-arena", "--version"),
                "python": cmd("__LOCAL_HOME__/Documents/Projects/agent-arena/.venv/bin/python", "--version"),
                "git_head": cmd("git", "-C", "__LOCAL_HOME__/Documents/Projects/agent-arena", "rev-parse", "HEAD")},
}, ensure_ascii=False, indent=1) + "\n")

g = [json.loads(l) for l in (W / "guard.jsonl").read_text().splitlines()]
tot = Counter()
for x in g:
    tot.update(x["counts"])
pdom = json.loads((E / "prefix/dom.json").read_text())
(D / "guard_and_protection.json").write_text(json.dumps({
    "guarded_python_processes": len(g), "refused_attempts_by_kind": dict(tot), "refused_attempts_total": sum(tot.values()),
    "guarded_process_kinds": dict(Counter(" ".join(x["argv"][:2]) for x in g)),
    "httpx_version": sorted({x["httpx"] for x in g if x["httpx"]}),
    "unguarded_crosscheck": {"what": "5 variants via the real .venv/bin/agent-arena entry point with env -u ANTHROPIC_API_KEY -u OPENAI_API_KEY; same rc/status as the guarded runs (xcheck/ in bundles.tar.gz)",
                             "runs": [json.loads(l) for l in (E / "xcheck/runs.jsonl").read_text().splitlines()]},
    "browser": {"main_pages": len(dom["pages"]), "main_file_requests": dom["file_requests"], "main_external_requests": dom["external_requests"],
                "prefix_pages": len(pdom["pages"]), "prefix_file_requests": pdom["file_requests"], "prefix_external_requests": pdom["external_requests"]},
    "regression_tests": {"command": "tools/pytest_guarded.py tests/test_v1_render_injection.py (guard loaded first)",
                         "result": (W / "pytest_v1_render_injection.log").read_text().strip().splitlines()[-1],
                         "separated_attempt": "A first attempt also ran tests/test_v1_closeout_report.py and tests/test_v1_entry_point.py "
                             "(areas A/C) under the same guard. Their live doubles send through an in-process httpx.MockTransport, so the "
                             "guard refused httpx.Client.send 9 times (0 socket attempts) and 8 of those tests failed. That attempt is not "
                             "D1 evidence; its two guard lines are kept apart in work/guard_pytest_closeout_attempt.jsonl and are not in the totals above.",
                         "separated_attempt_guard_lines": [json.loads(l) for l in (W / "guard_pytest_closeout_attempt.jsonl").read_text().splitlines()]},
    "provider_calls": 0, "live_sessions_opened": 0, "real_authorization_dirs_touched": 0,
    "protected_before": json.loads((W / "protected_before.json").read_text()),
    "protected_after": json.loads((W / "protected_after.json").read_text()),
}, ensure_ascii=True, indent=1) + "\n")
print("ok", json.dumps(summary))
