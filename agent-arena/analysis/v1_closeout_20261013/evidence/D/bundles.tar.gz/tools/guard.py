"""evidence-D network/provider guard. Must be imported before any product code.

Refuses and counts every attempt at: httpx.Client.send, httpx.AsyncClient.send, httpx.HTTPTransport.handle_request,
httpx.AsyncHTTPTransport.handle_async_request, socket.socket.connect / connect_ex (non-AF_UNIX),
socket.create_connection, socket.getaddrinfo. Counts are appended as one JSON line per process to $ED_GUARD_LOG.
"""
import atexit
import json
import os
import socket
import sys
import time

sys.dont_write_bytecode = True
LOG = os.environ.get("ED_GUARD_LOG", "__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/"
                     "cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/evidence-D/work/guard.jsonl")
COUNTS = {"httpx.Client.send": 0, "httpx.AsyncClient.send": 0, "httpx.HTTPTransport.handle_request": 0,
          "httpx.AsyncHTTPTransport.handle_async_request": 0, "socket.socket.connect": 0,
          "socket.socket.connect_ex": 0, "socket.create_connection": 0, "socket.getaddrinfo": 0}
for key in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY"):
    if os.environ.get(key):
        sys.stderr.write(f"evidence-D guard: {key} present -> abort\n")
        os._exit(97)


def _refuse(kind, detail=""):
    COUNTS[kind] += 1
    raise ConnectionRefusedError(f"evidence-D guard refused {kind} ({str(detail)[:120]})")


_connect, _connect_ex = socket.socket.connect, socket.socket.connect_ex


def connect(self, address, *a, **k):
    if self.family == getattr(socket, "AF_UNIX", None):
        return _connect(self, address, *a, **k)
    _refuse("socket.socket.connect", address)


def connect_ex(self, address, *a, **k):
    if self.family == getattr(socket, "AF_UNIX", None):
        return _connect_ex(self, address, *a, **k)
    _refuse("socket.socket.connect_ex", address)


socket.socket.connect = connect
socket.socket.connect_ex = connect_ex
socket.create_connection = lambda address, *a, **k: _refuse("socket.create_connection", address)
socket.getaddrinfo = lambda host, *a, **k: _refuse("socket.getaddrinfo", host)

HTTPX = None
try:
    import httpx
    HTTPX = httpx.__version__

    def _send(self, request, *a, **k):
        _refuse("httpx.Client.send", getattr(request, "url", ""))

    async def _asend(self, request, *a, **k):
        _refuse("httpx.AsyncClient.send", getattr(request, "url", ""))

    def _handle(self, request):
        _refuse("httpx.HTTPTransport.handle_request", request.url)

    async def _ahandle(self, request):
        _refuse("httpx.AsyncHTTPTransport.handle_async_request", request.url)

    httpx.Client.send = _send
    httpx.AsyncClient.send = _asend
    httpx.HTTPTransport.handle_request = _handle
    httpx.AsyncHTTPTransport.handle_async_request = _ahandle
except ImportError:
    pass


@atexit.register
def _report():
    try:
        with open(LOG, "a", encoding="utf-8") as handle:
            handle.write(json.dumps({"t": round(time.time(), 3), "pid": os.getpid(), "argv": sys.argv[1:4],
                                     "httpx": HTTPX, "counts": COUNTS, "total": sum(COUNTS.values())}) + "\n")
    except OSError:
        pass
