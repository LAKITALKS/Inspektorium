// evidence-D: load every page (canonical report.html and Markdown renders of report.md) in local headless
// Google Chrome via playwright-core; every non-file request is aborted and counted. Per-page facts + verdicts.
// usage: node dom_check.mjs <pages.json> <out.json>
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire('__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/verify-D/node/');
const { chromium } = require('playwright-core');
const [pagesFile, outFile] = process.argv.slice(2);
const pages = JSON.parse(fs.readFileSync(pagesFile, 'utf8'));
const browser = await chromium.launch({ executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  headless: true, args: ['--no-first-run', '--disable-background-networking', '--disable-component-update', '--disable-sync',
  '--disable-default-apps', '--disable-domain-reliability', '--no-pings'] });
const ctx = await browser.newContext({ javaScriptEnabled: true, offline: true, viewport: { width: 1100, height: 900 } });
const external = [];
let fileRequests = 0;
await ctx.route('**/*', (route) => { const u = route.request().url();
  if (u.startsWith('file:')) { fileRequests++; return route.continue(); } external.push(u); return route.abort(); });
const version = browser.version();
const out = [];
for (const spec of pages) {
  const page = await ctx.newPage();
  const dialogs = [], consoleErrors = [];
  page.on('dialog', async d => { dialogs.push(d.message()); await d.dismiss(); });
  page.on('pageerror', e => consoleErrors.push(String(e).slice(0, 200)));
  await page.goto('file://' + spec.file, { waitUntil: 'load' });
  const r = await page.evaluate((spec) => {
    const norm = s => (s || '').replace(/<br>/g, '\n').replace(/[ \t ]+/g, ' ').split('\n').map(l => l.trim()).join('\n').trim();
    const flat = s => (s || '').replace(/<br>/g, ' ').replace(/\s+/g, ' ').trim();
    const visible = e => { for (let n = e; n && n.nodeType === 1; n = n.parentElement) { const cs = getComputedStyle(n);
        if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse' || parseFloat(cs.opacity) === 0 ||
            n.hidden || parseFloat(cs.fontSize) === 0) return false; }
      const b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0; };
    const outside = e => !e.closest('table, pre, code');
    const body = document.body;
    // 1. h2 list
    const h2 = [...document.querySelectorAll('h2')].map(e => flat(e.textContent));
    const h2Visible = [...document.querySelectorAll('h2')].every(visible);
    // 2. status paragraphs (outside tables / code)
    // A status paragraph is an element (outside table/pre/code) whose whole text is one status line.
    const STATUS_LINE = /^[A-Z][A-Z_ ]*[A-Z] — local artifact status$/;
    const statusLike = [...body.querySelectorAll('p, li, h1, h2, h3, h4, h5, h6, blockquote, summary, div, span, dt, dd')]
      .filter(outside).filter(e => STATUS_LINE.test(flat(e.textContent)))
      .map(e => ({ tag: e.tagName.toLowerCase(), text: flat(e.textContent), vis: visible(e) }));
    const statusTextElsewhere = [...body.querySelectorAll('p, li, h1, h2, h3, h4, h5, h6, blockquote, summary')]
      .filter(outside).filter(e => /local artifact status/.test(e.textContent) && !STATUS_LINE.test(flat(e.textContent)))
      .map(e => ({ tag: e.tagName.toLowerCase(), starts: flat(e.textContent).slice(0, 40) }));
    const expectedStatus = spec.status + ' — local artifact status';
    const statusOk = statusLike.length === 1 && statusLike[0].text === expectedStatus && statusLike[0].vis;
    const pStatusClass = [...document.querySelectorAll('p.status')].map(e => flat(e.textContent));
    // 3. Executed controls table
    const h3s = [...document.querySelectorAll('h3')];
    const execH3 = h3s.filter(e => flat(e.textContent) === 'Executed controls');
    let execRows = null, execVisible = false, execMode = 'table', execOk = false, failRowsOk = false, fiveLines = false, execLineCount = null;
    const expRows = spec.exec_rows.map(r => r.map(norm));
    const noTables = document.querySelectorAll('table').length === 0;
    const pipeFlat = rows => rows.map(r => '| ' + r.join(' | ') + ' |').join(' ');
    let execPara = null;
    if (execH3.length === 1) { let t = execH3[0].nextElementSibling;
      if (noTables) {
        // Pure CommonMark (no table extension): the whole host table stays one paragraph of pipe text.
        execMode = 'paragraph';
        if (t && t.tagName === 'P') { execPara = t; execVisible = visible(t);
          const want = flat(pipeFlat([['Control and version', 'Execution, population and result'], ['---', '---'], ...expRows]));
          execOk = flat(t.innerText) === want && execVisible;
          failRowsOk = spec.failing_rows.every(fr => flat(t.innerText).includes(flat(pipeFlat([fr.map(norm)]))));
          // <br> are the only hard breaks: lines = 1 + 4 per control; line 4k+1..4k+4 = Outcome/Eligible/Evaluated/Reason
          const L = t.innerText.split('\n'); const N = spec.exec_outcomes.length;
          fiveLines = L.length === 4 * N + 1 && spec.exec_outcomes.every((o, k) => L[4 * k + 1] === 'Outcome: ' + o &&
            L[4 * k + 2].startsWith('Eligible: ') && L[4 * k + 3].startsWith('Evaluated: ') && L[4 * k + 4].startsWith('Reason: ') &&
            (k === 0 ? L[0] : L[4 * k]).includes(' | Execution: '));
          execLineCount = L.length; }
      } else {
        while (t && t.tagName !== 'TABLE') t = t.nextElementSibling;
        if (t) { const trs = [...t.querySelectorAll('tbody tr')];
          execRows = trs.map(tr => [...tr.children].map(td => norm(td.innerText)));
          execVisible = visible(t) && trs.every(visible);
          execOk = JSON.stringify(execRows) === JSON.stringify(expRows) && execVisible;
          failRowsOk = spec.failing_rows.every(fr => execRows.some(r => JSON.stringify(r) === JSON.stringify(fr.map(norm))));
          // markdown-it with html:false shows the host <br> as literal text (known note D6): only there it counts as a break
          const brText = x => spec.renderer === 'markdown-it-safe' ? x.replace(/<br>/g, '\n') : x;
          const cellLines = trs.map(tr => brText(tr.children[1].innerText).replace(/\n$/, '').split('\n'));
          fiveLines = trs.length === spec.exec_outcomes.length && cellLines.every((L, k) => L.length === 5 &&
            L[0].startsWith('Execution: ') && L[1] === 'Outcome: ' + spec.exec_outcomes[k] && L[2].startsWith('Eligible: ') &&
            L[3].startsWith('Evaluated: ') && L[4].startsWith('Reason: ') && trs[k].children.length === 2);
          execLineCount = cellLines.map(L => L.length); }
      } }
    // 4. host texts (all text() blocks of the projection) present as visible elements outside tables/code
    const blocks = [...body.querySelectorAll('p')].filter(outside);
    const findVisible = t => { const want = flat(t); return blocks.filter(e => flat(e.textContent) === want).map(visible); };
    const hostTexts = spec.host_texts.map(t => { const v = findVisible(t); return { text: t.slice(0, 70), count: v.length, visible: v.some(Boolean) }; });
    const hostTextsOk = hostTexts.every(h => h.count === 1 && h.visible);
    const warnings = {};
    for (const [k, t] of [['ended_sentence', spec.ended], ['notice', spec.notice], ['limits', spec.limits], ['display_note', spec.display_note]]) {
      const v = findVisible(t); warnings[k] = v.length === 1 && v[0]; }
    warnings.ended_sentence_starts = flat(spec.ended).startsWith('Automatic processing has ended.');
    // open cause row of Independent states visible
    let causeOneLine = false, causeLfToken = null, causeLineCount = null;
    if (noTables) {
      const paras = [...body.querySelectorAll('p')].filter(p => flat(p.innerText).includes(flat('| open cause | ' + norm(spec.open_cause) + ' |')));
      warnings.open_cause = paras.length === 1 && visible(paras[0]);
      const lines = paras.length === 1 ? paras[0].innerText.split('\n').filter(l => l.includes('| open cause | ')) : [];
      // Markdown renders collapse runs of spaces in normal flow: compare whitespace-collapsed, but require one line
      causeOneLine = lines.length === 1 && flat(lines[0]).includes(flat('| open cause | ' + spec.open_cause + ' |'));
    } else {
      const causeCells = [...body.querySelectorAll('td')].filter(td => flat(td.textContent) === 'open cause');
      const causeRow = causeCells.length === 1 ? causeCells[0].parentElement : null;
      warnings.open_cause = !!causeRow && visible(causeRow) && norm(causeRow.children[1].innerText) === norm(spec.open_cause);
      // exact text in canonical HTML (pre-wrap); whitespace-collapsed in Markdown renders (normal white-space)
      const ct = causeRow ? causeRow.children[1].innerText.replace(/\n$/, '') : '';
      causeLineCount = causeRow ? ct.split('\n').length : null;
      causeOneLine = !!causeRow && !ct.includes('\n') &&
        (spec.renderer === 'canonical-html' ? ct === spec.open_cause : flat(ct) === flat(spec.open_cause));
    }
    causeLfToken = spec.cause_needs_lf_token ? spec.open_cause.includes('\u27e6U+000A\u27e7') && causeOneLine : null;
    warnings.failing_control_rows = spec.failing.length === 0 ? null : failRowsOk && execVisible;
    // 5. active elements, attributes, comments, tag inventory
    const all = [...document.querySelectorAll('*')];
    const tags = {}; all.forEach(e => { const t = e.tagName.toLowerCase(); tags[t] = (tags[t] || 0) + 1; });
    const ACTIVE = /^(script|iframe|object|embed|img|link|form|input|button|textarea|select|video|audio|svg|math|template|details|summary|a|area|base|frame|frameset|applet|noscript|portal|dialog|marquee)$/i;
    const active = all.filter(e => ACTIVE.test(e.tagName)).map(e => e.tagName.toLowerCase());
    const onAttrs = all.flatMap(e => [...e.attributes].filter(a => /^on/i.test(a.name)).map(a => e.tagName.toLowerCase() + '@' + a.name));
    const styles = [...document.querySelectorAll('style')].map(s => ({ inHead: s.parentElement === document.head, len: s.textContent.length }));
    const bodyStyleAttrs = all.filter(e => e.hasAttribute('style')).map(e => e.tagName.toLowerCase());
    const hiddenAttrs = all.filter(e => e.hasAttribute('hidden')).map(e => e.tagName.toLowerCase());
    let comments = 0; const tw = document.createTreeWalker(document, NodeFilter.SHOW_COMMENT); while (tw.nextNode()) comments++;
    const CANON = new Set(['html', 'head', 'meta', 'title', 'style', 'body', 'section', 'h1', 'h2', 'h3', 'p', 'blockquote', 'pre', 'table', 'thead', 'tbody', 'tr', 'th', 'td']);
    const MD = new Set(['html', 'head', 'meta', 'title', 'body', 'h1', 'h2', 'h3', 'p', 'pre', 'code', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'br']);
    const allowed = spec.renderer === 'canonical-html' ? CANON : MD;
    const extraTags = Object.keys(tags).filter(t => !allowed.has(t));
    const styleOk = spec.renderer === 'canonical-html' ? (styles.length === 1 && styles[0].inHead) : styles.length === 0;
    // 6. payload only as text
    let markNodes = [], markInAttr = 0;
    if (spec.mark) {
      const w = document.createTreeWalker(body, NodeFilter.SHOW_TEXT);
      while (w.nextNode()) if (w.currentNode.data.includes(spec.mark)) { const el = w.currentNode.parentElement;
        markNodes.push(el.tagName === 'P' && noTables && flat(el.textContent).startsWith('| ') ? 'p(pipe-table-text)' : el.tagName.toLowerCase()); }
      all.forEach(e => [...e.attributes].forEach(a => { if (a.value.includes(spec.mark)) markInAttr++; }));
    }
    const markParentsOk = markNodes.every(t => ['td', 'pre', 'code', 'p(pipe-table-text)'].includes(t));
    const bodyText = norm(body.innerText);
    const payloadVisible = spec.payload_visible ? bodyText.replace(/\n/g, ' ').includes(norm(spec.payload_visible).replace(/\n/g, ' ')) : null;
    const tokensVisible = spec.tokens.every(t => bodyText.includes(t));
    const rawHidden = [...(body.textContent || '')].filter(c => c !== '\n' && c !== '\t' && /[\p{Cc}\p{Cf}\p{Zl}\p{Zp}]/u.test(c)).map(c => 'U+' + c.codePointAt(0).toString(16).toUpperCase().padStart(4, '0'));
    // 7. host h3 captions
    const captions = h3s.map(e => flat(e.textContent));
    const captionsWithMark = captions.filter(c => c.includes('PAYLOAD-') || c.includes('PLAIN-'));
    return { title: document.title, h2, h2Ok: JSON.stringify(h2) === JSON.stringify(spec.titles) && h2Visible,
      statusLike, statusTextElsewhere: statusTextElsewhere.slice(0, 5), statusOk, pStatusClass, execMode, execOk, failRowsOk, fiveLines, execLineCount, causeOneLine, causeLfToken, causeLineCount, execRowCount: execRows ? execRows.length : null, hostTextsOk,
      hostTextsMissing: hostTexts.filter(h => !(h.count === 1 && h.visible)), warnings, tags, extraTags, active, onAttrs,
      styles, styleOk, bodyStyleAttrs, hiddenAttrs, comments, markNodes: [...new Set(markNodes)], markCount: markNodes.length,
      markInAttr, markParentsOk, payloadVisible, tokensVisible, rawHidden: [...new Set(rawHidden)], captions, captionsWithMark,
      pwned: window.__pwned === undefined ? null : window.__pwned };
  }, spec);
  r.dialogs = dialogs; r.pageErrors = consoleErrors;
  out.push({ variant: spec.variant, bundle: spec.bundle, renderer: spec.renderer, file: spec.file, status: spec.status, ...r });
  await page.close();
}
await browser.close();
fs.writeFileSync(outFile, JSON.stringify({ chrome: version, playwright_core: require('playwright-core/package.json').version,
  file_requests: fileRequests, external_requests: external, pages: out }, null, 0));
console.log('pages', out.length, 'external', external.length, 'chrome', version);
