// verify-D: render report.md with several independent Markdown implementations (local, no network).
// usage: node md_render.mjs <report.md> <outdir>
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire('__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/verify-D/node/');
const MarkdownIt = require('markdown-it');
const commonmark = require('commonmark');
const { marked } = require('marked');
const nm = '__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/verify-D/node/node_modules/';
const { micromark } = await import(nm + 'micromark/index.js');
const { gfm, gfmHtml } = await import(nm + 'micromark-extension-gfm/index.js');

const [src, outdir] = process.argv.slice(2);
const md = fs.readFileSync(src, 'utf8');   // exact bytes decoded; no newline translation
fs.mkdirSync(outdir, { recursive: true });
const wrap = (body, name) => `<!doctype html><html><head><meta charset="utf-8"><title>${name}</title></head><body>${body}</body></html>`;
const out = {
  'markdown-it-html': new MarkdownIt({ html: true }).render(md),
  'markdown-it-safe': new MarkdownIt({ html: false }).render(md),
  'markdown-it-linkify': new MarkdownIt({ html: true, linkify: true }).render(md),
  'commonmark-js': new commonmark.HtmlRenderer().render(new commonmark.Parser().parse(md)),
  'marked-gfm': marked.parse(md, { gfm: true }),
  'micromark-gfm': micromark(md, { allowDangerousHtml: true, extensions: [gfm()], htmlExtensions: [gfmHtml()] }),
};
for (const [k, v] of Object.entries(out)) fs.writeFileSync(path.join(outdir, k + '.html'), wrap(v, k));
console.log(Object.keys(out).join(' '));
