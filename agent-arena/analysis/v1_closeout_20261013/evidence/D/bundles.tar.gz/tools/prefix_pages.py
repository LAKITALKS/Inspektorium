"""Pre-fix contrast: render report.md of the 558e920 / fd1ad7c bundles and build minimal DOM specs (no product import).
usage: python3 -I prefix_pages.py <evidence-D scratch>"""
import html, json, re, subprocess, sys
from pathlib import Path
E = Path(sys.argv[1]); V = E.parent / "verify-D"
TITLES = ["Execution and release", "Original claim", "Scientific judgments", "Original label and taxonomy",
          "Propositions and inference limits", "Evidence and source quotations", "Search scope",
          "Finding and client traces", "UNKNOWN, conflicts and review history", "Mandatory controls",
          "Limitations", "Provenance"]
pages, split = [], []
for line in (E / "prefix/runs.jsonl").read_text().splitlines():
    r = json.loads(line); root = Path(r["run"]["path"]); dec = json.loads((root / "decision.json").read_text())
    ctrls = [c for c in dec["controls"] if c["control_id"] not in {"markdown_qa", "html_qa"}]
    rows = [[c["control_id"] + " / " + c["version"], f"Execution: {c['execution']}\nOutcome: {c['outcome']}\nEligible: "
             f"{c['eligible']}\nEvaluated: {c['evaluated']}\nReason: {c['reason']}"] for c in ctrls]
    page = (root / "report.html").read_text(encoding="utf-8")
    hc = re.findall(r"<tr><td>open cause</td><td>(.*?)</td></tr>", page, re.S)
    cause = html.unescape(hc[0]) if hc else ""
    rd = E / "prefix" / r["commit"] / "render" / r["variant"]; rd.mkdir(parents=True, exist_ok=True)
    subprocess.run(["node", str(E / "tools/md_render.mjs"), str(root / "report.md"), str(rd)], check=True, capture_output=True)
    subprocess.run([str(V / "pyenv/bin/python"), "-I", "-B", str(E / "tools/md_render_py.py"), str(root / "report.md"), str(rd)],
                   check=True, capture_output=True)
    spec = {"variant": r["variant"], "bundle": "prefix-" + r["commit"], "status": dec["status"], "titles": TITLES,
            "host_texts": [], "exec_rows": rows, "exec_outcomes": [c["outcome"] for c in ctrls], "failing": [],
            "failing_rows": [], "open_cause": cause, "cause_needs_lf_token": False, "limits": "", "display_note": "",
            "notice": "", "ended": "", "payload_visible": None,
            "mark": "PAYLOAD-" if r["variant"] != "clean" else None, "tokens": []}
    pages.append({**spec, "renderer": "canonical-html", "file": str(root / "report.html")})
    pages += [{**spec, "renderer": h.stem, "file": str(h)} for h in sorted(rd.glob("*.html"))]
    md = (root / "report.md").read_bytes().decode("utf-8")
    lines = re.split(r"\r\n|\r|\n", md)
    split.append({"commit": r["commit"], "variant": r["variant"], "status": dec["status"], "raw_CR_in_report_md": md.count("\r"),
                  "commonmark_lines_starting_h2": sum(l.startswith("## ") for l in lines),
                  "commonmark_status_lines": sum(l.endswith("— local artifact status") for l in lines),
                  "md_lines_starting_Outcome": sum(bool(re.match(r"(Outcome|Outcome&#58;) ", l)) for l in lines),
                  "md_open_cause_lines": sum(l.startswith("| open cause |") for l in lines),
                  "md_open_cause_has_br": any(l.startswith("| open cause |") and "<br>" in l for l in lines),
                  "md_exec_cells_br_counts": [l.count("<br>") for l in md.split("\n") if re.match(r"\| [a-z0-9_&#;]+ / [0-9.]+ \| Execution", l)],
                  "cli_stdout_ascii": r["stdout_ascii"]})
(E / "prefix/pages.json").write_text(json.dumps(pages, ensure_ascii=False))
(E / "prefix/md_line_split.json").write_text(json.dumps(split, ensure_ascii=True, indent=1))
for s in split: print(json.dumps(s))
