"""verify-D: GitHub's cmark-gfm (cmarkgfm bindings) and markdown-it-py renders of report.md."""
import sys
from pathlib import Path
import cmarkgfm
from cmarkgfm.cmark import Options
from markdown_it import MarkdownIt
src, outdir = Path(sys.argv[1]), Path(sys.argv[2])
md = src.read_bytes().decode("utf-8")
outdir.mkdir(parents=True, exist_ok=True)
wrap = lambda b, n: f'<!doctype html><html><head><meta charset="utf-8"><title>{n}</title></head><body>{b}</body></html>'
outs = {
    "cmark-gfm-github": cmarkgfm.github_flavored_markdown_to_html(md, options=Options.CMARK_OPT_UNSAFE),
    "markdown-it-py": MarkdownIt("commonmark").enable("table").render(md),
}
for k, v in outs.items():
    (outdir / f"{k}.html").write_text(wrap(v, k), encoding="utf-8")
print(" ".join(outs))
