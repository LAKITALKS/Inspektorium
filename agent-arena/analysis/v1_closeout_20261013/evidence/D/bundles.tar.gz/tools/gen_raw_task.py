"""evidence-D: claim/context variants whose task.json carries RAW U+2028/U+2029/U+0085 (ensure_ascii=False).
SYNTHETIC TEST FIXTURE — not an empirical model response. The task loader reads task files with yaml.safe_load;
these variants document how a raw YAML line break in the task file is handled (expected: fail closed)."""
import json, shutil, sys
from pathlib import Path
IN, PAYLOADS = Path(sys.argv[1]), Path(sys.argv[2])
data = json.loads(PAYLOADS.read_text())
for field in ("claim", "context"):
    for cls in ("ls", "ps", "nel"):
        src, dst = IN / f"{field}--{cls}", IN / f"{field}--{cls}_rawtask"
        shutil.rmtree(dst, ignore_errors=True); dst.mkdir()
        task = json.loads((src / "task.json").read_text(encoding="utf-8"))
        (dst / "task.json").write_text(json.dumps(task, ensure_ascii=False, indent=2), encoding="utf-8")
        shutil.copy(src / "recording.json", dst / "recording.json")
        note = json.loads((src / "note.json").read_text(encoding="utf-8"))
        note.update({"class": f"{cls}_rawtask", "counterpart": f"{field}--plain",
                     "description": f"same as {field}--{cls} but task.json written with ensure_ascii=False (raw character)"})
        (dst / "note.json").write_text(json.dumps(note, ensure_ascii=False, indent=2), encoding="utf-8")
        data["variants"][dst.name] = note
PAYLOADS.write_text(json.dumps(data, ensure_ascii=True, indent=1))
print("raw-task variants added")
