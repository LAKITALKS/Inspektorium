"""Guarded canonical CLI: guard first, then agent_arena.cli.cli (same entry point as .venv/bin/agent-arena)."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import guard  # noqa: E402,F401  (must load before product code)
from agent_arena.cli import cli  # noqa: E402

if __name__ == "__main__":
    sys.argv[0] = "agent-arena"
    cli(standalone_mode=True)
