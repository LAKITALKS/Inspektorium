#!/bin/bash
# evidence-D (5560e95): build bundles.tar.gz (+ index with member SHA-256) from the scratch tree.
E=__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/evidence-D
D=__LOCAL_HOME__/Documents/Projects/agent-arena/analysis/v1_closeout_20261013/evidence/D
cd $E || exit 1
LIST=$E/work/tar_members.txt; : > $LIST
find in out xcheck probe_yaml -type f | sort >> $LIST
for v in clean reason--cr reason--html claim--cr spanfail--payload spanfail--lfpid spanfail--lfpid_mixed proposition_id--lfpid_mixed evidence_id--bidi transformation_id--control_like modelkey--derived_judgment modelkey--derived_judgment_flat uncertainty--zero_width context--ls; do
  find render/$v -type f | sort >> $LIST; done
find prefix/558e920/out prefix/558e920/render prefix/fd1ad7c/out prefix/fd1ad7c/render -type f | sort >> $LIST
ls prefix/*.json prefix/*.jsonl prefix/*.log >> $LIST
find tools -type f -not -path "*/__pycache__/*" | sort >> $LIST
for f in runs.jsonl static.json dom.json guard.jsonl commands.log payloads.json protected_before.json protected_after.json shots.json aggregate_stdout.json pytest_v1_render_injection.log pytest_v1.log guard_pytest_closeout_attempt.jsonl investigation_area_D_extract.txt investigation_verifyD_verdicts_prefix.txt; do echo work/$f >> $LIST; done
echo stage/dom_results.json >> $LIST; echo stage/release_independence.json >> $LIST
COPYFILE_DISABLE=1 tar --no-xattrs -czf $D/bundles.tar.gz -T $LIST
python3 -I - "$D/bundles.tar.gz" "$D/bundles_index.json" <<'PY'
import hashlib, json, sys, tarfile
src, dst = sys.argv[1], sys.argv[2]
members = []
with tarfile.open(src, "r:gz") as t:
    for m in t.getmembers():
        if m.isfile():
            members.append({"path": m.name, "size": m.size, "sha256": hashlib.sha256(t.extractfile(m).read()).hexdigest()})
data = open(src, "rb").read()
json.dump({"archive": "bundles.tar.gz", "archive_sha256": hashlib.sha256(data).hexdigest(), "archive_size": len(data),
           "candidate": "5560e95",
           "fixture": "SYNTHETIC TEST FIXTURE — not an empirical model response",
           "layout": {"in/<variant>/": "task.json, recording.json, note.json (synthetic inputs)",
                      "out/<variant>/run/<revision>/": "canonical bundle of `audit run --offline` (5 files)",
                      "out/<variant>/release/<revision>/": "bundle of `audit release` (READY variants only)",
                      "out/<variant>/{run,release}.{stdout,stderr}": "raw CLI output bytes (ASCII check)",
                      "xcheck/": "5 runs (+2 releases) via the real .venv/bin/agent-arena entry point",
                      "probe_yaml/": "raw U+0085/U+2028/U+2029 task-file probe (no '---' line)",
                      "render/<variant>/<run|release>/": "Markdown renders for 14 sample variants (all others regenerable with tools/md_render.mjs + tools/md_render_py.py)",
                      "prefix/<558e920|fd1ad7c>/": "pre-fix contrast: bundles, CLI stdout, renders; prefix/dom.json, md_line_split.json, runs.jsonl (code itself: git archive <commit> src)",
                      "tools/": "all scripts used", "work/": "runs, static checks, full DOM facts, guard log, commands, hashes, investigation extracts",
                      "stage/": "copies of dom_results.json and release_independence.json"},
           "member_count": len(members), "members": members}, open(dst, "w"), ensure_ascii=False, indent=0)
print(len(members), "members", len(data), "bytes")
PY
