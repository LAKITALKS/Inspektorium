#!/bin/bash
# evidence-D: run every variant through the canonical CLI (audit run --offline), then audit release for READY ones.
# stdout/stderr of every CLI call are kept as raw bytes (out/<v>/{run,release}.{stdout,stderr}) for the ASCII check.
E=__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/evidence-D
PY=__LOCAL_HOME__/Documents/Projects/agent-arena/.venv/bin/python
CLI() { (cd $E/work && env -u ANTHROPIC_API_KEY -u OPENAI_API_KEY PYTHONDONTWRITEBYTECODE=1 $PY -I -B $E/tools/cli.py "$@"); }
: > $E/work/runs.jsonl; : > $E/work/commands.log
for d in $E/in/*/; do
  n=$(basename $d); rm -rf $E/out/$n; mkdir -p $E/out/$n
  echo "agent-arena audit run --offline --task in/$n/task.json --recording in/$n/recording.json --output-root out/$n/run" >> $E/work/commands.log
  CLI audit run --offline --task $d/task.json --recording $d/recording.json --output-root $E/out/$n/run > $E/out/$n/run.stdout 2> $E/out/$n/run.stderr; rc=$?
  relrc=""
  st=$($PY -I -c 'import json,sys
try: print(json.load(open(sys.argv[1])).get("status",""))
except Exception: print("")' $E/out/$n/run.stdout)
  if [ "$st" = "READY_FOR_RELEASE" ]; then
    b=$($PY -I -c 'import json,sys; print(json.load(open(sys.argv[1]))["path"])' $E/out/$n/run.stdout)
    echo "agent-arena audit release --bundle out/$n/run/<revision> --output-root out/$n/release --reviewer evidence-D-synthetic --reason 'SYNTHETIC TEST FIXTURE release check'" >> $E/work/commands.log
    CLI audit release --bundle "$b" --output-root $E/out/$n/release --reviewer evidence-D-synthetic --reason "SYNTHETIC TEST FIXTURE release check" > $E/out/$n/release.stdout 2> $E/out/$n/release.stderr; relrc=$?
  fi
  $PY -I -c 'import json,sys,os
n,rc,relrc,o=sys.argv[1:5]
def p(f):
    if not os.path.exists(f): return None, None
    b=open(f,"rb").read()
    try: return json.loads(b), all(x < 128 for x in b)
    except Exception: return {"raw": b.decode("utf-8","replace")[-600:]}, all(x < 128 for x in b)
run, ra = p(o+"/run.stdout"); rel, la = p(o+"/release.stdout")
err = open(o+"/run.stderr","rb").read()
print(json.dumps({"variant": n, "rc": int(rc), "run": run, "run_stdout_ascii": ra, "run_stdout_bytes": os.path.getsize(o+"/run.stdout"),
 "run_stderr_bytes": len(err), "release_rc": int(relrc) if relrc else None, "release": rel, "release_stdout_ascii": la}, ensure_ascii=True))' "$n" "$rc" "$relrc" "$E/out/$n" >> $E/work/runs.jsonl
done
echo done $(wc -l < $E/work/runs.jsonl)
