"""Run repository regression tests with the evidence-D network guard loaded first (no cache, no bytecode)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import guard  # noqa: E402,F401
import pytest  # noqa: E402
sys.exit(pytest.main(["-p", "no:cacheprovider", "-q", "--rootdir", "__LOCAL_HOME__/Documents/Projects/agent-arena",
                      *sys.argv[1:]]))
