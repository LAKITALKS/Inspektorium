"""evidence-D (5560e95): static per-bundle checks + DOM expectations + Markdown renders.

For every bundle (audit run and, if READY, audit release) of every variant:
  * static checks over the actual files: no raw Cc/Cf/Zl/Zp characters (except LF/TAB) in report.md/report.html,
    a ⟦U+XXXX⟧ token in both reports for every hidden character of a displayed payload, record.json keeps the exact
    payload characters, decision.json status/controls, CLI stdout pure ASCII;
  * Executed controls: expected cells are computed INDEPENDENTLY from decision.json (own display transform, not the
    product's), each cell must be exactly five host lines Execution/Outcome/Eligible/Evaluated/Reason in report.md
    (4 <br>) and report.html (4 LF), with the real outcome; the open cause row is one line;
  * report.md rendered with 8 Markdown implementations (node: markdown-it html on/off/linkify, commonmark.js,
    marked gfm, micromark+gfm; python: GitHub cmark-gfm (cmarkgfm, UNSAFE), markdown-it-py).
usage: python -I -B prep.py   (guarded; imports product code read-only)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import guard  # noqa: E402,F401

import html as htmlmod  # noqa: E402
import json  # noqa: E402
import re  # noqa: E402
import subprocess  # noqa: E402
import unicodedata  # noqa: E402
from pathlib import Path  # noqa: E402

from agent_arena import phase10_render as render  # noqa: E402
from agent_arena.phase10_models import AuditRecord  # noqa: E402
from agent_arena.phase10_pipeline import digest, evaluate  # noqa: E402
from agent_arena.phase10_projection import DISPLAY_NOTE, LIMITS, TITLES, display_text, projection  # noqa: E402
from agent_arena.schemas import RunRecord  # noqa: E402

E = Path("__LOCAL_AGENT_SCRATCH__/-PUBLIC-HOME-Documents-Projects-agent-arena/"
         "cda624d0-c2aa-47a5-842e-e471afe176b7/scratchpad/v1/evidence-D")
V = E.parent / "verify-D"
HIDDEN = {"Cc", "Cf", "Zl", "Zp"}
payloads = json.loads((E / "work/payloads.json").read_text())
runs = [json.loads(line) for line in (E / "work/runs.jsonl").read_text().splitlines()]
ONLY = set(sys.argv[1:])  # optional variant filter


def tok(c):
    return f"⟦U+{ord(c):04X}⟧"


def my_display(s):  # independent re-implementation of the documented display rule
    return "".join(tok(c) if c in "⟦⟧" or (c not in "\n\t" and unicodedata.category(c) in HIDDEN) else c
                   for c in s)


def my_inline(s):
    return my_display(s).replace("\n", tok("\n")).replace("\t", tok("\t"))


def hidden_chars(text):
    return sorted({c for c in text if c not in "\n\t" and unicodedata.category(c) in HIDDEN})


def projected(root):
    audit = AuditRecord.model_validate_json((root / "record.json").read_bytes())
    _, controls, review, selected, assessment, forensic = evaluate(
        RunRecord.model_validate(audit.run_record), digest(audit.model_dump()), audit.provenance)
    return audit, projection(audit, controls, review, selected, assessment, forensic)


def strings(node):
    if isinstance(node, dict):
        for k, v in node.items():
            yield k
            yield from strings(v)
    elif isinstance(node, list):
        for v in node:
            yield from strings(v)
    elif isinstance(node, str):
        yield node


def mark_of(payload):
    m = re.search(r"PAYLOAD-[a-z_]+", payload)
    return m.group() if m else ("Reparsed raw" if "Reparsed raw" in payload else None)


PREFIX = ("Execution: ", "Outcome: ", "Eligible: ", "Evaluated: ", "Reason: ")
pages, static = [], {}
for run in sorted(runs, key=lambda r: r["variant"]):
    name = run["variant"]
    if ONLY and name not in ONLY:
        continue
    meta = payloads["variants"][name]
    payload = meta.get("payload") if meta["class"] not in {"plain", "clean"} else None
    if meta["class"] == "model_key":
        payload = None  # the key is checked structurally (host row label), not as free text
    if not (run["run"] or {}).get("path"):
        static[f"{name}/run"] = {"variant": name, "bundle": "none", "status": run["run"].get("status"),
                                 "no_bundle_written": True, "errors": run["run"].get("errors"),
                                 "cli_stdout_ascii": run["run_stdout_ascii"], "control_outcomes": None}
        continue
    bundles = [("run", run["run"]["path"], run["run_stdout_ascii"])]
    if run.get("release") and run["release"].get("path"):
        bundles.append(("release", run["release"]["path"], run["release_stdout_ascii"]))
    for kind, path, cli_ascii in bundles:
        root = Path(path)
        md = (root / "report.md").read_bytes().decode("utf-8")
        page = (root / "report.html").read_bytes().decode("utf-8")
        decision = json.loads((root / "decision.json").read_text())
        record = json.loads((root / "record.json").read_bytes())
        audit, proj = projected(root)
        status = decision.get("status") or audit.status
        texts = [b["text"] for _, s in proj for b in s["blocks"] if b["kind"] == "text"]
        table = next(b for _, s in proj for b in s["blocks"] if b["kind"] == "table" and b["caption"] == "Executed controls")
        dec_controls = [c for c in decision["controls"] if c["control_id"] not in {"markdown_qa", "html_qa"}]
        exp_rows = [[c["control_id"] + " / " + c["version"],
                     f"Execution: {my_display(c['execution'])}\nOutcome: {my_display(c['outcome'])}\n"
                     f"Eligible: {c['eligible']}\nEvaluated: {c['evaluated']}\nReason: " + my_inline(c["reason"])]
                    for c in dec_controls]
        failing = [c["control_id"] for c in decision["controls"] if c["outcome"] == "fail"]
        indep = next(b for _, s in proj for b in s["blocks"] if b["kind"] == "table" and b["caption"] == "Independent states")
        cause = next(r[1] for r in indep["rows"] if r[0] == "open cause")
        # --- report.md: Executed controls rows and open cause line, read from the file itself
        md_lines = md.split("\n")
        i = md_lines.index("### Executed controls")
        md_rows = []
        for line in md_lines[i + 4:]:
            if not line.startswith("| "):
                break
            cells = line[2:-2].split(" | ")
            md_rows.append([htmlmod.unescape(cells[0]), [htmlmod.unescape(x) for x in cells[1].split("<br>")]])
        md_five = len(md_rows) == len(dec_controls) and all(
            len(parts) == 5 and all(p.startswith(pre) for p, pre in zip(parts, PREFIX))
            and parts[1] == "Outcome: " + c["outcome"] and row == c["control_id"] + " / " + c["version"]
            for (row, parts), c in zip(md_rows, dec_controls))
        md_rows_equal = [[r, "\n".join(p)] for r, p in md_rows] == exp_rows
        cause_lines = [ln for ln in md_lines if ln.startswith("| open cause | ")]
        md_cause_one_line = len(cause_lines) == 1 and "<br>" not in cause_lines[0] and \
            htmlmod.unescape(cause_lines[0][len("| open cause | "):-2]) == cause
        # --- report.html: same, from the canonical page text
        m = re.search(r"<h3>Executed controls</h3><table>.*?<tbody>(.*?)</tbody>", page, re.S)
        html_rows = [[htmlmod.unescape(a), htmlmod.unescape(b)] for a, b in
                     re.findall(r"<tr><td>(.*?)</td><td>(.*?)</td></tr>", m.group(1), re.S)]
        html_five = len(html_rows) == len(dec_controls) and all(
            len(b.split("\n")) == 5 and all(p.startswith(pre) for p, pre in zip(b.split("\n"), PREFIX))
            and b.split("\n")[1] == "Outcome: " + c["outcome"] for (a, b), c in zip(html_rows, dec_controls))
        html_rows_equal = html_rows == exp_rows
        hc = re.findall(r"<tr><td>open cause</td><td>(.*?)</td></tr>", page, re.S)
        html_cause_one_line = len(hc) == 1 and "\n" not in hc[0] and htmlmod.unescape(hc[0]) == cause
        # record.json keeps the exact characters (raw output JSON strings, or task prompt/context).
        raw = json.loads(record["run_record"]["results"][0]["agent_result"]["raw_output"])
        task = record["run_record"]["task"]
        record_exact = displayed = None
        token_missing = []
        mark = mark_of(payload) if payload else None
        if payload:
            pool = list(strings(raw)) + [task.get("prompt", ""), task.get("context", "")]
            record_exact = any(payload in s for s in pool)
            displayed = (mark in md or render._md_inline(mark) in md) and mark in page
            if displayed:
                token_missing = [f"U+{ord(c):04X}" for c in hidden_chars(payload)
                                 if tok(c) not in md or tok(c) not in page]
        lf_payload = bool(payload) and meta["field"] == "proposition_id" and meta["class"].startswith("lfpid")
        # Host reasons may shorten quoted text (P9 reasons / _short at 200 chars): the first 150 payload characters,
        # which hold every line break of the lfpid payloads, must appear in inline (token) form.
        head = my_inline(payload[:150]) if lf_payload else None
        cause_quotes_payload_inline = (head in cause) if (lf_payload and failing) else None
        reasons_quote_payload_inline = ({c["control_id"]: (my_inline(payload) if c["control_id"] == "analysis_source"
                                                           else head) in r[1]
                                         for r, c in zip(exp_rows, dec_controls) if c["outcome"] == "fail"
                                         and c["control_id"] != "finding_artifact_binding"}
                                        if (lf_payload and failing) else None)
        modelkey = None
        if meta["class"] == "model_key":
            labels = [htmlmod.unescape(ln[2:].split(" | ")[0]) for ln in md_lines if ln.startswith("| ")]
            keys = ([k for k in ("derived judgment / host state", "derived judgment / model host conflict",
                                 "derived judgment / derived state", "from and to text (identical) / x")]
                    if name.endswith("_flat") else
                    ["derived judgment / derived state", "derived judgment / host reasons", "derived judgment / host state",
                     "derived judgment / model host conflict", "from and to text (identical)"]
                    if name == "modelkey--derived_judgment" else ["plain extra key"])
            modelkey = {"expected_model_labels": keys,
                        "shown_with_model_supplied_prefix": {k: ("model-supplied " + k) in labels for k in keys},
                        "unprefixed_model_rows_in_proposition_1": [k for k in keys if k in labels[
                            labels.index("derived judgment"):labels.index("derived judgment") + 20]
                            and not k.startswith("from")] if "derived judgment" in labels else None,
                        "host_row_derived_judgment_present": "derived judgment" in labels}
        st = {
            "variant": name, "bundle": kind, "path": str(root), "status": status,
            "decision_status_equals_record": decision.get("status") == audit.status,
            "cli_stdout_ascii": cli_ascii,
            "raw_hidden_in_report_md": [f"U+{ord(c):04X}" for c in hidden_chars(md)],
            "raw_hidden_in_report_html": [f"U+{ord(c):04X}" for c in hidden_chars(page)],
            "payload_hidden_chars": [f"U+{ord(c):04X}" for c in hidden_chars(payload or "")],
            "payload_displayed": displayed, "tokens_missing": token_missing, "record_keeps_exact_payload": record_exact,
            "projection_rows_equal_independent": table["rows"] == exp_rows,
            "md_exec_rows_equal_independent": md_rows_equal, "md_exec_cells_five_host_lines": md_five,
            "html_exec_rows_equal_independent": html_rows_equal, "html_exec_cells_five_host_lines": html_five,
            "md_open_cause_one_line": md_cause_one_line, "html_open_cause_one_line": html_cause_one_line,
            "cause_quotes_payload_inline": cause_quotes_payload_inline,
            "failing_reasons_quote_payload_inline": reasons_quote_payload_inline,
            "projection_texts_without_payload_mark": not any(("PAYLOAD-" in t) or (mark and mark in t) for t in texts),
            "product_display_text_equals_independent": (display_text(payload) == my_display(payload)) if payload else None,
            "model_key": modelkey,
            "failing_controls": failing, "open_cause": cause,
            "control_outcomes": [[c["control_id"], c["outcome"]] for c in decision["controls"]],
            "validate_files": bool(render.validate_files(root, proj)),
        }
        static[f"{name}/{kind}"] = st
        expect = {"variant": name, "bundle": kind, "status": status, "titles": list(TITLES),
                  "host_texts": texts, "exec_rows": exp_rows,
                  "exec_outcomes": [c["outcome"] for c in dec_controls], "failing": failing,
                  "failing_rows": [r for r, c in zip(exp_rows, dec_controls) if c["outcome"] == "fail"],
                  "open_cause": cause, "cause_needs_lf_token": bool(lf_payload and failing),
                  "limits": LIMITS, "display_note": DISPLAY_NOTE,
                  "notice": texts[2], "ended": texts[1],
                  "payload_visible": my_display(payload) if (payload and displayed) else None,
                  "mark": mark, "tokens": [tok(c) for c in hidden_chars(payload)] if (payload and displayed) else []}
        rd = E / "render" / name / kind
        rd.mkdir(parents=True, exist_ok=True)
        subprocess.run(["node", str(E / "tools/md_render.mjs"), str(root / "report.md"), str(rd)], check=True,
                       capture_output=True, cwd=str(V / "node"))
        subprocess.run([str(V / "pyenv/bin/python"), "-I", "-B", str(E / "tools/md_render_py.py"),
                        str(root / "report.md"), str(rd)], check=True, capture_output=True, cwd=str(E / "work"))
        pages.append({**expect, "renderer": "canonical-html", "file": str(root / "report.html")})
        for html_file in sorted(rd.glob("*.html")):
            pages.append({**expect, "renderer": html_file.stem, "file": str(html_file)})

suffix = "_sub" if ONLY else ""
(E / f"work/static{suffix}.json").write_text(json.dumps(static, ensure_ascii=True, indent=1))
(E / f"work/pages{suffix}.json").write_text(json.dumps(pages, ensure_ascii=False))
print("bundles", len(static), "pages", len(pages))
