# Canonical local audit

## Execution and release

ANALYSIS&#95;INCOMPLETE — local artifact status

Automatic processing has ended. The result is not conclusively resolved and is not scientifically released. No human reviewer or review queue is assumed. This revision is immutable&#58; only a recorded human decision (agent-arena audit review) or a new, explicitly commissioned run creates a new revision.

RECORDED OFFLINE / SYNTHETIC. Local artifact decision only; no live model execution, scientific truth, empirical validation, external evidence search or customer approval.

### Independent states

| Field | Recorded value |
| --- | --- |
| analysis execution | incomplete |
| automatic processing | ended |
| host evidence derivation (composite) | Not supplied |
| local release | ANALYSIS&#95;INCOMPLETE |
| mandatory review | true |
| model judgment (composite) | Not supplied |
| model/host conflicts | not evaluated (analysis technically incomplete) |
| open cause | technically incomplete analysis; no conflict review was run&#58; invalid ledger&#58; 4 validation errors for PropositionLedger⟦U+000A⟧propositions.0.derived judgment / host state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger⟦U+000A⟧propositions.0.derived judgment / host state⟦U+000A⟧  Extra inputs are not  |
| review execution | not&#95;executed |
| review route | HUMAN&#95;REVIEW&#95;REQUIRED |
| scientific judgment | unknown |

No host release intent&#58; this is a candidate, not a released artifact.

### Revision identity

| Field | Recorded value |
| --- | --- |
| created at | 2026-10-13T08&#58;21&#58;15.836920+00&#58;00 |
| parent | Not supplied |
| record fingerprint | 255c3cb7e14e0997cb07f1be5b695d05ab9da57488373950f7c7a9ebb8dddbba |
| revision | a7d74bb7-54d6-46cc-aafa-31105c809667 |
| selected position id | p9position&#58;c2c1107f2190434c12bec2ae |

## Original claim

Verbatim quoted input; foreign text is not a trusted status message.

```
intervention X reduces event Q in adults.
```

## Scientific judgments

### Selected scientific assessment

| Field | Recorded value |
| --- | --- |
| assessed composite state | unknown |
| assurance scope | Validates represented structure and semantic constraints; does not prove complete or correct model extraction, scientific truth or efficacy. |
| composite state | unknown |
| contract version | AA-P8/1.3 |
| derived label | Not supplied |
| host composite state | Not supplied |
| host derived copies | No entries recorded |
| host rule version | AA-P8-HOST/1.1 |
| input sha256 | d405ae6768246618b95a4d04eedcd9b6222fd78b607a902ace3a2e9ef0bebc71 |
| limitations | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |
| model composite state | Not supplied |
| model host conflicts | No entries recorded |
| original model label | solid |
| raw response sha256 | 652baffd337ab7569fb8b5ea1fae767e86ae7767c208eb17755d68609be7df5f |
| reasons | invalid ledger&#58; 4 validation errors for PropositionLedger<br>propositions.0.derived judgment / host state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived judgment / model host conflict<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived&#95;judgment / derived state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>transformations.0.from and to text (identical) / x<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger<br>propositions.0.derived judgment / host state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived judgment / model host conflict<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived&#95;judgment / derived state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>transformations.0.from and to text (identical) / x<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| record fingerprint | 01f3d1dd005ad5aea3b439f2cea918a4981bb7aaf081bddf32d5afafa0ef8ea7 |
| technical status | incomplete |
| transformation findings | No entries recorded |

In &#x27;reasons&#x27;, model-supplied text (the proposition reason, uncertainty and binding reasons) is combined with host sentences; only &#x27;host reasons&#x27; is host-written.

### Proposition judgments

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

## Original label and taxonomy

### Original versus derived classification

| Field | Recorded value |
| --- | --- |
| derived taxonomy | Not supplied |
| original model label | solid |
| represented trigger analysis / causal claim | true |
| represented trigger analysis / core error | none |
| represented trigger analysis / described biological mechanism | false |
| represented trigger analysis / evidence ids | e1 |
| represented trigger analysis / implies human benefit | true |
| represented trigger analysis / noncausal result used | false |
| represented trigger analysis / proposition ids | claim&#58;p1 |
| represented trigger analysis / reason | Generic represented core-error analysis |
| represented trigger analysis / trigger evidence id | e1 |
| represented trigger analysis / trigger proposition id | claim&#58;p1 |
| represented trigger analysis / trigger quote | A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks. |
| taxonomy check / assurance scope | Taxonomy decisions check represented trigger, core-error and evidence/proposition consistency. Quote containment does not prove entailment or correct model interpretation. |
| taxonomy check / derived label | Not supplied |
| taxonomy check / reasons | Semantic analysis did not complete; no taxonomy correction |
| taxonomy check / technical status | incomplete |

## Propositions and inference limits

### Claim composition

| Field | Recorded value |
| --- | --- |
| claim id | claim |
| extraction provenance | offline extraction from supplied prompt and context |
| logic / operator | leaf |
| logic / proposition id | claim&#58;p1 |
| provenance id | origin |
| required proposition ids | claim&#58;p1 |

### Proposition 1

| Field | Recorded value |
| --- | --- |
| derived judgment | Not supplied |
| material dimensions | species<br>population<br>intervention<br>comparator<br>endpoint<br>endpoint&#95;type<br>relation<br>follow&#95;up<br>certainty<br>comparison |
| materiality | required |
| model-supplied derived judgment / host state | supported |
| model-supplied derived judgment / model host conflict | false |
| model-supplied derived judgment / derived state | supported |
| parent claim id | claim |
| proposition id | claim&#58;p1 |
| provenance id | origin |
| reason | Source reports the stated comparison |
| reported verdict | supported |
| search question | What evidence supports&#58; intervention X reduces event Q in adults. |
| search scope ids | review |

Quoted proposition; this is represented input, not a release assertion.

```
intervention X reduces event Q in adults.
```

### Original span

| Field | Recorded value |
| --- | --- |
| end | 41 |
| start | 0 |
| text | intervention X reduces event Q in adults. |

### Population, endpoint, product and inference attributes

| Field | Recorded value |
| --- | --- |
| certainty | asserted |
| comparator | placebo |
| comparison | between |
| endpoint | event Q |
| endpoint type | clinical&#95;event |
| follow up | 12 weeks |
| intervention | intervention X |
| population | adults |
| relation | causal |
| species | human |

### Evidence bindings and directness

| Field | Recorded value |
| --- | --- |
|  / 1 / binding id | b1 |
|  / 1 / directness | direct |
|  / 1 / evidence id | e1 |
|  / 1 / observation | support |
|  / 1 / proposition id | claim&#58;p1 |
|  / 1 / reason | Matching trial |

### Bridges

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Product Transfers

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

### Transformation 1

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| model-supplied from and to text (identical) / x | forged |
| reason | Meaning retained |
| stage | extraction |
| target id | claim&#58;p1 |
| transformation id | extraction |

### Transformation 2

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from proposition ids | claim&#58;p1 |
| from text | intervention X reduces event Q in adults. |
| reason | Meaning retained |
| stage | search&#95;question |
| target id | claim&#58;p1 |
| to text | What evidence supports&#58; intervention X reduces event Q in adults. |
| transformation id | search&#95;question |

### Transformation 3

| Field | Recorded value |
| --- | --- |
| asserted state | Not supplied |
| asserts whole claim | false |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | internal |
| target id | claim&#58;p1 |
| transformation id | internal |

### Transformation 4

| Field | Recorded value |
| --- | --- |
| asserted state | supported |
| asserts whole claim | true |
| from and to attributes (identical) / certainty | asserted |
| from and to attributes (identical) / comparator | placebo |
| from and to attributes (identical) / comparison | between |
| from and to attributes (identical) / endpoint | event Q |
| from and to attributes (identical) / endpoint type | clinical&#95;event |
| from and to attributes (identical) / follow up | 12 weeks |
| from and to attributes (identical) / intervention | intervention X |
| from and to attributes (identical) / population | adults |
| from and to attributes (identical) / relation | causal |
| from and to attributes (identical) / species | human |
| from and to text (identical) | intervention X reduces event Q in adults. |
| from proposition ids | claim&#58;p1 |
| reason | Meaning retained |
| stage | summary |
| target id | client1 |
| transformation id | summary |

## Evidence and source quotations

Quotations are supplied source text. Evidence type, direction and semantic attributes are represented extraction; the checks do not authenticate study findings.

### Evidence item 1

| Field | Recorded value |
| --- | --- |
| derivation method | Not supplied |
| derivation note | Not supplied |
| endpoint | event Q |
| evidence id | e1 |
| input evidence ids | No entries recorded |
| material | true |
| reported value | Not supplied |
| role | supporting |
| source id | context |
| value origin | source&#95;reported |

Evidence text and exact source reference (identical)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

### Source type, capability and dependence

| Field | Recorded value |
| --- | --- |
| attributes / certainty | asserted |
| attributes / comparator | placebo |
| attributes / comparison | between |
| attributes / endpoint | event Q |
| attributes / endpoint type | clinical&#95;event |
| attributes / follow up | 12 weeks |
| attributes / intervention | intervention X |
| attributes / population | adults |
| attributes / relation | causal |
| attributes / species | human |
| evidence id | e1 |
| evidence type | controlled&#95;intervention |
| randomized | true |
| source role | primary&#95;study |
| study id | synthetic-study-1 |

## Search scope

External search executed&#58; false. Scope is limited to the captured supplied material; no evidence found does not mean no evidence exists.

### Declared search scopes

| Field | Recorded value |
| --- | --- |
|  / 1 / date cutoff | Not supplied |
|  / 1 / query terms | No entries recorded |
|  / 1 / resources | No entries recorded |
|  / 1 / reviewed source ids | input<br>context |
|  / 1 / scope type | reviewed&#95;set |
|  / 1 / search completeness | Not supplied |
|  / 1 / search scope id | review |

### Bound negative assertions

| Field | Recorded value |
| --- | --- |
| Value | No entries recorded |

Captured context (source&#95;id&#58; context)&#58;

```
A randomized comparison in adults (human) found that intervention X reduced event Q versus placebo at 12 weeks.
```

## Finding and client traces

### Provenance

| Field | Recorded value |
| --- | --- |
|  / 1 / canonical url | Not supplied |
|  / 1 / content fingerprint | Not supplied |
|  / 1 / context after | Not supplied |
|  / 1 / context before | Not supplied |
|  / 1 / exact claim text | intervention X reduces event Q in adults. |
|  / 1 / page title | Not supplied |
|  / 1 / provenance id | origin |
|  / 1 / provenance state | archived&#95;snapshot |
|  / 1 / retrieved at | Not supplied |
|  / 1 / source id | input |

### Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / allowed summary strength | not&#95;assessed |
|  / 1 / confidence status |  |
|  / 1 / contrary evidence ids | No entries recorded |
|  / 1 / finding id | claim&#58;p1 |
|  / 1 / predicted label | Not supplied |
|  / 1 / proposition | intervention X reduces event Q in adults. |
|  / 1 / provenance id | origin |
|  / 1 / supporting evidence ids | e1 |
|  / 1 / verdict summary |  |

### Client Findings

| Field | Recorded value |
| --- | --- |
|  / 1 / client explanation |  |
|  / 1 / client finding id | client1 |
|  / 1 / client negative assertions | No entries recorded |
|  / 1 / client strength | not&#95;assessed |
|  / 1 / display claim | intervention X reduces event Q in adults. |
|  / 1 / parent finding id | claim&#58;p1 |
|  / 1 / provenance id | origin |
|  / 1 / referenced evidence ids | e1 |
|  / 1 / value claims | No entries recorded |

## UNKNOWN, conflicts and review history

### Current review state

| Field | Recorded value |
| --- | --- |
| assurance scope | Checks represented positions, identity, materiality and routing. No majority vote, scientific truth, reviewer independence or release authorization is inferred. |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| contract version | AA-P9/1.3 |
| execution status | not&#95;executed |
| mandatory | true |
| reasons | Routing preserves separate scientific/taxonomy layers; no majority or provider call executed |
| review state | pending |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| technical status | incomplete |
| uncertainty | No entries recorded |

### Current revalidated assessment

| Field | Recorded value |
| --- | --- |
| assessment fingerprint | 2edd280a5d2381ee3e0cf641620cd5a32ef0f78dfc9db1ff120a10d06840d32e |
| history validation | Not supplied |
| interpretation | Current revalidated state |
| route | HUMAN&#95;REVIEW&#95;REQUIRED |
| source reference | record.json&#35;/run&#95;record |
| technical status | incomplete |

### Position p9position&#58;c2c1107f2190434c12bec2ae

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| complete analysis reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0 |
| derived taxonomy | Not supplied |
| model | offline-recording-no-live-model |
| origin | original |
| original model label | solid |
| position id | p9position&#58;c2c1107f2190434c12bec2ae |
| provider | offline-recording-no-live-model |
| raw response reference | record.json&#35;/run&#95;record/metadata/phase9/positions/0/agent&#95;result/raw&#95;output |
| raw sha256 | 652baffd337ab7569fb8b5ea1fae767e86ae7767c208eb17755d68609be7df5f |
| run id | b9d23951-263b-49ea-aabe-82b3e0fb3cd8 |
| scientific state | unknown |
| selected | true |
| taxonomy status | incomplete |
| technical status | incomplete |

### Captured execution

| Field | Recorded value |
| --- | --- |
| error | Not supplied |
| error type | Not supplied |
| finish reason | Not supplied |
| parse ok | true |
| usage | Not supplied |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | critical&#95;source&#95;binding |
| evidence ids | No entries recorded |
| field | phase8.phase7&#95;controls.finding&#95;artifact&#95;binding |
| mandatory | true |
| material | true |
| position ids | p9position&#58;c2c1107f2190434c12bec2ae |
| projected object fingerprint | 6ab44bfb8b249d14173bea6a05f608cb38cc5fd7d71d783a0066815a16b5b798 |
| proposition ids | No entries recorded |
| reason | Phase-8 output binding incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger<br>propositions.0.derived judgment / host state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived judgment / model host conflict<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived&#95;judgment / derived state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>transformations.0.from and to text (identical) / x<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/0 |
| trigger id | p9trigger&#58;80355d39d2549235a5eee983 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | No entries recorded |
| field | phase8.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;c2c1107f2190434c12bec2ae |
| projected object fingerprint | 7c36d0d6102bcebc2c681a2e50c26f05a8a2f2612b79d745a4ef4e45be73989f |
| proposition ids | No entries recorded |
| reason | invalid ledger&#58; 4 validation errors for PropositionLedger<br>propositions.0.derived judgment / host state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived judgment / model host conflict<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived&#95;judgment / derived state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>transformations.0.from and to text (identical) / x<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger<br>propositions.0.derived judgment / host state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived judgment / model host conflict<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived&#95;judgment / derived state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>transformations.0.from and to text (identical) / x<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/1 |
| trigger id | p9trigger&#58;942c95a436632f68e3d28e20 |

### Trigger

| Field | Recorded value |
| --- | --- |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| claim id | claim |
| code | failed&#95;mandatory&#95;control |
| evidence ids | e1 |
| field | phase8.taxonomy.technical&#95;status |
| mandatory | true |
| material | true |
| position ids | p9position&#58;c2c1107f2190434c12bec2ae |
| projected object fingerprint | 163620b0ff875447220fcc76b72b291a0d6dec971a6d04830bee9bb97594cdf7 |
| proposition ids | claim&#58;p1 |
| reason | Semantic analysis did not complete; no taxonomy correction |
| source reference | record.json&#35;/run&#95;record/metadata/phase9/triggers/2 |
| trigger id | p9trigger&#58;f5a9ec1a6da53d473c388816 |

Conflicts were not evaluated&#58; the selected analysis is technically incomplete.

No adjudication is recorded; absence is not human approval.

## Mandatory controls

### Executed controls

| Control and version | Execution, population and result |
| --- | --- |
| input&#95;preflight / 1.1 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Input and nonempty execution population checked |
| analysis&#95;source / 1.1 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Analysis incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger⟦U+000A⟧propositions.0.derived judgment / host state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧propositions.0.derived judgment / model host conflict⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧propositions.0.derived&#95;judgment / derived state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧transformations.0.from and to text (identical) / x⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger⟦U+000A⟧propositions.0.derived judgment / host state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧propositions.0.derived judgment / model host conflict⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧propositions.0.derived&#95;judgment / derived state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧transformations.0.from and to text (identical) / x⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| finding&#95;artifact&#95;binding / 1.1.0 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| summary&#95;strength&#95;monotonicity / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;findings |
| evidence&#95;symmetry / 1.1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;finding&#95;material&#95;evidence&#95;contexts |
| value&#95;origin&#95;provenance / 1.0.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Evaluated client&#95;visible&#95;evidence&#95;references |
| search&#95;scope&#95;binding / 1.0.0 | Execution&#58; executed<br>Outcome&#58; not&#95;applicable<br>Eligible&#58; 0<br>Evaluated&#58; 0<br>Reason&#58; Host-derived N/A&#58; no client&#95;negative&#95;assertions; check executed successfully |
| phase8&#95;semantics&#95;taxonomy / 1.3 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Semantic or taxonomy analysis incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger⟦U+000A⟧propositions.0.derived judgment / host state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧propositions.0.derived judgment / model host conflict⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧propositions.0.derived&#95;judgment / derived state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden⟦U+000A⟧transformations.0.from and to text (identical) / x⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;⟦U+000A⟧    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
| phase9&#95;history&#95;review / 1.3 | Execution&#58; executed<br>Outcome&#58; fail<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Review open&#58; technically incomplete analysis; no conflict review was run&#58; invalid ledger&#58; 4 validation errors for PropositionLedger⟦U+000A⟧propositions.0.derived judgment / host state⟦U+000A⟧  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;⟦U+000A⟧; Phase 7 artifact&#95;source&#95;binding&#95;drift&#58; Phase-8 output binding incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger⟦U+000A⟧propositions.0.derived judgment / host state⟦U+000A⟧  Extra inputs are not  |
| provenance / 1.0 | Execution&#58; executed<br>Outcome&#58; pass<br>Eligible&#58; 1<br>Evaluated&#58; 1<br>Reason&#58; Current code bytes, task/raw/history/selected evidence and offline configuration bound |

### Findings&#58; finding&#95;artifact&#95;binding

| Field | Recorded value |
| --- | --- |
|  / 1 / check | P8 |
|  / 1 / client finding id |  |
|  / 1 / code | artifact&#95;source&#95;binding&#95;drift |
|  / 1 / detail | Phase-8 output binding incomplete&#58; invalid ledger&#58; 4 validation errors for PropositionLedger<br>propositions.0.derived judgment / host state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived judgment / model host conflict<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=False, input&#95;type=bool&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>propositions.0.derived&#95;judgment / derived state<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;supported&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden<br>transformations.0.from and to text (identical) / x<br>  Extra inputs are not permitted &#91;type=extra&#95;forbidden, input&#95;value=&#x27;forged&#x27;, input&#95;type=str&#93;<br>    For further information visit https&#58;//errors.pydantic.dev/2.13/v/extra&#95;forbidden |
|  / 1 / refs | No entries recorded |
|  / 1 / severity | critical |

Final Markdown and HTML file checks read these actual files before promotion. Their results and exact hashes are bound in decision.json; this report does not self-certify its bytes.

### Post-render control references

| Control | Result reference | Population |
| --- | --- | --- |
| markdown&#95;qa | decision.json&#35;/controls | Actual rendered bytes |
| html&#95;qa | decision.json&#35;/controls | Actual rendered bytes |

## Limitations

Checks validate represented semantics and supplied source spans. Extraction correctness, exhaustiveness and scientific truth remain outside this assurance. Canonical PDF is unsupported.

Control, bidirectional and invisible format characters in displayed text are shown as ⟦U+XXXX⟧, and the brackets themselves as ⟦U+27E6⟧ and ⟦U+27E7⟧; record.json keeps the exact characters.

Not supplied and No entries recorded describe missing fields, not proof of absence or not-applicability. Confidence cannot override missing mandatory evidence.

### Assessment limitations

| Field | Recorded value |
| --- | --- |
| Value | Checks validate represented semantics and source spans; they do not prove correct model extraction, exhaustive evidence search, scientific truth or live-model accuracy. |

## Provenance

### Material provenance

| Field | Recorded value |
| --- | --- |
| analysis fingerprint | 0cc102f42f8fccd0f17659194e4d65ce6b981463570d837eb82311cb1bfe52d2 |
| case id | p9case&#58;a3e263e711168f8d4efc14a5 |
| code / code fingerprint | 03984bd436b852be4953aa77ed0a65b2f16bb1e4bc8e0a2432926bc080b221e1 |
| code / complete module hash index | manifest.json&#35;/provenance/code/module&#95;hashes |
| code / module count | 74 |
| code / source binding | verified Git source bytes |
| code / verified source commit | 5560e950af20cee8c35fb2c8e2bfb38807043fab |
| config | offline-recording-v1 |
| contract | AA-P10/1.0 |
| evidence fingerprint | cea4af84c8fff4b5d9a8b2b09054e1cfe5ed96a978fae1752f5027d2f1dfea08 |
| input fingerprint | 3ed6c37cef5b16e6a8cd1e2a61f4133a4bc14a2777c9492cd85cbfa124b206d8 |
| ledger fingerprint | 9a42bd4c9772fac1d397bdba514087b720904410f6b5486bd30af7bc274d1353 |
| package version | 1.0.0 |
| phase8 summary / composite state | unknown |
| phase8 summary / derived label | Not supplied |
| phase8 summary / original model label | solid |
| phase8 summary / taxonomy status | incomplete |
| phase8 summary / technical status | incomplete |
| phase9 summary / execution status | not&#95;executed |
| phase9 summary / final position id | Not supplied |
| phase9 summary / history validation | Not supplied |
| phase9 summary / mandatory | true |
| phase9 summary / review state | pending |
| phase9 summary / route | HUMAN&#95;REVIEW&#95;REQUIRED |
| phase9 summary / technical status | incomplete |
| providers / 1 / model | offline-recording-no-live-model |
| providers / 1 / provider | offline-recording-no-live-model |
| providers / 1 / usage | Not supplied |
| recording notice | RECORDED OFFLINE / SYNTHETIC; no live model execution |
| review counts / adjudications | 0 |
| review counts / attempts | 0 |
| review counts / conflicts | 0 |
| review counts / positions | 1 |
| review fingerprint | 2edd280a5d2381ee3e0cf641620cd5a32ef0f78dfc9db1ff120a10d06840d32e |
| run id | b9d23951-263b-49ea-aabe-82b3e0fb3cd8 |
| selected position id | p9position&#58;c2c1107f2190434c12bec2ae |

Complete original responses, all review carriers and machine bindings&#58; record.json. Final control decision&#58; decision.json. File hashes and full source index&#58; manifest.json. Hashes verify integrity, not actor identity or authentication.

